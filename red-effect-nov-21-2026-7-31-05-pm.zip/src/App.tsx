import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  PanelLeftClose,
  PanelLeftOpen,
  PanelRightClose,
  PanelRightOpen,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  ClipGroup,
  ColorGrade,
  FloatingPanelWindow,
  Keyframe,
  KeyframeProperty,
  MarkerColor,
  MediaAsset,
  Model3DBlueprint,
  NewProjectConfig,
  PanelId,
  PreviewQuality,
  ProxyQuality,
  SavedWorkspacePreset,
  SlotConfig,
  StudioProject,
  StudioSettings,
  TextProperties,
  TimelineClip,
  TimelineMarker,
  TimelineTrack,
  WorkspaceLayoutPresetId,
  WorkspaceLayoutSnapshot,
  WorkspaceMode,
} from './types/studio';
import {
  EffectInstance,
  ReadyMadeEffectPreset,
  ShapeKind,
  ShapeProperties,
  StudioPreset,
  TransitionSettings,
} from './types/effects';
import { Studio4DTransferPayload } from './types/studio4d';
import {
  createClipDefaults,
  createCustomProject,
  createDefaultChromaKey,
  createDefaultColorGrade,
  createDefaultEffects,
  createDefaultTransform,
  createStarterProject,
  DEFAULT_SETTINGS,
  deleteProjectFromDB,
  exportProjectFileToDisk,
  loadAllProjectsFromDB,
  loadSettingsFromDB,
  normalizeProject,
  openProjectFileFromDisk,
  saveBlobWithWindowsDialog,
  saveProjectToDB,
  saveSettingsToDB,
} from './services/projectStorage';
import {
  BUILT_IN_PRESETS,
  createEffectInstance,
  getDefaultTransitionSettings,
} from './services/effectsCatalog';
import {
  deleteCustomReadyPreset,
  findReadyMadePreset,
  loadCustomReadyPresets,
  saveCustomReadyPreset,
} from './services/readyMadeEffects';
import { reparentClipPreserveWorld, wouldCreateParentCycle } from './services/videoCompositor';
import { detectHardwareProfile, textBitmapCache } from './services/performanceEngine';
import { StudioAudioEngine, generateAudioWaveform } from './services/audioEngine';
import { createDefaultShowcase3DBlueprint } from './services/threeModelBuilder';
import { getProjectEndTime, exportProjectMedia } from './services/exportEngine';
import {
  buildAndPrepareTutorialProject,
  FIRST_LAUNCH_DONE_KEY,
  TUTORIAL_PROGRESS_KEY,
  TUTORIAL_PROJECT_ID,
  TutorialStep,
} from './services/tutorialData';
import {
  buildRedRebellionProject,
  createDefaultRedRebellionCustomization,
  deleteCustomTemplate,
  loadSavedCustomTemplates,
  SavedCustomTemplate,
  saveCustomTemplate,
  TrailerTemplateCustomization,
} from './services/trailerTemplate';
import { TopStudioBar, StudioMenuAction } from './components/TopStudioBar';
import { HomeScreen } from './components/HomeScreen';
import { NewProjectModal } from './components/NewProjectModal';
import { HelpModal } from './components/HelpModal';
import { PanelShell } from './components/PanelShell';
import { ProjectExplorerPanel } from './components/ProjectExplorerPanel';
import { MediaExplorerPanel } from './components/MediaExplorerPanel';
import { AssetBrowserPanel, AssetBrowserTabId } from './components/AssetBrowserPanel';
import { PreviewMonitorPanel } from './components/PreviewMonitorPanel';
import { TimelineEditorPanel } from './components/TimelineEditorPanel';
import {
  clearHoverPreviewCache,
} from './services/hoverPreviewCache';
import { EffectsPanel } from './components/EffectsPanel';
import { ReadyMadeEffectsPanel } from './components/ReadyMadeEffectsPanel';
import { TransitionsPanel } from './components/TransitionsPanel';
import { TextStudioPanel } from './components/TextStudioPanel';
import { ShapesMaskPanel } from './components/ShapesMaskPanel';
import { PresetLibraryPanel } from './components/PresetLibraryPanel';
import { InspectorTab, PropertiesPanel } from './components/PropertiesPanel';
import { LayersPanel } from './components/LayersPanel';
import { KeyframeGraphPanel } from './components/KeyframeGraphPanel';
import { NullHierarchyPanel } from './components/NullHierarchyPanel';
import { AudioMixerPanel } from './components/AudioMixerPanel';
import { Studio3DPanel } from './components/Studio3DPanel';
import { Studio4DPanel } from './components/Studio4DPanel';
import { ExportModal } from './components/ExportModal';
import { SettingsModal, SettingsModalTab } from './components/SettingsModal';
import { applyUiThemeToDocument } from './services/uiThemeEngine';
import { QualityEnhancerModal } from './components/QualityEnhancerModal';
import { InteractiveTutorialOverlay } from './components/InteractiveTutorialOverlay';
import { CustomizeTemplateModal } from './components/CustomizeTemplateModal';

const DEFAULT_SLOTS: SlotConfig = {
  leftTop: 'templates',
  leftBottom: 'effects',
  center: 'monitor',
  right: 'properties',
  bottom: 'timeline',
};

const WORKSPACE_LAYOUT_STORAGE_KEY = 'redeffect_workspace_layouts_v4';
const CUSTOM_PRESETS_STORAGE_KEY = 'redeffect_custom_presets_v1';

const BUILT_IN_LAYOUT_SNAPSHOTS: Record<string, WorkspaceLayoutSnapshot> = {
  'editing-workspace': {
    presetId: 'editing-workspace',
    workspaceMode: 'editing',
    slots: { ...DEFAULT_SLOTS },
    leftWidth: 280,
    rightWidth: 300,
    bottomHeight: 295,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: ['effects'],
    collapsedPanels: [],
    floatingPanels: [],
  },
  'effects-workspace': {
    presetId: 'effects-workspace',
    workspaceMode: 'editing',
    slots: { ...DEFAULT_SLOTS },
    leftWidth: 295,
    rightWidth: 320,
    bottomHeight: 285,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: ['effects'],
    collapsedPanels: [],
    floatingPanels: [],
  },
  'motion-workspace': {
    presetId: 'motion-workspace',
    workspaceMode: 'motion',
    slots: {
      leftTop: 'templates',
      leftBottom: 'layers',
      center: 'monitor',
      right: 'properties',
      bottom: 'keyframes',
    },
    leftWidth: 285,
    rightWidth: 310,
    bottomHeight: 310,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: [],
    collapsedPanels: [],
    floatingPanels: [],
  },
  'color-workspace': {
    presetId: 'color-workspace',
    workspaceMode: 'editing',
    slots: {
      leftTop: 'templates',
      leftBottom: 'effects',
      center: 'monitor',
      right: 'colorControls',
      bottom: 'timeline',
    },
    leftWidth: 275,
    rightWidth: 320,
    bottomHeight: 280,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: ['effects'],
    collapsedPanels: [],
    floatingPanels: [],
  },
  'audio-workspace': {
    presetId: 'audio-workspace',
    workspaceMode: 'audio',
    slots: {
      leftTop: 'templates',
      leftBottom: 'project',
      center: 'monitor',
      right: 'properties',
      bottom: 'mixer',
    },
    leftWidth: 275,
    rightWidth: 300,
    bottomHeight: 320,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: ['project'],
    collapsedPanels: [],
    floatingPanels: [],
  },
  'beginner-workspace': {
    presetId: 'beginner-workspace',
    workspaceMode: 'editing',
    slots: {
      leftTop: 'templates',
      leftBottom: 'presets',
      center: 'monitor',
      right: 'properties',
      bottom: 'timeline',
    },
    leftWidth: 280,
    rightWidth: 300,
    bottomHeight: 285,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: ['presets'],
    collapsedPanels: [],
    floatingPanels: [],
  },
  default: {
    presetId: 'editing-workspace',
    workspaceMode: 'editing',
    slots: { ...DEFAULT_SLOTS },
    leftWidth: 280,
    rightWidth: 300,
    bottomHeight: 295,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: ['effects'],
    collapsedPanels: [],
    floatingPanels: [],
  },
  'video-editing': {
    presetId: 'editing-workspace',
    workspaceMode: 'editing',
    slots: { ...DEFAULT_SLOTS },
    leftWidth: 280,
    rightWidth: 300,
    bottomHeight: 295,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: ['effects'],
    collapsedPanels: [],
    floatingPanels: [],
  },
  'motion-graphics': {
    presetId: 'motion-workspace',
    workspaceMode: 'motion',
    slots: {
      leftTop: 'templates',
      leftBottom: 'layers',
      center: 'monitor',
      right: 'properties',
      bottom: 'keyframes',
    },
    leftWidth: 285,
    rightWidth: 310,
    bottomHeight: 310,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: [],
    collapsedPanels: [],
    floatingPanels: [],
  },
  animation: {
    presetId: 'motion-workspace',
    workspaceMode: 'motion',
    slots: {
      leftTop: 'layers',
      leftBottom: 'shapes',
      center: 'monitor',
      right: 'properties',
      bottom: 'keyframes',
    },
    leftWidth: 280,
    rightWidth: 310,
    bottomHeight: 320,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: [],
    collapsedPanels: [],
    floatingPanels: [],
  },
  'audio-editing': {
    presetId: 'audio-workspace',
    workspaceMode: 'audio',
    slots: {
      leftTop: 'templates',
      leftBottom: 'project',
      center: 'monitor',
      right: 'properties',
      bottom: 'mixer',
    },
    leftWidth: 275,
    rightWidth: 300,
    bottomHeight: 320,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: ['project'],
    collapsedPanels: [],
    floatingPanels: [],
  },
  '3d-editing': {
    presetId: '3d-editing',
    workspaceMode: '3d',
    slots: { ...DEFAULT_SLOTS },
    leftWidth: 280,
    rightWidth: 300,
    bottomHeight: 295,
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    closedPanels: ['effects'],
    collapsedPanels: [],
    floatingPanels: [],
  },
};

function loadInitialWorkspaceState(): {
  snapshot: WorkspaceLayoutSnapshot;
  customLayouts: SavedWorkspacePreset[];
} {
  try {
    const raw = localStorage.getItem(WORKSPACE_LAYOUT_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as {
        snapshot?: Partial<WorkspaceLayoutSnapshot>;
        customLayouts?: SavedWorkspacePreset[];
      };
      const base = BUILT_IN_LAYOUT_SNAPSHOTS['editing-workspace'];
      const snap = parsed.snapshot || {};
      return {
        snapshot: {
          presetId: snap.presetId || base.presetId,
          workspaceMode: snap.workspaceMode || base.workspaceMode,
          slots: { ...base.slots, ...(snap.slots || {}) },
          leftWidth: typeof snap.leftWidth === 'number' ? snap.leftWidth : base.leftWidth,
          rightWidth: typeof snap.rightWidth === 'number' ? snap.rightWidth : base.rightWidth,
          bottomHeight:
            typeof snap.bottomHeight === 'number' ? snap.bottomHeight : base.bottomHeight,
          leftCollapsed: Boolean(snap.leftCollapsed),
          rightCollapsed: Boolean(snap.rightCollapsed),
          bottomCollapsed: Boolean(snap.bottomCollapsed),
          closedPanels: Array.isArray(snap.closedPanels) ? snap.closedPanels : base.closedPanels,
          collapsedPanels: Array.isArray(snap.collapsedPanels) ? snap.collapsedPanels : [],
          floatingPanels: Array.isArray(snap.floatingPanels) ? snap.floatingPanels : [],
        },
        customLayouts: Array.isArray(parsed.customLayouts) ? parsed.customLayouts : [],
      };
    }
  } catch {
    // Fallback to default layout
  }
  return {
    snapshot: structuredClone(BUILT_IN_LAYOUT_SNAPSHOTS['editing-workspace']),
    customLayouts: [],
  };
}

const PANEL_TITLES: Record<PanelId, string> = {
  project: 'Project Explorer',
  media: 'Media Explorer',
  templates: 'Media & Effects Browser',
  monitor: 'Preview Monitor',
  timeline: 'Timeline Editor',
  effects: 'Effects Library',
  transitions: 'Transition Library',
  textStudio: 'Text Animation Studio',
  shapes: 'Shapes & Masking',
  presets: 'Preset Library',
  properties: 'Properties Inspector',
  colorControls: 'Color Grading',
  mixer: 'Audio Mixer',
  layers: 'Layers & Tracking',
  keyframes: 'Keyframe & Graph Editor',
  nullHierarchy: 'Null Objects & Parenting',
};

function matchesShortcut(e: KeyboardEvent, combo: string): boolean {
  if (!combo) return false;
  const parts = combo.split('+').map((p) => p.trim().toLowerCase());
  const needCtrl = parts.includes('ctrl');
  const needShift = parts.includes('shift');
  const needAlt = parts.includes('alt');
  const keyPart = parts.filter((p) => !['ctrl', 'shift', 'alt'].includes(p))[0] || '';

  if ((e.ctrlKey || e.metaKey) !== needCtrl) return false;
  if (e.shiftKey !== needShift) return false;
  if (e.altKey !== needAlt) return false;

  const pressed = e.key === ' ' ? 'space' : e.key.toLowerCase();
  return pressed === keyPart;
}

export default function App() {
  const [project, setProject] = useState<StudioProject>(() => createStarterProject());
  const [recentProjects, setRecentProjects] = useState<StudioProject[]>([]);
  const [settings, setSettings] = useState<StudioSettings>(DEFAULT_SETTINGS);
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);

  // Screen & Modal States (Launch into redesigned RED EFFECT APPS Home Screen)
  const [showHomeScreen, setShowHomeScreen] = useState(true);
  const [isLoadingProjects, setIsLoadingProjects] = useState(true);
  const [projectsError, setProjectsError] = useState<string | null>(null);
  const [viewportSize, setViewportSize] = useState<{ width: number; height: number }>(() => ({
    width: typeof window !== 'undefined' ? window.innerWidth : 1600,
    height: typeof window !== 'undefined' ? window.innerHeight : 900,
  }));
  const [projectModalState, setProjectModalState] = useState<{
    mode: 'create' | 'edit';
    initialMediaPick?: 'video' | 'image' | 'all' | null;
  } | null>(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [autoKeyframeEnabled, setAutoKeyframeEnabled] = useState(false);
  const [settingsModalTab, setSettingsModalTab] = useState<SettingsModalTab | null>(null);
  const [qualityModalTab, setQualityModalTab] = useState<'enhancer' | 'smooth' | null>(null);

  // Interactive Tutorial State
  const [tutorialOpen, setTutorialOpen] = useState(false);
  const [tutorialStepIndex, setTutorialStepIndex] = useState<number>(() => {
    try {
      const raw = localStorage.getItem(TUTORIAL_PROGRESS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as { stepIndex?: number };
        if (typeof parsed.stepIndex === 'number') return parsed.stepIndex;
      }
    } catch {
      // Ignore
    }
    return 0;
  });
  const [completedTutorialSteps, setCompletedTutorialSteps] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(TUTORIAL_PROGRESS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as { completed?: string[] };
        if (Array.isArray(parsed.completed)) return parsed.completed;
      }
    } catch {
      // Ignore
    }
    return [];
  });

  // Undo / Redo Stacks (Unified Project + Layout History)
  const [undoStack, setUndoStack] = useState<StudioProject[]>([]);
  const [redoStack, setRedoStack] = useState<StudioProject[]>([]);
  const [layoutUndoStack, setLayoutUndoStack] = useState<WorkspaceLayoutSnapshot[]>([]);
  const [layoutRedoStack, setLayoutRedoStack] = useState<WorkspaceLayoutSnapshot[]>([]);
  const [undoOrder, setUndoOrder] = useState<Array<'project' | 'layout'>>([]);
  const [redoOrder, setRedoOrder] = useState<Array<'project' | 'layout'>>([]);
  const dragCheckpointRef = useRef<StudioProject | null>(null);

  // Customizable Workspace UI State (Auto-Persisted)
  const initialWorkspace = useMemo(() => loadInitialWorkspaceState(), []);
  const [activePresetId, setActivePresetId] = useState<WorkspaceLayoutPresetId>(
    initialWorkspace.snapshot.presetId
  );
  const [savedCustomLayouts, setSavedCustomLayouts] = useState<SavedWorkspacePreset[]>(
    initialWorkspace.customLayouts
  );
  const [workspaceMode, setWorkspaceMode] = useState<WorkspaceMode>(
    initialWorkspace.snapshot.workspaceMode
  );
  const [slots, setSlots] = useState<SlotConfig>(initialWorkspace.snapshot.slots);
  const [maximizedPanel, setMaximizedPanel] = useState<PanelId | null>(null);
  const [leftWidth, setLeftWidth] = useState(initialWorkspace.snapshot.leftWidth);
  const [rightWidth, setRightWidth] = useState(initialWorkspace.snapshot.rightWidth);
  const [bottomHeight, setBottomHeight] = useState(initialWorkspace.snapshot.bottomHeight);
  const [leftCollapsed, setLeftCollapsed] = useState(initialWorkspace.snapshot.leftCollapsed);
  const [rightCollapsed, setRightCollapsed] = useState(initialWorkspace.snapshot.rightCollapsed);
  const [bottomCollapsed, setBottomCollapsed] = useState(
    initialWorkspace.snapshot.bottomCollapsed
  );
  const [closedPanels, setClosedPanels] = useState<PanelId[]>(
    initialWorkspace.snapshot.closedPanels
  );
  const [collapsedPanels, setCollapsedPanels] = useState<PanelId[]>(
    initialWorkspace.snapshot.collapsedPanels
  );
  const [floatingPanels, setFloatingPanels] = useState<FloatingPanelWindow[]>(
    initialWorkspace.snapshot.floatingPanels
  );

  // Studio Dialogs & Clip Editing UX State
  const [renamingClipId, setRenamingClipId] = useState<string | null>(null);
  const [forcePropertiesTabSignal, setForcePropertiesTabSignal] = useState<{
    clipId: string;
    tab: InspectorTab;
    seq: number;
  } | null>(null);
  const [speedDurationClipId, setSpeedDurationClipId] = useState<string | null>(null);
  const [speedDraft, setSpeedDraft] = useState<{
    speed: number;
    duration: number;
    reverse: boolean;
  }>({ speed: 1, duration: 5, reverse: false });
  const [layoutPromptModal, setLayoutPromptModal] = useState<{
    mode: 'save' | 'rename';
    name: string;
  } | null>(null);

  // Selection & Playback State
  const [playheadTime, setPlayheadTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [loopEnabled, setLoopEnabled] = useState(false);
  const [activeTool, setActiveTool] = useState<'select' | 'cut'>('select');
  const [penToolActive, setPenToolActive] = useState(false);
  const [selectedClipId, setSelectedClipId] = useState<string | null>('clip-1');
  const [selectedClipIds, setSelectedClipIds] = useState<string[]>(['clip-1']);
  const [selectedMarkerId, setSelectedMarkerId] = useState<string | null>(null);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>('asset-cinema-street');
  const [activeFolder, setActiveFolder] = useState<string>('ALL');
  const [clipboardClip, setClipboardClip] = useState<TimelineClip | null>(null);
  const [copiedEffectsStack, setCopiedEffectsStack] = useState<EffectInstance[]>([]);
  const [customPresets, setCustomPresets] = useState<StudioPreset[]>(() => {
    try {
      const raw = localStorage.getItem(CUSTOM_PRESETS_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as StudioPreset[]) : [];
    } catch {
      return [];
    }
  });
  const [showEffectsLibrary, setShowEffectsLibrary] = useState(false);
  const [customReadyPresets, setCustomReadyPresets] = useState<ReadyMadeEffectPreset[]>(() =>
    loadCustomReadyPresets()
  );
  const [hoverPreviewPreset, setHoverPreviewPreset] = useState<ReadyMadeEffectPreset | null>(null);
  const [hoverPreviewPending, setHoverPreviewPending] = useState(false);
  const hoverEnterTimerRef = useRef<number | null>(null);
  const hoverLeaveTimerRef = useRef<number | null>(null);

  const clearHoverPreviewImmediate = useCallback(() => {
    if (hoverEnterTimerRef.current !== null) {
      window.clearTimeout(hoverEnterTimerRef.current);
      hoverEnterTimerRef.current = null;
    }
    if (hoverLeaveTimerRef.current !== null) {
      window.clearTimeout(hoverLeaveTimerRef.current);
      hoverLeaveTimerRef.current = null;
    }
    setHoverPreviewPending(false);
    setHoverPreviewPreset(null);
  }, []);

  const handleHoverPreviewPreset = useCallback(
    (preset: ReadyMadeEffectPreset | null) => {
      if (settings.hoverPreviewEnabled === false) {
        clearHoverPreviewImmediate();
        return;
      }
      if (hoverEnterTimerRef.current !== null) {
        window.clearTimeout(hoverEnterTimerRef.current);
        hoverEnterTimerRef.current = null;
      }
      if (hoverLeaveTimerRef.current !== null) {
        window.clearTimeout(hoverLeaveTimerRef.current);
        hoverLeaveTimerRef.current = null;
      }
      if (!preset) {
        setHoverPreviewPending(false);
        hoverLeaveTimerRef.current = window.setTimeout(() => {
          hoverLeaveTimerRef.current = null;
          setHoverPreviewPreset(null);
        }, 16);
        return;
      }
      setHoverPreviewPending(true);
      hoverEnterTimerRef.current = window.setTimeout(() => {
        hoverEnterTimerRef.current = null;
        setHoverPreviewPending(false);
        setHoverPreviewPreset(preset);
      }, 65);
    },
    [settings.hoverPreviewEnabled, clearHoverPreviewImmediate]
  );

  useEffect(() => {
    if (settings.hoverPreviewEnabled === false || showHomeScreen) {
      clearHoverPreviewImmediate();
    }
  }, [settings.hoverPreviewEnabled, showHomeScreen, clearHoverPreviewImmediate]);

  useEffect(() => {
    clearHoverPreviewCache();
  }, [project.id]);

  useEffect(() => {
    return () => {
      if (hoverEnterTimerRef.current !== null) window.clearTimeout(hoverEnterTimerRef.current);
      if (hoverLeaveTimerRef.current !== null) window.clearTimeout(hoverLeaveTimerRef.current);
    };
  }, []);
  const [assetBrowserTab, setAssetBrowserTab] = useState<AssetBrowserTabId>('media');
  const [customTemplates, setCustomTemplates] = useState<SavedCustomTemplate[]>(() =>
    loadSavedCustomTemplates()
  );
  const [customizeTemplateConfig, setCustomizeTemplateConfig] =
    useState<TrailerTemplateCustomization | null>(null);
  const [copiedAttributes, setCopiedAttributes] = useState<{
    transform: TimelineClip['transform'];
    effects: TimelineClip['effects'];
    effectsStack?: EffectInstance[];
    colorGrade: ColorGrade;
    speed: number;
    volume: number;
    blendMode: TimelineClip['blendMode'];
  } | null>(null);

  // Audio Output State
  const [masterVolume, setMasterVolume] = useState(1);
  const [masterMuted, setMasterMuted] = useState(false);

  // Specialized Studios
  const [active3DBlueprint, setActive3DBlueprint] = useState<Model3DBlueprint | null>(() =>
    createDefaultShowcase3DBlueprint()
  );
  const [transfer4DPayload, setTransfer4DPayload] = useState<Studio4DTransferPayload | null>(null);

  const globalMediaInputRef = useRef<HTMLInputElement>(null);
  const audioEngineRef = useRef<StudioAudioEngine | null>(null);
  if (!audioEngineRef.current) {
    audioEngineRef.current = new StudioAudioEngine();
  }

  const totalDuration = useMemo(() => getProjectEndTime(project), [project]);
  const selectedClip = useMemo(
    () => project.clips.find((c) => c.id === selectedClipId) || null,
    [project.clips, selectedClipId]
  );

  useEffect(() => {
    applyUiThemeToDocument(settings.uiTheme);
  }, [settings.uiTheme]);

  // Load persisted projects and settings on mount
  useEffect(() => {
    (async () => {
      try {
        const [loadedSettings, savedProjects] = await Promise.all([
          loadSettingsFromDB(),
          loadAllProjectsFromDB(),
        ]);
        const hw = detectHardwareProfile();
        textBitmapCache.setBudget(hw.cacheBudgetBytes);
        let effectiveSettings = loadedSettings;
        if (
          !localStorage.getItem('redeffect_hw_init_v1') &&
          loadedSettings.performanceMode === false &&
          loadedSettings.previewQuality === 'high' &&
          loadedSettings.proxyQuality === 'full'
        ) {
          if (hw.tier === 'low-end') {
            effectiveSettings = {
              ...loadedSettings,
              performanceMode: hw.recommendedPerformanceMode,
              previewQuality: hw.recommendedPreviewQuality,
              proxyQuality: hw.recommendedProxyQuality,
            };
            saveSettingsToDB(effectiveSettings).catch(() => {});
          }
          try {
            localStorage.setItem('redeffect_hw_init_v1', '1');
          } catch {
            // Ignore storage errors
          }
        }
        setSettings(effectiveSettings);
        if (effectiveSettings.audioOutputDeviceId) {
          audioEngineRef.current?.setOutputDevice(effectiveSettings.audioOutputDeviceId).catch(() => {});
        }
        if (savedProjects.length > 0) {
          setRecentProjects(savedProjects);
          const first = normalizeProject(savedProjects[0]);
          projectRef.current = first;
          setProject(first);
          setLastSavedAt(first.updatedAt);
          const firstCid = first.clips[0]?.id || null;
          setSelectedClipId(firstCid);
          setSelectedClipIds(firstCid ? [firstCid] : []);
        } else if (!localStorage.getItem(FIRST_LAUNCH_DONE_KEY)) {
          const tutorialProj = normalizeProject(await buildAndPrepareTutorialProject());
          await saveProjectToDB(tutorialProj);
          localStorage.setItem(FIRST_LAUNCH_DONE_KEY, '1');
          projectRef.current = tutorialProj;
          setProject(tutorialProj);
          setRecentProjects([tutorialProj]);
          setLastSavedAt(tutorialProj.updatedAt);
          setPlayheadTime(0);
          setSelectedClipId('clip-tut-null');
          setSelectedClipIds(['clip-tut-null']);
        } else {
          const starter = createStarterProject();
          await saveProjectToDB(starter);
          setRecentProjects([starter]);
        }
      } catch (err) {
        setProjectsError(
          err instanceof Error ? err.message : 'Unable to load saved projects from local storage.'
        );
      } finally {
        setIsLoadingProjects(false);
      }
    })();

    const onResize = () => {
      setViewportSize({ width: window.innerWidth, height: window.innerHeight });
    };
    window.addEventListener('resize', onResize);

    return () => {
      window.removeEventListener('resize', onResize);
      audioEngineRef.current?.dispose();
    };
  }, []);

  // Persist Interactive Tutorial progress
  useEffect(() => {
    try {
      localStorage.setItem(
        TUTORIAL_PROGRESS_KEY,
        JSON.stringify({
          stepIndex: tutorialStepIndex,
          completed: completedTutorialSteps,
        })
      );
    } catch {
      // Ignore storage quota errors
    }
  }, [tutorialStepIndex, completedTutorialSteps]);

  // Auto-save timer
  useEffect(() => {
    if (!settings.autoSaveIntervalSec || settings.autoSaveIntervalSec <= 0) return;
    const timer = window.setInterval(() => {
      saveProjectToDB(project)
        .then(() => {
          setLastSavedAt(Date.now());
          loadAllProjectsFromDB().then(setRecentProjects).catch(() => {});
        })
        .catch(() => {});
    }, settings.autoSaveIntervalSec * 1000);
    return () => clearInterval(timer);
  }, [project, settings.autoSaveIntervalSec]);

  const currentLayoutSnapshot = useMemo<WorkspaceLayoutSnapshot>(
    () => ({
      presetId: activePresetId,
      workspaceMode,
      slots,
      leftWidth,
      rightWidth,
      bottomHeight,
      leftCollapsed,
      rightCollapsed,
      bottomCollapsed,
      closedPanels,
      collapsedPanels,
      floatingPanels,
    }),
    [
      activePresetId,
      workspaceMode,
      slots,
      leftWidth,
      rightWidth,
      bottomHeight,
      leftCollapsed,
      rightCollapsed,
      bottomCollapsed,
      closedPanels,
      collapsedPanels,
      floatingPanels,
    ]
  );

  // Auto-persist active workspace customization across reloads/restarts
  useEffect(() => {
    try {
      localStorage.setItem(
        WORKSPACE_LAYOUT_STORAGE_KEY,
        JSON.stringify({
          snapshot: currentLayoutSnapshot,
          customLayouts: savedCustomLayouts,
        })
      );
    } catch {
      // Ignore storage quota errors
    }
  }, [currentLayoutSnapshot, savedCustomLayouts]);

  const applyLayoutSnapshot = useCallback((snap: WorkspaceLayoutSnapshot) => {
    setActivePresetId(snap.presetId);
    setWorkspaceMode(snap.workspaceMode);
    setSlots(snap.slots);
    setLeftWidth(snap.leftWidth);
    setRightWidth(snap.rightWidth);
    setBottomHeight(snap.bottomHeight);
    setLeftCollapsed(snap.leftCollapsed);
    setRightCollapsed(snap.rightCollapsed);
    setBottomCollapsed(snap.bottomCollapsed);
    setClosedPanels(snap.closedPanels);
    setCollapsedPanels(snap.collapsedPanels);
    setFloatingPanels(snap.floatingPanels);
    setMaximizedPanel(null);
  }, []);

  const pushLayoutUndo = useCallback((snapshotOverride?: WorkspaceLayoutSnapshot) => {
    const snap = snapshotOverride ?? currentLayoutSnapshot;
    setLayoutUndoStack((prev) => [...prev.slice(-29), structuredClone(snap)]);
    setLayoutRedoStack([]);
    setUndoOrder((prev) => [...prev.slice(-49), 'layout']);
    setRedoOrder([]);
  }, [currentLayoutSnapshot]);

  const projectRef = useRef(project);
  projectRef.current = project;

  const playheadRef = useRef(playheadTime);
  playheadRef.current = playheadTime;

  // Project Mutation with Undo Stack
  const commitProject = useCallback(
    (updater: (prev: StudioProject) => StudioProject, pushHistory = true) => {
      const prev = projectRef.current;
      const next = { ...updater(prev), updatedAt: Date.now() };
      projectRef.current = next;
      if (pushHistory) {
        setUndoStack((st) => [...st.slice(-39), prev]);
        setRedoStack([]);
        setUndoOrder((o) => [...o.slice(-49), 'project']);
        setRedoOrder([]);
      }
      setProject(next);
    },
    []
  );

  const handleUndo = useCallback(() => {
    clearHoverPreviewImmediate();
    const lastKind = undoOrder[undoOrder.length - 1];
    if (lastKind === 'layout' && layoutUndoStack.length > 0) {
      const prevSnap = layoutUndoStack[layoutUndoStack.length - 1];
      setLayoutUndoStack((s) => s.slice(0, -1));
      setLayoutRedoStack((r) => [...r, structuredClone(currentLayoutSnapshot)]);
      setUndoOrder((o) => o.slice(0, -1));
      setRedoOrder((r) => [...r, 'layout']);
      applyLayoutSnapshot(prevSnap);
      return;
    }
    if (undoStack.length > 0) {
      const prevProj = undoStack[undoStack.length - 1];
      setUndoStack((s) => s.slice(0, -1));
      setRedoStack((r) => [...r, projectRef.current]);
      setUndoOrder((o) => o.slice(0, -1));
      setRedoOrder((r) => [...r, 'project']);
      projectRef.current = prevProj;
      setProject(prevProj);
    }
  }, [undoOrder, layoutUndoStack, undoStack, currentLayoutSnapshot, applyLayoutSnapshot, clearHoverPreviewImmediate]);

  const handleRedo = useCallback(() => {
    clearHoverPreviewImmediate();
    const lastKind = redoOrder[redoOrder.length - 1];
    if (lastKind === 'layout' && layoutRedoStack.length > 0) {
      const nextSnap = layoutRedoStack[layoutRedoStack.length - 1];
      setLayoutRedoStack((s) => s.slice(0, -1));
      setLayoutUndoStack((u) => [...u, structuredClone(currentLayoutSnapshot)]);
      setRedoOrder((o) => o.slice(0, -1));
      setUndoOrder((u) => [...u, 'layout']);
      applyLayoutSnapshot(nextSnap);
      return;
    }
    if (redoStack.length > 0) {
      const nextProj = redoStack[redoStack.length - 1];
      setRedoStack((s) => s.slice(0, -1));
      setUndoStack((u) => [...u, projectRef.current]);
      setRedoOrder((o) => o.slice(0, -1));
      setUndoOrder((u) => [...u, 'project']);
      projectRef.current = nextProj;
      setProject(nextProj);
    }
  }, [redoOrder, layoutRedoStack, redoStack, currentLayoutSnapshot, applyLayoutSnapshot, clearHoverPreviewImmediate]);

  // Playback Loop
  useEffect(() => {
    if (!isPlaying) {
      audioEngineRef.current?.pauseAll();
      return;
    }

    let lastTime = performance.now();
    let rafId = 0;

    const tick = (now: number) => {
      const dt = Math.min(0.1, (now - lastTime) / 1000);
      lastTime = now;

      const next = playheadRef.current + dt;
      if (next >= totalDuration) {
        if (loopEnabled) {
          playheadRef.current = 0;
          setPlayheadTime(0);
        } else {
          playheadRef.current = totalDuration;
          setPlayheadTime(totalDuration);
          setIsPlaying(false);
          return;
        }
      } else {
        playheadRef.current = next;
        setPlayheadTime(next);
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [isPlaying, totalDuration, loopEnabled]);

  useEffect(() => {
    audioEngineRef.current?.syncPlayback(project, playheadTime, isPlaying);
  }, [project, playheadTime, isPlaying]);

  const getMixerPeakLevels = useCallback(
    () => audioEngineRef.current?.getPeakLevels() || { left: 0, right: 0 },
    []
  );

  const handleMarkTutorialStepCompleted = useCallback((stepId: string) => {
    setCompletedTutorialSteps((prev) => (prev.includes(stepId) ? prev : [...prev, stepId]));
  }, []);

  // Master Audio Controls
  const handleToggleMasterMute = useCallback(() => {
    setMasterMuted((prev) => {
      const next = !prev;
      audioEngineRef.current?.setMasterMuted(next);
      return next;
    });
  }, []);

  const handleSetMasterVolume = useCallback((vol: number) => {
    const clamped = Math.max(0, Math.min(1.5, vol));
    setMasterVolume(clamped);
    audioEngineRef.current?.setMasterVolume(clamped);
    if (clamped > 0) {
      setMasterMuted(false);
      audioEngineRef.current?.setMasterMuted(false);
    }
  }, []);

  const handleSelectAudioDevice = useCallback(
    async (deviceId: string) => {
      const nextSettings = { ...settings, audioOutputDeviceId: deviceId };
      setSettings(nextSettings);
      await saveSettingsToDB(nextSettings).catch(() => {});
      await audioEngineRef.current?.setOutputDevice(deviceId);
    },
    [settings]
  );

  // Selection Helper (Single, Group & Multi-Clip Selection)
  const handleSelectClip = useCallback(
    (clipId: string | null, additive = false) => {
      if (!clipId) {
        setSelectedClipId(null);
        setSelectedClipIds([]);
        return;
      }
      const targetClip = project.clips.find((c) => c.id === clipId);
      const memberIds = targetClip?.groupId
        ? project.clips.filter((c) => c.groupId === targetClip.groupId).map((c) => c.id)
        : [clipId];

      if (additive) {
        setSelectedClipId(clipId);
        setSelectedClipIds((prev) =>
          prev.includes(clipId)
            ? prev.filter((id) => !memberIds.includes(id))
            : Array.from(new Set([...prev, ...memberIds]))
        );
      } else {
        setSelectedClipId(clipId);
        setSelectedClipIds(memberIds);
        if (targetClip?.type === 'fx') {
          setClosedPanels((prev) => prev.filter((p) => p !== 'properties'));
          setRightCollapsed(false);
          setSlots((s) => ({ ...s, right: 'properties' }));
          setForcePropertiesTabSignal((prev) => ({
            clipId: targetClip.id,
            tab: targetClip.fxMeta?.category === 'cc' ? 'color' : 'effects',
            seq: (prev?.seq || 0) + 1,
          }));
        }
      }
    },
    [project.clips]
  );

  const handleSelectMultipleClips = useCallback(
    (clipIds: string[], primaryId?: string | null) => {
      const unique = Array.from(new Set(clipIds));
      setSelectedClipIds(unique);
      if (primaryId !== undefined) {
        setSelectedClipId(primaryId);
      } else {
        setSelectedClipId(unique[0] || null);
      }
    },
    []
  );

  // Custom Presets Persistence
  const handleSaveCustomPreset = useCallback((preset: StudioPreset) => {
    setCustomPresets((prev) => {
      const next = [preset, ...prev.filter((p) => p.id !== preset.id)];
      try {
        localStorage.setItem(CUSTOM_PRESETS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage quota errors
      }
      return next;
    });
  }, []);

  const handleDeleteCustomPreset = useCallback((id: string) => {
    setCustomPresets((prev) => {
      const next = prev.filter((p) => p.id !== id);
      try {
        localStorage.setItem(CUSTOM_PRESETS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore
      }
      return next;
    });
  }, []);

  // Workspace Mode Preset Switching (with Undo + Closed/Floating awareness)
  const handleWorkspaceModeChange = useCallback(
    (mode: WorkspaceMode) => {
      clearHoverPreviewImmediate();
      setShowHomeScreen(false);
      pushLayoutUndo();
      setWorkspaceMode(mode);
      setMaximizedPanel(null);
      setLeftCollapsed(false);
      setRightCollapsed(false);
      setBottomCollapsed(false);
      if (mode === 'editing') {
        applyLayoutSnapshot(structuredClone(BUILT_IN_LAYOUT_SNAPSHOTS['editing-workspace']));
        setAssetBrowserTab('media');
      } else if (mode === 'motion') {
        applyLayoutSnapshot(structuredClone(BUILT_IN_LAYOUT_SNAPSHOTS['motion-workspace']));
        setAssetBrowserTab('text');
      } else if (mode === 'audio') {
        applyLayoutSnapshot(structuredClone(BUILT_IN_LAYOUT_SNAPSHOTS['audio-workspace']));
        setAssetBrowserTab('audio');
      } else if (mode === '3d') {
        setActivePresetId('3d-editing');
      }
    },
    [pushLayoutUndo, applyLayoutSnapshot, clearHoverPreviewImmediate]
  );

  // Select any built-in or saved custom workspace layout preset
  const handleSelectLayoutPreset = useCallback(
    (presetId: string) => {
      const target =
        BUILT_IN_LAYOUT_SNAPSHOTS[presetId] ||
        savedCustomLayouts.find((l) => l.id === presetId);
      if (!target) return;
      pushLayoutUndo();
      setShowHomeScreen(false);
      applyLayoutSnapshot(structuredClone(target));
      if (presetId === 'editing-workspace' || presetId === 'video-editing' || presetId === 'default') {
        setAssetBrowserTab('media');
      } else if (presetId === 'effects-workspace') {
        setAssetBrowserTab('effects');
      } else if (presetId === 'motion-workspace' || presetId === 'motion-graphics') {
        setAssetBrowserTab('text');
      } else if (presetId === 'color-workspace') {
        setAssetBrowserTab('color');
      } else if (presetId === 'audio-workspace' || presetId === 'audio-editing') {
        setAssetBrowserTab('audio');
      } else if (presetId === 'beginner-workspace') {
        setAssetBrowserTab('templates');
      }
    },
    [savedCustomLayouts, pushLayoutUndo, applyLayoutSnapshot]
  );

  // Swap panels when dragging headers
  const handleSwapPanels = useCallback(
    (sourceId: PanelId, targetId: PanelId) => {
      pushLayoutUndo();
      setSlots((prev) => {
        const next = { ...prev };
        const keys = Object.keys(next) as Array<keyof SlotConfig>;
        const srcKey = keys.find((k) => next[k] === sourceId);
        const dstKey = keys.find((k) => next[k] === targetId);
        if (srcKey && dstKey) {
          next[srcKey] = targetId;
          next[dstKey] = sourceId;
        }
        return next;
      });
    },
    [pushLayoutUndo]
  );

  // Close / Reopen / Collapse / Undock Panels
  const findPreferredSlotForPanel = (panelId: PanelId): keyof SlotConfig => {
    if (['templates', 'project', 'media', 'transitions'].includes(panelId)) return 'leftTop';
    if (['effects', 'textStudio', 'shapes', 'presets', 'layers'].includes(panelId))
      return 'leftBottom';
    if (['properties', 'colorControls'].includes(panelId)) return 'right';
    if (['timeline', 'keyframes', 'nullHierarchy', 'mixer'].includes(panelId)) return 'bottom';
    return 'center';
  };

  const handleClosePanel = useCallback(
    (panelId: PanelId) => {
      if (panelId === 'monitor') return;
      pushLayoutUndo();
      setClosedPanels((prev) => (prev.includes(panelId) ? prev : [...prev, panelId]));
      setFloatingPanels((prev) => prev.filter((fp) => fp.panelId !== panelId));
      if (maximizedPanel === panelId) setMaximizedPanel(null);
    },
    [maximizedPanel, pushLayoutUndo]
  );

  const handleTogglePanelWindow = useCallback(
    (panelId: PanelId) => {
      pushLayoutUndo();
      const isClosed = closedPanels.includes(panelId);
      if (isClosed) {
        setClosedPanels((prev) => prev.filter((p) => p !== panelId));
        const slotKey = findPreferredSlotForPanel(panelId);
        setSlots((s) => ({ ...s, [slotKey]: panelId }));
        if (slotKey === 'leftTop' || slotKey === 'leftBottom') setLeftCollapsed(false);
        if (slotKey === 'right') setRightCollapsed(false);
        if (slotKey === 'bottom') setBottomCollapsed(false);
      } else if (panelId !== 'monitor') {
        setClosedPanels((prev) => [...prev, panelId]);
        setFloatingPanels((prev) => prev.filter((fp) => fp.panelId !== panelId));
      }
    },
    [closedPanels, pushLayoutUndo]
  );

  const handleTogglePanelCollapse = useCallback(
    (panelId: PanelId) => {
      pushLayoutUndo();
      setCollapsedPanels((prev) =>
        prev.includes(panelId) ? prev.filter((p) => p !== panelId) : [...prev, panelId]
      );
    },
    [pushLayoutUndo]
  );

  const handleTogglePanelFloat = useCallback(
    (panelId: PanelId) => {
      pushLayoutUndo();
      const exists = floatingPanels.some((fp) => fp.panelId === panelId);
      if (exists) {
        // Dock Back into appropriate workspace slot
        setFloatingPanels((prev) => prev.filter((fp) => fp.panelId !== panelId));
        setClosedPanels((prev) => prev.filter((p) => p !== panelId));
        const slotKey = findPreferredSlotForPanel(panelId);
        setSlots((s) => ({ ...s, [slotKey]: panelId }));
        if (slotKey === 'leftTop' || slotKey === 'leftBottom') setLeftCollapsed(false);
        if (slotKey === 'right') setRightCollapsed(false);
        if (slotKey === 'bottom') setBottomCollapsed(false);
      } else {
        const maxZ = floatingPanels.reduce((m, f) => Math.max(m, f.zIndex), 60);
        const offset = (floatingPanels.length % 5) * 28;
        setClosedPanels((prev) => prev.filter((p) => p !== panelId));
        setCollapsedPanels((prev) => prev.filter((p) => p !== panelId));
        setFloatingPanels((prev) => [
          ...prev,
          {
            panelId,
            x: 140 + offset,
            y: 95 + offset,
            width: panelId === 'timeline' || panelId === 'keyframes' ? 760 : 420,
            height: panelId === 'timeline' || panelId === 'keyframes' ? 320 : 460,
            zIndex: maxZ + 1,
          },
        ]);
      }
    },
    [floatingPanels, pushLayoutUndo]
  );

  const bringFloatingToFront = useCallback((panelId: PanelId) => {
    setFloatingPanels((prev) => {
      const maxZ = prev.reduce((m, f) => Math.max(m, f.zIndex), 60);
      const target = prev.find((f) => f.panelId === panelId);
      if (!target || target.zIndex === maxZ) return prev;
      return prev.map((f) => (f.panelId === panelId ? { ...f, zIndex: maxZ + 1 } : f));
    });
  }, []);

  const startFloatingDrag = useCallback(
    (panelId: PanelId, e: React.MouseEvent<HTMLDivElement>) => {
      e.preventDefault();
      bringFloatingToFront(panelId);
      const fp = floatingPanels.find((f) => f.panelId === panelId);
      if (!fp) return;
      const startX = e.clientX;
      const startY = e.clientY;
      const origX = fp.x;
      const origY = fp.y;
      const onMove = (ev: MouseEvent) => {
        const nx = Math.max(0, Math.min(window.innerWidth - 160, origX + (ev.clientX - startX)));
        const ny = Math.max(36, Math.min(window.innerHeight - 64, origY + (ev.clientY - startY)));
        setFloatingPanels((prev) =>
          prev.map((item) => (item.panelId === panelId ? { ...item, x: nx, y: ny } : item))
        );
      };
      const onUp = () => {
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
      };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    },
    [floatingPanels, bringFloatingToFront]
  );

  const startFloatingResize = useCallback(
    (panelId: PanelId, e: React.MouseEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      bringFloatingToFront(panelId);
      const fp = floatingPanels.find((f) => f.panelId === panelId);
      if (!fp) return;
      const startX = e.clientX;
      const startY = e.clientY;
      const origW = fp.width;
      const origH = fp.height;
      const onMove = (ev: MouseEvent) => {
        const nw = Math.max(280, Math.min(window.innerWidth - fp.x - 16, origW + (ev.clientX - startX)));
        const nh = Math.max(200, Math.min(window.innerHeight - fp.y - 16, origH + (ev.clientY - startY)));
        setFloatingPanels((prev) =>
          prev.map((item) => (item.panelId === panelId ? { ...item, width: nw, height: nh } : item))
        );
      };
      const onUp = () => {
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
      };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    },
    [floatingPanels, bringFloatingToFront]
  );

  // File Imports from Windows PC (extracts audio waveform for BOTH video and audio!)
  const handleImportFiles = useCallback(
    async (files: FileList | File[]): Promise<MediaAsset[]> => {
      const newAssets: MediaAsset[] = [];
      const fallbackDur = project.defaultClipDuration || 5;

      for (const file of Array.from(files)) {
        const ext = file.name.split('.').pop()?.toLowerCase() || '';
        const url = URL.createObjectURL(file);

        if (
          ['mp4', 'mov', 'avi', 'mkv', 'webm', 'm4v'].includes(ext) ||
          file.type.startsWith('video/')
        ) {
          const meta = await new Promise<{ duration: number; width?: number; height?: number }>(
            (resolve) => {
              const v = document.createElement('video');
              v.preload = 'metadata';
              v.onloadedmetadata = () =>
                resolve({
                  duration: Number.isFinite(v.duration) && v.duration > 0 ? v.duration : 8,
                  width: v.videoWidth > 0 ? v.videoWidth : undefined,
                  height: v.videoHeight > 0 ? v.videoHeight : undefined,
                });
              v.onerror = () => resolve({ duration: 8 });
              v.src = url;
            }
          );
          const asset: MediaAsset = {
            id: `asset-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            name: file.name,
            type: 'video',
            mimeType: file.type || 'video/mp4',
            url,
            originalUrl: url,
            duration: Math.max(1, meta.duration),
            width: meta.width,
            height: meta.height,
            sourceFps: project.fps || 30,
            sizeBytes: file.size,
            folder: 'Media/Videos',
            createdAt: Date.now(),
          };
          const wf = await generateAudioWaveform(asset);
          asset.waveformPeaks = wf.peaks;
          asset.hasAudio = wf.hasAudio;
          newAssets.push(asset);
        } else if (
          ['mp3', 'wav', 'ogg', 'aac', 'm4a', 'flac'].includes(ext) ||
          file.type.startsWith('audio/')
        ) {
          const duration = await new Promise<number>((resolve) => {
            const a = new Audio(url);
            a.onloadedmetadata = () =>
              resolve(Number.isFinite(a.duration) && a.duration > 0 ? a.duration : 10);
            a.onerror = () => resolve(10);
          });
          const asset: MediaAsset = {
            id: `asset-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            name: file.name,
            type: 'audio',
            mimeType: file.type || 'audio/mpeg',
            url,
            originalUrl: url,
            duration: Math.max(1, duration),
            sizeBytes: file.size,
            folder: 'Media/Audio',
            createdAt: Date.now(),
          };
          const wf = await generateAudioWaveform(asset);
          asset.waveformPeaks = wf.peaks;
          asset.hasAudio = wf.hasAudio;
          newAssets.push(asset);
        } else if (['obj', 'glb', 'gltf', 'fbx'].includes(ext)) {
          newAssets.push({
            id: `asset-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            name: file.name,
            type: 'model3d',
            mimeType: 'model/gltf-binary',
            url,
            originalUrl: url,
            duration: fallbackDur,
            sizeBytes: file.size,
            folder: '3D Models',
            createdAt: Date.now(),
          });
        } else {
          // Read natural image resolution without resizing or re-encoding
          const imgMeta = await new Promise<{ width?: number; height?: number }>((resolve) => {
            const img = new Image();
            img.onload = () =>
              resolve({
                width: img.naturalWidth > 0 ? img.naturalWidth : undefined,
                height: img.naturalHeight > 0 ? img.naturalHeight : undefined,
              });
            img.onerror = () => resolve({});
            img.src = url;
          });
          newAssets.push({
            id: `asset-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            name: file.name,
            type: 'image',
            mimeType: file.type || 'image/png',
            url,
            originalUrl: url,
            width: imgMeta.width,
            height: imgMeta.height,
            duration: fallbackDur,
            sizeBytes: file.size,
            folder: 'Media/Images',
            createdAt: Date.now(),
          });
        }
      }

      if (newAssets.length > 0) {
        commitProject((p) => ({ ...p, assets: [...newAssets, ...p.assets] }));
        setSelectedAssetId(newAssets[0].id);
      }

      return newAssets;
    },
    [commitProject, project.defaultClipDuration]
  );

  const addAssetToTimeline = useCallback(
    (asset: MediaAsset, targetTrackId?: string, startAt?: number) => {
      let createdClipId: string | null = null;
      commitProject((p) => {
        const defaultTrackId =
          asset.type === 'audio'
            ? p.tracks.find((t) => t.kind === 'audio')?.id || 'A1'
            : asset.type === 'image'
            ? p.tracks.find((t) => t.kind === 'image')?.id ||
              p.tracks.find((t) => t.kind === 'video')?.id ||
              'V1'
            : asset.type === 'model3d'
            ? p.tracks.find((t) => t.id === 'V2')?.id ||
              p.tracks.find((t) => t.kind === 'video')?.id ||
              'V1'
            : p.tracks.find((t) => t.kind === 'video')?.id || 'V1';

        const trackId = targetTrackId || defaultTrackId;
        const trackClips = p.clips.filter((c) => c.trackId === trackId);
        const endOfTrack = trackClips.reduce(
          (max, c) => Math.max(max, c.startTime + c.duration),
          0
        );
        const startTime = startAt !== undefined ? Math.max(0, startAt) : endOfTrack;
        const clipDur =
          asset.type === 'video' || asset.type === 'audio'
            ? Math.max(1, asset.duration)
            : Math.max(2, p.defaultClipDuration || asset.duration);

        const newClip = createClipDefaults({
          id: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          assetId: asset.id,
          trackId,
          name: asset.name,
          type: asset.type,
          startTime,
          duration: clipDur,
          is3DLayer: asset.type === 'model3d',
          modelBlueprint: asset.modelBlueprint,
        });
        createdClipId = newClip.id;
        return { ...p, clips: [...p.clips, newClip] };
      });
      if (createdClipId) {
        setSelectedClipId(createdClipId);
        setSelectedClipIds([createdClipId]);
      }
    },
    [commitProject]
  );

  const handleDropFilesOnTrack = useCallback(
    async (files: FileList, trackId: string, startTime: number) => {
      const imported = await handleImportFiles(files);
      let cursor = Math.max(0, startTime);
      for (const asset of imported) {
        addAssetToTimeline(asset, trackId, cursor);
        cursor += Math.max(1, asset.duration);
      }
    },
    [handleImportFiles, addAssetToTimeline]
  );

  // Track Management (Add, Rename, Delete, Reorder)
  const handleAddTrack = useCallback(
    (kind: TimelineTrack['kind']) => {
      commitProject((p) => {
        const countOfKind = p.tracks.filter((t) => t.kind === kind).length + 1;
        const prefix =
          kind === 'video'
            ? 'V'
            : kind === 'audio'
            ? 'A'
            : kind === 'image'
            ? 'I'
            : kind === 'shape'
            ? 'S'
            : kind === 'null'
            ? 'N'
            : kind === 'fx'
            ? 'FX'
            : 'T';
        const label =
          kind === 'video'
            ? 'Video'
            : kind === 'audio'
            ? 'Audio'
            : kind === 'image'
            ? 'Image'
            : kind === 'shape'
            ? 'Shape'
            : kind === 'null'
            ? 'Null'
            : kind === 'fx'
            ? 'Adjustment'
            : 'Text';
        const defaultColor: MarkerColor =
          kind === 'audio'
            ? 'emerald'
            : kind === 'text'
            ? 'amber'
            : kind === 'null' || kind === 'fx'
            ? 'rose'
            : kind === 'shape'
            ? 'violet'
            : 'sky';
        const newTrack: TimelineTrack = {
          id: `${prefix}${countOfKind}-${Date.now().toString(36).slice(-3)}`,
          name: `${prefix}${countOfKind} · ${label}`,
          kind,
          muted: false,
          solo: false,
          locked: false,
          visible: true,
          volume: 1,
          pan: 0,
          color: defaultColor,
          collapsed: true,
        };

        if (kind === 'audio') {
          return { ...p, tracks: [...p.tracks, newTrack] };
        }
        return { ...p, tracks: [newTrack, ...p.tracks] };
      });
    },
    [commitProject]
  );

  const handleRenameTrack = useCallback(
    (trackId: string, name: string) => {
      const trimmed = name.trim();
      if (!trimmed) return;
      commitProject((p) => ({
        ...p,
        tracks: p.tracks.map((t) => (t.id === trackId ? { ...t, name: trimmed } : t)),
      }));
    },
    [commitProject]
  );

  const handleDeleteTrack = useCallback(
    (trackId: string) => {
      commitProject((p) => {
        if (p.tracks.length <= 1) return p;
        return {
          ...p,
          tracks: p.tracks.filter((t) => t.id !== trackId),
          clips: p.clips.filter((c) => c.trackId !== trackId),
        };
      });
    },
    [commitProject]
  );

  const handleMoveTrack = useCallback(
    (trackId: string, direction: 'up' | 'down') => {
      commitProject((p) => {
        const idx = p.tracks.findIndex((t) => t.id === trackId);
        if (idx < 0) return p;
        const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
        if (swapIdx < 0 || swapIdx >= p.tracks.length) return p;
        const nextTracks = [...p.tracks];
        const tmp = nextTracks[idx];
        nextTracks[idx] = nextTracks[swapIdx];
        nextTracks[swapIdx] = tmp;
        return { ...p, tracks: nextTracks };
      });
    },
    [commitProject]
  );

  const handleReorderTracks = useCallback(
    (fromIndex: number, toIndex: number) => {
      if (fromIndex === toIndex) return;
      commitProject((p) => {
        if (
          fromIndex < 0 ||
          toIndex < 0 ||
          fromIndex >= p.tracks.length ||
          toIndex >= p.tracks.length
        ) {
          return p;
        }
        const nextTracks = [...p.tracks];
        const [moved] = nextTracks.splice(fromIndex, 1);
        nextTracks.splice(toIndex, 0, moved);
        return { ...p, tracks: nextTracks };
      });
    },
    [commitProject]
  );

  const handleSetTrackColor = useCallback(
    (trackId: string, color: MarkerColor) => {
      commitProject((p) => ({
        ...p,
        tracks: p.tracks.map((t) => (t.id === trackId ? { ...t, color } : t)),
      }));
    },
    [commitProject]
  );

  const handleToggleTrackCollapsed = useCallback(
    (trackId: string) => {
      commitProject(
        (p) => ({
          ...p,
          tracks: p.tracks.map((t) =>
            t.id === trackId
              ? { ...t, collapsed: t.collapsed === undefined ? false : !t.collapsed }
              : t
          ),
        }),
        false
      );
    },
    [commitProject]
  );

  // Clip Manipulation & Direct Canvas Drag History Coalescing (with Auto-Keyframe recording)
  const handleUpdateClip = useCallback(
    (clipId: string, updater: (c: TimelineClip) => TimelineClip, commitHist = true) => {
      commitProject(
        (p) => ({
          ...p,
          clips: p.clips.map((c) => {
            if (c.id !== clipId) return c;
            const nextClip = updater(c);
            if (!autoKeyframeEnabled || nextClip.keyframes !== c.keyframes) {
              return nextClip;
            }
            const relTime = Math.round(
              Math.max(0, Math.min(nextClip.duration, playheadTime - nextClip.startTime)) * 100
            ) / 100;
            const diffs: Array<{ prop: KeyframeProperty; prev: number; next: number }> = [
              { prop: 'x', prev: c.transform.x, next: nextClip.transform.x },
              { prop: 'y', prev: c.transform.y, next: nextClip.transform.y },
              { prop: 'z', prev: c.transform.zDepth, next: nextClip.transform.zDepth },
              { prop: 'scale', prev: c.transform.scale, next: nextClip.transform.scale },
              { prop: 'scaleX', prev: c.transform.scaleX ?? 1, next: nextClip.transform.scaleX ?? 1 },
              { prop: 'scaleY', prev: c.transform.scaleY ?? 1, next: nextClip.transform.scaleY ?? 1 },
              { prop: 'rotation', prev: c.transform.rotation, next: nextClip.transform.rotation },
              { prop: 'rotX', prev: c.transform.rotX, next: nextClip.transform.rotX },
              { prop: 'rotY', prev: c.transform.rotY, next: nextClip.transform.rotY },
              { prop: 'anchorX', prev: c.transform.anchorX, next: nextClip.transform.anchorX },
              { prop: 'anchorY', prev: c.transform.anchorY, next: nextClip.transform.anchorY },
              { prop: 'opacity', prev: c.transform.opacity, next: nextClip.transform.opacity },
              { prop: 'blur', prev: c.effects.blur, next: nextClip.effects.blur },
              { prop: 'glow', prev: c.effects.glow, next: nextClip.effects.glow },
              { prop: 'maskRadius', prev: c.mask.radiusX, next: nextClip.mask.radiusX },
              { prop: 'maskFeather', prev: c.mask.feather, next: nextClip.mask.feather },
              { prop: 'maskExpansion', prev: c.mask.expansion ?? 0, next: nextClip.mask.expansion ?? 0 },
            ];
            if (c.textProps && nextClip.textProps) {
              diffs.push(
                { prop: 'fontSize', prev: c.textProps.fontSize, next: nextClip.textProps.fontSize },
                {
                  prop: 'textTracking',
                  prev: c.textProps.letterSpacing ?? 0,
                  next: nextClip.textProps.letterSpacing ?? 0,
                }
              );
            }
            const changed = diffs.filter((d) => Math.abs(d.next - d.prev) > 1e-4);
            if (changed.length === 0) return nextClip;
            let kfs: Keyframe[] = [...nextClip.keyframes];
            for (const item of changed) {
              const idx = kfs.findIndex(
                (k) => k.property === item.prop && Math.abs(k.time - relTime) < 0.06
              );
              if (idx >= 0) {
                kfs[idx] = { ...kfs[idx], value: item.next };
              } else {
                kfs.push({
                  id: `kf-auto-${Date.now()}-${item.prop}-${Math.random().toString(36).slice(2, 5)}`,
                  time: relTime,
                  property: item.prop,
                  value: item.next,
                  easing: 'easeInOut',
                  bezier: [0.42, 0, 0.58, 1],
                });
              }
            }
            return { ...nextClip, keyframes: kfs };
          }),
        }),
        commitHist
      );
    },
    [commitProject, autoKeyframeEnabled, playheadTime]
  );

  const handleBatchUpdateClips = useCallback(
    (updates: Record<string, (c: TimelineClip) => TimelineClip>, commitHist = true) => {
      commitProject(
        (p) => ({
          ...p,
          clips: p.clips.map((c) => (updates[c.id] ? updates[c.id](c) : c)),
        }),
        commitHist
      );
    },
    [commitProject]
  );

  const handleBeginDragHistory = useCallback(() => {
    dragCheckpointRef.current = project;
  }, [project]);

  const handleEndDragHistory = useCallback(() => {
    const snapshot = dragCheckpointRef.current;
    if (!snapshot) return;
    dragCheckpointRef.current = null;
    setUndoStack((st) => [...st.slice(-39), snapshot]);
    setRedoStack([]);
  }, []);

  const handleGroupSelected = useCallback(() => {
    if (selectedClipIds.length < 2) return;
    const groupId = `grp-${Date.now().toString(36)}`;
    const newGroup: ClipGroup = {
      id: groupId,
      name: `Group ${(project.groups?.length || 0) + 1}`,
      clipIds: [...selectedClipIds],
    };
    commitProject((p) => ({
      ...p,
      groups: [...(p.groups || []), newGroup],
      clips: p.clips.map((c) => (selectedClipIds.includes(c.id) ? { ...c, groupId } : c)),
    }));
  }, [selectedClipIds, project.groups, commitProject]);

  const handleUngroupSelected = useCallback(() => {
    const selectedGroupIds = new Set(
      project.clips
        .filter((c) => selectedClipIds.includes(c.id) && c.groupId)
        .map((c) => c.groupId!)
    );
    if (selectedGroupIds.size === 0) return;
    commitProject((p) => ({
      ...p,
      groups: (p.groups || []).filter((g) => !selectedGroupIds.has(g.id)),
      clips: p.clips.map((c) =>
        c.groupId && selectedGroupIds.has(c.groupId) ? { ...c, groupId: undefined } : c
      ),
    }));
  }, [project.clips, selectedClipIds, commitProject]);

  const handleSplitClip = useCallback(
    (clipId: string, splitTime: number) => {
      let createdSecondHalfId: string | null = null;
      commitProject((p) => {
        const target = p.clips.find((c) => c.id === clipId);
        if (!target) return p;
        const rel = splitTime - target.startTime;
        if (rel <= 0.15 || rel >= target.duration - 0.15) return p;

        const firstHalf: TimelineClip = {
          ...target,
          duration: Math.round(rel * 100) / 100,
        };
        const secondHalf: TimelineClip = {
          ...target,
          id: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          startTime: Math.round(splitTime * 100) / 100,
          duration: Math.round((target.duration - rel) * 100) / 100,
          sourceOffset: target.sourceOffset + rel * target.speed,
        };
        createdSecondHalfId = secondHalf.id;
        return {
          ...p,
          clips: p.clips.flatMap((c) => (c.id === clipId ? [firstHalf, secondHalf] : [c])),
        };
      });
      if (createdSecondHalfId) {
        setSelectedClipId(createdSecondHalfId);
        setSelectedClipIds([createdSecondHalfId]);
      }
    },
    [commitProject]
  );

  const handleMergeWithNext = useCallback(
    (clipId: string) => {
      commitProject((p) => {
        const target = p.clips.find((c) => c.id === clipId);
        if (!target) return p;
        const sameTrack = p.clips
          .filter((c) => c.trackId === target.trackId && c.startTime > target.startTime)
          .sort((a, b) => a.startTime - b.startTime);
        const nextClip = sameTrack[0];
        if (!nextClip) return p;

        const mergedDuration = Math.max(
          target.duration,
          nextClip.startTime + nextClip.duration - target.startTime
        );
        const updated: TimelineClip = {
          ...target,
          duration: mergedDuration,
          name: `${target.name} +`,
        };
        return {
          ...p,
          clips: p.clips
            .filter((c) => c.id !== nextClip.id)
            .map((c) => (c.id === target.id ? updated : c)),
        };
      });
    },
    [commitProject]
  );

  const handleDeleteClip = useCallback(
    (clipId: string) => {
      const idsToDelete =
        selectedClipIds.includes(clipId) && selectedClipIds.length > 1
          ? selectedClipIds
          : [clipId];
      const delSet = new Set(idsToDelete);
      commitProject((p) => ({
        ...p,
        clips: p.clips
          .filter((c) => !delSet.has(c.id))
          .map((c) =>
            c.parentClipId && delSet.has(c.parentClipId)
              ? reparentClipPreserveWorld(c, undefined, p, playheadTime)
              : c
          ),
      }));
      if (selectedClipId && delSet.has(selectedClipId)) setSelectedClipId(null);
      setSelectedClipIds((prev) => prev.filter((id) => !delSet.has(id)));
    },
    [commitProject, selectedClipId, selectedClipIds, playheadTime]
  );

  const handleRippleDeleteClip = useCallback(
    (clipId: string) => {
      commitProject((p) => {
        const target = p.clips.find((c) => c.id === clipId);
        if (!target) return p;
        const shiftGap = target.duration;
        const deletedEnd = target.startTime + target.duration;
        return {
          ...p,
          clips: p.clips
            .filter((c) => c.id !== clipId)
            .map((c) => {
              let next =
                c.parentClipId === clipId
                  ? reparentClipPreserveWorld(c, undefined, p, playheadTime)
                  : c;
              if (next.trackId === target.trackId && next.startTime >= deletedEnd - 0.02) {
                next = {
                  ...next,
                  startTime: Math.max(0, Math.round((next.startTime - shiftGap) * 100) / 100),
                };
              }
              return next;
            }),
        };
      });
      if (selectedClipId === clipId) setSelectedClipId(null);
      setSelectedClipIds((prev) => prev.filter((id) => id !== clipId));
    },
    [commitProject, playheadTime, selectedClipId]
  );

  const handleCopyAttributes = useCallback(
    (clipId: string) => {
      const clip = project.clips.find((c) => c.id === clipId);
      if (!clip) return;
      setCopiedAttributes({
        transform: structuredClone(clip.transform || createDefaultTransform()),
        effects: structuredClone(clip.effects || createDefaultEffects()),
        effectsStack: clip.effectsStack ? structuredClone(clip.effectsStack) : undefined,
        colorGrade: structuredClone(clip.colorGrade || createDefaultColorGrade()),
        speed: clip.speed,
        volume: clip.volume,
        blendMode: clip.blendMode,
      });
    },
    [project.clips]
  );

  const handlePasteAttributes = useCallback(
    (clipId: string) => {
      if (!copiedAttributes) return;
      handleUpdateClip(clipId, (c) => ({
        ...c,
        transform: structuredClone(copiedAttributes.transform || createDefaultTransform()),
        effects: structuredClone(copiedAttributes.effects || createDefaultEffects()),
        effectsStack: copiedAttributes.effectsStack
          ? copiedAttributes.effectsStack.map((fx, i) => ({
              ...structuredClone(fx),
              id: `fx-paste-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 5)}`,
            }))
          : c.effectsStack,
        colorGrade: structuredClone(copiedAttributes.colorGrade || createDefaultColorGrade()),
        speed: copiedAttributes.speed,
        volume: copiedAttributes.volume,
        blendMode: copiedAttributes.blendMode,
      }));
    },
    [copiedAttributes, handleUpdateClip]
  );

  const handleDuplicateClip = useCallback(
    (clipId: string) => {
      const idsToDup =
        selectedClipIds.includes(clipId) && selectedClipIds.length > 1
          ? selectedClipIds
          : [clipId];
      const createdIds: string[] = [];
      commitProject((p) => {
        const copies: TimelineClip[] = [];
        for (const id of idsToDup) {
          const orig = p.clips.find((c) => c.id === id);
          if (!orig) continue;
          const dupId = `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
          createdIds.push(dupId);
          copies.push({
            ...structuredClone(orig),
            id: dupId,
            name: `${orig.name} Copy`,
            startTime: orig.startTime + (orig.type === 'null' || orig.type === 'fx' ? 0.5 : orig.duration),
          });
        }
        return copies.length > 0 ? { ...p, clips: [...p.clips, ...copies] } : p;
      });
      if (createdIds.length > 0) {
        setSelectedClipId(createdIds[0]);
        setSelectedClipIds(createdIds);
      }
    },
    [selectedClipIds, commitProject]
  );

  // World-Preserving Parent Assignment (supports multi-selection & cycle guard)
  const handleSetClipParent = useCallback(
    (clipId: string, parentId: string | undefined) => {
      const targetIds =
        selectedClipIds.includes(clipId) && selectedClipIds.length > 1
          ? selectedClipIds
          : [clipId];
      commitProject((p) => ({
        ...p,
        clips: p.clips.map((c) => {
          if (!targetIds.includes(c.id)) return c;
          if (parentId && (c.id === parentId || wouldCreateParentCycle(c.id, parentId, p.clips))) {
            return c;
          }
          return reparentClipPreserveWorld(c, parentId, p, playheadTime);
        }),
      }));
    },
    [selectedClipIds, commitProject, playheadTime]
  );

  const handleCopyClip = useCallback(
    (clipId: string) => {
      const found = project.clips.find((c) => c.id === clipId);
      if (found) setClipboardClip(found);
    },
    [project.clips]
  );

  const handleCutClip = useCallback(
    (clipId: string) => {
      const found = project.clips.find((c) => c.id === clipId);
      if (!found) return;
      setClipboardClip(found);
      handleDeleteClip(clipId);
    },
    [project.clips, handleDeleteClip]
  );

  const handlePasteClip = useCallback(
    (atTime?: number) => {
      if (!clipboardClip) return;
      const newClip: TimelineClip = {
        ...structuredClone(clipboardClip),
        id: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        startTime: atTime !== undefined ? Math.max(0, atTime) : playheadTime,
      };
      commitProject((p) => ({ ...p, clips: [...p.clips, newClip] }));
      setSelectedClipId(newClip.id);
      setSelectedClipIds([newClip.id]);
    },
    [clipboardClip, playheadTime, commitProject]
  );

  // Timeline Marker Manipulation
  const handleAddMarker = useCallback(
    (time: number, color: MarkerColor = 'rose', label?: string) => {
      const cleanTime = Math.round(Math.max(0, time) * 100) / 100;
      const existingCount = (project.markers ?? []).length;
      const newMarker: TimelineMarker = {
        id: `marker-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        time: cleanTime,
        label: label || `Marker ${existingCount + 1}`,
        notes: '',
        color,
      };
      commitProject((p) => ({
        ...p,
        markers: [...(p.markers ?? []), newMarker].sort((a, b) => a.time - b.time),
      }));
      setSelectedMarkerId(newMarker.id);
    },
    [project.markers, commitProject]
  );

  const handleUpdateMarker = useCallback(
    (
      markerId: string,
      updater: (m: TimelineMarker) => TimelineMarker,
      commitHist = true
    ) => {
      commitProject(
        (p) => ({
          ...p,
          markers: (p.markers ?? [])
            .map((m) => (m.id === markerId ? updater(m) : m))
            .sort((a, b) => a.time - b.time),
        }),
        commitHist
      );
    },
    [commitProject]
  );

  const handleDeleteMarker = useCallback(
    (markerId: string) => {
      commitProject((p) => ({
        ...p,
        markers: (p.markers ?? []).filter((m) => m.id !== markerId),
      }));
      setSelectedMarkerId((curr) => (curr === markerId ? null : curr));
    },
    [commitProject]
  );

  const handleAddTextClip = useCallback(
    (
      text = 'RED EFFECT TITLE',
      isSubtitle = false,
      presetOverrides?: Partial<TextProperties>,
      posOverride?: { x: number; y: number }
    ) => {
      const targetTextTrack =
        project.tracks.find((t) => t.kind === 'text')?.id ||
        project.tracks[0]?.id ||
        'T1';
      const displayText = presetOverrides?.text || text;
      const newClip = createClipDefaults({
        id: `clip-${Date.now()}`,
        assetId: 'text-asset',
        trackId: targetTextTrack,
        name: isSubtitle
          ? `Sub · ${displayText.slice(0, 14)}`
          : `Title · ${displayText.slice(0, 14)}`,
        type: 'text',
        startTime: playheadTime,
        duration: 4,
        textProps: {
          text: displayText,
          fontFamily: 'Outfit',
          fontSize: isSubtitle ? 40 : 68,
          fontWeight: 700,
          color: '#FFFFFF',
          strokeColor: '#E50914',
          strokeWidth: isSubtitle ? 0 : 2,
          backgroundColor: isSubtitle ? 'rgba(9,9,11,0.78)' : 'transparent',
          animation: isSubtitle ? 'none' : 'fade-up',
          isSubtitle,
          align: 'center',
          letterSpacing: 0,
          lineHeight: 1.2,
          revealProgress: 100,
          granularity: 'character',
          pathMode: 'none',
          shadowBlur: 12,
          shadowColor: 'rgba(0,0,0,0.75)',
          extrude3D: false,
          extrudeDepth: 0,
          ...presetOverrides,
        },
        transform: {
          x: posOverride ? posOverride.x : 0,
          y: posOverride ? posOverride.y : isSubtitle ? 36 : 0,
          scale: 1,
          rotation: 0,
          opacity: 1,
          anchorX: 0.5,
          anchorY: 0.5,
          zDepth: 0,
          rotX: 0,
          rotY: 0,
        },
      });
      commitProject((p) => ({ ...p, clips: [...p.clips, newClip] }));
      handleSelectClip(newClip.id);
    },
    [playheadTime, project.tracks, commitProject, handleSelectClip]
  );

  const handleAddTextAtPosition = useCallback(
    (xPct: number, yPct: number) => {
      handleAddTextClip('RED EFFECT TITLE', false, undefined, { x: xPct, y: yPct });
    },
    [handleAddTextClip]
  );

  const handleAddNullClip = useCallback(() => {
    const nullCount = project.clips.filter((c) => c.type === 'null').length + 1;
    const newClipId = `null-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
    commitProject((p) => {
      let targetTrack = p.tracks.find((t) => t.kind === 'null')?.id;
      let nextTracks = p.tracks;
      if (!targetTrack) {
        const firstVisualIdx = p.tracks.findIndex((t) => t.kind !== 'audio');
        const newTrack: TimelineTrack = {
          id: `N${p.tracks.filter((t) => t.kind === 'null').length + 1}-${Date.now().toString(36).slice(-3)}`,
          name: `N${p.tracks.filter((t) => t.kind === 'null').length + 1} · Null Rig`,
          kind: 'null',
          muted: false,
          solo: false,
          locked: false,
          visible: true,
          volume: 1,
          pan: 0,
          color: 'rose',
          collapsed: true,
        };
        targetTrack = newTrack.id;
        nextTracks =
          firstVisualIdx <= 0
            ? [newTrack, ...p.tracks]
            : [...p.tracks.slice(0, firstVisualIdx), newTrack, ...p.tracks.slice(firstVisualIdx)];
      }
      const newClip = createClipDefaults({
        id: newClipId,
        assetId: 'null-controller',
        trackId: targetTrack,
        name: `Null ${nullCount}`,
        type: 'null',
        labelColor: 'rose',
        startTime: playheadTime,
        duration: 6,
      });
      return { ...p, tracks: nextTracks, clips: [...p.clips, newClip] };
    });
    setSelectedClipId(newClipId);
    setSelectedClipIds([newClipId]);
  }, [project.clips, playheadTime, commitProject]);

  const handleAddEffectLayer = useCallback(() => {
    const fxCount = project.clips.filter((c) => c.type === 'fx').length + 1;
    const newClipId = `fx-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
    commitProject((p) => {
      let targetTrack = p.tracks.find((t) => t.kind === 'fx')?.id;
      let nextTracks = p.tracks;
      if (!targetTrack) {
        const newTrack: TimelineTrack = {
          id: `FX${p.tracks.filter((t) => t.kind === 'fx').length + 1}-${Date.now().toString(36).slice(-3)}`,
          name: `FX${p.tracks.filter((t) => t.kind === 'fx').length + 1} · Adjustment`,
          kind: 'fx',
          muted: false,
          solo: false,
          locked: false,
          visible: true,
          volume: 1,
          pan: 0,
          color: 'violet',
          collapsed: true,
        };
        targetTrack = newTrack.id;
        nextTracks = [newTrack, ...p.tracks];
      }
      const newClip = createClipDefaults({
        id: newClipId,
        assetId: 'fx-adjustment',
        trackId: targetTrack,
        name: `Adjustment Layer ${fxCount}`,
        type: 'fx',
        labelColor: 'violet',
        startTime: playheadTime,
        duration: 6,
      });
      return { ...p, tracks: nextTracks, clips: [...p.clips, newClip] };
    });
    setSelectedClipId(newClipId);
    setSelectedClipIds([newClipId]);
    setForcePropertiesTabSignal((prev) => ({
      clipId: newClipId,
      tab: 'effects',
      seq: (prev?.seq || 0) + 1,
    }));
  }, [project.clips, playheadTime, commitProject]);

  const handleDetachAudio = useCallback(
    (clipId: string) => {
      const src = project.clips.find((c) => c.id === clipId);
      if (!src || src.type !== 'video') return;
      const newAudioId = `clip-audio-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
      commitProject((p) => {
        let audioTrackId = p.tracks.find((t) => t.kind === 'audio')?.id;
        let nextTracks = p.tracks;
        if (!audioTrackId) {
          const newTrack: TimelineTrack = {
            id: `A${p.tracks.filter((t) => t.kind === 'audio').length + 1}-${Date.now().toString(36).slice(-3)}`,
            name: 'A · Detached Audio',
            kind: 'audio',
            muted: false,
            solo: false,
            locked: false,
            visible: true,
            volume: 1,
            pan: 0,
            color: 'emerald',
            collapsed: true,
          };
          audioTrackId = newTrack.id;
          nextTracks = [...p.tracks, newTrack];
        }
        const detachedClip = createClipDefaults({
          id: newAudioId,
          assetId: src.assetId,
          trackId: audioTrackId,
          name: `${src.name} (Audio)`,
          type: 'audio',
          startTime: src.startTime,
          duration: src.duration,
          sourceOffset: src.sourceOffset,
          speed: src.speed,
          volume: src.volume,
          fadeIn: src.fadeIn,
          fadeOut: src.fadeOut,
          muted: false,
          labelColor: 'emerald',
        });
        return {
          ...p,
          tracks: nextTracks,
          clips: [
            ...p.clips.map((c) => (c.id === clipId ? { ...c, muted: true } : c)),
            detachedClip,
          ],
        };
      });
      setSelectedClipId(newAudioId);
      setSelectedClipIds([newAudioId]);
    },
    [project.clips, commitProject]
  );

  const handleCreateCompoundClip = useCallback(() => {
    if (selectedClipIds.length >= 2) {
      handleGroupSelected();
      return;
    }
    if (!selectedClipId) return;
    const groupId = `grp-${Date.now().toString(36)}`;
    commitProject((p) => ({
      ...p,
      groups: [
        ...(p.groups || []),
        { id: groupId, name: 'Compound Group', clipIds: [selectedClipId] },
      ],
      clips: p.clips.map((c) => (c.id === selectedClipId ? { ...c, groupId } : c)),
    }));
  }, [selectedClipIds, selectedClipId, handleGroupSelected, commitProject]);

  const handleConvertTextToShape = useCallback(
    (clipId: string) => {
      commitProject((p) => ({
        ...p,
        clips: p.clips.map((c) => {
          if (c.id !== clipId || c.type !== 'text') return c;
          return {
            ...c,
            type: 'shape',
            name: `${c.name} (Shape)`,
            shapeProps: {
              shape: 'rectangle',
              fillColor: c.textProps?.color || '#E50914',
              fillOpacity: 0.9,
              strokeColor: c.textProps?.strokeColor || '#FFFFFF',
              strokeWidth: c.textProps?.strokeWidth || 2,
              cornerRadius: 16,
              points: 4,
              innerRadius: 0.5,
              widthPct: 38,
              heightPct: 16,
              closed: true,
              pathPoints: [],
            },
          };
        }),
      }));
    },
    [commitProject]
  );

  const handleFocusEffectInProperties = useCallback(
    (clipId: string) => {
      const target = project.clips.find((c) => c.id === clipId);
      setSelectedClipId(clipId);
      setSelectedClipIds([clipId]);
      setClosedPanels((prev) => prev.filter((p) => p !== 'properties'));
      setRightCollapsed(false);
      setSlots((s) => ({ ...s, right: 'properties' }));
      setForcePropertiesTabSignal((prev) => ({
        clipId,
        tab: target?.type === 'fx' && target.fxMeta?.category === 'cc' ? 'color' : 'effects',
        seq: (prev?.seq || 0) + 1,
      }));
    },
    [project.clips]
  );

  const handleOpenSpeedDuration = useCallback(
    (clipId: string) => {
      const target = project.clips.find((c) => c.id === clipId);
      if (!target) return;
      setSpeedDraft({
        speed: target.speed,
        duration: target.duration,
        reverse: target.reverse,
      });
      setSpeedDurationClipId(clipId);
    },
    [project.clips]
  );

  const handleAddShapeClip = useCallback(
    (
      shape: ShapeKind = 'rectangle',
      customLabel?: string,
      shapeOverrides?: Partial<ShapeProperties>
    ) => {
      const targetTrack =
        project.tracks.find((t) => t.kind === 'shape')?.id ||
        project.tracks.find((t) => t.kind === 'text')?.id ||
        project.tracks.find((t) => t.kind !== 'audio')?.id ||
        'T1';
      const label = customLabel || shape.charAt(0).toUpperCase() + shape.slice(1).replace('-', ' ');
      const newClip = createClipDefaults({
        id: `shape-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        assetId: 'shape-vector',
        trackId: targetTrack,
        name: customLabel ? `Sticker · ${label}` : `Shape · ${label}`,
        type: 'shape',
        startTime: playheadTime,
        duration: 5,
        shapeProps: {
          shape,
          fillColor: '#E50914',
          fillOpacity: 0.9,
          strokeColor: '#FFFFFF',
          strokeWidth: 4,
          cornerRadius: 18,
          points: shape === 'polygon' ? 6 : 5,
          innerRadius: 0.48,
          widthPct: 28,
          heightPct: 28,
          closed: true,
          pathPoints:
            shape === 'custom-path'
              ? [
                  { x: -0.18, y: -0.16, inX: -0.05, inY: 0, outX: 0.05, outY: 0 },
                  { x: 0.18, y: -0.14, inX: -0.05, inY: 0, outX: 0.05, outY: 0 },
                  { x: 0.22, y: 0.16, inX: 0, inY: -0.05, outX: 0, outY: 0.05 },
                  { x: -0.2, y: 0.14, inX: 0, inY: 0.05, outX: 0, outY: -0.05 },
                ]
              : [],
          ...shapeOverrides,
        },
      });
      commitProject((p) => ({ ...p, clips: [...p.clips, newClip] }));
      handleSelectClip(newClip.id);
    },
    [project.tracks, playheadTime, commitProject, handleSelectClip]
  );

  const handleAddBuiltinAudioAsset = useCallback(
    (asset: MediaAsset) => {
      let createdAudioClipId: string | null = null;
      commitProject((p) => {
        const exists = p.assets.some((a) => a.id === asset.id);
        const audioTrackId =
          p.tracks.find((t) => t.kind === 'audio')?.id ||
          p.tracks[p.tracks.length - 1]?.id ||
          'A1';
        const audioClip = createClipDefaults({
          id: `clip-aud-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
          assetId: asset.id,
          trackId: audioTrackId,
          name: asset.name,
          type: 'audio',
          startTime: playheadTime,
          duration: asset.duration,
          labelColor: 'emerald',
        });
        createdAudioClipId = audioClip.id;
        return {
          ...p,
          assets: exists ? p.assets : [asset, ...p.assets],
          clips: [...p.clips, audioClip],
        };
      });
      if (createdAudioClipId) {
        setSelectedClipId(createdAudioClipId);
        setSelectedClipIds([createdAudioClipId]);
      }
    },
    [commitProject, playheadTime]
  );

  const handleAddEffectToClip = useCallback(
    (effectType: string, targetClipId?: string) => {
      const clipId =
        targetClipId || selectedClipId || project.clips.find((c) => c.type !== 'audio')?.id;
      if (!clipId) return;
      const fx = createEffectInstance(effectType);
      if (!fx) return;
      handleUpdateClip(clipId, (c) => ({
        ...c,
        effectsStack: [...(c.effectsStack || []), fx],
      }));
      handleSelectClip(clipId);
    },
    [selectedClipId, project.clips, handleUpdateClip, handleSelectClip]
  );

  const handleApplyTransition = useCallback(
    (
      side: 'in' | 'out' | 'both',
      settingsObj: TransitionSettings,
      targetClipId?: string
    ) => {
      const clipId =
        targetClipId || selectedClipId || project.clips.find((c) => c.type !== 'audio')?.id;
      if (!clipId) return;
      handleUpdateClip(clipId, (c) => ({
        ...c,
        transitionIn: side === 'out' ? c.transitionIn : settingsObj.type,
        transitionInDuration:
          side === 'out' ? c.transitionInDuration : settingsObj.duration,
        transitionInConfig:
          side === 'out' ? c.transitionInConfig : structuredClone(settingsObj),
        transitionOut: side === 'in' ? c.transitionOut : settingsObj.type,
        transitionOutDuration:
          side === 'in' ? c.transitionOutDuration : settingsObj.duration,
        transitionOutConfig:
          side === 'in' ? c.transitionOutConfig : structuredClone(settingsObj),
      }));
      handleSelectClip(clipId);
    },
    [selectedClipId, project.clips, handleUpdateClip, handleSelectClip]
  );

  const handleApplyPresetToClips = useCallback(
    (preset: StudioPreset, clipIds: string[]) => {
      const targets =
        clipIds.length > 0
          ? clipIds
          : selectedClipId
          ? [selectedClipId]
          : project.clips.find((c) => c.type !== 'audio')
          ? [project.clips.find((c) => c.type !== 'audio')!.id]
          : [];
      if (targets.length === 0) return;

      commitProject((p) => ({
        ...p,
        clips: p.clips.map((c) => {
          if (!targets.includes(c.id)) return c;
          const nextEffectsStack = preset.effectsStack
            ? preset.effectsStack.map((fx) => ({
                ...structuredClone(fx),
                id: `fx-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
              }))
            : c.effectsStack;
          const nextKeyframes = preset.keyframes
            ? preset.keyframes.map((k, idx) => ({
                id: `kf-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
                time: Math.round(k.timeRatio * c.duration * 100) / 100,
                property: k.property as KeyframeProperty,
                value: k.value,
                easing: k.easing,
                bezier: k.bezier ? ([...k.bezier] as [number, number, number, number]) : undefined,
              }))
            : c.keyframes;
          return {
            ...c,
            effectsStack: nextEffectsStack,
            transitionIn: preset.transitionIn ? preset.transitionIn.type : c.transitionIn,
            transitionInDuration: preset.transitionIn
              ? preset.transitionIn.duration
              : c.transitionInDuration,
            transitionInConfig: preset.transitionIn
              ? structuredClone(preset.transitionIn)
              : c.transitionInConfig,
            transitionOut: preset.transitionOut ? preset.transitionOut.type : c.transitionOut,
            transitionOutDuration: preset.transitionOut
              ? preset.transitionOut.duration
              : c.transitionOutDuration,
            transitionOutConfig: preset.transitionOut
              ? structuredClone(preset.transitionOut)
              : c.transitionOutConfig,
            textProps:
              c.type === 'text' && c.textProps && preset.textStyle
                ? { ...c.textProps, ...(preset.textStyle as Partial<TextProperties>) }
                : c.textProps,
            keyframes: nextKeyframes,
          };
        }),
      }));
    },
    [selectedClipId, project.clips, commitProject]
  );

  const handleSaveReadyMadePreset = useCallback((preset: ReadyMadeEffectPreset) => {
    setCustomReadyPresets(saveCustomReadyPreset(preset));
  }, []);

  const handleDeleteReadyMadePreset = useCallback((id: string) => {
    setCustomReadyPresets(deleteCustomReadyPreset(id));
  }, []);

  const handleApplyReadyMadePreset = useCallback(
    (
      preset: ReadyMadeEffectPreset,
      targetClipId?: string,
      dropTime?: number,
      dropTrackId?: string
    ) => {
      clearHoverPreviewImmediate();

      // 1. Transition preset
      if (preset.category === 'transition' && preset.transitionConfig) {
        const clipId =
          targetClipId ||
          selectedClipId ||
          project.clips.find(
            (c) =>
              c.type !== 'audio' &&
              c.type !== 'fx' &&
              playheadTime >= c.startTime &&
              playheadTime <= c.startTime + c.duration
          )?.id ||
          project.clips.find((c) => c.type !== 'audio' && c.type !== 'fx')?.id;
        if (!clipId) return;
        handleApplyTransition('in', preset.transitionConfig, clipId);
        setClosedPanels((prev) => prev.filter((p) => p !== 'properties'));
        setRightCollapsed(false);
        setSlots((s) => ({ ...s, right: 'properties' }));
        setForcePropertiesTabSignal((prev) => ({
          clipId,
          tab: 'effects',
          seq: (prev?.seq || 0) + 1,
        }));
        return;
      }

      // 2. Text Effect preset
      if (preset.category === 'text' && preset.textPreset) {
        const tp = preset.textPreset;
        const explicitTarget = targetClipId
          ? project.clips.find((c) => c.id === targetClipId)
          : undefined;
        const selectedTarget = selectedClipId
          ? project.clips.find((c) => c.id === selectedClipId)
          : undefined;
        const tTarget =
          explicitTarget?.type === 'text'
            ? explicitTarget
            : selectedTarget?.type === 'text'
            ? selectedTarget
            : project.clips.find(
                (c) =>
                  c.type === 'text' &&
                  (dropTime ?? playheadTime) >= c.startTime &&
                  (dropTime ?? playheadTime) <= c.startTime + c.duration
              );

        if (tTarget && tTarget.textProps) {
          handleUpdateClip(tTarget.id, (c) => ({
            ...c,
            textProps: {
              ...(c.textProps as TextProperties),
              animation: tp.animation,
              effectSpeed: tp.effectSpeed,
              effectIntensity: tp.effectIntensity,
              effectDuration: tp.effectDuration,
              effectDirection: tp.effectDirection,
              animationStrength: tp.animationStrength,
              fontWeight: tp.fontWeight ?? c.textProps?.fontWeight,
              color: tp.color ?? c.textProps?.color ?? '#FFFFFF',
              strokeColor: tp.strokeColor ?? c.textProps?.strokeColor ?? '#000000',
              strokeWidth: tp.strokeWidth ?? c.textProps?.strokeWidth ?? 2,
              shadowBlur: tp.shadowBlur ?? c.textProps?.shadowBlur,
              shadowColor: tp.shadowColor ?? c.textProps?.shadowColor,
              extrude3D: tp.extrude3D ?? c.textProps?.extrude3D,
              extrudeDepth: tp.extrudeDepth ?? c.textProps?.extrudeDepth,
              letterSpacing: tp.letterSpacing ?? c.textProps?.letterSpacing,
              gradientEnabled: tp.gradientEnabled ?? c.textProps?.gradientEnabled,
              gradientStart: tp.gradientStart ?? c.textProps?.gradientStart,
              gradientEnd: tp.gradientEnd ?? c.textProps?.gradientEnd,
            },
          }));
          handleSelectClip(tTarget.id);
          setClosedPanels((prev) => prev.filter((p) => p !== 'properties'));
          setRightCollapsed(false);
          setSlots((s) => ({ ...s, right: 'properties' }));
          setForcePropertiesTabSignal((prev) => ({
            clipId: tTarget.id,
            tab: 'effects',
            seq: (prev?.seq || 0) + 1,
          }));
        } else {
          handleAddTextClip(preset.name.toUpperCase(), false, {
            animation: tp.animation,
            effectSpeed: tp.effectSpeed,
            effectIntensity: tp.effectIntensity,
            effectDuration: tp.effectDuration,
            effectDirection: tp.effectDirection,
            animationStrength: tp.animationStrength,
            fontWeight: tp.fontWeight ?? 800,
            color: tp.color || '#FFFFFF',
            strokeColor: tp.strokeColor || '#000000',
            strokeWidth: tp.strokeWidth ?? 2,
            shadowBlur: tp.shadowBlur ?? 16,
            shadowColor: tp.shadowColor || 'rgba(0,0,0,0.8)',
            extrude3D: tp.extrude3D,
            extrudeDepth: tp.extrudeDepth,
            letterSpacing: tp.letterSpacing,
            gradientEnabled: tp.gradientEnabled,
            gradientStart: tp.gradientStart,
            gradientEnd: tp.gradientEnd,
          });
        }
        return;
      }

      // 3. Clip Effects (Shake, Glitch, CC, Blur, RGB, Distortion, Cinematic) -> Non-destructive FX Layer above clip!
      const newFxId = `fx-layer-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
      let openedClipId = newFxId;
      const catLabelMap: Record<string, string> = {
        shake: 'Shake',
        glitch: 'Glitch',
        cc: 'CC',
        blur: 'Blur',
        rgb: 'RGB',
        distortion: 'Distort',
        cinematic: 'Cinema',
      };
      const catPrefix = catLabelMap[preset.category] || 'FX';

      commitProject((p) => {
        const refTime = dropTime ?? playheadTime;
        let baseClip = targetClipId
          ? p.clips.find((c) => c.id === targetClipId)
          : undefined;
        if (baseClip?.type === 'fx' && baseClip.fxMeta?.targetClipId) {
          baseClip = p.clips.find((c) => c.id === baseClip!.fxMeta!.targetClipId) || baseClip;
        }
        if (!baseClip && selectedClipId) {
          const sel = p.clips.find((c) => c.id === selectedClipId);
          if (sel && sel.type !== 'audio') {
            baseClip =
              sel.type === 'fx' && sel.fxMeta?.targetClipId
                ? p.clips.find((c) => c.id === sel.fxMeta!.targetClipId) || sel
                : sel;
          }
        }
        if (!baseClip) {
          baseClip =
            p.clips.find(
              (c) =>
                c.type !== 'audio' &&
                c.type !== 'fx' &&
                refTime >= c.startTime &&
                refTime <= c.startTime + c.duration
            ) || p.clips.find((c) => c.type !== 'audio' && c.type !== 'fx');
        }

        const startTime =
          dropTime !== undefined
            ? Math.max(0, Math.round(dropTime * 100) / 100)
            : baseClip
            ? baseClip.startTime
            : Math.max(0, Math.round(playheadTime * 100) / 100);

        const defaultSpan =
          preset.category === 'shake' && baseClip
            ? Math.min(baseClip.duration, preset.defaultDuration || 2.0)
            : baseClip
            ? baseClip.duration
            : preset.defaultDuration || 3.0;
        const duration = Math.max(0.4, Math.round(defaultSpan * 100) / 100);
        const endTime = startTime + duration;

        const baseTrackIdx = baseClip
          ? p.tracks.findIndex((t) => t.id === baseClip!.trackId)
          : p.tracks.findIndex((t) => t.kind !== 'audio');
        const effectiveBaseIdx = baseTrackIdx >= 0 ? baseTrackIdx : p.tracks.length;

        const hasOverlapOnTrack = (trackId: string) =>
          p.clips.some(
            (c) =>
              c.trackId === trackId &&
              Math.max(c.startTime, startTime) < Math.min(c.startTime + c.duration, endTime) - 0.02
          );

        let nextTracks = [...p.tracks];
        let destTrackId: string | null = null;

        // If explicitly dropped on an FX track with space, honor that track
        if (dropTrackId) {
          const droppedTrack = nextTracks.find((t) => t.id === dropTrackId);
          if (droppedTrack && droppedTrack.kind === 'fx' && !hasOverlapOnTrack(droppedTrack.id)) {
            destTrackId = droppedTrack.id;
          }
        }

        // Otherwise find an existing FX track strictly above baseClip (index < effectiveBaseIdx)
        if (!destTrackId) {
          for (let idx = effectiveBaseIdx - 1; idx >= 0; idx--) {
            if (nextTracks[idx].kind === 'fx' && !hasOverlapOnTrack(nextTracks[idx].id)) {
              destTrackId = nextTracks[idx].id;
              break;
            }
          }
        }

        // If none free above baseClip, create a fresh stacked FX track right above baseClip/FX stack
        if (!destTrackId) {
          const fxCount = nextTracks.filter((t) => t.kind === 'fx').length + 1;
          const newTrack: TimelineTrack = {
            id: `FX-${Date.now().toString(36)}-${fxCount}`,
            name: `FX ${fxCount} (${catPrefix})`,
            kind: 'fx',
            muted: false,
            solo: false,
            locked: false,
            visible: true,
            volume: 1,
            pan: 0,
            color: preset.category === 'shake' ? 'rose' : preset.category === 'cc' ? 'amber' : 'sky',
          };
          // Place above any existing FX tracks or right above baseClip
          const insertIdx = Math.max(
            0,
            Math.min(
              effectiveBaseIdx,
              nextTracks.findIndex((t) => t.kind === 'fx') >= 0
                ? nextTracks.findIndex((t) => t.kind === 'fx')
                : effectiveBaseIdx
            )
          );
          nextTracks.splice(insertIdx, 0, newTrack);
          destTrackId = newTrack.id;
        }

        const clonedStack: EffectInstance[] = (preset.effectsStack || []).map((fx, i) => ({
          ...structuredClone(fx),
          id: `fx-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 5)}`,
        }));

        const fxClip = createClipDefaults({
          id: newFxId,
          assetId: 'fx-adjustment',
          trackId: destTrackId,
          name: `${catPrefix} · ${preset.name}`,
          type: 'fx',
          startTime,
          duration,
          effectsStack: clonedStack,
          ...(preset.colorGrade
            ? {
                colorGrade: {
                  ...createDefaultColorGrade(),
                  lutIntensity: 95,
                  ...(preset.colorGrade as Partial<ColorGrade>),
                },
              }
            : {}),
          fxMeta: {
            presetId: preset.id,
            presetName: preset.name,
            category: preset.category,
            targetClipId: baseClip?.id,
          },
        });

        openedClipId = fxClip.id;
        return {
          ...p,
          tracks: nextTracks,
          clips: [...p.clips, fxClip],
        };
      });

      setSelectedClipId(openedClipId);
      setSelectedClipIds([openedClipId]);
      setClosedPanels((prev) => prev.filter((p) => p !== 'properties'));
      setRightCollapsed(false);
      setSlots((s) => ({ ...s, right: 'properties' }));
      setForcePropertiesTabSignal((prev) => ({
        clipId: openedClipId,
        tab: preset.category === 'cc' ? 'color' : 'effects',
        seq: (prev?.seq || 0) + 1,
      }));
    },
    [
      selectedClipId,
      project.clips,
      playheadTime,
      handleApplyTransition,
      handleUpdateClip,
      handleSelectClip,
      handleAddTextClip,
      commitProject,
    ]
  );

  const handleApplyEffectPayload = useCallback(
    (payloadStr: string, targetClipId?: string, dropTime?: number, dropTrackId?: string) => {
      try {
        const parsed = JSON.parse(payloadStr) as {
          kind: string;
          presetId?: string;
          value?: string;
          effectType?: string;
          side?: 'in' | 'out' | 'both';
          config?: TransitionSettings;
          color?: string;
          shape?: string;
          blur?: number;
          glow?: number;
          stabilization?: number;
        };

        if (parsed.kind === 'readyPreset' && parsed.presetId) {
          const found = findReadyMadePreset(parsed.presetId, customReadyPresets);
          if (found) {
            handleApplyReadyMadePreset(found, targetClipId, dropTime, dropTrackId);
          }
          return;
        }

        if (parsed.kind === 'template') {
          handleAddTextClip(
            parsed.value === 'lower-third' ? 'DIRECTOR CUT · 2026' : 'RED EFFECT',
            parsed.value === 'lower-third'
          );
          return;
        }

        if (parsed.kind === 'effectStackItem' && parsed.effectType) {
          handleAddEffectToClip(parsed.effectType, targetClipId);
          return;
        }

        if (parsed.kind === 'transitionConfig' && parsed.config) {
          handleApplyTransition(parsed.side || 'in', parsed.config, targetClipId);
          return;
        }

        const clipId =
          targetClipId || selectedClipId || project.clips.find((c) => c.type !== 'audio')?.id;
        if (!clipId) return;

        handleUpdateClip(clipId, (c) => {
          if (parsed.kind === 'transition') {
            const trType = (parsed.value as TimelineClip['transitionIn']) || 'cross-dissolve';
            const trCfg = getDefaultTransitionSettings(trType);
            return {
              ...c,
              transitionIn: trType,
              transitionInDuration: trCfg.duration,
              transitionInConfig: trCfg,
              transitionOut: trType,
              transitionOutDuration: trCfg.duration,
              transitionOutConfig: structuredClone(trCfg),
            };
          }
          if (parsed.kind === 'colorGrade') {
            return {
              ...c,
              colorGrade: {
                ...(c.colorGrade || createDefaultColorGrade()),
                preset: (parsed.value as ColorGrade['preset']) || 'cinematic-teal-orange',
              },
            };
          }
          if (parsed.kind === 'chromaKey') {
            return {
              ...c,
              chromaKey: {
                ...(c.chromaKey || createDefaultChromaKey()),
                enabled: true,
                color: parsed.color || '#00ff00',
              },
            };
          }
          if (parsed.kind === 'mask') {
            return {
              ...c,
              mask: { ...c.mask, shape: (parsed.shape as TimelineClip['mask']['shape']) || 'circle' },
            };
          }
          if (parsed.kind === 'particles') {
            return {
              ...c,
              effects: {
                ...(c.effects || createDefaultEffects()),
                particles: (parsed.value as TimelineClip['effects']['particles']) || 'red-smoke',
              },
            };
          }
          if (parsed.kind === 'fx') {
            const safeFx = c.effects || createDefaultEffects();
            return {
              ...c,
              effects: {
                ...safeFx,
                blur: parsed.blur ?? safeFx.blur,
                glow: parsed.glow ?? safeFx.glow,
                stabilization: parsed.stabilization ?? safeFx.stabilization,
              },
            };
          }
          return c;
        });
        handleSelectClip(clipId);
      } catch {
        // Ignore malformed effect payload
      }
    },
    [
      selectedClipId,
      project.clips,
      customReadyPresets,
      handleApplyReadyMadePreset,
      handleUpdateClip,
      handleAddTextClip,
      handleAddEffectToClip,
      handleApplyTransition,
      handleSelectClip,
    ]
  );

  // Project Management Actions
  const handleCreateConfiguredProject = useCallback(
    async (config: NewProjectConfig, mediaFiles?: File[]) => {
      const fresh = normalizeProject(createCustomProject(config));
      setIsPlaying(false);
      projectRef.current = fresh;
      setProject(fresh);
      setUndoStack([]);
      setRedoStack([]);
      setPlayheadTime(0);
      setSelectedClipId(null);
      setSelectedClipIds([]);
      setSelectedMarkerId(null);
      setProjectModalState(null);
      setShowHomeScreen(false);
      setWorkspaceMode('editing');

      if (mediaFiles && mediaFiles.length > 0) {
        const imported = await handleImportFiles(mediaFiles);
        let cursor = 0;
        for (const asset of imported) {
          addAssetToTimeline(asset, undefined, asset.type === 'audio' ? 0 : cursor);
          if (asset.type !== 'audio') {
            cursor += Math.max(1, asset.duration);
          }
        }
      }

      await saveProjectToDB(projectRef.current).catch(() => {});
      const list = await loadAllProjectsFromDB().catch(() => []);
      if (list.length) setRecentProjects(list);
    },
    [handleImportFiles, addAssetToTimeline]
  );

  const handleRenameRecentProject = useCallback(async (id: string, nextName: string) => {
    const trimmed = nextName.trim();
    if (!trimmed) return;
    const all = await loadAllProjectsFromDB().catch(() => []);
    const target = all.find((p) => p.id === id) || (projectRef.current.id === id ? projectRef.current : null);
    if (!target) return;
    const updated: StudioProject = { ...target, name: trimmed, updatedAt: Date.now() };
    await saveProjectToDB(updated).catch(() => {});
    if (projectRef.current.id === id) {
      projectRef.current = updated;
      setProject(updated);
    }
    const list = await loadAllProjectsFromDB().catch(() => []);
    if (list.length) setRecentProjects(list);
  }, []);

  const handleDuplicateRecentProject = useCallback(async (rp: StudioProject) => {
    const now = Date.now();
    const copy: StudioProject = normalizeProject({
      ...structuredClone(rp),
      id: `proj-${now}-${Math.random().toString(36).slice(2, 6)}`,
      name: `${rp.name} (Copy)`,
      createdAt: now,
      updatedAt: now,
    });
    await saveProjectToDB(copy).catch(() => {});
    const list = await loadAllProjectsFromDB().catch(() => []);
    if (list.length) setRecentProjects(list);
  }, []);

  const handleExportRecentProject = useCallback((rp: StudioProject) => {
    const normalized = normalizeProject(rp);
    setIsPlaying(false);
    projectRef.current = normalized;
    setProject(normalized);
    setUndoStack([]);
    setRedoStack([]);
    setPlayheadTime(0);
    const firstId = normalized.clips[0]?.id || null;
    setSelectedClipId(firstId);
    setSelectedClipIds(firstId ? [firstId] : []);
    setSelectedMarkerId(null);
    setShowHomeScreen(false);
    setWorkspaceMode('editing');
    setShowExportModal(true);
  }, []);

  const handleCreateTemplateProject = useCallback(
    async (tpl: {
      name: string;
      width: number;
      height: number;
      fps: number;
      aspectRatio: '16:9' | '9:16' | '1:1';
    }) => {
      await handleCreateConfiguredProject({
        name: tpl.name,
        location: 'RED EFFECT APPS / Templates',
        width: tpl.width,
        height: tpl.height,
        fps: tpl.fps as NewProjectConfig['fps'],
        aspectRatio: tpl.aspectRatio,
        videoFormat: 'mp4',
        audioSampleRate: 48000,
        backgroundColor: '#101010',
        videoTrackCount: 2,
        audioTrackCount: 2,
        snapEnabled: true,
        defaultClipDuration: 5,
      });
    },
    [handleCreateConfiguredProject]
  );

  const handleUpdateProjectSettings = useCallback(
    (config: NewProjectConfig) => {
      commitProject((p) => ({
        ...p,
        name: config.name,
        location: config.location,
        width: config.width,
        height: config.height,
        fps: config.fps,
        aspectRatio: config.aspectRatio,
        videoFormat: config.videoFormat,
        audioSampleRate: config.audioSampleRate,
        backgroundColor: config.backgroundColor,
        snapEnabled: config.snapEnabled,
        defaultClipDuration: config.defaultClipDuration,
      }));
      setProjectModalState(null);
    },
    [commitProject]
  );

  const handleSaveProject = useCallback(async () => {
    await saveProjectToDB(project);
    setLastSavedAt(Date.now());
    const list = await loadAllProjectsFromDB().catch(() => []);
    if (list.length) setRecentProjects(list);
  }, [project]);

  const handleOpenProjectFromPC = useCallback(async () => {
    const opened = await openProjectFileFromDisk();
    if (opened && opened.tracks && opened.clips) {
      const normalized = normalizeProject(opened);
      setIsPlaying(false);
      projectRef.current = normalized;
      setProject(normalized);
      setUndoStack([]);
      setRedoStack([]);
      setPlayheadTime(0);
      const firstId = normalized.clips[0]?.id || null;
      setSelectedClipId(firstId);
      setSelectedClipIds(firstId ? [firstId] : []);
      setSelectedMarkerId(null);
      setShowHomeScreen(false);
      setWorkspaceMode('editing');
      await saveProjectToDB(normalized);
      const list = await loadAllProjectsFromDB().catch(() => []);
      if (list.length) setRecentProjects(list);
    }
  }, []);

  const handleLoadRecentProject = useCallback((rp: StudioProject) => {
    const normalized = normalizeProject(rp);
    setIsPlaying(false);
    projectRef.current = normalized;
    setProject(normalized);
    setUndoStack([]);
    setRedoStack([]);
    setPlayheadTime(0);
    const firstId = normalized.clips[0]?.id || null;
    setSelectedClipId(firstId);
    setSelectedClipIds(firstId ? [firstId] : []);
    setSelectedMarkerId(null);
    setShowHomeScreen(false);
    setWorkspaceMode('editing');
  }, []);

  // Interactive Tutorial Launcher & Step Panel Focusing (never overwrites existing user projects)
  const handleFocusTutorialStepPanel = useCallback(
    (step: TutorialStep) => {
      setShowHomeScreen(false);
      setMaximizedPanel(null);
      setLeftCollapsed(false);
      setRightCollapsed(false);
      setBottomCollapsed(false);

      if (step.recommendedWorkspace) {
        handleWorkspaceModeChange(step.recommendedWorkspace);
      }
      setSlots((prev) => ({
        ...prev,
        leftTop: step.recommendedLeftTop ?? prev.leftTop,
        leftBottom: step.recommendedLeftBottom ?? prev.leftBottom,
        right: step.recommendedRight ?? prev.right,
        bottom: step.recommendedBottom ?? prev.bottom,
      }));
    },
    [handleWorkspaceModeChange]
  );

  const handleStartInteractiveTutorial = useCallback(
    async (restart = false) => {
      setIsPlaying(false);
      let tutProj =
        recentProjects.find((p) => p.id === TUTORIAL_PROJECT_ID) ||
        (await loadAllProjectsFromDB()
          .then((all) => all.find((p) => p.id === TUTORIAL_PROJECT_ID))
          .catch(() => undefined));

      if (!tutProj) {
        tutProj = await buildAndPrepareTutorialProject();
        await saveProjectToDB(tutProj).catch(() => {});
        const updatedList = await loadAllProjectsFromDB().catch(() => [tutProj!]);
        setRecentProjects(updatedList.length > 0 ? updatedList : [tutProj]);
      }

      const normalizedTut = normalizeProject(tutProj);
      projectRef.current = normalizedTut;
      setProject(normalizedTut);
      setUndoStack([]);
      setRedoStack([]);
      setPlayheadTime(0);
      const preferredClipId =
        normalizedTut.clips.find((c) => c.id === 'clip-tut-null')?.id || normalizedTut.clips[0]?.id || null;
      setSelectedClipId(preferredClipId);
      setSelectedClipIds(preferredClipId ? [preferredClipId] : []);
      setSelectedMarkerId(null);
      setShowHomeScreen(false);
      setWorkspaceMode('editing');
      setSlots(DEFAULT_SLOTS);
      localStorage.setItem(FIRST_LAUNCH_DONE_KEY, '1');
      if (restart) {
        setTutorialStepIndex(0);
      }
      setTutorialOpen(true);
    },
    [recentProjects]
  );

  // Ready-Made Trailer Template Launcher (non-destructive: preserves all existing projects)
  const handleOpenTrailerTemplate = useCallback(
    async (customization?: TrailerTemplateCustomization) => {
      setIsPlaying(false);
      // Save current project safely before switching so nothing is lost
      await saveProjectToDB(project).catch(() => {});
      const tplProject = normalizeProject(buildRedRebellionProject(customization));
      await saveProjectToDB(tplProject).catch(() => {});
      const updatedList = await loadAllProjectsFromDB().catch(() => [tplProject]);
      setRecentProjects(updatedList.length > 0 ? updatedList : [tplProject]);

      projectRef.current = tplProject;
      setProject(tplProject);
      setUndoStack([]);
      setRedoStack([]);
      setPlayheadTime(0);
      setSelectedClipId('clip-rr-txt1');
      setSelectedClipIds(['clip-rr-txt1']);
      setSelectedMarkerId(null);
      setShowHomeScreen(false);
      applyLayoutSnapshot(structuredClone(BUILT_IN_LAYOUT_SNAPSHOTS['editing-workspace']));
      setAssetBrowserTab('templates');
      setCustomizeTemplateConfig(null);
    },
    [project, applyLayoutSnapshot]
  );

  // Capture current monitor frame directly as PNG via Windows dialog
  const handleQuickSnapshotPNG = useCallback(async () => {
    const rendered = await exportProjectMedia(
      project,
      {
        format: 'png',
        resolution: 'project',
        fps: 30,
        bitrateMbps: 12,
        fileName: `${project.name}_Frame`,
        audioEnabled: false,
        audioQuality: '192',
      },
      playheadTime,
      () => {}
    );
    await saveBlobWithWindowsDialog(
      rendered.blob,
      rendered.suggestedFileName,
      { 'image/png': ['.png'] },
      'PNG Frame Snapshot'
    );
  }, [project, playheadTime]);

  const handleQuickAudioWAV = useCallback(async () => {
    const rendered = await exportProjectMedia(
      project,
      {
        format: 'wav',
        resolution: 'project',
        fps: 30,
        bitrateMbps: 12,
        fileName: `${project.name}_Master_Audio`,
        audioEnabled: true,
        audioQuality: '320',
      },
      playheadTime,
      () => {}
    );
    await saveBlobWithWindowsDialog(
      rendered.blob,
      rendered.suggestedFileName,
      { 'audio/wav': ['.wav'] },
      'WAV Master Audio'
    );
  }, [project, playheadTime]);

  // Top Menu Bar Action Dispatcher
  const handleMenuAction = useCallback(
    (action: StudioMenuAction) => {
      switch (action) {
        case 'file:new':
          setProjectModalState({ mode: 'create' });
          break;
        case 'file:open':
          void handleOpenProjectFromPC();
          break;
        case 'file:save':
          void handleSaveProject();
          break;
        case 'file:saveAs':
          void exportProjectFileToDisk(project);
          break;
        case 'file:importMedia':
          globalMediaInputRef.current?.click();
          break;
        case 'file:export':
        case 'export:video':
          setShowExportModal(true);
          break;
        case 'file:exitHome':
        case 'view:home':
          setIsPlaying(false);
          setShowHomeScreen(true);
          break;
        case 'edit:undo':
          handleUndo();
          break;
        case 'edit:redo':
          handleRedo();
          break;
        case 'edit:cut':
          if (selectedClipId) handleCutClip(selectedClipId);
          break;
        case 'edit:copy':
          if (selectedClipId) handleCopyClip(selectedClipId);
          break;
        case 'edit:paste':
          handlePasteClip();
          break;
        case 'edit:delete':
          if (selectedClipId) handleDeleteClip(selectedClipId);
          else if (selectedMarkerId) handleDeleteMarker(selectedMarkerId);
          break;
        case 'edit:selectAll':
          if (project.clips.length > 0) {
            setSelectedClipId(project.clips[0].id);
            setSelectedClipIds(project.clips.map((c) => c.id));
          }
          break;
        case 'edit:preferences':
          setSettingsModalTab('performance');
          break;
        case 'view:uiTheme':
          setSettingsModalTab('appearance');
          break;
        case 'view:workspace:editing':
          handleWorkspaceModeChange('editing');
          break;
        case 'view:workspace:motion':
          handleWorkspaceModeChange('motion');
          break;
        case 'view:workspace:3d':
          handleWorkspaceModeChange('3d');
          break;
        case 'view:workspace:4d':
          handleWorkspaceModeChange('4d');
          break;
        case 'view:workspace:audio':
          handleWorkspaceModeChange('audio');
          break;
        case 'view:saveCustomLayout':
          setLayoutPromptModal({
            mode: 'save',
            name: `Custom Layout ${savedCustomLayouts.length + 1}`,
          });
          break;
        case 'view:restoreDefaultLayout':
        case 'view:resetLayout':
          pushLayoutUndo();
          applyLayoutSnapshot(structuredClone(BUILT_IN_LAYOUT_SNAPSHOTS['editing-workspace']));
          setAssetBrowserTab('media');
          break;
        case 'project:settings':
          setProjectModalState({ mode: 'edit' });
          break;
        case 'project:saveSnapshot':
          void handleSaveProject();
          break;
        case 'clip:split':
          if (selectedClipId) handleSplitClip(selectedClipId, playheadTime);
          break;
        case 'clip:merge':
          if (selectedClipId) handleMergeWithNext(selectedClipId);
          break;
        case 'clip:duplicate':
          if (selectedClipId) handleDuplicateClip(selectedClipId);
          break;
        case 'clip:toggleMute':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({ ...c, muted: !c.muted }));
          }
          break;
        case 'clip:toggleLock':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({ ...c, locked: !c.locked }));
          }
          break;
        case 'clip:speedSlow':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({ ...c, speed: 0.5 }));
          }
          break;
        case 'clip:speedFast':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({ ...c, speed: 2.0 }));
          }
          break;
        case 'clip:resetTransform':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({
              ...c,
              transform: {
                x: 0,
                y: 0,
                scale: 1,
                rotation: 0,
                opacity: 1,
                anchorX: 0.5,
                anchorY: 0.5,
                zDepth: 0,
                rotX: 0,
                rotY: 0,
              },
            }));
          }
          break;
        case 'sequence:addVideoTrack':
          handleAddTrack('video');
          break;
        case 'sequence:addAudioTrack':
        case 'audio:addTrack':
          handleAddTrack('audio');
          break;
        case 'sequence:addImageTrack':
          handleAddTrack('image');
          break;
        case 'sequence:addTextTrack':
          handleAddTrack('text');
          break;
        case 'sequence:addMarker':
          handleAddMarker(playheadTime);
          break;
        case 'sequence:toggleSnap':
          commitProject((p) => ({ ...p, snapEnabled: !p.snapEnabled }), false);
          break;
        case 'layer:addTitle':
          handleAddTextClip('RED EFFECT TITLE', false);
          break;
        case 'layer:addSubtitle':
          handleAddTextClip('Subtitles Text', true);
          break;
        case 'layer:toggle3D':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({ ...c, is3DLayer: !c.is3DLayer }));
          }
          break;
        case 'layer:openLayers':
          setWorkspaceMode('motion');
          setSlots((s) => ({ ...s, leftTop: 'layers' }));
          break;
        case 'effects:tealOrange':
          handleApplyEffectPayload(
            JSON.stringify({ kind: 'colorGrade', value: 'cinematic-teal-orange' })
          );
          break;
        case 'effects:crimsonNoir':
          handleApplyEffectPayload(
            JSON.stringify({ kind: 'colorGrade', value: 'crimson-noir' })
          );
          break;
        case 'effects:crossDissolve':
          handleApplyEffectPayload(
            JSON.stringify({ kind: 'transition', value: 'cross-dissolve' })
          );
          break;
        case 'effects:chromaKey':
          handleApplyEffectPayload(
            JSON.stringify({ kind: 'chromaKey', color: '#00ff00' })
          );
          break;
        case 'effects:redSmoke':
          handleApplyEffectPayload(
            JSON.stringify({ kind: 'particles', value: 'red-smoke' })
          );
          break;
        case 'effects:openPanel':
          setWorkspaceMode('editing');
          setShowEffectsLibrary(true);
          break;
        case 'animation:keyScale':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({
              ...c,
              keyframes: [
                ...c.keyframes,
                {
                  id: `kf-${Date.now()}`,
                  time: Math.max(0, playheadTime - c.startTime),
                  property: 'scale',
                  value: c.transform.scale,
                  easing: 'easeInOut',
                },
              ],
            }));
          }
          break;
        case 'animation:keyOpacity':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({
              ...c,
              keyframes: [
                ...c.keyframes,
                {
                  id: `kf-${Date.now()}`,
                  time: Math.max(0, playheadTime - c.startTime),
                  property: 'opacity',
                  value: c.transform.opacity,
                  easing: 'easeInOut',
                },
              ],
            }));
          }
          break;
        case 'animation:zoomIn':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({
              ...c,
              keyframes: [
                ...c.keyframes,
                { id: `kf-${Date.now()}-1`, time: 0, property: 'scale', value: 1, easing: 'easeInOut' },
                {
                  id: `kf-${Date.now()}-2`,
                  time: c.duration,
                  property: 'scale',
                  value: 1.2,
                  easing: 'easeInOut',
                },
              ],
            }));
          }
          break;
        case 'animation:logoSpin':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({
              ...c,
              keyframes: [
                ...c.keyframes,
                { id: `kf-${Date.now()}-1`, time: 0, property: 'rotation', value: -15, easing: 'easeInOut' },
                {
                  id: `kf-${Date.now()}-2`,
                  time: c.duration,
                  property: 'rotation',
                  value: 360,
                  easing: 'easeInOut',
                },
              ],
            }));
          }
          break;
        case 'audio:toggleMasterMute':
          handleToggleMasterMute();
          break;
        case 'audio:fadeIn':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({ ...c, fadeIn: 1.0 }));
          }
          break;
        case 'audio:fadeOut':
          if (selectedClipId) {
            handleUpdateClip(selectedClipId, (c) => ({ ...c, fadeOut: 1.0 }));
          }
          break;
        case 'audio:openMixer':
          setWorkspaceMode('editing');
          setSlots((s) => ({ ...s, bottom: 'mixer' }));
          break;
        case 'audio:deviceSettings':
          setSettingsModalTab('audio');
          break;
        case 'export:framePNG':
          void handleQuickSnapshotPNG();
          break;
        case 'export:audioWAV':
          void handleQuickAudioWAV();
          break;
        case 'help:tutorial':
          void handleStartInteractiveTutorial(false);
          break;
        case 'help:shortcuts':
          setSettingsModalTab('shortcuts');
          break;
        case 'help:guide':
          setShowHelpModal(true);
          break;
      }
    },
    [
      project,
      selectedClipId,
      selectedMarkerId,
      playheadTime,
      savedCustomLayouts.length,
      handleOpenProjectFromPC,
      handleSaveProject,
      handleUndo,
      handleRedo,
      handleCutClip,
      handleCopyClip,
      handlePasteClip,
      handleDeleteClip,
      handleDeleteMarker,
      handleDuplicateClip,
      handleWorkspaceModeChange,
      pushLayoutUndo,
      applyLayoutSnapshot,
      handleSplitClip,
      handleMergeWithNext,
      handleUpdateClip,
      handleAddTrack,
      handleAddMarker,
      handleAddTextClip,
      handleApplyEffectPayload,
      handleToggleMasterMute,
      handleQuickSnapshotPNG,
      handleQuickAudioWAV,
      handleStartInteractiveTutorial,
    ]
  );

  // Global Keyboard Shortcuts
  useEffect(() => {
    const addKeyframesForProps = (
      props: Array<{ prop: TimelineClip['keyframes'][number]['property']; getVal: (c: TimelineClip) => number }>
    ) => {
      if (!selectedClipId) return;
      handleUpdateClip(selectedClipId, (c) => {
        const relTime = Math.max(0, Math.min(c.duration, playheadTime - c.startTime));
        let nextKfs = [...c.keyframes];
        for (const item of props) {
          const exists = nextKfs.find(
            (k) => k.property === item.prop && Math.abs(k.time - relTime) < 0.08
          );
          if (exists) {
            nextKfs = nextKfs.filter((k) => k.id !== exists.id);
          } else {
            nextKfs.push({
              id: `kf-${Date.now()}-${item.prop}-${Math.random().toString(36).slice(2, 5)}`,
              time: Math.round(relTime * 100) / 100,
              property: item.prop,
              value: item.getVal(c),
              easing: 'easeInOut',
            });
          }
        }
        return { ...c, keyframes: nextKfs };
      });
    };

    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isTyping =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable);
      if (isTyping) return;

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'g') {
        e.preventDefault();
        if (e.shiftKey) {
          handleUngroupSelected();
        } else {
          handleGroupSelected();
        }
        return;
      }

      const sc = settings.shortcuts;
      if (matchesShortcut(e, sc.playPause)) {
        e.preventDefault();
        setIsPlaying((p) => !p);
      } else if (matchesShortcut(e, sc.undo)) {
        e.preventDefault();
        handleUndo();
      } else if (matchesShortcut(e, sc.redo)) {
        e.preventDefault();
        handleRedo();
      } else if (matchesShortcut(e, sc.saveProject)) {
        e.preventDefault();
        void handleSaveProject();
      } else if (matchesShortcut(e, sc.saveAs)) {
        e.preventDefault();
        void exportProjectFileToDisk(project);
      } else if (matchesShortcut(e, sc.importMedia)) {
        e.preventDefault();
        globalMediaInputRef.current?.click();
      } else if (matchesShortcut(e, sc.newProject)) {
        e.preventDefault();
        setProjectModalState({ mode: 'create' });
      } else if (matchesShortcut(e, sc.openProject)) {
        e.preventDefault();
        void handleOpenProjectFromPC();
      } else if (matchesShortcut(e, sc.exportVideo)) {
        e.preventDefault();
        setShowExportModal(true);
      } else if (matchesShortcut(e, sc.cutTool)) {
        e.preventDefault();
        setActiveTool('cut');
        setPenToolActive(false);
      } else if (matchesShortcut(e, sc.selectTool)) {
        e.preventDefault();
        setActiveTool('select');
        setPenToolActive(false);
      } else if (matchesShortcut(e, sc.textTool)) {
        e.preventDefault();
        handleAddTextClip('RED EFFECT TITLE', false);
        setLeftCollapsed(false);
        setSlots((s) => ({ ...s, leftBottom: 'textStudio' }));
      } else if (matchesShortcut(e, sc.keyPosition)) {
        e.preventDefault();
        addKeyframesForProps([
          { prop: 'x', getVal: (c) => c.transform.x },
          { prop: 'y', getVal: (c) => c.transform.y },
        ]);
      } else if (matchesShortcut(e, sc.keyScale)) {
        e.preventDefault();
        addKeyframesForProps([{ prop: 'scale', getVal: (c) => c.transform.scale }]);
      } else if (matchesShortcut(e, sc.keyRotation)) {
        e.preventDefault();
        addKeyframesForProps([{ prop: 'rotation', getVal: (c) => c.transform.rotation }]);
      } else if (matchesShortcut(e, sc.keyAnchor)) {
        e.preventDefault();
        addKeyframesForProps([
          { prop: 'anchorX', getVal: (c) => c.transform.anchorX },
          { prop: 'anchorY', getVal: (c) => c.transform.anchorY },
        ]);
      } else if (matchesShortcut(e, sc.keyOpacity)) {
        e.preventDefault();
        addKeyframesForProps([{ prop: 'opacity', getVal: (c) => c.transform.opacity }]);
      } else if (matchesShortcut(e, sc.showAnimated)) {
        e.preventDefault();
        setBottomCollapsed(false);
        setSlots((s) => ({ ...s, bottom: s.bottom === 'keyframes' ? 'timeline' : 'keyframes' }));
      } else if (matchesShortcut(e, sc.easyEase) && selectedClipId) {
        e.preventDefault();
        handleUpdateClip(selectedClipId, (c) => ({
          ...c,
          keyframes: c.keyframes.map((k) => ({
            ...k,
            easing: 'easeInOut',
            bezier: [0.42, 0, 0.58, 1],
          })),
        }));
      } else if (matchesShortcut(e, sc.renameClip) && selectedClipId) {
        e.preventDefault();
        setRenamingClipId(selectedClipId);
      } else if (matchesShortcut(e, sc.duplicateClip) && selectedClipId) {
        e.preventDefault();
        handleDuplicateClip(selectedClipId);
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'x' && selectedClipId) {
        e.preventDefault();
        handleCutClip(selectedClipId);
      } else if (matchesShortcut(e, sc.copyClip) && selectedClipId) {
        e.preventDefault();
        handleCopyClip(selectedClipId);
      } else if (matchesShortcut(e, sc.pasteClip)) {
        e.preventDefault();
        handlePasteClip();
      } else if (matchesShortcut(e, sc.selectAll)) {
        e.preventDefault();
        if (project.clips.length > 0) {
          setSelectedClipId(project.clips[0].id);
          setSelectedClipIds(project.clips.map((c) => c.id));
        }
      } else if (matchesShortcut(e, sc.addMarker)) {
        e.preventDefault();
        handleAddMarker(playheadTime);
      } else if (matchesShortcut(e, sc.deleteClip)) {
        if (selectedClipId) {
          e.preventDefault();
          handleDeleteClip(selectedClipId);
        } else if (selectedMarkerId) {
          e.preventDefault();
          handleDeleteMarker(selectedMarkerId);
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    settings.shortcuts,
    project,
    selectedClipId,
    selectedMarkerId,
    playheadTime,
    handleUndo,
    handleRedo,
    handleSaveProject,
    handleOpenProjectFromPC,
    handleAddTextClip,
    handleUpdateClip,
    handleDuplicateClip,
    handleCutClip,
    handleCopyClip,
    handlePasteClip,
    handleDeleteClip,
    handleAddMarker,
    handleDeleteMarker,
    handleGroupSelected,
    handleUngroupSelected,
  ]);

  // Resizable Drag Dividers (undoable on release)
  const startResize = (axis: 'left' | 'right' | 'bottom', e: React.MouseEvent) => {
    e.preventDefault();
    const startSnap = structuredClone(currentLayoutSnapshot);
    const startX = e.clientX;
    const startY = e.clientY;
    const origLeft = leftWidth;
    const origRight = rightWidth;
    const origBottom = bottomHeight;
    let moved = false;

    const onMove = (ev: MouseEvent) => {
      if (Math.abs(ev.clientX - startX) > 2 || Math.abs(ev.clientY - startY) > 2) moved = true;
      if (axis === 'left') {
        setLeftWidth(Math.max(220, Math.min(460, origLeft + (ev.clientX - startX))));
      } else if (axis === 'right') {
        setRightWidth(Math.max(250, Math.min(500, origRight - (ev.clientX - startX))));
      } else {
        setBottomHeight(Math.max(190, Math.min(500, origBottom - (ev.clientY - startY))));
      }
    };
    const onUp = () => {
      if (moved) pushLayoutUndo(startSnap);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  // Render any of the workspace panels by ID
  const renderPanelContent = (panelId: PanelId) => {
    switch (panelId) {
      case 'project':
        return (
          <ProjectExplorerPanel
            project={project}
            recentProjects={recentProjects}
            lastSavedAt={lastSavedAt}
            onOpenNewProjectModal={() => setProjectModalState({ mode: 'create' })}
            onOpenProjectSettingsModal={() => setProjectModalState({ mode: 'edit' })}
            onLoadProject={handleLoadRecentProject}
            onDeleteProject={async (id) => {
              await deleteProjectFromDB(id);
              const list = await loadAllProjectsFromDB();
              setRecentProjects(list);
            }}
            onSaveToDB={handleSaveProject}
            onSaveFileToPC={() => exportProjectFileToDisk(project)}
            onOpenFileFromPC={handleOpenProjectFromPC}
            onCreateFolder={(folderName) =>
              commitProject((p) =>
                p.folders.includes(folderName)
                  ? p
                  : { ...p, folders: [...p.folders, folderName] }
              )
            }
            activeFolder={activeFolder}
            onSelectFolder={setActiveFolder}
          />
        );

      case 'media':
        return (
          <MediaExplorerPanel
            assets={project.assets}
            activeFolder={activeFolder}
            selectedAssetId={selectedAssetId}
            onSelectAsset={setSelectedAssetId}
            onImportFiles={(files) => {
              void handleImportFiles(files);
            }}
            onAddAssetToTimeline={(asset) => addAssetToTimeline(asset)}
            onOpen3DForAsset={(asset) => {
              if (asset.modelBlueprint) setActive3DBlueprint(asset.modelBlueprint);
              setWorkspaceMode('3d');
            }}
            onDeleteAsset={(assetId) =>
              commitProject((p) => ({
                ...p,
                assets: p.assets.filter((a) => a.id !== assetId),
              }))
            }
          />
        );

      case 'templates':
        return (
          <AssetBrowserPanel
            activeTab={assetBrowserTab}
            onChangeTab={setAssetBrowserTab}
            assets={project.assets}
            activeFolder={activeFolder}
            selectedAssetId={selectedAssetId}
            selectedClip={selectedClip}
            playheadTime={playheadTime}
            customReadyPresets={customReadyPresets}
            customTemplates={customTemplates}
            hoverPreviewEnabled={settings.hoverPreviewEnabled !== false}
            onSelectAsset={setSelectedAssetId}
            onImportFiles={(files) => {
              void handleImportFiles(files);
            }}
            onAddAssetToTimeline={(asset) => addAssetToTimeline(asset)}
            onAddBuiltinAudioAsset={handleAddBuiltinAudioAsset}
            onOpen3DForAsset={(asset) => {
              if (asset.modelBlueprint) setActive3DBlueprint(asset.modelBlueprint);
              setWorkspaceMode('3d');
            }}
            onDeleteAsset={(assetId) =>
              commitProject((p) => ({
                ...p,
                assets: p.assets.filter((a) => a.id !== assetId),
              }))
            }
            onApplyReadyPreset={(preset) => handleApplyReadyMadePreset(preset)}
            onHoverReadyPreset={handleHoverPreviewPreset}
            onClearHoverImmediate={clearHoverPreviewImmediate}
            onAddCatalogEffect={handleAddEffectToClip}
            onApplyTransition={handleApplyTransition}
            onAddTextClip={(isSub, overrides) =>
              handleAddTextClip(
                overrides?.text || (isSub ? 'Subtitle Line' : 'RED EFFECT TITLE'),
                Boolean(isSub),
                overrides
              )
            }
            onAddStickerShape={(kind, label, overrides) =>
              handleAddShapeClip(kind, label, overrides)
            }
            onUpdateClip={(clipId, updater) => handleUpdateClip(clipId, updater)}
            onSaveReadyMadePreset={handleSaveReadyMadePreset}
            onOpenTemplate={(cust) => void handleOpenTrailerTemplate(cust)}
            onCustomizeTemplate={(cust) =>
              setCustomizeTemplateConfig(
                cust ? structuredClone(cust) : createDefaultRedRebellionCustomization()
              )
            }
            onDeleteCustomTemplate={(id) => {
              setCustomTemplates(deleteCustomTemplate(id));
            }}
          />
        );

      case 'monitor':
        return (
          <PreviewMonitorPanel
            project={project}
            playheadTime={playheadTime}
            totalDuration={totalDuration}
            isPlaying={isPlaying}
            loopEnabled={loopEnabled}
            masterVolume={masterVolume}
            masterMuted={masterMuted}
            workspaceMode={workspaceMode}
            selectedClip={selectedClip}
            selectedClipIds={selectedClipIds}
            hoverPreviewPreset={hoverPreviewPreset}
            hoverPreviewPending={hoverPreviewPending}
            penToolActive={penToolActive}
            autoKeyframeEnabled={autoKeyframeEnabled}
            onToggleAutoKeyframe={() => setAutoKeyframeEnabled((v) => !v)}
            onTogglePenTool={() => setPenToolActive((p) => !p)}
            onSelectClip={handleSelectClip}
            onUpdateClip={handleUpdateClip}
            onBatchUpdateClips={handleBatchUpdateClips}
            onBeginDragHistory={handleBeginDragHistory}
            onEndDragHistory={handleEndDragHistory}
            onAddTextAtPosition={handleAddTextAtPosition}
            onAddShapeClip={handleAddShapeClip}
            onGroupSelected={handleGroupSelected}
            onUngroupSelected={handleUngroupSelected}
            onToggleSnap={() =>
              commitProject((p) => ({ ...p, snapEnabled: !p.snapEnabled }), false)
            }
            onTogglePlay={() => setIsPlaying((p) => !p)}
            onSeek={setPlayheadTime}
            onToggleLoop={() => setLoopEnabled((l) => !l)}
            onToggleMasterMute={handleToggleMasterMute}
            onSetMasterVolume={handleSetMasterVolume}
            onChangeProxy={(q: ProxyQuality) =>
              commitProject((p) => ({ ...p, proxyQuality: q }), false)
            }
            previewQuality={project.previewQuality || settings.previewQuality}
            performanceMode={settings.performanceMode}
            autoDownscalePreview={settings.autoDownscalePreview}
            onChangePreviewQuality={(q: PreviewQuality) => {
              commitProject((p) => ({ ...p, previewQuality: q }), false);
              const next = { ...settings, previewQuality: q };
              setSettings(next);
              saveSettingsToDB(next).catch(() => {});
            }}
            onUpdateMotionTrackTarget={(clipId, x, y) =>
              handleUpdateClip(clipId, (c) => ({
                ...c,
                motionTrack: { ...c.motionTrack, enabled: true, targetX: x, targetY: y },
              }))
            }
            onCaptureFramePNG={handleQuickSnapshotPNG}
            hasCopiedAttributes={Boolean(copiedAttributes)}
            onSplitClip={(cid) => handleSplitClip(cid, playheadTime)}
            onDeleteClip={handleDeleteClip}
            onDuplicateClip={handleDuplicateClip}
            onOpenSpeedDuration={handleOpenSpeedDuration}
            onFocusInspectorTab={(cid, tab) => {
              setClosedPanels((prev) => prev.filter((p) => p !== 'properties'));
              setRightCollapsed(false);
              setSlots((s) => ({ ...s, right: 'properties' }));
              setForcePropertiesTabSignal((prev) => ({
                clipId: cid,
                tab,
                seq: (prev?.seq || 0) + 1,
              }));
            }}
            onAddKeyframeAtPlayhead={(cid) => {
              const target = project.clips.find((c) => c.id === cid);
              if (!target) return;
              const relTime = Math.max(
                0,
                Math.min(target.duration, Math.round((playheadTime - target.startTime) * 100) / 100)
              );
              handleUpdateClip(cid, (c) => ({
                ...c,
                keyframes: [
                  ...c.keyframes.filter(
                    (k) => !(Math.abs(k.time - relTime) < 0.08 && ['x', 'y', 'scale', 'rotation', 'opacity'].includes(k.property))
                  ),
                  { id: `kf-${Date.now()}-x`, time: relTime, property: 'x', value: c.transform.x, easing: 'easeInOut' },
                  { id: `kf-${Date.now()}-y`, time: relTime, property: 'y', value: c.transform.y, easing: 'easeInOut' },
                  { id: `kf-${Date.now()}-s`, time: relTime, property: 'scale', value: c.transform.scale, easing: 'easeInOut' },
                  { id: `kf-${Date.now()}-r`, time: relTime, property: 'rotation', value: c.transform.rotation, easing: 'easeInOut' },
                  { id: `kf-${Date.now()}-o`, time: relTime, property: 'opacity', value: c.transform.opacity, easing: 'easeInOut' },
                ],
              }));
            }}
            onCopyAttributes={handleCopyAttributes}
            onPasteAttributes={handlePasteAttributes}
          />
        );

      case 'timeline':
        return (
          <TimelineEditorPanel
            project={project}
            playheadTime={playheadTime}
            selectedClipId={selectedClipId}
            selectedClipIds={selectedClipIds}
            selectedMarkerId={selectedMarkerId}
            activeTool={activeTool}
            hasClipboard={Boolean(clipboardClip)}
            timelineHeight={bottomHeight}
            renamingClipId={renamingClipId}
            onRequestRenameClip={setRenamingClipId}
            onSelectClip={handleSelectClip}
            onSelectMultipleClips={handleSelectMultipleClips}
            onSelectMarker={setSelectedMarkerId}
            onSetTool={setActiveTool}
            onSeek={setPlayheadTime}
            onToggleSnap={() =>
              commitProject((p) => ({ ...p, snapEnabled: !p.snapEnabled }), false)
            }
            onUpdateClip={handleUpdateClip}
            onBatchUpdateClips={handleBatchUpdateClips}
            onSplitClip={handleSplitClip}
            onMergeWithNext={handleMergeWithNext}
            onDeleteClip={handleDeleteClip}
            onRippleDeleteClip={handleRippleDeleteClip}
            onCutClip={handleCutClip}
            onCopyClip={handleCopyClip}
            onPasteClip={handlePasteClip}
            onDuplicateClip={handleDuplicateClip}
            onSetClipParent={handleSetClipParent}
            onDropAssetOnTrack={(assetId, trackId, startTime) => {
              const asset = project.assets.find((a) => a.id === assetId);
              if (asset) addAssetToTimeline(asset, trackId, startTime);
            }}
            onDropFilesOnTrack={(files, trackId, startTime) => {
              void handleDropFilesOnTrack(files, trackId, startTime);
            }}
            onDropEffectOnClip={(payload, clipId) => handleApplyEffectPayload(payload, clipId)}
            onDropEffectOnTrack={(payload, trackId, dropTime) =>
              handleApplyEffectPayload(payload, undefined, dropTime, trackId)
            }
            onAddTextClip={() => handleAddTextClip()}
            onAddNullClip={handleAddNullClip}
            onAddShapeClip={() => handleAddShapeClip('rectangle')}
            onAddEffectLayer={handleAddEffectLayer}
            onAddTrack={handleAddTrack}
            onRenameTrack={handleRenameTrack}
            onDeleteTrack={handleDeleteTrack}
            onMoveTrack={handleMoveTrack}
            onReorderTracks={handleReorderTracks}
            onSetTrackColor={handleSetTrackColor}
            onToggleTrackCollapsed={handleToggleTrackCollapsed}
            onToggleTrackProp={(trackId, prop) =>
              commitProject((p) => ({
                ...p,
                tracks: p.tracks.map((t) =>
                  t.id === trackId ? { ...t, [prop]: !t[prop] } : t
                ),
              }))
            }
            onChangeTimelineHeight={(nextH) => setBottomHeight(nextH)}
            onAddMarker={handleAddMarker}
            onUpdateMarker={handleUpdateMarker}
            onDeleteMarker={handleDeleteMarker}
            onQuickAddEffect={handleAddEffectToClip}
            onQuickApplyPreset={(clipId, presetId) => {
              const found = [...customPresets, ...BUILT_IN_PRESETS].find((pr) => pr.id === presetId);
              if (found) handleApplyPresetToClips(found, [clipId]);
            }}
            onDetachAudio={handleDetachAudio}
            onCreateCompoundClip={handleCreateCompoundClip}
            onConvertTextToShape={handleConvertTextToShape}
            onOpenSpeedDuration={handleOpenSpeedDuration}
            onFocusEffectInProperties={handleFocusEffectInProperties}
          />
        );

      case 'effects':
        return (
          <EffectsPanel
            selectedClip={selectedClip}
            hoverPreviewEnabled={settings.hoverPreviewEnabled !== false}
            onAddEffectToClip={handleAddEffectToClip}
            onApplyEffectPayload={handleApplyEffectPayload}
            onHoverEffect={handleHoverPreviewPreset}
            onClearHoverImmediate={clearHoverPreviewImmediate}
          />
        );

      case 'transitions':
        return (
          <TransitionsPanel
            selectedClip={selectedClip}
            hoverPreviewEnabled={settings.hoverPreviewEnabled !== false}
            onApplyTransition={handleApplyTransition}
            onHoverTransition={handleHoverPreviewPreset}
            onClearHoverImmediate={clearHoverPreviewImmediate}
          />
        );

      case 'textStudio':
        return (
          <TextStudioPanel
            selectedClip={selectedClip}
            playheadTime={playheadTime}
            hoverPreviewEnabled={settings.hoverPreviewEnabled !== false}
            onAddTextClip={(isSub, overrides) =>
              handleAddTextClip(
                overrides?.text || (isSub ? 'Subtitle Line' : 'RED EFFECT TITLE'),
                Boolean(isSub),
                overrides
              )
            }
            onUpdateClip={(clipId, updater) => handleUpdateClip(clipId, updater)}
            onSaveReadyMadePreset={handleSaveReadyMadePreset}
            onHoverTextPreset={handleHoverPreviewPreset}
            onClearHoverImmediate={clearHoverPreviewImmediate}
          />
        );

      case 'shapes':
        return (
          <ShapesMaskPanel
            selectedClip={selectedClip}
            playheadTime={playheadTime}
            penToolActive={penToolActive}
            onTogglePenTool={() => setPenToolActive((p) => !p)}
            onAddShapeClip={handleAddShapeClip}
            onUpdateClip={(clipId, updater) => handleUpdateClip(clipId, updater)}
          />
        );

      case 'presets':
        return (
          <PresetLibraryPanel
            selectedClip={selectedClip}
            selectedClipIds={selectedClipIds}
            customPresets={customPresets}
            onSaveCustomPreset={handleSaveCustomPreset}
            onDeleteCustomPreset={handleDeleteCustomPreset}
            onApplyPresetToClips={handleApplyPresetToClips}
          />
        );

      case 'properties':
        return (
          <PropertiesPanel
            project={project}
            selectedClip={selectedClip}
            selectedClipIds={selectedClipIds}
            playheadTime={playheadTime}
            camera3D={project.camera3D}
            copiedEffectsStack={copiedEffectsStack}
            hasCopiedAttributes={Boolean(copiedAttributes)}
            autoKeyframeEnabled={autoKeyframeEnabled}
            onToggleAutoKeyframe={() => setAutoKeyframeEnabled((v) => !v)}
            onSeek={setPlayheadTime}
            onUpdateClip={(clipId, updater) => handleUpdateClip(clipId, updater)}
            onBatchUpdateClips={handleBatchUpdateClips}
            onSetClipParent={handleSetClipParent}
            onDuplicateClip={handleDuplicateClip}
            onDeleteClip={handleDeleteClip}
            onRequestRenameClip={(clipId) => setRenamingClipId(clipId)}
            onSelectClip={(clipId) => handleSelectClip(clipId)}
            forceTabSignal={forcePropertiesTabSignal}
            onGroupSelected={handleGroupSelected}
            onUngroupSelected={handleUngroupSelected}
            onUpdateCamera3D={(camera3D) =>
              commitProject((p) => ({ ...p, camera3D }), false)
            }
            onCopyEffectsStack={setCopiedEffectsStack}
            onCopyAttributes={handleCopyAttributes}
            onPasteAttributes={handlePasteAttributes}
            onSaveStackAsPreset={handleSaveCustomPreset}
            onSaveReadyMadePreset={handleSaveReadyMadePreset}
          />
        );

      case 'colorControls':
        return (
          <PropertiesPanel
            project={project}
            selectedClip={selectedClip}
            selectedClipIds={selectedClipIds}
            playheadTime={playheadTime}
            camera3D={project.camera3D}
            copiedEffectsStack={copiedEffectsStack}
            hasCopiedAttributes={Boolean(copiedAttributes)}
            initialTab="color"
            autoKeyframeEnabled={autoKeyframeEnabled}
            onToggleAutoKeyframe={() => setAutoKeyframeEnabled((v) => !v)}
            onSeek={setPlayheadTime}
            onUpdateClip={(clipId, updater) => handleUpdateClip(clipId, updater)}
            onBatchUpdateClips={handleBatchUpdateClips}
            onSetClipParent={handleSetClipParent}
            onDuplicateClip={handleDuplicateClip}
            onDeleteClip={handleDeleteClip}
            onRequestRenameClip={(clipId) => setRenamingClipId(clipId)}
            onSelectClip={(clipId) => handleSelectClip(clipId)}
            forceTabSignal={forcePropertiesTabSignal}
            onGroupSelected={handleGroupSelected}
            onUngroupSelected={handleUngroupSelected}
            onUpdateCamera3D={(camera3D) =>
              commitProject((p) => ({ ...p, camera3D }), false)
            }
            onCopyEffectsStack={setCopiedEffectsStack}
            onCopyAttributes={handleCopyAttributes}
            onPasteAttributes={handlePasteAttributes}
            onSaveStackAsPreset={handleSaveCustomPreset}
            onSaveReadyMadePreset={handleSaveReadyMadePreset}
          />
        );

      case 'layers':
        return (
          <LayersPanel
            project={project}
            selectedClipId={selectedClipId}
            playheadTime={playheadTime}
            onSelectClip={(id) => handleSelectClip(id)}
            onUpdateClip={(clipId, updater) => handleUpdateClip(clipId, updater)}
            onSeek={setPlayheadTime}
          />
        );

      case 'keyframes':
        return (
          <KeyframeGraphPanel
            selectedClip={selectedClip}
            playheadTime={playheadTime}
            onUpdateClip={(clipId, updater) => handleUpdateClip(clipId, updater)}
            onSeek={setPlayheadTime}
          />
        );

      case 'nullHierarchy':
        return (
          <NullHierarchyPanel
            project={project}
            selectedClipId={selectedClipId}
            onSelectClip={(id) => handleSelectClip(id)}
            onCreateNullObject={handleAddNullClip}
            onUpdateClip={(clipId, updater) => handleUpdateClip(clipId, updater)}
            onSetClipParent={handleSetClipParent}
            onDuplicateClip={handleDuplicateClip}
            onDeleteClip={handleDeleteClip}
          />
        );

      case 'mixer':
        return (
          <AudioMixerPanel
            project={project}
            isPlaying={isPlaying}
            masterVolume={masterVolume}
            masterMuted={masterMuted}
            audioOutputDeviceId={settings.audioOutputDeviceId || 'default'}
            selectedClip={selectedClip}
            getPeakLevels={getMixerPeakLevels}
            onSetMasterVolume={handleSetMasterVolume}
            onToggleMasterMute={handleToggleMasterMute}
            onSelectAudioDevice={handleSelectAudioDevice}
            onUpdateTrack={(trackId, updater: (t: TimelineTrack) => TimelineTrack) =>
              commitProject((p) => ({
                ...p,
                tracks: p.tracks.map((t) => (t.id === trackId ? updater(t) : t)),
              }))
            }
            onUpdateClip={(clipId, updater) => handleUpdateClip(clipId, updater)}
          />
        );
    }
  };

  const getTabLabel = (opt: PanelId): string => {
    switch (opt) {
      case 'templates':
        return 'Browser';
      case 'project':
        return 'Projects';
      case 'media':
        return 'Media';
      case 'effects':
        return 'FX';
      case 'transitions':
        return 'Transitions';
      case 'textStudio':
        return 'Text';
      case 'shapes':
        return 'Shapes';
      case 'presets':
        return 'Presets';
      case 'layers':
        return 'Layers';
      case 'properties':
        return 'Inspector';
      case 'colorControls':
        return 'Color';
      case 'keyframes':
        return 'Keyframes';
      case 'nullHierarchy':
        return 'Nulls';
      case 'timeline':
        return 'Timeline';
      case 'mixer':
        return 'Mixer';
      case 'monitor':
        return 'Monitor';
    }
  };

  // Helper to render slot with quick tab switcher, Collapse, Undock/Float, Maximize, and Close
  const isPanelDockedVisible = (panelId: PanelId) =>
    !closedPanels.includes(panelId) && !floatingPanels.some((fp) => fp.panelId === panelId);

  const hasLeftDock = isPanelDockedVisible(slots.leftTop) || isPanelDockedVisible(slots.leftBottom);
  const hasRightDock = isPanelDockedVisible(slots.right);
  const maxBottomH = Math.max(210, viewportSize.height - 52 - 260);
  const effectiveBottomHeight = Math.min(bottomHeight, maxBottomH);
  const leftReserve = hasLeftDock ? (leftCollapsed ? 28 : leftWidth) : 0;
  const rightReserve = hasRightDock ? (rightCollapsed ? 28 : rightWidth) : 0;
  const minCenterW = Math.min(540, Math.max(360, viewportSize.width * 0.42));
  const maxDockTotal = Math.max(460, viewportSize.width - minCenterW - 14);
  const activeLeftTarget = hasLeftDock && !leftCollapsed ? leftWidth : 0;
  const activeRightTarget = hasRightDock && !rightCollapsed ? rightWidth : 0;
  const effectiveLeftWidth =
    leftReserve + rightReserve > maxDockTotal && hasLeftDock && !leftCollapsed
      ? Math.max(240, Math.round((leftWidth / Math.max(1, activeLeftTarget + activeRightTarget)) * maxDockTotal))
      : leftWidth;
  const effectiveRightWidth =
    leftReserve + rightReserve > maxDockTotal && hasRightDock && !rightCollapsed
      ? Math.max(260, Math.round((rightWidth / Math.max(1, activeLeftTarget + activeRightTarget)) * maxDockTotal))
      : rightWidth;

  const renderSlot = (slotKey: keyof SlotConfig, switcherOptions: PanelId[]) => {
    const panelId = slots[slotKey];
    const isCollapsed = collapsedPanels.includes(panelId);
    return (
      <PanelShell
        panelId={panelId}
        title={PANEL_TITLES[panelId]}
        subtitle={
          panelId === 'monitor'
            ? `${project.width}×${project.height} · ${project.fps}fps`
            : undefined
        }
        isMaximized={maximizedPanel === panelId}
        isCollapsed={isCollapsed}
        canClose={panelId !== 'monitor'}
        canFloat={panelId !== 'monitor'}
        onToggleMaximize={() =>
          setMaximizedPanel((curr) => (curr === panelId ? null : panelId))
        }
        onToggleCollapse={() => handleTogglePanelCollapse(panelId)}
        onToggleFloat={() => handleTogglePanelFloat(panelId)}
        onClosePanel={() => handleClosePanel(panelId)}
        onSwapPanels={handleSwapPanels}
        headerRight={
          switcherOptions.length > 1 ? (
            <div className="flex items-center gap-0.5 bg-[#18181A] p-0.5 rounded-[5px] border border-[#3E3E44] max-w-full overflow-x-auto">
              {switcherOptions.map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => {
                    pushLayoutUndo();
                    setClosedPanels((prev) => prev.filter((p) => p !== opt));
                    setFloatingPanels((prev) => prev.filter((fp) => fp.panelId !== opt));
                    setSlots((s) => ({ ...s, [slotKey]: opt }));
                  }}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-medium transition-colors whitespace-nowrap ${
                    panelId === opt
                      ? 'bg-[#52525B] text-[#F4F4F5]'
                      : 'text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
                  }`}
                >
                  {getTabLabel(opt)}
                </button>
              ))}
            </div>
          ) : undefined
        }
        className="h-full"
      >
        {renderPanelContent(panelId)}
      </PanelShell>
    );
  };

  const modalInitialConfig: Partial<NewProjectConfig> | undefined =
    projectModalState?.mode === 'edit'
      ? {
          name: project.name,
          location: project.location || 'C:\\Users\\Documents\\RED EFFECT\\Projects',
          width: project.width,
          height: project.height,
          fps: ([24, 25, 30, 50, 60, 120].includes(project.fps)
            ? project.fps
            : 30) as NewProjectConfig['fps'],
          aspectRatio: project.aspectRatio || '16:9',
          videoFormat: project.videoFormat || 'mp4',
          audioSampleRate: project.audioSampleRate || 48000,
          backgroundColor: project.backgroundColor || '#050507',
          videoTrackCount: project.tracks.filter((t) => t.kind === 'video').length || 2,
          audioTrackCount: project.tracks.filter((t) => t.kind === 'audio').length || 2,
          snapEnabled: project.snapEnabled,
          defaultClipDuration: project.defaultClipDuration || 5,
        }
      : {
          fps: settings.defaultFps,
          width:
            settings.defaultResolution === '4k'
              ? 3840
              : settings.defaultResolution === '2k' || settings.defaultResolution === '1440p'
              ? 2560
              : settings.defaultResolution === '720p'
              ? 1280
              : 1920,
          height:
            settings.defaultResolution === '4k'
              ? 2160
              : settings.defaultResolution === '2k' || settings.defaultResolution === '1440p'
              ? 1440
              : settings.defaultResolution === '720p'
              ? 720
              : 1080,
        };

  return (
    <>
      <input
        ref={globalMediaInputRef}
        type="file"
        multiple
        accept="video/*,image/*,audio/*,.aac,.m4a,.mp3,.wav,.mp4,.mov,.webm,.obj,.glb,.gltf"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) {
            void handleImportFiles(e.target.files);
          }
          e.target.value = '';
        }}
      />

      {showHomeScreen ? (
        <HomeScreen
          recentProjects={recentProjects}
          activeProjectId={project.id}
          settings={settings}
          customReadyPresets={customReadyPresets}
          isLoadingProjects={isLoadingProjects}
          projectsError={projectsError}
          onDismissProjectsError={() => setProjectsError(null)}
          onNewProject={(initialMediaPick) =>
            setProjectModalState({ mode: 'create', initialMediaPick: initialMediaPick ?? null })
          }
          onOpenProjectFromPC={() => void handleOpenProjectFromPC()}
          onLoadRecentProject={handleLoadRecentProject}
          onRenameRecentProject={handleRenameRecentProject}
          onDuplicateRecentProject={handleDuplicateRecentProject}
          onExportRecentProject={handleExportRecentProject}
          onDeleteRecentProject={async (id) => {
            await deleteProjectFromDB(id);
            const list = await loadAllProjectsFromDB();
            setRecentProjects(list);
            if (project.id === id && list.length > 0) {
              const nextProj = normalizeProject(list[0]);
              projectRef.current = nextProj;
              setProject(nextProj);
            }
          }}
          onImportMediaAndEdit={(files) => {
            void handleImportFiles(files).then((imported) => {
              let cursor = 0;
              for (const asset of imported) {
                addAssetToTimeline(asset, undefined, asset.type === 'audio' ? 0 : cursor);
                if (asset.type !== 'audio') {
                  cursor += Math.max(1, asset.duration);
                }
              }
              setShowHomeScreen(false);
              setWorkspaceMode('editing');
            });
          }}
          onCreateTemplateProject={handleCreateTemplateProject}
          onOpen3DGenerator={() => {
            setShowHomeScreen(false);
            setWorkspaceMode('3d');
          }}
          onOpen4DStudio={() => {
            setShowHomeScreen(false);
            setWorkspaceMode('4d');
          }}
          onUpdateSettings={(next) => {
            setSettings(next);
            saveSettingsToDB(next).catch(() => {});
          }}
          onSelectAudioDevice={handleSelectAudioDevice}
          onOpenSettings={(tab = 'appearance') => setSettingsModalTab(tab)}
          onResumeActiveProject={() => setShowHomeScreen(false)}
          onOpenInteractiveTutorial={() => void handleStartInteractiveTutorial(false)}
          onOpenTrailerTemplate={() => void handleOpenTrailerTemplate()}
          onApplyReadyMadePreset={(preset) => {
            handleApplyReadyMadePreset(preset);
            setShowHomeScreen(false);
            setWorkspaceMode('editing');
          }}
          onDeleteCustomReadyPreset={handleDeleteReadyMadePreset}
        />
      ) : (
        <div className="h-screen w-screen flex flex-col bg-[#18181A] text-[#F4F4F5] overflow-hidden">
          <TopStudioBar
            projectName={project.name}
            recentProjects={recentProjects}
            workspaceMode={workspaceMode}
            canUndo={undoOrder.length > 0 || undoStack.length > 0}
            canRedo={redoOrder.length > 0 || redoStack.length > 0}
            hasSelectedClip={Boolean(selectedClipId)}
            hasClipboard={Boolean(clipboardClip)}
            masterVolume={masterVolume}
            masterMuted={masterMuted}
            closedPanels={closedPanels}
            floatingPanels={floatingPanels.map((f) => f.panelId)}
            activeLayoutPresetId={activePresetId}
            customLayouts={savedCustomLayouts.map((l) => ({ id: l.id, name: l.name }))}
            previewQuality={project.previewQuality || settings.previewQuality}
            performanceMode={settings.performanceMode}
            lastSavedAt={lastSavedAt}
            onChangeWorkspace={handleWorkspaceModeChange}
            onMenuAction={handleMenuAction}
            onLoadRecentProject={handleLoadRecentProject}
            onToggleMasterMute={handleToggleMasterMute}
            onSetMasterVolume={handleSetMasterVolume}
            onTogglePanelWindow={handleTogglePanelWindow}
            onSelectLayoutPreset={handleSelectLayoutPreset}
            onRenameCustomLayout={() => {
              const cur = savedCustomLayouts.find((l) => l.id === activePresetId);
              if (cur) setLayoutPromptModal({ mode: 'rename', name: cur.name });
            }}
            onDuplicateLayout={() => {
              const curName =
                savedCustomLayouts.find((l) => l.id === activePresetId)?.name || activePresetId;
              setLayoutPromptModal({ mode: 'save', name: `${curName} Copy` });
            }}
            onDeleteCustomLayout={() => {
              setSavedCustomLayouts((prev) => prev.filter((l) => l.id !== activePresetId));
              applyLayoutSnapshot(
                structuredClone(BUILT_IN_LAYOUT_SNAPSHOTS['editing-workspace'])
              );
            }}
            effectsLibraryOpen={showEffectsLibrary}
            onToggleEffectsLibrary={() => {
              clearHoverPreviewImmediate();
              setShowEffectsLibrary((v) => !v);
            }}
            onOpenQualityEnhancer={(tab) => setQualityModalTab(tab)}
            onChangePreviewQuality={(q) => {
              commitProject((p) => ({ ...p, previewQuality: q }), false);
              const next = { ...settings, previewQuality: q };
              setSettings(next);
              saveSettingsToDB(next).catch(() => {});
            }}
            onTogglePerformanceMode={() => {
              const next = { ...settings, performanceMode: !settings.performanceMode };
              setSettings(next);
              saveSettingsToDB(next).catch(() => {});
            }}
          />

          {showEffectsLibrary && workspaceMode !== '3d' && workspaceMode !== '4d' && (
            <ReadyMadeEffectsPanel
              customPresets={customReadyPresets}
              selectedClipName={selectedClip?.name}
              selectedClipType={selectedClip?.type}
              variant="drawer"
              hoverPreviewEnabled={settings.hoverPreviewEnabled !== false}
              onApplyPreset={(preset) => handleApplyReadyMadePreset(preset)}
              onHoverPreset={handleHoverPreviewPreset}
              onClearHoverImmediate={clearHoverPreviewImmediate}
              onDeleteCustomPreset={handleDeleteReadyMadePreset}
              onClose={() => {
                clearHoverPreviewImmediate();
                setShowEffectsLibrary(false);
              }}
            />
          )}

          {/* Main 4-Panel Desktop NLE Workspace Body */}
          <div className="flex-1 min-h-0 flex overflow-hidden p-1 gap-0 bg-[#18181A]">
            <main className="flex-1 min-w-0 min-h-0 flex flex-col overflow-hidden bg-[#18181A]">
              {workspaceMode === '3d' ? (
                <Studio3DPanel
                  activeBlueprint={active3DBlueprint}
                  onBlueprintChange={setActive3DBlueprint}
                  onImport3DToProject={(bp, thumb) => {
                    const asset: MediaAsset = {
                      id: `asset-3d-${Date.now()}`,
                      name: `${bp.title.replace(/\s+/g, '_')}.glb`,
                      type: 'model3d',
                      mimeType: 'model/gltf-binary',
                      url: thumb || '',
                      duration: project.defaultClipDuration || 6,
                      folder: '3D Models',
                      createdAt: Date.now(),
                      modelBlueprint: bp,
                    };
                    commitProject((p) => ({ ...p, assets: [asset, ...p.assets] }));
                    addAssetToTimeline(asset);
                  }}
                  onOpenIn4DStudio={(payload) => {
                    setTransfer4DPayload(payload);
                    handleWorkspaceModeChange('4d');
                  }}
                />
              ) : workspaceMode === '4d' ? (
                <Studio4DPanel
                  transferPayload={transfer4DPayload}
                  onSendVideoToTimeline={(targetWorkspace, name, blob, duration, width, height) => {
                    const url = URL.createObjectURL(blob);
                    const asset: MediaAsset = {
                      id: `asset-4d-${Date.now()}`,
                      name,
                      type: 'video',
                      mimeType: blob.type || 'video/webm',
                      url,
                      duration: Math.max(1, duration),
                      width,
                      height,
                      hasAudio: false,
                      waveformPeaks: [],
                      folder: '4D Sequences',
                      createdAt: Date.now(),
                    };
                    commitProject((p) => ({ ...p, assets: [asset, ...p.assets] }));
                    addAssetToTimeline(asset);
                    handleWorkspaceModeChange(targetWorkspace);
                  }}
                />
              ) : maximizedPanel ? (
                <div className="flex-1 min-h-0">
                  <PanelShell
                    panelId={maximizedPanel}
                    title={PANEL_TITLES[maximizedPanel]}
                    isMaximized
                    onToggleMaximize={() => setMaximizedPanel(null)}
                    className="h-full"
                  >
                    {renderPanelContent(maximizedPanel)}
                  </PanelShell>
                </div>
              ) : (
                <>
                  {/* Upper Split: LEFT ASSET BROWSER | CENTER VIDEO PREVIEW | RIGHT INSPECTOR */}
                  <div className="flex-1 min-h-0 flex overflow-hidden">
                    {hasLeftDock &&
                      (leftCollapsed ? (
                        <div className="w-7 bg-[#222225] border border-[#3E3E44] rounded-[6px] flex flex-col items-center py-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              pushLayoutUndo();
                              setLeftCollapsed(false);
                            }}
                            title="Expand Left Browser"
                            className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] rounded transition-colors"
                          >
                            <PanelLeftOpen className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <div
                            style={{ width: effectiveLeftWidth }}
                            className="shrink-0 flex flex-col min-h-0 overflow-hidden"
                          >
                            {isPanelDockedVisible(slots.leftTop) && (
                              <div
                                className={
                                  collapsedPanels.includes(slots.leftTop)
                                    ? 'shrink-0'
                                    : 'flex-1 min-h-0'
                                }
                              >
                                {renderSlot('leftTop', [
                                  'templates',
                                  'layers',
                                  'project',
                                ])}
                              </div>
                            )}
                            {isPanelDockedVisible(slots.leftTop) &&
                              isPanelDockedVisible(slots.leftBottom) && (
                                <div className="h-1 bg-[#18181A]" />
                              )}
                            {isPanelDockedVisible(slots.leftBottom) && (
                              <div
                                className={
                                  collapsedPanels.includes(slots.leftBottom)
                                    ? 'shrink-0'
                                    : 'flex-1 min-h-0'
                                }
                              >
                                {renderSlot('leftBottom', [
                                  'effects',
                                  'textStudio',
                                  'shapes',
                                  'presets',
                                  'layers',
                                ])}
                              </div>
                            )}
                          </div>

                          {/* Left Horizontal Splitter */}
                          <div
                            onMouseDown={(e) => startResize('left', e)}
                            title="Drag to resize left panel"
                            className="w-1.5 bg-[#18181A] hover:bg-[#52525B] cursor-col-resize shrink-0 transition-colors flex items-center justify-center group relative"
                          >
                            <button
                              type="button"
                              onMouseDown={(e) => e.stopPropagation()}
                              onClick={() => {
                                pushLayoutUndo();
                                setLeftCollapsed(true);
                              }}
                              title="Collapse Left Browser"
                              className="hidden group-hover:flex items-center justify-center w-4 h-7 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#A1A1AA] hover:text-[#F4F4F5] z-20 shadow"
                            >
                              <PanelLeftClose className="w-3 h-3" />
                            </button>
                          </div>
                        </>
                      ))}

                    {/* Center Video Preview (Largest Main Canvas) */}
                    <div className="flex-1 min-w-0 min-h-0">
                      {renderSlot('center', ['monitor'])}
                    </div>

                    {/* Right Inspector Dock */}
                    {hasRightDock &&
                      (rightCollapsed ? (
                        <div className="w-7 bg-[#222225] border border-[#3E3E44] rounded-[6px] flex flex-col items-center py-2 shrink-0 ml-1">
                          <button
                            type="button"
                            onClick={() => {
                              pushLayoutUndo();
                              setRightCollapsed(false);
                            }}
                            title="Expand Right Inspector"
                            className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] rounded transition-colors"
                          >
                            <PanelRightOpen className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <>
                          {/* Right Horizontal Splitter */}
                          <div
                            onMouseDown={(e) => startResize('right', e)}
                            title="Drag to resize inspector"
                            className="w-1.5 bg-[#18181A] hover:bg-[#52525B] cursor-col-resize shrink-0 transition-colors flex items-center justify-center group relative"
                          >
                            <button
                              type="button"
                              onMouseDown={(e) => e.stopPropagation()}
                              onClick={() => {
                                pushLayoutUndo();
                                setRightCollapsed(true);
                              }}
                              title="Collapse Right Inspector"
                              className="hidden group-hover:flex items-center justify-center w-4 h-7 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#A1A1AA] hover:text-[#F4F4F5] z-20 shadow"
                            >
                              <PanelRightClose className="w-3 h-3" />
                            </button>
                          </div>

                          <div style={{ width: effectiveRightWidth }} className="shrink-0 min-h-0">
                            {renderSlot('right', ['properties', 'colorControls', 'layers'])}
                          </div>
                        </>
                      ))}
                  </div>

                  {/* Bottom Full-Width Multi-Track Timeline Dock */}
                  {isPanelDockedVisible(slots.bottom) &&
                    (bottomCollapsed ? (
                      <div className="h-7 mt-1 bg-[#222225] border border-[#3E3E44] rounded-[6px] flex items-center justify-between px-3 shrink-0">
                        <span className="text-[11px] font-medium text-[#A1A1AA]">
                          Timeline Collapsed ({PANEL_TITLES[slots.bottom]})
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            pushLayoutUndo();
                            setBottomCollapsed(false);
                          }}
                          className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#2C2C30] border border-[#3E3E44] text-[10px] text-[#F4F4F5] hover:border-[#A1A1AA] transition-colors"
                        >
                          <ChevronUp className="w-3 h-3" /> Expand Timeline
                        </button>
                      </div>
                    ) : (
                      <>
                        {/* Bottom Vertical Splitter */}
                        <div
                          onMouseDown={(e) => startResize('bottom', e)}
                          title="Drag to resize Timeline height"
                          className="h-1.5 bg-[#18181A] hover:bg-[#52525B] cursor-row-resize shrink-0 transition-colors flex items-center justify-center group"
                        >
                          <button
                            type="button"
                            onMouseDown={(e) => e.stopPropagation()}
                            onClick={() => {
                              pushLayoutUndo();
                              setBottomCollapsed(true);
                            }}
                            title="Collapse Timeline"
                            className="hidden group-hover:flex items-center justify-center w-8 h-3.5 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#A1A1AA] hover:text-[#F4F4F5] z-20 shadow"
                          >
                            <ChevronDown className="w-3 h-3" />
                          </button>
                        </div>

                        <div
                          style={{
                            height: collapsedPanels.includes(slots.bottom)
                              ? 34
                              : effectiveBottomHeight,
                          }}
                          className="shrink-0 min-h-0"
                        >
                          {renderSlot('bottom', ['timeline', 'keyframes', 'nullHierarchy', 'mixer'])}
                        </div>
                      </>
                    ))}
                </>
              )}
            </main>
          </div>

          {/* Floating / Undocked Panel Windows */}
          {floatingPanels.map((fp) => (
            <div
              key={fp.panelId}
              onMouseDown={() => bringFloatingToFront(fp.panelId)}
              style={{
                left: fp.x,
                top: fp.y,
                width: fp.width,
                height: fp.height,
                zIndex: fp.zIndex,
              }}
              className="fixed rounded-[6px] shadow-2xl border border-[#A1A1AA]/50 bg-[#222225] flex flex-col overflow-hidden"
            >
              <PanelShell
                panelId={fp.panelId}
                title={PANEL_TITLES[fp.panelId]}
                isFloating
                canClose={fp.panelId !== 'monitor'}
                canFloat
                onToggleFloat={() => handleTogglePanelFloat(fp.panelId)}
                onClosePanel={() => handleClosePanel(fp.panelId)}
                onDragHeaderMouseDown={(e) => startFloatingDrag(fp.panelId, e)}
                className="h-full border-0"
              >
                {renderPanelContent(fp.panelId)}
              </PanelShell>
              <div
                onMouseDown={(e) => startFloatingResize(fp.panelId, e)}
                title="Drag corner to resize floating panel"
                className="absolute bottom-0 right-0 w-3.5 h-3.5 cursor-nwse-resize z-20"
                style={{
                  background:
                    'linear-gradient(135deg, transparent 50%, rgba(139,112,232,0.8) 50%)',
                }}
              />
            </div>
          ))}
        </div>
      )}

      {/* Save / Rename Custom Workspace Layout Modal */}
      {layoutPromptModal && (
        <div className="fixed inset-0 z-[130] bg-black/70 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#222225] border border-[#3E3E44] rounded-lg shadow-2xl p-4 space-y-3 text-xs text-[#F4F4F5]">
            <h3 className="text-sm font-semibold">
              {layoutPromptModal.mode === 'save'
                ? 'Save Custom Workspace Layout'
                : 'Rename Custom Workspace Layout'}
            </h3>
            <div>
              <label className="block text-[11px] text-[#A1A1AA] mb-1">Layout Name</label>
              <input
                type="text"
                autoFocus
                value={layoutPromptModal.name}
                onChange={(e) =>
                  setLayoutPromptModal((prev) =>
                    prev ? { ...prev, name: e.target.value } : prev
                  )
                }
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && layoutPromptModal.name.trim()) {
                    const cleanName = layoutPromptModal.name.trim();
                    if (layoutPromptModal.mode === 'save') {
                      const newId = `custom-${Date.now().toString(36)}`;
                      const entry: SavedWorkspacePreset = {
                        ...structuredClone(currentLayoutSnapshot),
                        id: newId,
                        presetId: newId,
                        name: cleanName,
                      };
                      setSavedCustomLayouts((prev) => [...prev, entry]);
                      setActivePresetId(newId);
                    } else {
                      setSavedCustomLayouts((prev) =>
                        prev.map((l) =>
                          l.id === activePresetId ? { ...l, name: cleanName } : l
                        )
                      );
                    }
                    setLayoutPromptModal(null);
                  } else if (e.key === 'Escape') {
                    setLayoutPromptModal(null);
                  }
                }}
                className="w-full px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] focus:border-[#A1A1AA] rounded text-[#F4F4F5] focus:outline-none"
              />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setLayoutPromptModal(null)}
                className="px-3 py-1.5 rounded bg-[#2C2C30] hover:bg-[#2F3340] text-[#A1A1AA] hover:text-[#F4F4F5]"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!layoutPromptModal.name.trim()}
                onClick={() => {
                  const cleanName = layoutPromptModal.name.trim();
                  if (!cleanName) return;
                  if (layoutPromptModal.mode === 'save') {
                    const newId = `custom-${Date.now().toString(36)}`;
                    const entry: SavedWorkspacePreset = {
                      ...structuredClone(currentLayoutSnapshot),
                      id: newId,
                      presetId: newId,
                      name: cleanName,
                    };
                    setSavedCustomLayouts((prev) => [...prev, entry]);
                    setActivePresetId(newId);
                  } else {
                    setSavedCustomLayouts((prev) =>
                      prev.map((l) =>
                        l.id === activePresetId ? { ...l, name: cleanName } : l
                      )
                    );
                  }
                  setLayoutPromptModal(null);
                }}
                className="px-3 py-1.5 rounded bg-[#52525B] hover:bg-[#6B7280] disabled:opacity-40 font-semibold text-[#F4F4F5]"
              >
                Save Layout
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clip Speed / Duration Dialog */}
      {speedDurationClipId && (
        <div className="fixed inset-0 z-[130] bg-black/70 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#222225] border border-[#3E3E44] rounded-lg shadow-2xl p-4 space-y-3 text-xs text-[#F4F4F5]">
            <h3 className="text-sm font-semibold">Clip Speed / Duration</h3>
            <div className="space-y-2.5">
              <div>
                <div className="flex justify-between text-[11px] text-[#A1A1AA] mb-1">
                  <span>Speed Multiplier</span>
                  <span className="font-mono-tabular text-[#F4F4F5]">
                    {Math.round(speedDraft.speed * 100)}% ({speedDraft.speed.toFixed(2)}×)
                  </span>
                </div>
                <input
                  type="range"
                  min={0.25}
                  max={4}
                  step={0.05}
                  value={speedDraft.speed}
                  onChange={(e) => {
                    const nextSpeed = Number(e.target.value);
                    const ratio = speedDraft.speed / Math.max(0.1, nextSpeed);
                    setSpeedDraft((d) => ({
                      ...d,
                      speed: nextSpeed,
                      duration: Math.max(0.3, Math.round(d.duration * ratio * 100) / 100),
                    }));
                  }}
                  className="w-full accent-[#A1A1AA]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#A1A1AA] mb-1">
                  Timeline Duration (seconds)
                </label>
                <input
                  type="number"
                  min={0.3}
                  max={3600}
                  step={0.1}
                  value={speedDraft.duration}
                  onChange={(e) =>
                    setSpeedDraft((d) => ({
                      ...d,
                      duration: Math.max(0.3, Number(e.target.value) || 0.3),
                    }))
                  }
                  className="w-full px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] focus:border-[#A1A1AA] rounded text-[#F4F4F5] font-mono-tabular focus:outline-none"
                />
              </div>
              <label className="flex items-center gap-2 cursor-pointer text-[11px]">
                <input
                  type="checkbox"
                  checked={speedDraft.reverse}
                  onChange={(e) =>
                    setSpeedDraft((d) => ({ ...d, reverse: e.target.checked }))
                  }
                  className="accent-[#A1A1AA]"
                />
                Reverse Playback Direction
              </label>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setSpeedDurationClipId(null)}
                className="px-3 py-1.5 rounded bg-[#2C2C30] hover:bg-[#2F3340] text-[#A1A1AA] hover:text-[#F4F4F5]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleUpdateClip(speedDurationClipId, (c) => ({
                    ...c,
                    speed: speedDraft.speed,
                    duration: speedDraft.duration,
                    reverse: speedDraft.reverse,
                  }));
                  setSpeedDurationClipId(null);
                }}
                className="px-3 py-1.5 rounded bg-[#52525B] hover:bg-[#6B7280] font-semibold text-[#F4F4F5]"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}

      {projectModalState && (
        <NewProjectModal
          mode={projectModalState.mode}
          initialConfig={modalInitialConfig}
          initialMediaPick={projectModalState.initialMediaPick ?? null}
          onConfirm={(cfg, mediaFiles) => {
            if (projectModalState.mode === 'create') {
              void handleCreateConfiguredProject(cfg, mediaFiles);
            } else {
              handleUpdateProjectSettings(cfg);
            }
          }}
          onCancel={() => setProjectModalState(null)}
        />
      )}

      {showExportModal && (
        <ExportModal
          project={project}
          playheadTime={playheadTime}
          defaultSettings={{
            resolution: settings.defaultResolution,
            fps: settings.defaultFps,
          }}
          onClose={() => setShowExportModal(false)}
        />
      )}

      {settingsModalTab && (
        <SettingsModal
          settings={settings}
          initialTab={settingsModalTab}
          onUpdateSettings={(next) => {
            setSettings(next);
            saveSettingsToDB(next).catch(() => {});
          }}
          onSelectAudioDevice={handleSelectAudioDevice}
          onClose={() => setSettingsModalTab(null)}
        />
      )}

      {qualityModalTab && (
        <QualityEnhancerModal
          initialTab={qualityModalTab}
          project={project}
          selectedClipId={selectedClipId}
          playheadTime={playheadTime}
          onUpdateClip={handleUpdateClip}
          onClose={() => setQualityModalTab(null)}
        />
      )}

      {showHelpModal && (
        <HelpModal
          onClose={() => setShowHelpModal(false)}
          onOpenShortcuts={() => {
            setShowHelpModal(false);
            setSettingsModalTab('shortcuts');
          }}
          onOpenInteractiveTutorial={() => {
            setShowHelpModal(false);
            void handleStartInteractiveTutorial(false);
          }}
        />
      )}

      {customizeTemplateConfig && (
        <CustomizeTemplateModal
          initialCustomization={customizeTemplateConfig}
          onClose={() => setCustomizeTemplateConfig(null)}
          onApplyAndOpen={(cust) => {
            void handleOpenTrailerTemplate(cust);
          }}
          onSaveAsCustomTemplate={(tpl) => {
            setCustomTemplates(saveCustomTemplate(tpl));
          }}
        />
      )}

      <InteractiveTutorialOverlay
        isOpen={tutorialOpen}
        project={project}
        selectedClip={selectedClip}
        workspaceMode={workspaceMode}
        slots={slots}
        playheadTime={playheadTime}
        isPlaying={isPlaying}
        autoKeyframeEnabled={autoKeyframeEnabled}
        exportModalOpen={showExportModal}
        activeStepIndex={tutorialStepIndex}
        completedStepIds={completedTutorialSteps}
        onChangeStepIndex={setTutorialStepIndex}
        onMarkStepCompleted={handleMarkTutorialStepCompleted}
        onAutoFocusStepPanel={handleFocusTutorialStepPanel}
        onRestartTutorial={() => void handleStartInteractiveTutorial(true)}
        onCloseTutorial={() => setTutorialOpen(false)}
      />
    </>
  );
}
