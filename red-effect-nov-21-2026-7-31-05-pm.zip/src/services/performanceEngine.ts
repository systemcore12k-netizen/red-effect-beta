import { PreviewQuality, ProxyQuality } from '../types/studio';

export type HardwareTier = 'low-end' | 'mid-range' | 'high-end';

export interface HardwareProfile {
  tier: HardwareTier;
  cpuCores: number;
  deviceMemoryGB: number | null;
  webgl2Supported: boolean;
  gpuRenderer: string;
  isIntegratedGPU: boolean;
  recommendedPreviewQuality: PreviewQuality;
  recommendedProxyQuality: ProxyQuality;
  recommendedPerformanceMode: boolean;
  cacheBudgetBytes: number;
}

export interface RenderQualityContext {
  isExport?: boolean;
  previewQuality?: PreviewQuality;
  proxyQuality?: ProxyQuality;
  isInteracting?: boolean; // timeline scrub or canvas drag
  isHoverPreview?: boolean; // transient effect hover preview
  fpsDropFactor?: number; // 0 = normal, 1 = severe drop
}

export interface ResolvedRenderPolicy {
  resolutionScale: number;
  motionBlurSampleCap: number;
  shakeBlurEnabled: boolean;
  particleDensityMult: number;
  skipHeavyScrubEffects: boolean;
  preferWebGL2: boolean;
}

let cachedHardwareProfile: HardwareProfile | null = null;

export function detectHardwareProfile(): HardwareProfile {
  if (cachedHardwareProfile) return cachedHardwareProfile;

  const cpuCores =
    typeof navigator !== 'undefined' && typeof navigator.hardwareConcurrency === 'number'
      ? navigator.hardwareConcurrency
      : 4;
  const deviceMemoryGB =
    typeof navigator !== 'undefined' &&
    typeof (navigator as unknown as { deviceMemory?: number }).deviceMemory === 'number'
      ? ((navigator as unknown as { deviceMemory?: number }).deviceMemory ?? null)
      : null;

  let webgl2Supported = false;
  let gpuRenderer = 'CPU / Software Canvas';
  let isIntegratedGPU = true;

  if (typeof document !== 'undefined') {
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl2', {
        failIfMajorPerformanceCaveat: false,
        powerPreference: 'high-performance',
      });
      if (gl) {
        webgl2Supported = true;
        const dbg = gl.getExtension('WEBGL_debug_renderer_info');
        if (dbg) {
          const raw = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL);
          if (typeof raw === 'string' && raw.trim()) {
            gpuRenderer = raw.trim();
          }
        } else {
          gpuRenderer = String(gl.getParameter(gl.RENDERER) || 'WebGL2 GPU');
        }
        const lower = gpuRenderer.toLowerCase();
        const isDiscrete =
          /rtx|gtx|geforce|radeon rx|quadro|arc a\d+|m[1-4] (pro|max|ultra)/i.test(lower);
        const isSoftware = /swiftshader|llvmpipe|microsoft basic|software/i.test(lower);
        isIntegratedGPU = !isDiscrete || isSoftware;
      }
    } catch {
      webgl2Supported = false;
    }
  }

  let tier: HardwareTier = 'mid-range';
  if (
    cpuCores <= 4 ||
    (deviceMemoryGB !== null && deviceMemoryGB <= 4) ||
    !webgl2Supported ||
    /swiftshader|llvmpipe|intel\(r\) hd graphics|intel\(r\) uhd/i.test(gpuRenderer)
  ) {
    tier = 'low-end';
  } else if (cpuCores >= 8 && (deviceMemoryGB === null || deviceMemoryGB >= 8) && !isIntegratedGPU) {
    tier = 'high-end';
  }

  const recommendedPreviewQuality: PreviewQuality =
    tier === 'low-end' ? 'performance' : tier === 'mid-range' ? 'high' : 'ultra';
  const recommendedProxyQuality: ProxyQuality =
    tier === 'low-end' ? 'half' : 'full';
  const cacheBudgetBytes =
    tier === 'low-end'
      ? 48 * 1024 * 1024
      : tier === 'mid-range'
      ? 128 * 1024 * 1024
      : 256 * 1024 * 1024;

  cachedHardwareProfile = {
    tier,
    cpuCores,
    deviceMemoryGB,
    webgl2Supported,
    gpuRenderer,
    isIntegratedGPU,
    recommendedPreviewQuality,
    recommendedProxyQuality,
    recommendedPerformanceMode: tier === 'low-end',
    cacheBudgetBytes,
  };

  return cachedHardwareProfile;
}

export function getProxyScaleMultiplier(proxyQuality?: ProxyQuality): number {
  switch (proxyQuality) {
    case 'eighth':
      return 0.125;
    case 'quarter':
      return 0.25;
    case 'half':
      return 0.5;
    case 'full':
    default:
      return 1;
  }
}

export function resolveRenderPolicy(ctx: RenderQualityContext): ResolvedRenderPolicy {
  // Final export MUST always use full uncompromised quality regardless of preview settings
  if (ctx.isExport) {
    return {
      resolutionScale: 1,
      motionBlurSampleCap: 16,
      shakeBlurEnabled: true,
      particleDensityMult: 1,
      skipHeavyScrubEffects: false,
      preferWebGL2: true,
    };
  }

  const pq = ctx.previewQuality || 'high';
  const baseProxy = getProxyScaleMultiplier(ctx.proxyQuality);
  let qualityScale = 1;
  let motionBlurSampleCap = 12;
  let shakeBlurEnabled = true;
  let particleDensityMult = 1;
  let skipHeavyScrubEffects = false;

  switch (pq) {
    case 'ultra':
      qualityScale = 1;
      motionBlurSampleCap = 14;
      shakeBlurEnabled = true;
      particleDensityMult = 1;
      break;
    case 'high':
      qualityScale = 1;
      motionBlurSampleCap = 8;
      shakeBlurEnabled = true;
      particleDensityMult = 0.9;
      break;
    case 'medium':
      qualityScale = 0.75;
      motionBlurSampleCap = 5;
      shakeBlurEnabled = true;
      particleDensityMult = 0.65;
      skipHeavyScrubEffects = Boolean(ctx.isInteracting);
      break;
    case 'low':
      qualityScale = 0.45;
      motionBlurSampleCap = 3;
      shakeBlurEnabled = false;
      particleDensityMult = 0.45;
      skipHeavyScrubEffects = Boolean(ctx.isInteracting);
      break;
    case 'performance':
      qualityScale = 0.4;
      motionBlurSampleCap = 2;
      shakeBlurEnabled = false;
      particleDensityMult = 0.35;
      skipHeavyScrubEffects = Boolean(ctx.isInteracting);
      break;
  }

  // Adaptive drop when interactively scrubbing/dragging keyframes or during live hover previews
  if (ctx.isInteracting && pq !== 'ultra') {
    qualityScale *= 0.65;
    motionBlurSampleCap = Math.min(motionBlurSampleCap, 2);
  }
  if (ctx.isHoverPreview) {
    if (pq === 'low' || pq === 'performance') {
      qualityScale *= 0.65;
      motionBlurSampleCap = Math.min(motionBlurSampleCap, 2);
      particleDensityMult *= 0.5;
    } else if (pq !== 'ultra') {
      qualityScale *= 0.8;
      motionBlurSampleCap = Math.min(motionBlurSampleCap, 5);
      particleDensityMult *= 0.75;
    }
  }
  if (ctx.fpsDropFactor && ctx.fpsDropFactor > 0.25) {
    qualityScale *= Math.max(0.45, 1 - ctx.fpsDropFactor * 0.45);
    motionBlurSampleCap = Math.min(motionBlurSampleCap, 3);
  }

  return {
    resolutionScale: Math.max(0.125, Math.min(1, baseProxy * qualityScale)),
    motionBlurSampleCap,
    shakeBlurEnabled,
    particleDensityMult,
    skipHeavyScrubEffects,
    preferWebGL2: true,
  };
}

// Active global render policy for the current frame pass (read by effectsProcessor helpers)
let activePolicy: ResolvedRenderPolicy = {
  resolutionScale: 1,
  motionBlurSampleCap: 12,
  shakeBlurEnabled: true,
  particleDensityMult: 1,
  skipHeavyScrubEffects: false,
  preferWebGL2: true,
};

export function setActiveRenderPolicy(policy: ResolvedRenderPolicy): void {
  activePolicy = policy;
}

export function getActiveRenderPolicy(): ResolvedRenderPolicy {
  return activePolicy;
}

// Reusable ImageData output buffer pool to avoid multi-megabyte allocations per frame
let pooledOutImageData: ImageData | null = null;
let pooledWidth = 0;
let pooledHeight = 0;

export function acquireReusableImageData(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number
): ImageData {
  if (pooledOutImageData && pooledWidth === w && pooledHeight === h) {
    return pooledOutImageData;
  }
  pooledWidth = w;
  pooledHeight = h;
  pooledOutImageData = ctx.createImageData(w, h);
  return pooledOutImageData;
}

export function releasePooledBuffers(): void {
  pooledOutImageData = null;
  pooledWidth = 0;
  pooledHeight = 0;
}

interface CacheEntry<T> {
  key: string;
  value: T;
  bytes: number;
  lastAccess: number;
}

/**
 * Bounded Smart LRU cache with byte budget & prefix invalidation.
 */
export class SmartRenderCache<T = HTMLCanvasElement> {
  private map = new Map<string, CacheEntry<T>>();
  private currentBytes = 0;
  private maxBytes: number;
  private maxEntries: number;
  private accessTick = 0;

  constructor(maxBytes = 64 * 1024 * 1024, maxEntries = 80) {
    this.maxBytes = maxBytes;
    this.maxEntries = maxEntries;
  }

  setBudget(maxBytes: number): void {
    this.maxBytes = Math.max(8 * 1024 * 1024, maxBytes);
    this.evictIfNeeded();
  }

  get(key: string): T | undefined {
    const entry = this.map.get(key);
    if (!entry) return undefined;
    entry.lastAccess = ++this.accessTick;
    // Refresh insertion order for O(1) LRU
    this.map.delete(key);
    this.map.set(key, entry);
    return entry.value;
  }

  set(key: string, value: T, bytes: number): void {
    const existing = this.map.get(key);
    if (existing) {
      this.currentBytes -= existing.bytes;
      this.map.delete(key);
    }
    const safeBytes = Math.max(256, bytes);
    this.map.set(key, {
      key,
      value,
      bytes: safeBytes,
      lastAccess: ++this.accessTick,
    });
    this.currentBytes += safeBytes;
    this.evictIfNeeded();
  }

  invalidatePrefix(prefix: string): void {
    for (const [k, v] of this.map.entries()) {
      if (k.startsWith(prefix)) {
        this.currentBytes -= v.bytes;
        this.map.delete(k);
      }
    }
  }

  clear(): void {
    this.map.clear();
    this.currentBytes = 0;
  }

  getStats(): { entries: number; usedMB: number; budgetMB: number } {
    return {
      entries: this.map.size,
      usedMB: Math.round((this.currentBytes / (1024 * 1024)) * 10) / 10,
      budgetMB: Math.round(this.maxBytes / (1024 * 1024)),
    };
  }

  private evictIfNeeded(): void {
    while (this.currentBytes > this.maxBytes || this.map.size > this.maxEntries) {
      const oldestKey = this.map.keys().next().value;
      if (!oldestKey) break;
      const entry = this.map.get(oldestKey);
      if (entry) {
        this.currentBytes -= entry.bytes;
      }
      this.map.delete(oldestKey);
    }
  }
}

export const textBitmapCache = new SmartRenderCache<HTMLCanvasElement>(48 * 1024 * 1024, 60);

/**
 * Lightweight WebGL2 fragment shader runner for per-pixel video/image effects.
 * Eliminates expensive getImageData/putImageData readbacks on supported hardware.
 */
class WebGL2EffectRunner {
  private canvas: HTMLCanvasElement | null = null;
  private gl: WebGL2RenderingContext | null = null;
  private quadVao: WebGLVertexArrayObject | null = null;
  private srcTex: WebGLTexture | null = null;
  private programs = new Map<string, WebGLProgram>();
  private disabled = false;

  private ensureContext(): WebGL2RenderingContext | null {
    if (this.disabled || typeof document === 'undefined') return null;
    if (this.gl && !this.gl.isContextLost()) return this.gl;

    try {
      this.canvas = document.createElement('canvas');
      const gl = this.canvas.getContext('webgl2', {
        alpha: true,
        premultipliedAlpha: false,
        preserveDrawingBuffer: true,
        antialias: false,
      });
      if (!gl) {
        this.disabled = true;
        return null;
      }

      const vao = gl.createVertexArray();
      gl.bindVertexArray(vao);
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(
        gl.ARRAY_BUFFER,
        new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
        gl.STATIC_DRAW
      );
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      gl.bindVertexArray(null);

      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

      this.gl = gl;
      this.quadVao = vao;
      this.srcTex = tex;
      return gl;
    } catch {
      this.disabled = true;
      return null;
    }
  }

  private getProgram(gl: WebGL2RenderingContext, key: string, fragSrc: string): WebGLProgram | null {
    const cached = this.programs.get(key);
    if (cached) return cached;

    const vertSrc = `#version 300 es
layout(location=0) in vec2 a_pos;
out vec2 v_uv;
void main() {
  v_uv = a_pos * 0.5 + 0.5;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}`;
    const vs = gl.createShader(gl.VERTEX_SHADER);
    const fs = gl.createShader(gl.FRAGMENT_SHADER);
    if (!vs || !fs) return null;

    gl.shaderSource(vs, vertSrc);
    gl.compileShader(vs);
    gl.shaderSource(fs, fragSrc);
    gl.compileShader(fs);
    if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS) || !gl.getShaderParameter(fs, gl.COMPILE_STATUS)) {
      gl.deleteShader(vs);
      gl.deleteShader(fs);
      return null;
    }

    const prog = gl.createProgram();
    if (!prog) return null;
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    gl.deleteShader(vs);
    gl.deleteShader(fs);

    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      gl.deleteProgram(prog);
      return null;
    }
    this.programs.set(key, prog);
    return prog;
  }

  runShader(
    targetCanvas: HTMLCanvasElement,
    key: string,
    fragSrc: string,
    setUniforms: (gl: WebGL2RenderingContext, prog: WebGLProgram) => void
  ): boolean {
    if (!activePolicy.preferWebGL2) return false;
    const gl = this.ensureContext();
    if (!gl || !this.canvas || !this.quadVao || !this.srcTex) return false;

    const w = targetCanvas.width;
    const h = targetCanvas.height;
    if (w < 2 || h < 2) return false;

    const prog = this.getProgram(gl, key, fragSrc);
    if (!prog) return false;

    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }

    gl.viewport(0, 0, w, h);
    gl.useProgram(prog);
    gl.bindVertexArray(this.quadVao);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.srcTex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 1);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, targetCanvas);

    const uTex = gl.getUniformLocation(prog, 'u_tex');
    if (uTex) gl.uniform1i(uTex, 0);
    const uRes = gl.getUniformLocation(prog, 'u_res');
    if (uRes) gl.uniform2f(uRes, w, h);

    setUniforms(gl, prog);

    gl.drawArrays(gl.TRIANGLES, 0, 6);

    const outCtx = targetCanvas.getContext('2d');
    if (!outCtx) return false;
    outCtx.clearRect(0, 0, w, h);
    outCtx.drawImage(this.canvas, 0, 0, w, h);
    return true;
  }
}

export const webgl2Runner = new WebGL2EffectRunner();
