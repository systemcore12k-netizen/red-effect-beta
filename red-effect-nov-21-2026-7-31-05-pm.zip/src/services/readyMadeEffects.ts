import {
  EffectInstance,
  ReadyMadeCategoryId,
  ReadyMadeEffectPreset,
  TransitionSettings,
} from '../types/effects';

export const READY_MADE_CATEGORIES: Array<{
  id: ReadyMadeCategoryId | 'custom';
  label: string;
  shortLabel: string;
  accent: string;
}> = [
  { id: 'shake', label: 'Shake Effects', shortLabel: 'Shake', accent: '#E50914' },
  { id: 'text', label: 'Text Effects', shortLabel: 'Text', accent: '#F59E0B' },
  { id: 'glitch', label: 'Glitch Effects', shortLabel: 'Glitch', accent: '#06B6D4' },
  { id: 'cc', label: 'CC / Color Effects', shortLabel: 'CC / Color', accent: '#F97316' },
  { id: 'blur', label: 'Blur Effects', shortLabel: 'Blur', accent: '#60A5FA' },
  { id: 'rgb', label: 'RGB Effects', shortLabel: 'RGB', accent: '#EC4899' },
  { id: 'distortion', label: 'Distortion Effects', shortLabel: 'Distort', accent: '#A855F7' },
  { id: 'cinematic', label: 'Cinematic Effects', shortLabel: 'Cinematic', accent: '#EAB308' },
  { id: 'transition', label: 'Transition Effects', shortLabel: 'Transitions', accent: '#10B981' },
  { id: 'custom', label: 'Custom Saved', shortLabel: 'Saved', accent: '#94A3B8' },
];

function mkShake(
  id: string,
  name: string,
  description: string,
  accentColor: string,
  params: {
    intensity: number;
    speed: number;
    frequency: number;
    rotation: number;
    posX: number;
    posY: number;
    zoomStrength: number;
    motionBlur: number;
    duration: number;
    smoothness: number;
    startStrength: number;
    endStrength: number;
    waveProfile: 'smooth' | 'impact' | 'staccato' | 'whip' | 'circular';
  }
): ReadyMadeEffectPreset {
  const fx: EffectInstance = {
    id: `fx_${id}`,
    type: 'camera-shake',
    name,
    category: 'shake',
    enabled: true,
    blendMode: 'normal',
    params,
  };
  return {
    id,
    name,
    category: 'shake',
    description,
    accentColor,
    defaultDuration: Math.max(0.8, Math.min(4, params.duration)),
    effectsStack: [fx],
  };
}

function mkFx(
  id: string,
  name: string,
  category: ReadyMadeCategoryId,
  description: string,
  accentColor: string,
  effectsStack: EffectInstance[],
  defaultDuration = 3
): ReadyMadeEffectPreset {
  return {
    id,
    name,
    category,
    description,
    accentColor,
    defaultDuration,
    effectsStack,
  };
}

function mkCC(
  id: string,
  name: string,
  description: string,
  accentColor: string,
  colorGrade: Record<string, unknown>
): ReadyMadeEffectPreset {
  return {
    id,
    name,
    category: 'cc',
    description,
    accentColor,
    defaultDuration: 5,
    colorGrade,
  };
}

function mkTransition(
  id: string,
  name: string,
  description: string,
  accentColor: string,
  transitionConfig: TransitionSettings
): ReadyMadeEffectPreset {
  return {
    id,
    name,
    category: 'transition',
    description,
    accentColor,
    defaultDuration: transitionConfig.duration,
    transitionConfig,
  };
}

export const READY_MADE_PRESETS: ReadyMadeEffectPreset[] = [
  // =========================================================================
  // 1. SHAKE EFFECTS (16 distinct presets)
  // =========================================================================
  mkShake('shake-smooth', 'Smooth Shake', 'Silky sinusoidal handheld float with gentle roll.', '#E50914', {
    intensity: 28,
    speed: 0.75,
    frequency: 3.5,
    rotation: 1.5,
    posX: 16,
    posY: 14,
    zoomStrength: 4,
    motionBlur: 18,
    duration: 2.5,
    smoothness: 88,
    startStrength: 100,
    endStrength: 100,
    waveProfile: 'smooth',
  }),
  mkShake('shake-hard', 'Hard Shake', 'Punchy multi-axis tremor for high-energy edits.', '#EF4444', {
    intensity: 74,
    speed: 1.65,
    frequency: 11,
    rotation: 4.5,
    posX: 34,
    posY: 30,
    zoomStrength: 14,
    motionBlur: 45,
    duration: 1.5,
    smoothness: 25,
    startStrength: 120,
    endStrength: 65,
    waveProfile: 'staccato',
  }),
  mkShake('shake-extreme', 'Extreme Shake', 'Maximum kinetic jolt with heavy rotation & shutter streak.', '#DC2626', {
    intensity: 96,
    speed: 2.25,
    frequency: 15,
    rotation: 9,
    posX: 52,
    posY: 46,
    zoomStrength: 24,
    motionBlur: 72,
    duration: 1.1,
    smoothness: 12,
    startStrength: 150,
    endStrength: 35,
    waveProfile: 'impact',
  }),
  mkShake('shake-velocity', 'Velocity Shake', 'Elastic whip-ramp shake built for speed-ramps.', '#F43F5E', {
    intensity: 64,
    speed: 1.9,
    frequency: 9.5,
    rotation: 3.5,
    posX: 44,
    posY: 22,
    zoomStrength: 20,
    motionBlur: 64,
    duration: 1.2,
    smoothness: 42,
    startStrength: 145,
    endStrength: 18,
    waveProfile: 'whip',
  }),
  mkShake('shake-camera', 'Camera Shake', 'Realistic DSLR handheld lens vibration & micro drift.', '#FB7185', {
    intensity: 34,
    speed: 1.1,
    frequency: 6.2,
    rotation: 1.8,
    posX: 18,
    posY: 20,
    zoomStrength: 2,
    motionBlur: 12,
    duration: 4.0,
    smoothness: 68,
    startStrength: 100,
    endStrength: 100,
    waveProfile: 'circular',
  }),
  mkShake('shake-motion-blur', 'Motion Blur Shake', 'Directional shutter smear sweep with rapid shake.', '#E11D48', {
    intensity: 58,
    speed: 1.5,
    frequency: 8.5,
    rotation: 2.5,
    posX: 42,
    posY: 24,
    zoomStrength: 10,
    motionBlur: 92,
    duration: 1.6,
    smoothness: 52,
    startStrength: 115,
    endStrength: 80,
    waveProfile: 'whip',
  }),
  mkShake('shake-beat', 'Beat Shake', 'Rhythmic bass-drop kick synced to transient beats.', '#F97316', {
    intensity: 68,
    speed: 1.4,
    frequency: 7.5,
    rotation: 3.0,
    posX: 20,
    posY: 36,
    zoomStrength: 26,
    motionBlur: 38,
    duration: 1.0,
    smoothness: 38,
    startStrength: 145,
    endStrength: 10,
    waveProfile: 'impact',
  }),
  mkShake('shake-zoom', 'Zoom Shake', 'Optical pump zoom shake with subtle rotational bounce.', '#FB923C', {
    intensity: 55,
    speed: 1.35,
    frequency: 8.0,
    rotation: 2.0,
    posX: 10,
    posY: 10,
    zoomStrength: 34,
    motionBlur: 44,
    duration: 1.4,
    smoothness: 48,
    startStrength: 130,
    endStrength: 25,
    waveProfile: 'impact',
  }),
  mkShake('shake-horizontal', 'Horizontal Shake', 'Pure crisp X-axis whip oscillation.', '#E50914', {
    intensity: 62,
    speed: 1.6,
    frequency: 10.5,
    rotation: 0.4,
    posX: 60,
    posY: 2,
    zoomStrength: 4,
    motionBlur: 55,
    duration: 1.5,
    smoothness: 40,
    startStrength: 120,
    endStrength: 40,
    waveProfile: 'whip',
  }),
  mkShake('shake-vertical', 'Vertical Shake', 'Subwoofer vertical bounce along Y-axis.', '#F87171', {
    intensity: 60,
    speed: 1.55,
    frequency: 9.0,
    rotation: 0.4,
    posX: 2,
    posY: 58,
    zoomStrength: 5,
    motionBlur: 52,
    duration: 1.5,
    smoothness: 42,
    startStrength: 125,
    endStrength: 45,
    waveProfile: 'impact',
  }),
  mkShake('shake-rotation', 'Rotation Shake', 'Dutch-tilt angular twist with centrifugal pull.', '#EC4899', {
    intensity: 58,
    speed: 1.25,
    frequency: 6.5,
    rotation: 11.5,
    posX: 14,
    posY: 14,
    zoomStrength: 12,
    motionBlur: 35,
    duration: 1.8,
    smoothness: 60,
    startStrength: 110,
    endStrength: 75,
    waveProfile: 'circular',
  }),
  mkShake('shake-cinematic', 'Cinematic Shake', 'Anamorphic earthquake rumble with weighted inertia.', '#B91C1C', {
    intensity: 44,
    speed: 0.85,
    frequency: 5.5,
    rotation: 2.2,
    posX: 26,
    posY: 22,
    zoomStrength: 6,
    motionBlur: 28,
    duration: 2.8,
    smoothness: 76,
    startStrength: 95,
    endStrength: 95,
    waveProfile: 'smooth',
  }),
  mkShake('shake-impact', 'Impact Shake', 'Front-loaded collision shockwave that settles rapidly.', '#DC2626', {
    intensity: 88,
    speed: 2.1,
    frequency: 13.5,
    rotation: 6.0,
    posX: 46,
    posY: 42,
    zoomStrength: 28,
    motionBlur: 68,
    duration: 0.9,
    smoothness: 18,
    startStrength: 150,
    endStrength: 0,
    waveProfile: 'impact',
  }),
  mkShake('shake-fast', 'Fast Shake', 'High-frequency staccato micro-shiver.', '#F43F5E', {
    intensity: 48,
    speed: 2.4,
    frequency: 16.5,
    rotation: 2.8,
    posX: 24,
    posY: 24,
    zoomStrength: 8,
    motionBlur: 36,
    duration: 1.4,
    smoothness: 15,
    startStrength: 110,
    endStrength: 90,
    waveProfile: 'staccato',
  }),
  mkShake('shake-slow', 'Slow Shake', 'Hypnotic zero-gravity organic camera float.', '#FB7185', {
    intensity: 24,
    speed: 0.45,
    frequency: 1.8,
    rotation: 1.6,
    posX: 22,
    posY: 18,
    zoomStrength: 5,
    motionBlur: 8,
    duration: 3.8,
    smoothness: 95,
    startStrength: 100,
    endStrength: 100,
    waveProfile: 'circular',
  }),
  mkShake('shake-whip-snap', 'Whip Snap Shake', 'Sharp whip-pan snap entry with clean damped settle.', '#E50914', {
    intensity: 76,
    speed: 1.85,
    frequency: 10,
    rotation: 5.0,
    posX: 54,
    posY: 18,
    zoomStrength: 16,
    motionBlur: 82,
    duration: 1.0,
    smoothness: 34,
    startStrength: 140,
    endStrength: 5,
    waveProfile: 'whip',
  }),

  // =========================================================================
  // 2. TEXT EFFECTS (15 distinct presets)
  // =========================================================================
  {
    id: 'text-shake',
    name: 'Text Shake',
    category: 'text',
    description: 'High-energy kinetic title tremble for action & edits.',
    accentColor: '#F59E0B',
    defaultDuration: 3,
    textPreset: {
      animation: 'text-shake',
      effectSpeed: 1.4,
      effectIntensity: 115,
      effectDuration: 1.5,
      effectDirection: 'center',
      animationStrength: 120,
      fontWeight: 900,
      color: '#FFFFFF',
      strokeColor: '#000000',
      strokeWidth: 4,
      shadowBlur: 18,
      shadowColor: 'rgba(229,9,20,0.6)',
    },
  },
  {
    id: 'text-glitch',
    name: 'Text Glitch',
    category: 'text',
    description: 'Digital jitter glitch with RGB offset bursts.',
    accentColor: '#06B6D4',
    defaultDuration: 3,
    textPreset: {
      animation: 'text-glitch',
      effectSpeed: 1.6,
      effectIntensity: 130,
      effectDuration: 1.4,
      effectDirection: 'left',
      animationStrength: 130,
      fontWeight: 800,
      color: '#F8FAFC',
      strokeColor: '#06B6D4',
      strokeWidth: 2,
      shadowBlur: 16,
      shadowColor: '#E50914',
    },
  },
  {
    id: 'text-reveal',
    name: 'Text Reveal',
    category: 'text',
    description: 'Clean staggered character reveal from masked baseline.',
    accentColor: '#F59E0B',
    defaultDuration: 3.5,
    textPreset: {
      animation: 'character-reveal',
      effectSpeed: 1.0,
      effectIntensity: 100,
      effectDuration: 1.4,
      effectDirection: 'up',
      animationStrength: 100,
      fontWeight: 700,
      color: '#FFFFFF',
      letterSpacing: 3,
      shadowBlur: 14,
      shadowColor: 'rgba(0,0,0,0.75)',
    },
  },
  {
    id: 'text-typewriter',
    name: 'Typewriter',
    category: 'text',
    description: 'Crisp terminal character-by-character typing sequence.',
    accentColor: '#10B981',
    defaultDuration: 3.5,
    textPreset: {
      animation: 'typewriter',
      effectSpeed: 1.1,
      effectIntensity: 100,
      effectDuration: 1.8,
      effectDirection: 'left',
      animationStrength: 100,
      fontWeight: 600,
      color: '#E2E8F0',
      letterSpacing: 2,
      shadowBlur: 10,
      shadowColor: 'rgba(0,0,0,0.8)',
    },
  },
  {
    id: 'text-bounce',
    name: 'Bounce Text',
    category: 'text',
    description: 'Playful spring overshoot wave on letter scale.',
    accentColor: '#F59E0B',
    defaultDuration: 3,
    textPreset: {
      animation: 'text-bounce',
      effectSpeed: 1.25,
      effectIntensity: 120,
      effectDuration: 1.1,
      effectDirection: 'up',
      animationStrength: 130,
      fontWeight: 800,
      color: '#FDE047',
      strokeColor: '#18181B',
      strokeWidth: 5,
      shadowBlur: 16,
      shadowColor: 'rgba(0,0,0,0.85)',
    },
  },
  {
    id: 'text-popup',
    name: 'Pop-up Text',
    category: 'text',
    description: 'Snappy social-caption elastic scale pop from zero.',
    accentColor: '#FB923C',
    defaultDuration: 2.5,
    textPreset: {
      animation: 'pop-up',
      effectSpeed: 1.4,
      effectIntensity: 135,
      effectDuration: 0.75,
      effectDirection: 'center',
      animationStrength: 140,
      fontWeight: 900,
      color: '#FFFFFF',
      strokeColor: '#09090B',
      strokeWidth: 6,
      shadowBlur: 20,
      shadowColor: 'rgba(0,0,0,0.9)',
    },
  },
  {
    id: 'text-zoom',
    name: 'Zoom Text',
    category: 'text',
    description: 'Dramatic punch-in scale surge with soft motion impact.',
    accentColor: '#EF4444',
    defaultDuration: 3,
    textPreset: {
      animation: 'text-zoom',
      effectSpeed: 1.2,
      effectIntensity: 115,
      effectDuration: 1.2,
      effectDirection: 'center',
      animationStrength: 115,
      fontWeight: 900,
      color: '#FFFFFF',
      shadowBlur: 24,
      shadowColor: 'rgba(0,0,0,0.9)',
    },
  },
  {
    id: 'text-fade',
    name: 'Fade Text',
    category: 'text',
    description: 'Smooth editorial upward drift & gentle opacity fade.',
    accentColor: '#94A3B8',
    defaultDuration: 3.5,
    textPreset: {
      animation: 'fade-up',
      effectSpeed: 0.9,
      effectIntensity: 90,
      effectDuration: 1.4,
      effectDirection: 'up',
      animationStrength: 95,
      fontWeight: 600,
      color: '#F8FAFC',
      letterSpacing: 4,
      shadowBlur: 12,
      shadowColor: 'rgba(0,0,0,0.6)',
    },
  },
  {
    id: 'text-3d',
    name: '3D Text',
    category: 'text',
    description: 'Deep isometric layered 3D extrusion with metallic sheen.',
    accentColor: '#F59E0B',
    defaultDuration: 3.5,
    textPreset: {
      animation: '3d-extrude',
      effectSpeed: 1.0,
      effectIntensity: 110,
      effectDuration: 1.5,
      effectDirection: 'center',
      animationStrength: 115,
      fontWeight: 900,
      color: '#FFFFFF',
      extrude3D: true,
      extrudeDepth: 10,
      gradientEnabled: true,
      gradientStart: '#FFFFFF',
      gradientEnd: '#E50914',
      shadowBlur: 24,
      shadowColor: 'rgba(0,0,0,0.95)',
    },
  },
  {
    id: 'text-cinematic',
    name: 'Cinematic Text',
    category: 'text',
    description: 'Wide-tracked film trailer title card expansion.',
    accentColor: '#EAB308',
    defaultDuration: 4,
    textPreset: {
      animation: 'cinematic-title',
      effectSpeed: 0.8,
      effectIntensity: 105,
      effectDuration: 2.2,
      effectDirection: 'center',
      animationStrength: 105,
      fontWeight: 700,
      color: '#FEF3C7',
      letterSpacing: 10,
      shadowBlur: 22,
      shadowColor: 'rgba(0,0,0,0.85)',
    },
  },
  {
    id: 'text-neon',
    name: 'Neon Text',
    category: 'text',
    description: 'Electric crimson/pink neon tube flicker glow.',
    accentColor: '#EC4899',
    defaultDuration: 3.5,
    textPreset: {
      animation: 'neon-text',
      effectSpeed: 1.3,
      effectIntensity: 135,
      effectDuration: 1.4,
      effectDirection: 'center',
      animationStrength: 125,
      fontWeight: 800,
      color: '#FFF1F2',
      strokeColor: '#E50914',
      strokeWidth: 2,
      shadowBlur: 32,
      shadowColor: '#E50914',
    },
  },
  {
    id: 'text-rgb-split',
    name: 'RGB Split Text',
    category: 'text',
    description: 'Chromatic red-cyan prismatic split across typography.',
    accentColor: '#22D3EE',
    defaultDuration: 3,
    textPreset: {
      animation: 'rgb-text',
      effectSpeed: 1.35,
      effectIntensity: 125,
      effectDuration: 1.5,
      effectDirection: 'right',
      animationStrength: 125,
      fontWeight: 900,
      color: '#FFFFFF',
      shadowBlur: 18,
      shadowColor: '#06B6D4',
    },
  },
  {
    id: 'text-velocity',
    name: 'Velocity Text',
    category: 'text',
    description: 'Rapid horizontal kinetic whip-slide with snap settle.',
    accentColor: '#F43F5E',
    defaultDuration: 2.5,
    textPreset: {
      animation: 'velocity-text',
      effectSpeed: 1.75,
      effectIntensity: 140,
      effectDuration: 0.9,
      effectDirection: 'left',
      animationStrength: 145,
      fontWeight: 900,
      color: '#FFFFFF',
      strokeColor: '#000000',
      strokeWidth: 3,
      shadowBlur: 16,
      shadowColor: 'rgba(229,9,20,0.65)',
    },
  },
  {
    id: 'text-distortion',
    name: 'Distortion Text',
    category: 'text',
    description: 'Liquid shear warp & undulating horizontal skew.',
    accentColor: '#A855F7',
    defaultDuration: 3,
    textPreset: {
      animation: 'distortion-text',
      effectSpeed: 1.25,
      effectIntensity: 125,
      effectDuration: 1.6,
      effectDirection: 'right',
      animationStrength: 130,
      fontWeight: 800,
      color: '#F3E8FF',
      strokeColor: '#7E22CE',
      strokeWidth: 3,
      shadowBlur: 18,
      shadowColor: '#A855F7',
    },
  },
  {
    id: 'text-tracking',
    name: 'Tracking Text',
    category: 'text',
    description: 'Expanding letter-spacing documentary title reveal.',
    accentColor: '#F59E0B',
    defaultDuration: 3.5,
    textPreset: {
      animation: 'tracking-animation',
      effectSpeed: 0.95,
      effectIntensity: 100,
      effectDuration: 1.8,
      effectDirection: 'center',
      animationStrength: 105,
      fontWeight: 600,
      color: '#FFFFFF',
      letterSpacing: 6,
      shadowBlur: 14,
      shadowColor: 'rgba(0,0,0,0.75)',
    },
  },

  // =========================================================================
  // 3. GLITCH EFFECTS (16 genuinely distinct presets)
  // =========================================================================
  mkFx('glitch-rgb-split', 'RGB Split Glitch', 'glitch', 'Prismatic 3-channel tear with diagonal shear.', '#06B6D4', [
    { id: 'fx1', type: 'rgb-glitch', name: 'RGB Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { offset: 22, speed: 1.4, verticalJitter: 6 } },
  ]),
  mkFx('glitch-digital', 'Digital Glitch', 'glitch', 'Macroblock bit-crush packet corruption & freeze tears.', '#22D3EE', [
    { id: 'fx1', type: 'digital-glitch', name: 'Digital Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { blockSize: 28, density: 48, seedSpeed: 14 } },
  ]),
  mkFx('glitch-vhs', 'VHS Glitch', 'glitch', 'Analog magnetic tape tracking warble & head-switch snow.', '#EC4899', [
    { id: 'fx1', type: 'vhs-glitch', name: 'VHS Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { trackingError: 55, staticNoise: 38, colorBleed: 62 } },
  ]),
  mkFx('glitch-cyber', 'Cyber Glitch', 'glitch', 'Neon cybernetic slice-tear + chromatic edge separation.', '#8B5CF6', [
    { id: 'fx1', type: 'horizontal-glitch', name: 'Horizontal Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { tearCount: 16, displacement: 36, speed: 2.1 } },
    { id: 'fx2', type: 'chromatic-aberration', name: 'Chromatic Aberration', category: 'glitch', enabled: true, blendMode: 'normal', params: { shift: 14, angle: 12 } },
  ]),
  mkFx('glitch-pixel', 'Pixel Glitch', 'glitch', 'Vertical pixel-sort smear streaks across highlights.', '#38BDF8', [
    { id: 'fx1', type: 'pixel-sorting', name: 'Pixel Sorting', category: 'glitch', enabled: true, blendMode: 'normal', params: { threshold: 45, streakLength: 64 } },
    { id: 'fx2', type: 'digital-glitch', name: 'Digital Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { blockSize: 16, density: 28, seedSpeed: 10 } },
  ]),
  mkFx('glitch-data-corruption', 'Data Corruption', 'glitch', 'Severe MPEG I-frame macroblock scramble & color invert strips.', '#F43F5E', [
    { id: 'fx1', type: 'data-corruption', name: 'Data Corruption', category: 'glitch', enabled: true, blendMode: 'normal', params: { severity: 72, corruptionBlocks: 28, speed: 1.5 } },
  ]),
  mkFx('glitch-horizontal', 'Horizontal Glitch', 'glitch', 'Razor-sharp horizontal scan-row displacement slicing.', '#0EA5E9', [
    { id: 'fx1', type: 'horizontal-glitch', name: 'Horizontal Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { tearCount: 22, displacement: 52, speed: 1.7 } },
  ]),
  mkFx('glitch-vertical', 'Vertical Glitch', 'glitch', 'Vertical column drop & telemetry strip shift.', '#14B8A6', [
    { id: 'fx1', type: 'vertical-glitch', name: 'Vertical Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { columns: 18, displacement: 44, speed: 1.5 } },
  ]),
  mkFx('glitch-screen-tear', 'Screen Tear', 'glitch', 'Uncapped V-Sync jagged frame split with red bleed.', '#E50914', [
    { id: 'fx1', type: 'screen-tear', name: 'Screen Tear', category: 'glitch', enabled: true, blendMode: 'normal', params: { tears: 8, offset: 58, flicker: 55 } },
  ]),
  mkFx('glitch-chromatic', 'Chromatic Aberration', 'glitch', 'Optic radial RGB fringe dispersion along frame edges.', '#A855F7', [
    { id: 'fx1', type: 'chromatic-aberration', name: 'Chromatic Aberration', category: 'glitch', enabled: true, blendMode: 'normal', params: { shift: 24, angle: 0 } },
  ]),
  mkFx('glitch-static-noise', 'Static Noise', 'glitch', 'Broadcast antenna snow static & RF signal hiss lines.', '#94A3B8', [
    { id: 'fx1', type: 'digital-noise', name: 'Digital Noise', category: 'glitch', enabled: true, blendMode: 'normal', params: { intensity: 48, chromaNoise: 65 } },
    { id: 'fx2', type: 'scan-lines', name: 'Scan Lines', category: 'glitch', enabled: true, blendMode: 'normal', params: { density: 58, opacity: 52, scrollSpeed: 1.6 } },
  ]),
  mkFx('glitch-digital-distortion', 'Digital Distortion', 'glitch', 'RF signal interference bars paired with wave frequency bends.', '#6366F1', [
    { id: 'fx1', type: 'signal-interference', name: 'Signal Interference', category: 'glitch', enabled: true, blendMode: 'normal', params: { strength: 68, bandHeight: 42 } },
    { id: 'fx2', type: 'glitch-distortion', name: 'Glitch Distortion', category: 'distortion', enabled: true, blendMode: 'normal', params: { strength: 42, slices: 18 } },
  ]),
  mkFx('glitch-rgb-flash', 'RGB Flash', 'glitch', 'Strobe red-cyan exposure pulses with prism offset.', '#FB7185', [
    { id: 'fx1', type: 'rgb-flash', name: 'RGB Flash', category: 'glitch', enabled: true, blendMode: 'normal', params: { flashRate: 8, intensity: 72, split: 18 } },
  ]),
  mkFx('glitch-cyberpunk', 'Cyberpunk Glitch', 'glitch', 'CRT scanline overlay + neon edge RGB glitch + VHS bleed.', '#F472B6', [
    { id: 'fx1', type: 'scan-lines', name: 'Scan Lines', category: 'glitch', enabled: true, blendMode: 'normal', params: { density: 70, opacity: 45, scrollSpeed: 1.1 } },
    { id: 'fx2', type: 'rgb-glitch', name: 'RGB Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { offset: 18, speed: 1.8, verticalJitter: 4 } },
    { id: 'fx3', type: 'vhs-glitch', name: 'VHS Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { trackingError: 25, staticNoise: 18, colorBleed: 48 } },
  ]),
  mkFx('glitch-fast', 'Fast Glitch', 'glitch', 'Hyper-rapid burst jitter at 2.8x strobe cadence.', '#22D3EE', [
    { id: 'fx1', type: 'horizontal-glitch', name: 'Horizontal Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { tearCount: 28, displacement: 30, speed: 2.9 } },
    { id: 'fx2', type: 'rgb-flash', name: 'RGB Flash', category: 'glitch', enabled: true, blendMode: 'normal', params: { flashRate: 14, intensity: 35, split: 12 } },
  ]),
  mkFx('glitch-extreme', 'Extreme Glitch', 'glitch', 'Full-spectrum data shatter + vertical & horizontal chaos.', '#E50914', [
    { id: 'fx1', type: 'data-corruption', name: 'Data Corruption', category: 'glitch', enabled: true, blendMode: 'normal', params: { severity: 88, corruptionBlocks: 44, speed: 2.4 } },
    { id: 'fx2', type: 'screen-tear', name: 'Screen Tear', category: 'glitch', enabled: true, blendMode: 'normal', params: { tears: 12, offset: 72, flicker: 75 } },
    { id: 'fx3', type: 'rgb-glitch', name: 'RGB Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { offset: 32, speed: 2.5, verticalJitter: 14 } },
  ]),

  // =========================================================================
  // 4. CC / COLOR EFFECTS (15 distinct full-grade looks)
  // =========================================================================
  mkCC('cc-cinematic', 'Cinematic CC', 'Balanced Hollywood contrast, gentle shadow cool & crisp skin.', '#F97316', {
    preset: 'cinematic-cc',
    exposure: 4,
    contrast: 18,
    saturation: 8,
    temperature: -4,
    tint: 2,
    highlights: -14,
    shadows: 12,
    whites: 10,
    blacks: -12,
    vibrance: 16,
    vignette: 26,
    lutIntensity: 90,
  }),
  mkCC('cc-dark', 'Dark CC', 'Low-key obsidian shadows with controlled highlight roll-off.', '#64748B', {
    preset: 'dark-cc',
    exposure: -22,
    contrast: 28,
    saturation: -18,
    temperature: -10,
    tint: 0,
    highlights: -20,
    shadows: -24,
    whites: -6,
    blacks: -28,
    vibrance: 8,
    vignette: 48,
    lutIntensity: 95,
  }),
  mkCC('cc-moody', 'Moody CC', 'Desaturated slate shadow base with muted atmospheric depth.', '#475569', {
    preset: 'moody-cc',
    exposure: -10,
    contrast: 16,
    saturation: -26,
    temperature: -14,
    tint: 6,
    highlights: -18,
    shadows: -10,
    whites: -10,
    blacks: -18,
    vibrance: 14,
    vignette: 38,
    lutIntensity: 90,
  }),
  mkCC('cc-teal-orange', 'Teal & Orange', 'Signature blockbuster cyan shadows & warm amber skin tones.', '#06B6D4', {
    preset: 'cinematic-teal-orange',
    exposure: 2,
    contrast: 22,
    saturation: 14,
    temperature: 10,
    tint: -6,
    highlights: -10,
    shadows: 8,
    whites: 12,
    blacks: -14,
    vibrance: 22,
    vignette: 24,
    lutIntensity: 95,
  }),
  mkCC('cc-blue-cinematic', 'Blue Cinematic', 'Cool sapphire sci-fi & night-thriller steel color grade.', '#3B82F6', {
    preset: 'blue-cinematic',
    exposure: -6,
    contrast: 20,
    saturation: -6,
    temperature: -38,
    tint: -8,
    highlights: -8,
    shadows: 10,
    whites: 4,
    blacks: -16,
    vibrance: 12,
    vignette: 34,
    lutIntensity: 92,
  }),
  mkCC('cc-warm-film', 'Warm Film', 'Nostalgic amber tungsten stock with gentle lifted shadows.', '#F59E0B', {
    preset: 'warm-film',
    exposure: 8,
    contrast: 10,
    saturation: 12,
    temperature: 32,
    tint: 6,
    highlights: -6,
    shadows: 14,
    whites: 8,
    blacks: 4,
    vibrance: 18,
    vignette: 20,
    lutIntensity: 90,
  }),
  mkCC('cc-cold-film', 'Cold Film', 'Arctic winter silver-blue tone with crisp midtone clarity.', '#38BDF8', {
    preset: 'cold-film',
    exposure: 0,
    contrast: 16,
    saturation: -12,
    temperature: -34,
    tint: 4,
    highlights: 8,
    shadows: -6,
    whites: 14,
    blacks: -12,
    vibrance: 6,
    vignette: 28,
    lutIntensity: 90,
  }),
  mkCC('cc-vintage-film', 'Vintage Film', 'Matte 35mm faded blacks, warm halation & classic grain tint.', '#D97706', {
    preset: 'vintage-35mm',
    exposure: 4,
    contrast: -8,
    saturation: -16,
    temperature: 18,
    tint: 10,
    highlights: -18,
    shadows: 24,
    whites: -12,
    blacks: 18,
    vibrance: 10,
    vignette: 42,
    lutIntensity: 92,
  }),
  mkCC('cc-anime', 'Anime CC', 'Hyper-vibrant Makoto Shinkai sky saturation & luminous pop.', '#EC4899', {
    preset: 'anime-cc',
    exposure: 10,
    contrast: 20,
    saturation: 36,
    temperature: 4,
    tint: 8,
    highlights: 16,
    shadows: 18,
    whites: 20,
    blacks: -8,
    vibrance: 42,
    vignette: 12,
    lutIntensity: 95,
  }),
  mkCC('cc-hdr', 'HDR Look', 'Micro-contrast detail recovery with deep shadow/highlight lift.', '#10B981', {
    preset: 'hdr-look',
    exposure: 6,
    contrast: 30,
    saturation: 22,
    temperature: 2,
    tint: 0,
    highlights: -36,
    shadows: 38,
    whites: 22,
    blacks: -18,
    vibrance: 28,
    vignette: 14,
    lutIntensity: 90,
  }),
  mkCC('cc-high-contrast', 'High Contrast', 'Punchy commercial contrast curve with razor-sharp blacks.', '#F8FAFC', {
    preset: 'high-contrast',
    exposure: 4,
    contrast: 46,
    saturation: 8,
    temperature: 0,
    tint: 0,
    highlights: 14,
    shadows: -20,
    whites: 24,
    blacks: -32,
    vibrance: 10,
    vignette: 22,
    lutIntensity: 95,
  }),
  mkCC('cc-dark-fantasy', 'Dark Fantasy', 'Deep amethyst shadows & crimson/gold spectral highlights.', '#9333EA', {
    preset: 'dark-fantasy',
    exposure: -14,
    contrast: 32,
    saturation: -6,
    temperature: -18,
    tint: 18,
    highlights: 10,
    shadows: -18,
    whites: -4,
    blacks: -26,
    vibrance: 24,
    vignette: 54,
    lutIntensity: 95,
  }),
  mkCC('cc-film-pro', 'Professional Film Look', 'Kodak 2383 print curve with rich neutral highlight roll-off.', '#EAB308', {
    preset: 'film-pro',
    exposure: 2,
    contrast: 16,
    saturation: 6,
    temperature: 6,
    tint: -2,
    highlights: -16,
    shadows: 6,
    whites: 6,
    blacks: -14,
    vibrance: 14,
    vignette: 26,
    lutIntensity: 92,
  }),
  mkCC('cc-crimson-noir', 'Crimson Noir', 'Sin City stark monochrome with glowing red selectivity.', '#E50914', {
    preset: 'crimson-noir',
    exposure: -8,
    contrast: 38,
    saturation: -45,
    temperature: 12,
    tint: 14,
    highlights: 12,
    shadows: -24,
    whites: 18,
    blacks: -34,
    vibrance: 32,
    vignette: 58,
    lutIntensity: 100,
  }),
  mkCC('cc-golden-hour', 'Golden Hour', 'Sun-drenched honey backlight glow with soft highlight bloom.', '#FB923C', {
    preset: 'golden-hour',
    exposure: 10,
    contrast: 12,
    saturation: 18,
    temperature: 42,
    tint: 8,
    highlights: 10,
    shadows: 20,
    whites: 12,
    blacks: -4,
    vibrance: 26,
    vignette: 18,
    lutIntensity: 92,
  }),

  // =========================================================================
  // 5. BLUR EFFECTS (8 presets)
  // =========================================================================
  mkFx('blur-gaussian', 'Gaussian Dream', 'blur', 'Smooth isotropic optical Gaussian softness.', '#60A5FA', [
    { id: 'fx1', type: 'gaussian-blur', name: 'Gaussian Blur', category: 'blur', enabled: true, blendMode: 'normal', params: { radius: 14, iterations: 2 } },
  ]),
  mkFx('blur-motion', 'Directional Velocity Blur', 'blur', 'Horizontal high-speed action shutter blur.', '#3B82F6', [
    { id: 'fx1', type: 'motion-blur', name: 'Motion Blur', category: 'blur', enabled: true, blendMode: 'normal', params: { angle: 0, distance: 34, samples: 12 } },
  ]),
  mkFx('blur-radial', 'Radial Spin Blur', 'blur', 'Centrifugal whirl blur spinning around center focus.', '#6366F1', [
    { id: 'fx1', type: 'radial-blur', name: 'Radial Blur', category: 'blur', enabled: true, blendMode: 'normal', params: { strength: 48, centerX: 50, centerY: 50 } },
  ]),
  mkFx('blur-zoom', 'Zoom Rush Blur', 'blur', 'Hyper-speed tunnel streaks radiating outward.', '#38BDF8', [
    { id: 'fx1', type: 'zoom-blur', name: 'Zoom Blur', category: 'blur', enabled: true, blendMode: 'normal', params: { strength: 52, centerX: 50, centerY: 50 } },
  ]),
  mkFx('blur-lens', 'Cinema Lens Blur', 'blur', 'Shallow depth-of-field specular aperture defocus.', '#818CF8', [
    { id: 'fx1', type: 'lens-blur', name: 'Lens Blur', category: 'blur', enabled: true, blendMode: 'normal', params: { radius: 18, brightnessBoost: 28 } },
  ]),
  mkFx('blur-box', 'Soft Box Haze', 'blur', 'Uniform matte box defocus for clean title backdrops.', '#93C5FD', [
    { id: 'fx1', type: 'box-blur', name: 'Box Blur', category: 'blur', enabled: true, blendMode: 'normal', params: { radius: 12 } },
  ]),
  mkFx('blur-edge', 'Tilt-Shift Edge Blur', 'blur', 'Keeps center razor-sharp while softening outer frame.', '#60A5FA', [
    { id: 'fx1', type: 'edge-blur', name: 'Edge Blur', category: 'blur', enabled: true, blendMode: 'normal', params: { radius: 22, innerClear: 48 } },
  ]),
  mkFx('blur-bokeh', 'Creamy Bokeh Blur', 'blur', 'Luminous highlight blooming aperture bokeh circles.', '#A5B4FC', [
    { id: 'fx1', type: 'bokeh-blur', name: 'Bokeh Blur', category: 'blur', enabled: true, blendMode: 'normal', params: { radius: 16, highlightThreshold: 175, bokehGain: 68 } },
  ]),

  // =========================================================================
  // 6. RGB EFFECTS (7 presets)
  // =========================================================================
  mkFx('rgb-prism', 'Prism RGB Split', 'rgb', 'Horizontal red/cyan prismatic channel separation.', '#EC4899', [
    { id: 'fx1', type: 'rgb-split', name: 'RGB Split', category: 'color', enabled: true, blendMode: 'normal', params: { shiftX: 18, shiftY: 0, angle: 0 } },
  ]),
  mkFx('rgb-diagonal', 'Diagonal Channel Drift', 'rgb', '45° angled RGB dispersion with neon edge pop.', '#F472B6', [
    { id: 'fx1', type: 'rgb-split', name: 'RGB Split', category: 'color', enabled: true, blendMode: 'normal', params: { shiftX: 20, shiftY: 14, angle: 45 } },
  ]),
  mkFx('rgb-optic-fringe', 'Optic Lens Fringe', 'rgb', 'Anamorphic lens-edge chromatic aberration.', '#06B6D4', [
    { id: 'fx1', type: 'chromatic-aberration', name: 'Chromatic Aberration', category: 'glitch', enabled: true, blendMode: 'normal', params: { shift: 20, angle: 15 } },
  ]),
  mkFx('rgb-pulse', 'Beat RGB Pulse', 'rgb', 'Animated oscillating RGB split burst.', '#E50914', [
    { id: 'fx1', type: 'rgb-glitch', name: 'RGB Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { offset: 24, speed: 1.9, verticalJitter: 2 } },
  ]),
  mkFx('rgb-neon-outline', 'Neon Edge RGB', 'rgb', 'Glowing crimson Sobel edge highlight overlay.', '#F43F5E', [
    { id: 'fx1', type: 'glow-edges', name: 'Glow Edges', category: 'stylize', enabled: true, blendMode: 'normal', params: { threshold: 36, intensity: 90, color: '#E50914' } },
  ]),
  mkFx('rgb-flash-strobe', 'RGB Color Flash', 'rgb', 'Rapid RGB strobe tint pulse for beat drops.', '#A855F7', [
    { id: 'fx1', type: 'rgb-flash', name: 'RGB Flash', category: 'glitch', enabled: true, blendMode: 'normal', params: { flashRate: 10, intensity: 65, split: 20 } },
  ]),
  mkFx('rgb-vhs-bleed', 'Analog RGB Bleed', 'rgb', 'Soft chroma shift + warm analog tape color smear.', '#FB7185', [
    { id: 'fx1', type: 'rgb-split', name: 'RGB Split', category: 'color', enabled: true, blendMode: 'normal', params: { shiftX: 12, shiftY: 4, angle: 8 } },
    { id: 'fx2', type: 'vhs-glitch', name: 'VHS Glitch', category: 'glitch', enabled: true, blendMode: 'normal', params: { trackingError: 18, staticNoise: 12, colorBleed: 85 } },
  ]),

  // =========================================================================
  // 7. DISTORTION EFFECTS (8 presets)
  // =========================================================================
  mkFx('distort-wave', 'Ocean Wave Warp', 'distortion', 'Smooth animated sinusoidal horizon ripple warp.', '#A855F7', [
    { id: 'fx1', type: 'wave-warp', name: 'Wave Warp', category: 'distortion', enabled: true, blendMode: 'normal', params: { amplitude: 22, frequency: 4.5, speed: 1.8, direction: 'horizontal' } },
  ]),
  mkFx('distort-ripple', 'Shockwave Ripple', 'distortion', 'Concentric expanding water ripple ring distortion.', '#8B5CF6', [
    { id: 'fx1', type: 'ripple', name: 'Ripple', category: 'distortion', enabled: true, blendMode: 'normal', params: { amplitude: 20, frequency: 12, speed: 2.0 } },
  ]),
  mkFx('distort-twirl', 'Vortex Twirl', 'distortion', 'Swirling gravitational whirlpool twist around center.', '#C084FC', [
    { id: 'fx1', type: 'twirl', name: 'Twirl', category: 'distortion', enabled: true, blendMode: 'normal', params: { angle: 110, radius: 75 } },
  ]),
  mkFx('distort-bulge', 'Fisheye Bulge', 'distortion', 'Wide-angle action cam spherical center magnification.', '#9333EA', [
    { id: 'fx1', type: 'bulge', name: 'Bulge', category: 'distortion', enabled: true, blendMode: 'normal', params: { strength: 58, radius: 78 } },
  ]),
  mkFx('distort-pinch', 'Implosion Pinch', 'distortion', 'Dramatic inward suction pinch pulling toward center.', '#7E22CE', [
    { id: 'fx1', type: 'pinch', name: 'Pinch', category: 'distortion', enabled: true, blendMode: 'normal', params: { strength: 55, radius: 75 } },
  ]),
  mkFx('distort-turbulent', 'Heat Mirage Displace', 'distortion', 'Organic multi-octave turbulent shimmer displacement.', '#D946EF', [
    { id: 'fx1', type: 'turbulent-displace', name: 'Turbulent Displace', category: 'distortion', enabled: true, blendMode: 'normal', params: { amount: 26, scale: 38, speed: 1.6 } },
  ]),
  mkFx('distort-lens', 'Anamorphic Barrel Lens', 'distortion', 'Optic barrel curvature for ultra-wide cinema shots.', '#A855F7', [
    { id: 'fx1', type: 'lens-distortion', name: 'Lens Distortion', category: 'distortion', enabled: true, blendMode: 'normal', params: { curvature: 42 } },
  ]),
  mkFx('distort-perspective', 'Perspective Tilt', 'distortion', 'Dynamic 3D keystone perspective trapezoid skew.', '#6366F1', [
    { id: 'fx1', type: 'perspective-distortion', name: 'Perspective Distortion', category: 'distortion', enabled: true, blendMode: 'normal', params: { topPinch: 28, bottomSpread: 18 } },
  ]),

  // =========================================================================
  // 8. CINEMATIC EFFECTS (8 presets)
  // =========================================================================
  mkFx('cinema-glow', 'Pro Halation Glow', 'cinematic', 'Warm cinema film halation bloom around bright highlights.', '#EAB308', [
    { id: 'fx1', type: 'glow', name: 'Glow', category: 'glow', enabled: true, blendMode: 'normal', params: { intensity: 72, radius: 22, threshold: 130, color: '#FFD8B0' } },
  ]),
  mkFx('cinema-streaks', 'Anamorphic Streaks', 'cinematic', 'Classic J.J. Abrams horizontal blue-gold lens streak flare.', '#38BDF8', [
    { id: 'fx1', type: 'light-streaks', name: 'Light Streaks', category: 'glow', enabled: true, blendMode: 'normal', params: { length: 110, intensity: 72, threshold: 175, color: '#60A5FA' } },
  ]),
  mkFx('cinema-lens-flare', 'Solar Lens Flare', 'cinematic', 'Orbital sun-flare hotspots & hexagonal iris ghosts.', '#F59E0B', [
    { id: 'fx1', type: 'lens-flare', name: 'Lens Flare', category: 'glow', enabled: true, blendMode: 'normal', params: { x: 26, y: 24, intensity: 78, tint: '#FFE4A0' } },
  ]),
  mkFx('cinema-light-leak', '35mm Film Light Leak', 'cinematic', 'Organic sweeping warm crimson-amber film burn leak.', '#EF4444', [
    { id: 'fx1', type: 'light-leak', name: 'Light Leak', category: 'glow', enabled: true, blendMode: 'normal', params: { intensity: 68, speed: 0.75, colorA: '#E50914', colorB: '#FF9800' } },
  ]),
  mkFx('cinema-god-rays', 'Volumetric God Rays', 'cinematic', 'Cathedral overhead light shafts cutting through haze.', '#FBBF24', [
    { id: 'fx1', type: 'god-rays', name: 'God Rays', category: 'glow', enabled: true, blendMode: 'normal', params: { angle: -32, density: 68, brightness: 64, color: '#FFE082' } },
  ]),
  mkFx('cinema-bloom', 'Ethereal Highlight Bloom', 'cinematic', 'Velvety soft-focus highlight veil for music videos.', '#FDE047', [
    { id: 'fx1', type: 'bloom', name: 'Bloom', category: 'glow', enabled: true, blendMode: 'normal', params: { intensity: 66, radius: 28, knee: 155 } },
  ]),
  mkFx('cinema-film-grain', '35mm Kodak Grain', 'cinematic', 'Organic silver-halide film texture & subtle bloom.', '#D97706', [
    { id: 'fx1', type: 'film-grain', name: 'Film Grain', category: 'texture', enabled: true, blendMode: 'normal', params: { amount: 34, size: 1.4, animated: true } },
    { id: 'fx2', type: 'bloom', name: 'Bloom', category: 'glow', enabled: true, blendMode: 'normal', params: { intensity: 28, radius: 14, knee: 185 } },
  ]),
  mkFx('cinema-neon-rim', 'Cyber Rim Neon Glow', 'cinematic', 'Electric crimson neon specular accent lighting.', '#E50914', [
    { id: 'fx1', type: 'neon-glow', name: 'Neon Glow', category: 'glow', enabled: true, blendMode: 'normal', params: { intensity: 74, radius: 18, color: '#E50914' } },
    { id: 'fx2', type: 'vignette-shadow', name: 'Vignette Shadow', category: 'shadow', enabled: true, blendMode: 'normal', params: { amount: 46, softness: 65 } },
  ]),

  // =========================================================================
  // 9. TRANSITION EFFECTS (8 ready-to-drop transitions)
  // =========================================================================
  mkTransition('trans-whip-pan', 'Whip Pan Swipe', 'High-velocity directional camera whip blur.', '#10B981', {
    type: 'whip-pan',
    duration: 0.55,
    speed: 1.35,
    direction: 'left',
    intensity: 88,
    smoothness: 75,
    easing: 'easeOut',
  }),
  mkTransition('trans-zoom-punch', 'Zoom Punch In', 'Snappy lens zoom rush into next cut.', '#34D399', {
    type: 'lens-zoom',
    duration: 0.6,
    speed: 1.25,
    direction: 'center',
    intensity: 85,
    smoothness: 70,
    easing: 'easeInOut',
  }),
  mkTransition('trans-flash-cut', 'White Flash Cut', 'Strobe exposure flash bridge between action beats.', '#F8FAFC', {
    type: 'flash-transition',
    duration: 0.45,
    speed: 1.4,
    direction: 'center',
    intensity: 90,
    smoothness: 60,
    easing: 'easeOut',
  }),
  mkTransition('trans-glitch-cut', 'Glitch Cut', 'Digital RGB split shockwave cut.', '#06B6D4', {
    type: 'glitch-cut',
    duration: 0.5,
    speed: 1.5,
    direction: 'left',
    intensity: 85,
    smoothness: 35,
    easing: 'linear',
  }),
  mkTransition('trans-film-burn', 'Film Burn Leak', 'Warm 35mm organic light flare burn.', '#F97316', {
    type: 'film-burn',
    duration: 0.85,
    speed: 1.0,
    direction: 'center',
    intensity: 85,
    smoothness: 80,
    easing: 'easeInOut',
  }),
  mkTransition('trans-spin-cut', '360° Spin Blur', 'Whip centrifugal spin cut with motion blur.', '#A855F7', {
    type: 'spin-transition',
    duration: 0.65,
    speed: 1.25,
    direction: 'right',
    intensity: 82,
    smoothness: 72,
    easing: 'easeInOut',
  }),
  mkTransition('trans-circle-reveal', 'Iris Circle Reveal', 'Expanding circular aperture mask transition.', '#10B981', {
    type: 'circle-reveal',
    duration: 0.75,
    speed: 1.0,
    direction: 'center',
    intensity: 90,
    smoothness: 80,
    easing: 'easeInOut',
  }),
  mkTransition('trans-cross-dissolve', 'Smooth Cross Dissolve', 'Classic cinema opacity dissolve blend.', '#94A3B8', {
    type: 'cross-dissolve',
    duration: 0.8,
    speed: 1.0,
    direction: 'center',
    intensity: 100,
    smoothness: 90,
    easing: 'smooth',
  }),
];

const CUSTOM_READY_PRESETS_KEY = 'redeffect_custom_ready_presets_v1';

export function loadCustomReadyPresets(): ReadyMadeEffectPreset[] {
  try {
    const raw = localStorage.getItem(CUSTOM_READY_PRESETS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveCustomReadyPreset(preset: ReadyMadeEffectPreset): ReadyMadeEffectPreset[] {
  const existing = loadCustomReadyPresets();
  const next = [{ ...preset, isCustom: true, createdAt: Date.now() }, ...existing.filter((p) => p.id !== preset.id)];
  try {
    localStorage.setItem(CUSTOM_READY_PRESETS_KEY, JSON.stringify(next));
  } catch {
    // ignore storage quota
  }
  return next;
}

export function deleteCustomReadyPreset(id: string): ReadyMadeEffectPreset[] {
  const next = loadCustomReadyPresets().filter((p) => p.id !== id);
  try {
    localStorage.setItem(CUSTOM_READY_PRESETS_KEY, JSON.stringify(next));
  } catch {
    // ignore
  }
  return next;
}

export function getAllReadyMadePresets(customPresets?: ReadyMadeEffectPreset[]): ReadyMadeEffectPreset[] {
  const custom = customPresets ?? loadCustomReadyPresets();
  return [...custom, ...READY_MADE_PRESETS];
}

export function findReadyMadePreset(
  presetId: string,
  customPresets?: ReadyMadeEffectPreset[]
): ReadyMadeEffectPreset | undefined {
  return getAllReadyMadePresets(customPresets).find((p) => p.id === presetId);
}
