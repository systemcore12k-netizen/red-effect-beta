import {
  EnhancementProcessingQuality,
  MediaAsset,
  SmoothVideoFpsTarget,
  SmoothVideoSettings,
  TimelineClip,
} from '../types/studio';
import { detectHardwareProfile } from './performanceEngine';

export function createDefaultSmoothVideoSettings(): SmoothVideoSettings {
  return {
    enabled: false,
    targetFps: 60,
    processingQuality: 'balanced',
    slowMotionSpeed: 1,
    motionBlurReduction: 35,
    artifactSuppression: 75,
    preRenderedCount: 0,
  };
}

export function resolveEffectiveTargetFps(
  target: SmoothVideoFpsTarget,
  sourceFps = 30
): number {
  if (target === 'original') return Math.max(12, sourceFps);
  return target;
}

export function serializeSmoothSignature(s: SmoothVideoSettings): string {
  return `${s.enabled ? 1 : 0}_${s.targetFps}_${s.processingQuality}_${s.slowMotionSpeed}_${Math.round(
    s.artifactSuppression
  )}`;
}

export interface OpticalFlowField {
  cols: number;
  rows: number;
  blockSize: number;
  scaleToFullX: number;
  scaleToFullY: number;
  vx: Float32Array;
  vy: Float32Array;
  confidence: Float32Array; // 0..1
}

function buildLumaBuffer(
  rgba: Uint8ClampedArray,
  srcW: number,
  srcH: number,
  dstW: number,
  dstH: number
): Float32Array {
  const luma = new Float32Array(dstW * dstH);
  const rx = srcW / dstW;
  const ry = srcH / dstH;
  for (let y = 0; y < dstH; y++) {
    const sy = Math.min(srcH - 1, Math.floor(y * ry));
    const sRow = sy * srcW;
    const dRow = y * dstW;
    for (let x = 0; x < dstW; x++) {
      const sx = Math.min(srcW - 1, Math.floor(x * rx));
      const idx = (sRow + sx) * 4;
      luma[dRow + x] =
        0.2126 * rgba[idx] + 0.7152 * rgba[idx + 1] + 0.0722 * rgba[idx + 2];
    }
  }
  return luma;
}

function blockSad(
  lumaA: Float32Array,
  lumaB: Float32Array,
  w: number,
  h: number,
  bx: number,
  by: number,
  dx: number,
  dy: number,
  blockSize: number,
  step = 1
): number {
  let sum = 0;
  let count = 0;
  const maxY = Math.min(blockSize, h - by);
  const maxX = Math.min(blockSize, w - bx);
  for (let y = 0; y < maxY; y += step) {
    const ay = by + y;
    const byT = Math.max(0, Math.min(h - 1, ay + dy));
    const rowA = ay * w;
    const rowB = byT * w;
    for (let x = 0; x < maxX; x += step) {
      const ax = bx + x;
      const bxT = Math.max(0, Math.min(w - 1, ax + dx));
      sum += Math.abs(lumaA[rowA + ax] - lumaB[rowB + bxT]);
      count++;
    }
  }
  return count > 0 ? sum / count : 255;
}

// Hierarchical Coarse-to-Fine Block-Matching Optical Flow with Vector Median Smoothing
export function estimateBlockOpticalFlow(
  rgbaA: Uint8ClampedArray,
  rgbaB: Uint8ClampedArray,
  fullW: number,
  fullH: number,
  quality: EnhancementProcessingQuality
): OpticalFlowField {
  const maxAnalysisW = quality === 'high' ? 480 : quality === 'balanced' ? 360 : 256;
  const scale = Math.min(1, maxAnalysisW / Math.max(1, fullW));
  const aw = Math.max(32, Math.round(fullW * scale));
  const ah = Math.max(24, Math.round(fullH * scale));

  const lumaA = buildLumaBuffer(rgbaA, fullW, fullH, aw, ah);
  const lumaB = buildLumaBuffer(rgbaB, fullW, fullH, aw, ah);

  const blockSize = quality === 'high' ? 10 : quality === 'balanced' ? 12 : 14;
  const cols = Math.max(1, Math.ceil(aw / blockSize));
  const rows = Math.max(1, Math.ceil(ah / blockSize));

  const vxRaw = new Float32Array(cols * rows);
  const vyRaw = new Float32Array(cols * rows);
  const conf = new Float32Array(cols * rows);

  const searchRadius = quality === 'high' ? 16 : quality === 'balanced' ? 12 : 8;
  const subSample = quality === 'fast' ? 2 : 1;

  for (let r = 0; r < rows; r++) {
    const by = r * blockSize;
    for (let c = 0; c < cols; c++) {
      const bx = c * blockSize;
      const cellIdx = r * cols + c;

      // Zero-motion bias helps stationary backgrounds lock rock-solid without jitter
      let bestDx = 0;
      let bestDy = 0;
      let bestSad = blockSad(lumaA, lumaB, aw, ah, bx, by, 0, 0, blockSize, subSample) * 0.94;

      // Neighbor spatial predictor (left & top) speeds convergence and preserves motion coherence
      if (c > 0) {
        const pdx = Math.round(vxRaw[cellIdx - 1]);
        const pdy = Math.round(vyRaw[cellIdx - 1]);
        if (pdx !== 0 || pdy !== 0) {
          const s = blockSad(lumaA, lumaB, aw, ah, bx, by, pdx, pdy, blockSize, subSample);
          if (s < bestSad) {
            bestSad = s;
            bestDx = pdx;
            bestDy = pdy;
          }
        }
      }
      if (r > 0) {
        const pdx = Math.round(vxRaw[cellIdx - cols]);
        const pdy = Math.round(vyRaw[cellIdx - cols]);
        if (pdx !== 0 || pdy !== 0) {
          const s = blockSad(lumaA, lumaB, aw, ah, bx, by, pdx, pdy, blockSize, subSample);
          if (s < bestSad) {
            bestSad = s;
            bestDx = pdx;
            bestDy = pdy;
          }
        }
      }

      // Hierarchical 3-step / logarithmic diamond refinement
      let stepSize = quality === 'high' ? 8 : 4;
      while (stepSize >= 1) {
        let improved = true;
        let iter = 0;
        while (improved && iter < 4) {
          improved = false;
          iter++;
          const cx = bestDx;
          const cy = bestDy;
          const offsets = [
            [-stepSize, 0],
            [stepSize, 0],
            [0, -stepSize],
            [0, stepSize],
            [-stepSize, -stepSize],
            [stepSize, -stepSize],
            [-stepSize, stepSize],
            [stepSize, stepSize],
          ];
          for (let k = 0; k < offsets.length; k++) {
            const nx = cx + offsets[k][0];
            const ny = cy + offsets[k][1];
            if (Math.abs(nx) > searchRadius || Math.abs(ny) > searchRadius) continue;
            const sad = blockSad(lumaA, lumaB, aw, ah, bx, by, nx, ny, blockSize, subSample);
            if (sad + 0.25 < bestSad) {
              bestSad = sad;
              bestDx = nx;
              bestDy = ny;
              improved = true;
            }
          }
        }
        stepSize = stepSize >> 1;
      }

      vxRaw[cellIdx] = bestDx;
      vyRaw[cellIdx] = bestDy;
      conf[cellIdx] = Math.max(0, Math.min(1, 1 - bestSad / 48));
    }
  }

  // 3x3 Spatial Vector Median Filter to eliminate noisy outlier vectors
  const vxSmooth = new Float32Array(cols * rows);
  const vySmooth = new Float32Array(cols * rows);
  const scaleToFullX = fullW / aw;
  const scaleToFullY = fullH / ah;

  const xs: number[] = [];
  const ys: number[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      xs.length = 0;
      ys.length = 0;
      for (let dr = -1; dr <= 1; dr++) {
        const rr = Math.max(0, Math.min(rows - 1, r + dr));
        for (let dc = -1; dc <= 1; dc++) {
          const cc = Math.max(0, Math.min(cols - 1, c + dc));
          const nIdx = rr * cols + cc;
          xs.push(vxRaw[nIdx]);
          ys.push(vyRaw[nIdx]);
        }
      }
      xs.sort((a, b) => a - b);
      ys.sort((a, b) => a - b);
      const mid = xs.length >> 1;
      const cell = r * cols + c;
      vxSmooth[cell] = xs[mid] * scaleToFullX;
      vySmooth[cell] = ys[mid] * scaleToFullY;
    }
  }

  return {
    cols,
    rows,
    blockSize: blockSize * scaleToFullX,
    scaleToFullX,
    scaleToFullY,
    vx: vxSmooth,
    vy: vySmooth,
    confidence: conf,
  };
}

function sampleBilinearRGBA(
  buf: Uint8ClampedArray,
  w: number,
  h: number,
  x: number,
  y: number
): [number, number, number, number] {
  const cx = Math.max(0, Math.min(w - 1.001, x));
  const cy = Math.max(0, Math.min(h - 1.001, y));
  const x0 = Math.floor(cx);
  const y0 = Math.floor(cy);
  const x1 = Math.min(w - 1, x0 + 1);
  const y1 = Math.min(h - 1, y0 + 1);
  const fx = cx - x0;
  const fy = cy - y0;
  const w00 = (1 - fx) * (1 - fy);
  const w10 = fx * (1 - fy);
  const w01 = (1 - fx) * fy;
  const w11 = fx * fy;

  const i00 = (y0 * w + x0) * 4;
  const i10 = (y0 * w + x1) * 4;
  const i01 = (y1 * w + x0) * 4;
  const i11 = (y1 * w + x1) * 4;

  return [
    buf[i00] * w00 + buf[i10] * w10 + buf[i01] * w01 + buf[i11] * w11,
    buf[i00 + 1] * w00 + buf[i10 + 1] * w10 + buf[i01 + 1] * w01 + buf[i11 + 1] * w11,
    buf[i00 + 2] * w00 + buf[i10 + 2] * w10 + buf[i01 + 2] * w01 + buf[i11 + 2] * w11,
    buf[i00 + 3] * w00 + buf[i10 + 3] * w10 + buf[i01 + 3] * w01 + buf[i11 + 3] * w11,
  ];
}

// Bidirectional Motion-Compensated Frame Synthesis (eliminates judder & suppresses ghosting)
export function synthesizeOpticalFlowFrame(
  rgbaA: Uint8ClampedArray,
  rgbaB: Uint8ClampedArray,
  w: number,
  h: number,
  flow: OpticalFlowField,
  alpha: number, // 0..1 between frame A and frame B
  artifactSuppression = 75
): Uint8ClampedArray {
  const t = Math.max(0, Math.min(1, alpha));
  if (t <= 0.01) return new Uint8ClampedArray(rgbaA);
  if (t >= 0.99) return new Uint8ClampedArray(rgbaB);

  const out = new Uint8ClampedArray(w * h * 4);
  const { cols, rows, blockSize, vx, vy, confidence } = flow;
  const occThreshold = Math.max(16, 85 - (artifactSuppression / 100) * 60);
  const invB = 1 / Math.max(1, blockSize);

  for (let y = 0; y < h; y++) {
    const rowOff = y * w;
    // Continuous block coordinate for smooth bilinear vector field sampling
    const gy = Math.max(0, Math.min(rows - 1.001, y * invB - 0.5));
    const r0 = Math.floor(gy);
    const r1 = Math.min(rows - 1, r0 + 1);
    const fy = gy - r0;

    for (let x = 0; x < w; x++) {
      const gx = Math.max(0, Math.min(cols - 1.001, x * invB - 0.5));
      const c0 = Math.floor(gx);
      const c1 = Math.min(cols - 1, c0 + 1);
      const fx = gx - c0;

      const idx00 = r0 * cols + c0;
      const idx10 = r0 * cols + c1;
      const idx01 = r1 * cols + c0;
      const idx11 = r1 * cols + c1;

      const w00 = (1 - fx) * (1 - fy);
      const w10 = fx * (1 - fy);
      const w01 = (1 - fx) * fy;
      const w11 = fx * fy;

      const mvx = vx[idx00] * w00 + vx[idx10] * w10 + vx[idx01] * w01 + vx[idx11] * w11;
      const mvy = vy[idx00] * w00 + vy[idx10] * w10 + vy[idx01] * w01 + vy[idx11] * w11;
      const conf =
        confidence[idx00] * w00 +
        confidence[idx10] * w10 +
        confidence[idx01] * w01 +
        confidence[idx11] * w11;

      // Forward sample from Frame A & Backward sample from Frame B along motion trajectory
      const ax = x - t * mvx;
      const ay = y - t * mvy;
      const bx = x + (1 - t) * mvx;
      const by = y + (1 - t) * mvy;

      const sA = sampleBilinearRGBA(rgbaA, w, h, ax, ay);
      const sB = sampleBilinearRGBA(rgbaB, w, h, bx, by);

      // Photometric occlusion check: detect disocclusion / bad warp & clamp ghosting
      const diff =
        (Math.abs(sA[0] - sB[0]) + Math.abs(sA[1] - sB[1]) + Math.abs(sA[2] - sB[2])) / 3;

      let blendB = t;
      if (diff > occThreshold || conf < 0.35) {
        // Occluded or ambiguous region: softly bias toward temporally nearer frame
        const nearestB = t < 0.5 ? 0 : 1;
        const snap = Math.min(0.88, Math.max(0, (diff - occThreshold) / 50) + (0.35 - Math.min(0.35, conf)));
        blendB = t + (nearestB - t) * snap;
      }

      const blendA = 1 - blendB;
      const outIdx = (rowOff + x) * 4;
      out[outIdx] = Math.round(sA[0] * blendA + sB[0] * blendB);
      out[outIdx + 1] = Math.round(sA[1] * blendA + sB[1] * blendB);
      out[outIdx + 2] = Math.round(sA[2] * blendA + sB[2] * blendB);
      out[outIdx + 3] = Math.round(sA[3] * blendA + sB[3] * blendB);
    }
  }

  return out;
}

// Synthesize an HTMLCanvasElement directly from two CanvasImageSources via Optical Flow
export function renderOpticalFlowFrameCanvas(
  sourceA: CanvasImageSource,
  sourceB: CanvasImageSource,
  width: number,
  height: number,
  alpha: number,
  quality: EnhancementProcessingQuality,
  artifactSuppression: number,
  targetCanvas?: HTMLCanvasElement
): HTMLCanvasElement {
  const cA = document.createElement('canvas');
  cA.width = width;
  cA.height = height;
  const ctxA = cA.getContext('2d', { willReadFrequently: true })!;
  ctxA.imageSmoothingEnabled = true;
  ctxA.imageSmoothingQuality = 'high';
  ctxA.drawImage(sourceA, 0, 0, width, height);

  const cB = document.createElement('canvas');
  cB.width = width;
  cB.height = height;
  const ctxB = cB.getContext('2d', { willReadFrequently: true })!;
  ctxB.imageSmoothingEnabled = true;
  ctxB.imageSmoothingQuality = 'high';
  ctxB.drawImage(sourceB, 0, 0, width, height);

  const imgA = ctxA.getImageData(0, 0, width, height).data;
  const imgB = ctxB.getImageData(0, 0, width, height).data;

  const flow = estimateBlockOpticalFlow(imgA, imgB, width, height, quality);
  const outRGBA = synthesizeOpticalFlowFrame(
    imgA,
    imgB,
    width,
    height,
    flow,
    alpha,
    artifactSuppression
  );

  const outCanvas = targetCanvas || document.createElement('canvas');
  outCanvas.width = width;
  outCanvas.height = height;
  const outCtx = outCanvas.getContext('2d')!;
  const outImg = outCtx.createImageData(width, height);
  outImg.data.set(outRGBA);
  outCtx.putImageData(outImg, 0, 0);
  return outCanvas;
}

// Memory-Bounded LRU Cache for Optical-Flow Interpolated Video Frames (Safe on Low-End PCs)
interface SmoothCacheEntry {
  key: string;
  assetId: string;
  sig: string;
  timeSec: number;
  canvas: HTMLCanvasElement;
  byteSize: number;
  lastUsed: number;
}

class SmoothVideoFrameCache {
  private entries = new Map<string, SmoothCacheEntry>();
  private usedBytes = 0;

  private getBudgetBytes(): number {
    const hw = detectHardwareProfile();
    return hw.tier === 'low-end' ? 64 * 1024 * 1024 : hw.tier === 'mid-range' ? 160 * 1024 * 1024 : 320 * 1024 * 1024;
  }

  private evictIfNeeded(incomingBytes: number) {
    const limit = this.getBudgetBytes();
    while (this.usedBytes + incomingBytes > limit && this.entries.size > 0) {
      let oldestKey: string | null = null;
      let oldestTime = Infinity;
      for (const [k, v] of this.entries) {
        if (v.lastUsed < oldestTime) {
          oldestTime = v.lastUsed;
          oldestKey = k;
        }
      }
      if (!oldestKey) break;
      const item = this.entries.get(oldestKey);
      if (item) {
        this.usedBytes -= item.byteSize;
        this.entries.delete(oldestKey);
      }
    }
  }

  public putFrame(
    assetId: string,
    sig: string,
    timeSec: number,
    canvas: HTMLCanvasElement
  ): void {
    const quantized = Math.round(timeSec * 1000);
    const key = `${assetId}:${sig}:${quantized}`;
    const byteSize = canvas.width * canvas.height * 4;
    if (this.entries.has(key)) {
      const old = this.entries.get(key)!;
      this.usedBytes -= old.byteSize;
      this.entries.delete(key);
    }
    this.evictIfNeeded(byteSize);
    this.entries.set(key, {
      key,
      assetId,
      sig,
      timeSec,
      canvas,
      byteSize,
      lastUsed: performance.now(),
    });
    this.usedBytes += byteSize;
  }

  public getNearestFrame(
    assetId: string,
    settings: SmoothVideoSettings,
    sourceTimeSec: number,
    maxDeltaSec = 0.028
  ): HTMLCanvasElement | null {
    const sig = serializeSmoothSignature(settings);
    let best: SmoothCacheEntry | null = null;
    let bestDiff = maxDeltaSec;
    for (const entry of this.entries.values()) {
      if (entry.assetId !== assetId || entry.sig !== sig) continue;
      const d = Math.abs(entry.timeSec - sourceTimeSec);
      if (d <= bestDiff) {
        bestDiff = d;
        best = entry;
      }
    }
    if (best) {
      best.lastUsed = performance.now();
      return best.canvas;
    }
    return null;
  }

  public countForAsset(assetId: string, settings: SmoothVideoSettings): number {
    const sig = serializeSmoothSignature(settings);
    let n = 0;
    for (const entry of this.entries.values()) {
      if (entry.assetId === assetId && entry.sig === sig) n++;
    }
    return n;
  }

  public clearAsset(assetId: string): void {
    for (const [k, v] of this.entries) {
      if (v.assetId === assetId) {
        this.usedBytes -= v.byteSize;
        this.entries.delete(k);
      }
    }
  }

  public clearAll(): void {
    this.entries.clear();
    this.usedBytes = 0;
  }
}

export const smoothVideoCache = new SmoothVideoFrameCache();

async function seekElementExact(vid: HTMLVideoElement, timeSec: number): Promise<void> {
  const safe = Math.max(0, Math.min(vid.duration || timeSec, timeSec));
  if (Math.abs(vid.currentTime - safe) <= 0.008 && vid.readyState >= 2) return;
  await new Promise<void>((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      vid.removeEventListener('seeked', finish);
      resolve();
    };
    vid.addEventListener('seeked', finish);
    try {
      vid.currentTime = safe;
    } catch {
      finish();
    }
    setTimeout(finish, 260);
  });
}

async function createPreparedDecoderVideo(url: string): Promise<HTMLVideoElement> {
  const v = document.createElement('video');
  if (!url.startsWith('blob:') && !url.startsWith('data:')) {
    v.crossOrigin = 'anonymous';
  }
  v.muted = true;
  v.playsInline = true;
  v.preload = 'auto';
  v.src = url;
  await new Promise<void>((resolve, reject) => {
    if (v.readyState >= 2) {
      resolve();
      return;
    }
    const ok = () => {
      cleanup();
      resolve();
    };
    const err = () => {
      cleanup();
      reject(new Error('Failed to load video stream for optical flow'));
    };
    const cleanup = () => {
      v.removeEventListener('loadeddata', ok);
      v.removeEventListener('error', err);
    };
    v.addEventListener('loadeddata', ok);
    v.addEventListener('error', err);
    setTimeout(() => {
      cleanup();
      resolve();
    }, 2000);
  });
  return v;
}

// Streaming Background Pre-Renderer for Smooth Video (never loads full video into RAM!)
export async function preRenderSmoothClipSequence(params: {
  asset: MediaAsset;
  clip: TimelineClip;
  settings: SmoothVideoSettings;
  startSourceTime?: number;
  endSourceTime?: number;
  onProgress: (pct: number, stage: string, generatedFrames: number) => void;
  signal?: AbortSignal;
}): Promise<number> {
  const { asset, clip, settings, onProgress, signal } = params;
  if (asset.type !== 'video') return 0;

  const srcUrl = asset.originalUrl || asset.url;
  const sig = serializeSmoothSignature(settings);
  const srcFps = asset.sourceFps || 30;
  const tgtFps = resolveEffectiveTargetFps(settings.targetFps, srcFps);
  const effectiveOutFps = Math.max(tgtFps, srcFps * (1 / settings.slowMotionSpeed));

  const startSrc = Math.max(0, params.startSourceTime ?? clip.sourceOffset ?? 0);
  const maxAvailDur = Math.max(0.25, Math.min(asset.duration - startSrc, clip.duration * clip.speed));
  // Cap pre-rendered burst window safely so low-end PCs stay within RAM budget
  const hw = detectHardwareProfile();
  const maxWindowSec = hw.tier === 'low-end' ? 6 : hw.tier === 'mid-range' ? 12 : 20;
  const spanSrc = Math.min(maxAvailDur, (params.endSourceTime ?? startSrc + maxAvailDur) - startSrc, maxWindowSec);

  onProgress(2, 'Opening dual streaming video decoders...', 0);
  const [vidA, vidB] = await Promise.all([
    createPreparedDecoderVideo(srcUrl),
    createPreparedDecoderVideo(srcUrl),
  ]);

  try {
    const rawW = vidA.videoWidth || asset.width || 1280;
    const rawH = vidA.videoHeight || asset.height || 720;
    // Scale analysis/cache frame cleanly to respect low-end RAM without sacrificing sharp edges
    const maxCacheW = hw.tier === 'low-end' ? 960 : hw.tier === 'mid-range' ? 1280 : 1920;
    const scale = Math.min(1, maxCacheW / Math.max(1, rawW));
    const procW = Math.max(64, Math.round(rawW * scale));
    const procH = Math.max(64, Math.round(rawH * scale));

    const srcStep = 1 / Math.max(12, srcFps);
    const outStepInSourceTime = (1 / Math.max(15, effectiveOutFps)) * settings.slowMotionSpeed;
    const totalOutFrames = Math.max(2, Math.round(spanSrc / Math.max(0.002, outStepInSourceTime)));

    const bufA = document.createElement('canvas');
    bufA.width = procW;
    bufA.height = procH;
    const ctxA = bufA.getContext('2d', { willReadFrequently: true })!;

    const bufB = document.createElement('canvas');
    bufB.width = procW;
    bufB.height = procH;
    const ctxB = bufB.getContext('2d', { willReadFrequently: true })!;

    let cachedPairA = -1;
    let cachedPairB = -1;
    let dataA: Uint8ClampedArray | null = null;
    let dataB: Uint8ClampedArray | null = null;
    let currentFlow: OpticalFlowField | null = null;
    let generated = 0;

    for (let f = 0; f < totalOutFrames; f++) {
      if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
      const tSrc = startSrc + f * outStepInSourceTime;
      const pairIdx = Math.floor(tSrc / srcStep);
      const tA = Math.min(asset.duration, pairIdx * srcStep);
      const tB = Math.min(asset.duration, (pairIdx + 1) * srcStep);
      const alpha = Math.max(0, Math.min(1, (tSrc - tA) / Math.max(0.0001, tB - tA)));

      if (pairIdx !== cachedPairA || pairIdx + 1 !== cachedPairB || !dataA || !dataB || !currentFlow) {
        await Promise.all([seekElementExact(vidA, tA), seekElementExact(vidB, tB)]);
        if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
        ctxA.drawImage(vidA, 0, 0, procW, procH);
        ctxB.drawImage(vidB, 0, 0, procW, procH);
        dataA = ctxA.getImageData(0, 0, procW, procH).data;
        dataB = ctxB.getImageData(0, 0, procW, procH).data;
        currentFlow = estimateBlockOpticalFlow(
          dataA,
          dataB,
          procW,
          procH,
          settings.processingQuality
        );
        cachedPairA = pairIdx;
        cachedPairB = pairIdx + 1;
      }

      const rgbaOut = synthesizeOpticalFlowFrame(
        dataA,
        dataB,
        procW,
        procH,
        currentFlow,
        alpha,
        settings.artifactSuppression
      );

      const frameCanvas = document.createElement('canvas');
      frameCanvas.width = procW;
      frameCanvas.height = procH;
      const fCtx = frameCanvas.getContext('2d')!;
      const fImg = fCtx.createImageData(procW, procH);
      fImg.data.set(rgbaOut);
      fCtx.putImageData(fImg, 0, 0);

      smoothVideoCache.putFrame(asset.id, sig, tSrc, frameCanvas);
      generated++;

      if (f % 2 === 0 || f === totalOutFrames - 1) {
        onProgress(
          5 + Math.round(((f + 1) / totalOutFrames) * 95),
          `Synthesizing optical-flow frame ${f + 1}/${totalOutFrames} (${procW}×${procH})`,
          generated
        );
        await new Promise((r) => setTimeout(r, 0));
      }
    }

    return generated;
  } finally {
    try {
      vidA.pause();
      vidA.removeAttribute('src');
      vidA.load();
      vidB.pause();
      vidB.removeAttribute('src');
      vidB.load();
    } catch {
      // Ignore decoder cleanup errors
    }
  }
}
