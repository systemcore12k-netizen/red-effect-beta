import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { OBJExporter } from 'three/addons/exporters/OBJExporter.js';
import { Model3DBlueprint, Model3DPart } from '../types/studio';

function createProceduralPatternTexture(
  pattern: Model3DPart['texturePattern'],
  baseHex: string
): THREE.CanvasTexture | null {
  if (!pattern || pattern === 'none') return null;

  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, size, size);

  if (pattern === 'brushed-metal') {
    for (let y = 0; y < size; y += 2) {
      const alpha = (Math.sin(y * 1.7) * 0.5 + 0.5) * 0.14;
      ctx.fillStyle = y % 4 === 0 ? `rgba(255,255,255,${alpha})` : `rgba(0,0,0,${alpha})`;
      ctx.fillRect(0, y, size, 1);
    }
  } else if (pattern === 'carbon-weave') {
    for (let y = 0; y < size; y += 16) {
      for (let x = 0; x < size; x += 16) {
        ctx.fillStyle = (x + y) % 32 === 0 ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.22)';
        ctx.fillRect(x, y, 8, 8);
      }
    }
  } else if (pattern === 'scales') {
    ctx.strokeStyle = 'rgba(0,0,0,0.3)';
    ctx.lineWidth = 2;
    for (let y = 0; y < size + 24; y += 20) {
      const offset = (y / 20) % 2 === 0 ? 0 : 12;
      for (let x = -12; x < size + 24; x += 24) {
        ctx.beginPath();
        ctx.arc(x + offset, y, 12, 0, Math.PI);
        ctx.stroke();
      }
    }
  } else if (pattern === 'stone' || pattern === 'wood') {
    for (let i = 0; i < 420; i++) {
      const x = ((i * 73) % size);
      const y = ((i * 137) % size);
      ctx.fillStyle = i % 2 === 0 ? 'rgba(0,0,0,0.12)' : 'rgba(255,255,255,0.06)';
      if (pattern === 'wood') ctx.fillRect(0, y, size, 2);
      else ctx.fillRect(x, y, 6, 4);
    }
  } else if (pattern === 'grid') {
    ctx.strokeStyle = 'rgba(225, 29, 72, 0.35)';
    ctx.lineWidth = 1.5;
    for (let i = 0; i <= size; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, size);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(size, i);
      ctx.stroke();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  tex.needsUpdate = true;
  return tex;
}

function createGeometryForPart(part: Model3DPart): THREE.BufferGeometry {
  switch (part.geometry) {
    case 'sphere':
      return new THREE.SphereGeometry(0.5, 32, 24);
    case 'cylinder':
      return new THREE.CylinderGeometry(0.5, 0.5, 1, 28);
    case 'cone':
      return new THREE.ConeGeometry(0.5, 1, 24);
    case 'torus':
      return new THREE.TorusGeometry(0.5, 0.16, 18, 36);
    case 'icosahedron':
      return new THREE.IcosahedronGeometry(0.5, 1);
    case 'capsule':
      return new THREE.CapsuleGeometry(0.35, 0.6, 8, 16);
    case 'lathe': {
      const pts =
        part.profilePoints && part.profilePoints.length >= 3
          ? part.profilePoints.map(([x, y]) => new THREE.Vector2(Math.max(0.02, Math.abs(x)), y))
          : [
              new THREE.Vector2(0.05, -0.5),
              new THREE.Vector2(0.42, -0.3),
              new THREE.Vector2(0.32, 0.1),
              new THREE.Vector2(0.46, 0.45),
              new THREE.Vector2(0.05, 0.5),
            ];
      const geo = new THREE.LatheGeometry(pts, 28);
      geo.computeVertexNormals();
      return geo;
    }
    case 'extrude_bevel': {
      const shape = new THREE.Shape();
      const pts =
        part.profilePoints && part.profilePoints.length >= 3
          ? part.profilePoints
          : [
              [-0.4, -0.3],
              [0.4, -0.3],
              [0.5, 0.1],
              [0.2, 0.4],
              [-0.2, 0.4],
              [-0.5, 0.1],
            ];
      shape.moveTo(pts[0][0], pts[0][1]);
      for (let i = 1; i < pts.length; i++) {
        shape.lineTo(pts[i][0], pts[i][1]);
      }
      shape.closePath();
      const geo = new THREE.ExtrudeGeometry(shape, {
        depth: 0.35,
        bevelEnabled: true,
        bevelThickness: 0.05,
        bevelSize: 0.04,
        bevelSegments: 2,
      });
      geo.center();
      return geo;
    }
    case 'box':
    default:
      return new THREE.BoxGeometry(1, 1, 1);
  }
}

export function buildComposite3DGroup(
  blueprint: Model3DBlueprint,
  wireframe = false
): THREE.Group {
  const root = new THREE.Group();
  root.name = blueprint.title.replace(/\s+/g, '_');

  for (const part of blueprint.parts) {
    const geometry = createGeometryForPart(part);
    const tex = createProceduralPatternTexture(part.texturePattern, part.color || '#A1A1AA');

    const material = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(part.color || '#A1A1AA'),
      roughness: Math.max(0.05, Math.min(1, part.roughness ?? 0.4)),
      metalness: Math.max(0, Math.min(1, part.metalness ?? 0.3)),
      clearcoat: part.clearcoat ?? 0.15,
      clearcoatRoughness: 0.12,
      emissive: part.emissive ? new THREE.Color(part.emissive) : new THREE.Color(0x000000),
      emissiveIntensity: part.emissiveIntensity ?? 0,
      map: tex,
      wireframe,
    });

    const mesh = new THREE.Mesh(geometry, material);
    mesh.name = part.name || 'Part';
    mesh.castShadow = true;
    mesh.receiveShadow = true;

    const [px = 0, py = 0, pz = 0] = part.position || [];
    const [rx = 0, ry = 0, rz = 0] = part.rotation || [];
    const [sx = 1, sy = 1, sz = 1] = part.scale || [];

    mesh.position.set(px, py, pz);
    mesh.rotation.set(rx, ry, rz);
    mesh.scale.set(
      Math.max(0.02, sx),
      Math.max(0.02, sy),
      Math.max(0.02, sz)
    );
    mesh.userData.basePosition = [px, py, pz];
    root.add(mesh);
  }

  // Ground center pivot cleanly above Y = 0
  const box = new THREE.Box3().setFromObject(root);
  if (!box.isEmpty()) {
    const center = box.getCenter(new THREE.Vector3());
    root.children.forEach((child) => {
      child.position.x -= center.x;
      child.position.z -= center.z;
      child.position.y -= box.min.y;
      child.userData.basePosition = [child.position.x, child.position.y, child.position.z];
    });
  }

  return root;
}

export function createStudioEnvironment(renderer: THREE.WebGLRenderer): THREE.Texture {
  const pmrem = new THREE.PMREMGenerator(renderer);
  const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  pmrem.dispose();
  return envTex;
}

export function exportGroupToOBJ(group: THREE.Object3D): Blob {
  const exporter = new OBJExporter();
  const objText = exporter.parse(group);
  return new Blob([objText], { type: 'text/plain;charset=utf-8' });
}

export function exportGroupToGLB(group: THREE.Object3D): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const exporter = new GLTFExporter();
    exporter.parse(
      group,
      (result) => {
        if (result instanceof ArrayBuffer) {
          resolve(new Blob([result], { type: 'model/gltf-binary' }));
        } else {
          const json = JSON.stringify(result);
          resolve(new Blob([json], { type: 'model/gltf+json' }));
        }
      },
      (err) => reject(err),
      { binary: true }
    );
  });
}

export function createDefaultShowcase3DBlueprint(): Model3DBlueprint {
  return {
    title: 'Crimson Cinema Drone',
    category: 'Sci-Fi Hardware',
    description: 'Anodized carbon & crimson cinema camera drone rig with gimbal lens.',
    environmentLighting: 'crimson-rim',
    autoRotateSpeed: 0.8,
    parts: [
      {
        name: 'Chassis_Core',
        geometry: 'extrude_bevel',
        position: [0, 0.9, 0],
        rotation: [Math.PI / 2, 0, 0],
        scale: [1.4, 1.2, 0.9],
        color: '#18181B',
        roughness: 0.35,
        metalness: 0.75,
        clearcoat: 0.4,
        texturePattern: 'carbon-weave',
      },
      {
        name: 'Crimson_Spine',
        geometry: 'box',
        position: [0, 1.08, 0],
        rotation: [0, 0, 0],
        scale: [0.45, 0.16, 1.3],
        color: '#E11D48',
        roughness: 0.18,
        metalness: 0.85,
        clearcoat: 0.9,
        texturePattern: 'brushed-metal',
      },
      {
        name: 'Gimbal_Housing',
        geometry: 'sphere',
        position: [0, 0.62, 0.48],
        rotation: [0, 0, 0],
        scale: [0.44, 0.44, 0.44],
        color: '#27272A',
        roughness: 0.28,
        metalness: 0.8,
        texturePattern: 'brushed-metal',
      },
      {
        name: 'Cinema_Lens_Barrel',
        geometry: 'lathe',
        position: [0, 0.62, 0.74],
        rotation: [Math.PI / 2, 0, 0],
        scale: [0.32, 0.35, 0.32],
        color: '#09090B',
        roughness: 0.15,
        metalness: 0.9,
        texturePattern: 'none',
      },
      {
        name: 'Optical_Sensor_Ring',
        geometry: 'torus',
        position: [0, 0.62, 0.89],
        rotation: [0, 0, 0],
        scale: [0.24, 0.24, 0.24],
        color: '#E11D48',
        roughness: 0.2,
        metalness: 0.6,
        emissive: '#E11D48',
        emissiveIntensity: 1.5,
        texturePattern: 'none',
      },
      {
        name: 'Rotor_Arm_FL',
        geometry: 'cylinder',
        position: [-0.85, 0.96, 0.65],
        rotation: [0, 0, Math.PI / 2.2],
        scale: [0.1, 1.1, 0.1],
        color: '#3F3F46',
        roughness: 0.4,
        metalness: 0.8,
        texturePattern: 'carbon-weave',
      },
      {
        name: 'Rotor_Arm_FR',
        geometry: 'cylinder',
        position: [0.85, 0.96, 0.65],
        rotation: [0, 0, -Math.PI / 2.2],
        scale: [0.1, 1.1, 0.1],
        color: '#3F3F46',
        roughness: 0.4,
        metalness: 0.8,
        texturePattern: 'carbon-weave',
      },
      {
        name: 'Rotor_Ring_FL',
        geometry: 'torus',
        position: [-1.25, 1.08, 0.65],
        rotation: [Math.PI / 2, 0, 0],
        scale: [0.55, 0.55, 0.55],
        color: '#18181B',
        roughness: 0.25,
        metalness: 0.7,
        texturePattern: 'none',
      },
      {
        name: 'Rotor_Ring_FR',
        geometry: 'torus',
        position: [1.25, 1.08, 0.65],
        rotation: [Math.PI / 2, 0, 0],
        scale: [0.55, 0.55, 0.55],
        color: '#18181B',
        roughness: 0.25,
        metalness: 0.7,
        texturePattern: 'none',
      },
      {
        name: 'Rotor_Ring_BL',
        geometry: 'torus',
        position: [-1.15, 1.08, -0.7],
        rotation: [Math.PI / 2, 0, 0],
        scale: [0.55, 0.55, 0.55],
        color: '#18181B',
        roughness: 0.25,
        metalness: 0.7,
        texturePattern: 'none',
      },
      {
        name: 'Rotor_Ring_BR',
        geometry: 'torus',
        position: [1.15, 1.08, -0.7],
        rotation: [Math.PI / 2, 0, 0],
        scale: [0.55, 0.55, 0.55],
        color: '#18181B',
        roughness: 0.25,
        metalness: 0.7,
        texturePattern: 'none',
      },
    ],
  };
}
