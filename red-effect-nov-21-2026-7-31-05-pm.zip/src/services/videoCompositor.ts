import {
  Camera3DSettings,
  ColorGrade,
  Keyframe,
  MediaAsset,
  ParticlePreset,
  PreviewQuality,
  ProxyQuality,
  StudioProject,
  TimelineClip,
} from '../types/studio';
import { BezierPoint, ReadyMadeEffectPreset, TransitionSettings } from '../types/effects';
import { getDefaultTransitionSettings } from './effectsCatalog';
import {
  applyEasingCurve,
  applyEffectsStackToCanvas,
  applyFullColorGradeToCanvas,
  blendModeToCanvasOp,
  computeTransitionState,
  hasAdvancedColorGrade,
} from './effectsProcessor';
import {
  getActiveRenderPolicy,
  resolveRenderPolicy,
  setActiveRenderPolicy,
  textBitmapCache,
} from './performanceEngine';
import {
  applyClipQualityEnhancerToCanvas,
  enhancedImageCache,
} from './qualityEnhancerEngine';
import { smoothVideoCache } from './smoothVideoEngine';

export interface MediaElementCache {
  images: Map<string, HTMLImageElement>;
  videos: Map<string, HTMLVideoElement>;
  offscreen: HTMLCanvasElement;
  clipBuffer: HTMLCanvasElement;
  mipmapCanvas: HTMLCanvasElement;
}

export function createMediaCache(): MediaElementCache {
  return {
    images: new Map(),
    videos: new Map(),
    offscreen: document.createElement('canvas'),
    clipBuffer: document.createElement('canvas'),
    mipmapCanvas: document.createElement('canvas'),
  };
}

export function getOrLoadImage(cache: MediaElementCache, asset: MediaAsset): HTMLImageElement | null {
  const sourceUrl = asset.originalUrl || asset.url;
  const existing = cache.images.get(asset.id);
  if (existing) return existing.complete && existing.naturalWidth > 0 ? existing : null;

  const img = new Image();
  if (!sourceUrl.startsWith('blob:') && !sourceUrl.startsWith('data:')) {
    img.crossOrigin = 'anonymous';
  }
  img.decoding = 'sync';
  img.src = sourceUrl;
  cache.images.set(asset.id, img);
  return null;
}

export function getOrLoadVideo(cache: MediaElementCache, asset: MediaAsset): HTMLVideoElement | null {
  const sourceUrl = asset.originalUrl || asset.url;
  const existing = cache.videos.get(asset.id);
  if (existing) return existing.readyState >= 2 ? existing : null;

  const vid = document.createElement('video');
  if (!sourceUrl.startsWith('blob:') && !sourceUrl.startsWith('data:')) {
    vid.crossOrigin = 'anonymous';
  }
  vid.src = sourceUrl;
  vid.muted = true;
  vid.playsInline = true;
  vid.preload = 'auto';
  cache.videos.set(asset.id, vid);
  return null;
}

// High-quality progressive texture sampling prevents Chrome/Skia single-pass bilinear aliasing/blur when scaling 4K/8K sources
function drawHighQualitySource(
  ctx: CanvasRenderingContext2D,
  source: CanvasImageSource,
  srcW: number,
  srcH: number,
  dstX: number,
  dstY: number,
  dstW: number,
  dstH: number,
  mipmapCanvas: HTMLCanvasElement
): void {
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // If downscaling more than 2x on either axis, step down cleanly in 2x halving passes
  if (srcW > dstW * 2.1 || srcH > dstH * 2.1) {
    let curW = srcW;
    let curH = srcH;
    let stepSource: CanvasImageSource = source;

    // Limit to 3 mip steps max to preserve low-end CPU/GPU budget
    for (let step = 0; step < 3 && (curW > dstW * 2.05 || curH > dstH * 2.05); step++) {
      const nextW = Math.max(Math.round(dstW), Math.round(curW * 0.5));
      const nextH = Math.max(Math.round(dstH), Math.round(curH * 0.5));

      if (step === 0 || stepSource !== mipmapCanvas) {
        mipmapCanvas.width = nextW;
        mipmapCanvas.height = nextH;
        const mCtx = mipmapCanvas.getContext('2d', { colorSpace: 'srgb' }) || mipmapCanvas.getContext('2d');
        if (!mCtx) break;
        mCtx.imageSmoothingEnabled = true;
        mCtx.imageSmoothingQuality = 'high';
        mCtx.clearRect(0, 0, nextW, nextH);
        mCtx.drawImage(stepSource, 0, 0, nextW, nextH);
      } else {
        // Subsequent in-place halve using temp copy region via drawImage
        const tmpW = mipmapCanvas.width;
        const tmpH = mipmapCanvas.height;
        const mCtx = mipmapCanvas.getContext('2d', { colorSpace: 'srgb' }) || mipmapCanvas.getContext('2d');
        if (!mCtx) break;
        mCtx.imageSmoothingEnabled = true;
        mCtx.imageSmoothingQuality = 'high';
        mCtx.drawImage(mipmapCanvas, 0, 0, tmpW, tmpH, 0, 0, nextW, nextH);
        curW = nextW;
        curH = nextH;
        ctx.drawImage(mipmapCanvas, 0, 0, nextW, nextH, dstX, dstY, dstW, dstH);
        return;
      }
      stepSource = mipmapCanvas;
      curW = nextW;
      curH = nextH;
    }

    ctx.drawImage(stepSource, 0, 0, curW, curH, dstX, dstY, dstW, dstH);
    return;
  }

  ctx.drawImage(source, dstX, dstY, dstW, dstH);
}

export async function seekVideosForTime(
  project: StudioProject,
  playheadTime: number,
  cache: MediaElementCache
): Promise<void> {
  const seekPromises: Promise<void>[] = [];

  for (const clip of project.clips) {
    if (playheadTime < clip.startTime || playheadTime > clip.startTime + clip.duration) continue;
    const asset = project.assets.find((a) => a.id === clip.assetId);
    if (!asset || asset.type !== 'video') continue;

    let vid = cache.videos.get(asset.id);
    if (!vid) {
      getOrLoadVideo(cache, asset);
      vid = cache.videos.get(asset.id);
    }
    if (!vid) continue;

    const localTime = Math.max(0, playheadTime - clip.startTime);
    const slowMult = clip.smoothVideo?.enabled ? clip.smoothVideo.slowMotionSpeed : 1;
    const effectiveSpeed = clip.speed * slowMult;
    const targetMediaTime = clip.reverse
      ? Math.max(0, asset.duration - (clip.sourceOffset + localTime * effectiveSpeed))
      : clip.sourceOffset + localTime * effectiveSpeed;

    seekPromises.push(
      new Promise<void>((resolve) => {
        const waitMetaAndSeek = () => {
          const safeTime = Math.max(
            0,
            Math.min(vid!.duration || asset.duration, targetMediaTime)
          );
          if (Math.abs(vid!.currentTime - safeTime) <= 0.025 && vid!.readyState >= 2) {
            resolve();
            return;
          }
          let done = false;
          const finish = () => {
            if (done) return;
            done = true;
            vid!.removeEventListener('seeked', finish);
            resolve();
          };
          vid!.addEventListener('seeked', finish);
          try {
            vid!.currentTime = safeTime;
          } catch {
            finish();
          }
          setTimeout(finish, 180);
        };

        if (vid!.readyState >= 1) {
          waitMetaAndSeek();
        } else {
          const onLoaded = () => {
            vid!.removeEventListener('loadeddata', onLoaded);
            waitMetaAndSeek();
          };
          vid!.addEventListener('loadeddata', onLoaded);
          setTimeout(() => {
            vid!.removeEventListener('loadeddata', onLoaded);
            resolve();
          }, 500);
        }
      })
    );
  }

  await Promise.all(seekPromises);
}

export function getClipAnimationEvalTime(clip: TimelineClip, rawLocalTime: number): number {
  const speed = clip.animationSpeed ?? 1;
  const maxKfTime =
    clip.keyframes.length > 0
      ? Math.max(0.25, ...clip.keyframes.map((k) => k.time))
      : Math.max(0.25, clip.duration);

  const scaled = rawLocalTime * Math.max(0.1, speed);
  const mode = clip.animationLoopMode || 'none';
  if (mode === 'loop') {
    return scaled % maxKfTime;
  }
  if (mode === 'pingpong') {
    const cycle = maxKfTime * 2;
    const mod = scaled % cycle;
    return mod <= maxKfTime ? mod : cycle - mod;
  }
  if (mode === 'reverse') {
    return Math.max(0, maxKfTime - scaled);
  }
  return scaled;
}

export function evaluateKeyframeProperty(
  keyframes: Keyframe[],
  property: Keyframe['property'],
  localTime: number,
  fallbackValue: number
): number {
  const list = keyframes
    .filter((k) => k.property === property)
    .sort((a, b) => a.time - b.time);

  if (list.length === 0) return fallbackValue;
  if (localTime <= list[0].time) return list[0].value;
  if (localTime >= list[list.length - 1].time) return list[list.length - 1].value;

  for (let i = 0; i < list.length - 1; i++) {
    const k1 = list[i];
    const k2 = list[i + 1];
    if (localTime >= k1.time && localTime <= k2.time) {
      const span = Math.max(0.0001, k2.time - k1.time);
      const t = applyEasingCurve((localTime - k1.time) / span, k2.easing, k2.bezier);
      return k1.value + (k2.value - k1.value) * t;
    }
  }
  return fallbackValue;
}

export type Matrix2D = [number, number, number, number, number, number];

export function identityMatrix2D(): Matrix2D {
  return [1, 0, 0, 1, 0, 0];
}

export function multiplyMatrix2D(m1: Matrix2D, m2: Matrix2D): Matrix2D {
  return [
    m1[0] * m2[0] + m1[2] * m2[1],
    m1[1] * m2[0] + m1[3] * m2[1],
    m1[0] * m2[2] + m1[2] * m2[3],
    m1[1] * m2[2] + m1[3] * m2[3],
    m1[0] * m2[4] + m1[2] * m2[5] + m1[4],
    m1[1] * m2[4] + m1[3] * m2[5] + m1[5],
  ];
}

export function invertMatrix2D(m: Matrix2D): Matrix2D {
  const det = m[0] * m[3] - m[1] * m[2];
  if (Math.abs(det) < 1e-8) return identityMatrix2D();
  const inv = 1 / det;
  return [
    m[3] * inv,
    -m[1] * inv,
    -m[2] * inv,
    m[0] * inv,
    (m[2] * m[5] - m[3] * m[4]) * inv,
    (m[1] * m[4] - m[0] * m[5]) * inv,
  ];
}

export function transformPoint2D(m: Matrix2D, x: number, y: number): { x: number; y: number } {
  return {
    x: m[0] * x + m[2] * y + m[4],
    y: m[1] * x + m[3] * y + m[5],
  };
}

function buildLocalClipMatrix2D(
  lxPx: number,
  lyPx: number,
  rotDeg: number,
  sx: number,
  sy: number,
  axOff: number,
  ayOff: number
): Matrix2D {
  const rad = (rotDeg * Math.PI) / 180;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);
  // M = T(lxPx + axOff, lyPx + ayOff) * R(rot) * S(sx, sy) * T(-axOff, -ayOff)
  const a = cos * sx;
  const b = sin * sx;
  const c = -sin * sy;
  const d = cos * sy;
  const pivotX = lxPx + axOff;
  const pivotY = lyPx + ayOff;
  const tx = pivotX - (a * axOff + c * ayOff);
  const ty = pivotY - (b * axOff + d * ayOff);
  return [a, b, c, d, tx, ty];
}

export interface EvaluatedLocalClipTransform {
  lx: number;
  ly: number;
  lz: number;
  baseScale: number;
  scaleFactorX: number;
  scaleFactorY: number;
  scaleFactorZ: number;
  scaleX: number;
  scaleY: number;
  scaleZ: number;
  rotation: number;
  rotX: number;
  rotY: number;
  opacity: number;
  anchorX: number;
  anchorY: number;
}

export function evaluateLocalClipTransform(
  clip: TimelineClip,
  playheadTime: number
): EvaluatedLocalClipTransform {
  const rawLocal = Math.max(0, playheadTime - clip.startTime);
  const evalTime = getClipAnimationEvalTime(clip, rawLocal);

  const lx = evaluateKeyframeProperty(clip.keyframes, 'x', evalTime, clip.transform.x);
  const ly = evaluateKeyframeProperty(clip.keyframes, 'y', evalTime, clip.transform.y);
  const lz = evaluateKeyframeProperty(clip.keyframes, 'z', evalTime, clip.transform.zDepth || 0);
  const baseScale = evaluateKeyframeProperty(clip.keyframes, 'scale', evalTime, clip.transform.scale);
  const scaleFactorX = evaluateKeyframeProperty(
    clip.keyframes,
    'scaleX',
    evalTime,
    clip.transform.scaleX ?? 1
  );
  const scaleFactorY = evaluateKeyframeProperty(
    clip.keyframes,
    'scaleY',
    evalTime,
    clip.transform.scaleY ?? 1
  );
  const scaleFactorZ = evaluateKeyframeProperty(
    clip.keyframes,
    'scaleZ',
    evalTime,
    clip.transform.scaleZ ?? 1
  );
  const rotation =
    evaluateKeyframeProperty(clip.keyframes, 'rotation', evalTime, clip.transform.rotation) +
    evaluateKeyframeProperty(clip.keyframes, 'rotZ', evalTime, 0);
  const rotX = evaluateKeyframeProperty(clip.keyframes, 'rotX', evalTime, clip.transform.rotX || 0);
  const rotY = evaluateKeyframeProperty(clip.keyframes, 'rotY', evalTime, clip.transform.rotY || 0);
  const opacity = evaluateKeyframeProperty(
    clip.keyframes,
    'opacity',
    evalTime,
    clip.transform.opacity
  );
  const anchorX = evaluateKeyframeProperty(
    clip.keyframes,
    'anchorX',
    evalTime,
    clip.transform.anchorX ?? 0.5
  );
  const anchorY = evaluateKeyframeProperty(
    clip.keyframes,
    'anchorY',
    evalTime,
    clip.transform.anchorY ?? 0.5
  );

  return {
    lx,
    ly,
    lz,
    baseScale,
    scaleFactorX,
    scaleFactorY,
    scaleFactorZ,
    scaleX: baseScale * scaleFactorX,
    scaleY: baseScale * scaleFactorY,
    scaleZ: baseScale * scaleFactorZ,
    rotation,
    rotX,
    rotY,
    opacity: Math.max(0, Math.min(1, opacity)),
    anchorX,
    anchorY,
  };
}

export interface ResolvedWorldTransform {
  x: number; // % of canvas (-100..100)
  y: number; // % of canvas (-100..100)
  zDepth: number;
  scaleX: number;
  scaleY: number;
  scaleZ: number;
  rotation: number; // degrees
  rotX: number;
  rotY: number;
  opacity: number;
  anchorX: number;
  anchorY: number;
  worldMatrix: Matrix2D;
  parentMatrix: Matrix2D;
}

export function wouldCreateParentCycle(
  childId: string,
  candidateParentId: string | undefined,
  clips: TimelineClip[]
): boolean {
  if (!candidateParentId) return false;
  if (candidateParentId === childId) return true;
  const visited = new Set<string>([childId]);
  let curr: string | undefined = candidateParentId;
  while (curr) {
    if (visited.has(curr)) return true;
    visited.add(curr);
    curr = clips.find((c) => c.id === curr)?.parentClipId;
  }
  return false;
}

export function resolveWorldTransform(
  clip: TimelineClip,
  project: StudioProject,
  playheadTime: number,
  visited = new Set<string>(),
  refWidth = project.width || 1920,
  refHeight = project.height || 1080
): ResolvedWorldTransform {
  const local = evaluateLocalClipTransform(clip, playheadTime);
  const safeW = Math.max(1, refWidth);
  const safeH = Math.max(1, refHeight);

  const axOff = (local.anchorX - 0.5) * safeW;
  const ayOff = (local.anchorY - 0.5) * safeH;
  const lxPx = (local.lx / 100) * safeW;
  const lyPx = (local.ly / 100) * safeH;
  const rotXScale = clip.is3DLayer ? Math.cos((local.rotX * Math.PI) / 180) : 1;
  const rotYScale = clip.is3DLayer ? Math.cos((local.rotY * Math.PI) / 180) : 1;

  const localMatrix = buildLocalClipMatrix2D(
    lxPx,
    lyPx,
    local.rotation,
    local.scaleX * rotYScale,
    local.scaleY * rotXScale,
    axOff,
    ayOff
  );

  if (clip.parentClipId && !visited.has(clip.id)) {
    const nextVisited = new Set(visited);
    nextVisited.add(clip.id);
    const parent = project.clips.find((c) => c.id === clip.parentClipId);
    if (parent && !parent.disabled) {
      const pw = resolveWorldTransform(parent, project, playheadTime, nextVisited, safeW, safeH);
      const worldMatrix = multiplyMatrix2D(pw.worldMatrix, localMatrix);
      const origin = transformPoint2D(worldMatrix, 0, 0);

      return {
        x: (origin.x / safeW) * 100,
        y: (origin.y / safeH) * 100,
        zDepth: pw.zDepth + local.lz * pw.scaleZ,
        scaleX: pw.scaleX * local.scaleX,
        scaleY: pw.scaleY * local.scaleY,
        scaleZ: pw.scaleZ * local.scaleZ,
        rotation: pw.rotation + local.rotation,
        rotX: pw.rotX + local.rotX,
        rotY: pw.rotY + local.rotY,
        opacity: Math.max(0, Math.min(1, pw.opacity * local.opacity)),
        anchorX: local.anchorX,
        anchorY: local.anchorY,
        worldMatrix,
        parentMatrix: pw.worldMatrix,
      };
    }
  }

  return {
    x: local.lx,
    y: local.ly,
    zDepth: local.lz,
    scaleX: local.scaleX,
    scaleY: local.scaleY,
    scaleZ: local.scaleZ,
    rotation: local.rotation,
    rotX: local.rotX,
    rotY: local.rotY,
    opacity: local.opacity,
    anchorX: local.anchorX,
    anchorY: local.anchorY,
    worldMatrix: localMatrix,
    parentMatrix: identityMatrix2D(),
  };
}

export function reparentClipPreserveWorld(
  child: TimelineClip,
  newParentId: string | undefined,
  project: StudioProject,
  playheadTime: number
): TimelineClip {
  if (newParentId && wouldCreateParentCycle(child.id, newParentId, project.clips)) {
    return child;
  }
  const refW = Math.max(1, project.width || 1920);
  const refH = Math.max(1, project.height || 1080);

  const currentWorld = resolveWorldTransform(child, project, playheadTime, new Set(), refW, refH);
  const oldLocal = evaluateLocalClipTransform(child, playheadTime);

  let nextLx = currentWorld.x;
  let nextLy = currentWorld.y;
  let nextLz = currentWorld.zDepth;
  let nextSx = currentWorld.scaleX;
  let nextSy = currentWorld.scaleY;
  let nextSz = currentWorld.scaleZ;
  let nextRot = currentWorld.rotation;
  let nextRotX = currentWorld.rotX;
  let nextRotY = currentWorld.rotY;

  if (newParentId) {
    const newParent = project.clips.find((c) => c.id === newParentId);
    if (newParent && !newParent.disabled) {
      const pw = resolveWorldTransform(newParent, project, playheadTime, new Set(), refW, refH);
      const invParent = invertMatrix2D(pw.worldMatrix);
      const worldCenterPx = transformPoint2D(currentWorld.worldMatrix, 0, 0);
      const localCenterPx = transformPoint2D(invParent, worldCenterPx.x, worldCenterPx.y);

      const safePsx = Math.abs(pw.scaleX) > 0.001 ? pw.scaleX : 1;
      const safePsy = Math.abs(pw.scaleY) > 0.001 ? pw.scaleY : 1;
      const safePsz = Math.abs(pw.scaleZ) > 0.001 ? pw.scaleZ : 1;

      nextLx = (localCenterPx.x / refW) * 100;
      nextLy = (localCenterPx.y / refH) * 100;
      nextLz = (currentWorld.zDepth - pw.zDepth) / safePsz;
      nextSx = currentWorld.scaleX / safePsx;
      nextSy = currentWorld.scaleY / safePsy;
      nextSz = currentWorld.scaleZ / safePsz;
      nextRot = currentWorld.rotation - pw.rotation;
      nextRotX = currentWorld.rotX - pw.rotX;
      nextRotY = currentWorld.rotY - pw.rotY;
    }
  }

  const r2 = (n: number) => Math.round(n * 100) / 100;
  const r3 = (n: number) => Math.round(n * 1000) / 1000;
  const deltaX = nextLx - oldLocal.lx;
  const deltaY = nextLy - oldLocal.ly;
  const deltaRot = nextRot - oldLocal.rotation;

  const multX = Math.abs(oldLocal.scaleX) > 0.0001 ? nextSx / oldLocal.scaleX : nextSx;
  const multY = Math.abs(oldLocal.scaleY) > 0.0001 ? nextSy / oldLocal.scaleY : nextSy;
  const multZ = Math.abs(oldLocal.scaleZ) > 0.0001 ? nextSz / oldLocal.scaleZ : nextSz;

  // Preserve child's own animated scale keyframes without double-scaling
  const hasScaleXKf = child.keyframes.some((k) => k.property === 'scaleX');
  const hasScaleYKf = child.keyframes.some((k) => k.property === 'scaleY');
  const hasScaleZKf = child.keyframes.some((k) => k.property === 'scaleZ');
  const hasScaleKf = child.keyframes.some((k) => k.property === 'scale');

  const isUniformMult = Math.abs(multX - multY) < 0.002;
  const useUniformScaleAdjust =
    hasScaleKf && !hasScaleXKf && !hasScaleYKf && isUniformMult &&
    Math.abs((child.transform.scaleX ?? 1) - 1) < 0.002 &&
    Math.abs((child.transform.scaleY ?? 1) - 1) < 0.002;

  const adjustedKeyframes = child.keyframes.map((k) => {
    if (k.property === 'x') return { ...k, value: r2(k.value + deltaX) };
    if (k.property === 'y') return { ...k, value: r2(k.value + deltaY) };
    if (k.property === 'rotation') return { ...k, value: r2(k.value + deltaRot) };
    if (useUniformScaleAdjust && k.property === 'scale') {
      return { ...k, value: r3(k.value * multX) };
    }
    if (!useUniformScaleAdjust) {
      if (k.property === 'scaleX') return { ...k, value: r3(k.value * multX) };
      if (k.property === 'scaleY') return { ...k, value: r3(k.value * multY) };
      if (k.property === 'scaleZ') return { ...k, value: r3(k.value * multZ) };
    }
    return k;
  });

  const rawNextScale = useUniformScaleAdjust
    ? r3(child.transform.scale * multX)
    : child.transform.scale;
  const rawNextScaleX = useUniformScaleAdjust
    ? 1
    : r3((child.transform.scaleX ?? 1) * multX);
  const rawNextScaleY = useUniformScaleAdjust
    ? 1
    : r3((child.transform.scaleY ?? 1) * multY);
  const rawNextScaleZ =
    hasScaleZKf || !useUniformScaleAdjust
      ? r3((child.transform.scaleZ ?? 1) * multZ)
      : child.transform.scaleZ ?? 1;

  return {
    ...child,
    parentClipId: newParentId || undefined,
    keyframes: adjustedKeyframes,
    transform: {
      ...child.transform,
      x: r2(nextLx),
      y: r2(nextLy),
      zDepth: r2(nextLz),
      scale: rawNextScale,
      scaleX: rawNextScaleX,
      scaleY: rawNextScaleY,
      scaleZ: rawNextScaleZ,
      rotation: r2(nextRot),
      rotX: r2(nextRotX),
      rotY: r2(nextRotY),
    },
  };
}

export function buildColorFilterString(grade: ColorGrade, blurPx: number): string {
  let brightness = 1 + grade.exposure / 120;
  let contrast = 1 + grade.contrast / 100;
  let saturate = 1 + grade.saturation / 100;
  let sepia = 0;
  let hueRotate = grade.tint * 0.45;

  switch (grade.preset) {
    case 'cinematic-teal-orange':
      contrast *= 1.16;
      saturate *= 1.18;
      hueRotate -= 8;
      break;
    case 'crimson-noir':
      contrast *= 1.24;
      saturate *= 0.88;
      brightness *= 0.94;
      break;
    case 'golden-hour':
      sepia = 0.24;
      saturate *= 1.2;
      brightness *= 1.05;
      break;
    case 'vintage-35mm':
      sepia = 0.35;
      contrast *= 0.92;
      saturate *= 0.82;
      break;
    case 'monochrome':
      saturate = 0;
      contrast *= 1.22;
      break;
  }

  const parts = [
    `brightness(${Math.max(0.1, brightness).toFixed(2)})`,
    `contrast(${Math.max(0.1, contrast).toFixed(2)})`,
    `saturate(${Math.max(0, saturate).toFixed(2)})`,
  ];
  if (sepia > 0) parts.push(`sepia(${sepia.toFixed(2)})`);
  if (Math.abs(hueRotate) > 0.5) parts.push(`hue-rotate(${hueRotate.toFixed(1)}deg)`);
  if (blurPx > 0) parts.push(`blur(${blurPx.toFixed(1)}px)`);
  return parts.join(' ');
}

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean.padEnd(6, '0');
  const n = parseInt(full, 16) || 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function renderChromaKeyedSource(
  source: CanvasImageSource,
  srcW: number,
  srcH: number,
  clip: TimelineClip,
  bufferCanvas: HTMLCanvasElement
): HTMLCanvasElement {
  const maxW = 960;
  const scale = Math.min(1, maxW / Math.max(1, srcW));
  const w = Math.max(1, Math.round(srcW * scale));
  const h = Math.max(1, Math.round(srcH * scale));

  if (bufferCanvas.width !== w || bufferCanvas.height !== h) {
    bufferCanvas.width = w;
    bufferCanvas.height = h;
  }

  const bctx = bufferCanvas.getContext('2d', { willReadFrequently: true })!;
  bctx.clearRect(0, 0, w, h);
  bctx.drawImage(source, 0, 0, w, h);

  const imgData = bctx.getImageData(0, 0, w, h);
  const d = imgData.data;
  const [kr, kg, kb] = hexToRgb(clip.chromaKey.color);
  const tol = clip.chromaKey.tolerance * 2.4;
  const soft = Math.max(4, clip.chromaKey.softness * 1.8);
  const spill = clip.chromaKey.spillSuppression / 100;

  for (let i = 0; i < d.length; i += 4) {
    const r = d[i];
    const g = d[i + 1];
    const b = d[i + 2];
    const dist = Math.sqrt((r - kr) ** 2 + (g - kg) ** 2 + (b - kb) ** 2);

    if (dist < tol) {
      d[i + 3] = 0;
    } else if (dist < tol + soft) {
      const alpha = (dist - tol) / soft;
      d[i + 3] = Math.round(d[i + 3] * alpha);
      if (spill > 0 && kg > kr && kg > kb) {
        d[i + 1] = Math.min(g, Math.round((r + b) * 0.5 + (g - (r + b) * 0.5) * (1 - spill)));
      }
    }
  }

  bctx.putImageData(imgData, 0, 0);
  return bufferCanvas;
}

function drawParticles(
  ctx: CanvasRenderingContext2D,
  preset: ParticlePreset,
  intensity: number,
  time: number,
  w: number,
  h: number
) {
  if (preset === 'none' || intensity <= 0) return;
  const density = getActiveRenderPolicy().particleDensityMult;
  const count = Math.max(1, Math.round((intensity / 100) * 65 * density));

  ctx.save();
  for (let i = 0; i < count; i++) {
    const seed = (i * 9301 + 49297) % 233280;
    const rand1 = seed / 233280;
    const rand2 = ((i * 7919 + 104729) % 233280) / 233280;

    if (preset === 'red-smoke') {
      const px = ((rand1 + Math.sin(time * 0.35 + i) * 0.08) % 1) * w;
      const py = ((1 - ((rand2 + time * 0.09) % 1)) * 1.1 - 0.05) * h;
      const radius = (60 + rand1 * 120) * (w / 1280);
      const grad = ctx.createRadialGradient(px, py, 0, px, py, radius);
      grad.addColorStop(0, 'rgba(229, 9, 20, 0.16)');
      grad.addColorStop(0.5, 'rgba(136, 19, 55, 0.08)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(px, py, radius, 0, Math.PI * 2);
      ctx.fill();
    } else if (preset === 'fire-embers' || preset === 'neon-sparks') {
      const px = ((rand1 + Math.sin(time * 1.6 + i * 0.7) * 0.04) % 1) * w;
      const py = (1 - ((rand2 + time * (0.28 + rand1 * 0.25)) % 1)) * h;
      const r = (1.5 + rand2 * 3.5) * (w / 1280);
      ctx.fillStyle =
        preset === 'fire-embers'
          ? i % 3 === 0
            ? 'rgba(251, 146, 60, 0.85)'
            : 'rgba(239, 68, 68, 0.9)'
          : i % 2 === 0
          ? 'rgba(229, 9, 20, 0.9)'
          : 'rgba(255, 255, 255, 0.85)';
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();
    } else if (preset === 'rain') {
      const px = ((rand1 + time * 0.08) % 1) * w;
      const py = ((rand2 + time * 1.45) % 1) * h;
      ctx.strokeStyle = 'rgba(210, 225, 255, 0.34)';
      ctx.lineWidth = Math.max(1, w / 900);
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.lineTo(px - 6 * (w / 1280), py + 24 * (h / 720));
      ctx.stroke();
    } else if (preset === 'snow') {
      const px = ((rand1 + Math.sin(time + i) * 0.03) % 1) * w;
      const py = ((rand2 + time * 0.18) % 1) * h;
      const r = (1.5 + rand1 * 3) * (w / 1280);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.72)';
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}

function interpolateMaskPath(clip: TimelineClip, evalTime: number): BezierPoint[] {
  const kfs = clip.mask.animatedPaths;
  if (!kfs || kfs.length === 0) return clip.mask.pathPoints || [];
  const sorted = [...kfs].sort((a, b) => a.time - b.time);
  if (evalTime <= sorted[0].time) return sorted[0].points;
  if (evalTime >= sorted[sorted.length - 1].time) return sorted[sorted.length - 1].points;
  for (let i = 0; i < sorted.length - 1; i++) {
    const a = sorted[i];
    const b = sorted[i + 1];
    if (evalTime >= a.time && evalTime <= b.time) {
      const t = (evalTime - a.time) / Math.max(0.0001, b.time - a.time);
      const len = Math.min(a.points.length, b.points.length);
      const pts: BezierPoint[] = [];
      for (let j = 0; j < len; j++) {
        const p1 = a.points[j];
        const p2 = b.points[j];
        pts.push({
          x: p1.x + (p2.x - p1.x) * t,
          y: p1.y + (p2.y - p1.y) * t,
          inX: p1.inX + (p2.inX - p1.inX) * t,
          inY: p1.inY + (p2.inY - p1.inY) * t,
          outX: p1.outX + (p2.outX - p1.outX) * t,
          outY: p1.outY + (p2.outY - p1.outY) * t,
        });
      }
      return pts;
    }
  }
  return clip.mask.pathPoints || [];
}

function buildMaskSubpath(
  ctx: CanvasRenderingContext2D,
  clip: TimelineClip,
  evalTime: number,
  targetWidth: number,
  targetHeight: number
): boolean {
  const shape = clip.mask.shape;
  if (!shape || shape === 'none' || shape === 'radial-vignette') return false;

  const maskRadiusX = evaluateKeyframeProperty(
    clip.keyframes,
    'maskRadius',
    evalTime,
    clip.mask.radiusX
  );
  const exp =
    evaluateKeyframeProperty(clip.keyframes, 'maskExpansion', evalTime, clip.mask.expansion ?? 0) /
    100;
  const rx = Math.max(0.02, maskRadiusX + exp) * targetWidth * 0.5;
  const ry = Math.max(0.02, clip.mask.radiusY + exp) * targetHeight * 0.5;
  const mx = (clip.mask.centerX - 0.5) * targetWidth;
  const my = (clip.mask.centerY - 0.5) * targetHeight;

  ctx.beginPath();
  if (shape === 'circle') {
    const r = Math.min(rx, ry);
    ctx.arc(mx, my, Math.max(4, r), 0, Math.PI * 2);
  } else if (shape === 'ellipse') {
    ctx.ellipse(mx, my, Math.max(4, rx), Math.max(4, ry), 0, 0, Math.PI * 2);
  } else if (shape === 'rectangle') {
    ctx.rect(mx - rx, my - ry, rx * 2, ry * 2);
  } else if (shape === 'polygon') {
    const sides = Math.max(3, Math.round(clip.mask.points ?? 6));
    for (let i = 0; i < sides; i++) {
      const a = (i / sides) * Math.PI * 2 - Math.PI / 2;
      const px = mx + Math.cos(a) * rx;
      const py = my + Math.sin(a) * ry;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
  } else if (shape === 'star') {
    const spikes = Math.max(3, Math.round(clip.mask.points ?? 5));
    const inner = 0.45;
    for (let i = 0; i < spikes * 2; i++) {
      const a = (i / (spikes * 2)) * Math.PI * 2 - Math.PI / 2;
      const rScale = i % 2 === 0 ? 1 : inner;
      const px = mx + Math.cos(a) * rx * rScale;
      const py = my + Math.sin(a) * ry * rScale;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
  } else if (shape === 'custom-path') {
    const pts = interpolateMaskPath(clip, evalTime);
    if (pts.length < 2) return false;
    ctx.moveTo(pts[0].x * targetWidth, pts[0].y * targetHeight);
    for (let i = 0; i < pts.length; i++) {
      const curr = pts[i];
      const next = pts[(i + 1) % pts.length];
      ctx.bezierCurveTo(
        (curr.x + curr.outX) * targetWidth,
        (curr.y + curr.outY) * targetHeight,
        (next.x + next.inX) * targetWidth,
        (next.y + next.inY) * targetHeight,
        next.x * targetWidth,
        next.y * targetHeight
      );
    }
    ctx.closePath();
  }
  return true;
}

function drawShapeClip(
  ctx: CanvasRenderingContext2D,
  clip: TimelineClip,
  targetWidth: number,
  targetHeight: number
) {
  const sp = clip.shapeProps;
  if (!sp) return;
  const w = ((sp.widthPct || 36) / 100) * targetWidth;
  const h = ((sp.heightPct || 36) / 100) * targetHeight;

  ctx.save();
  ctx.beginPath();

  if (sp.shape === 'rectangle') {
    const r = Math.min(w * 0.5, h * 0.5, (sp.cornerRadius || 0) * (targetWidth / 1920));
    ctx.roundRect(-w * 0.5, -h * 0.5, w, h, Math.max(0, r));
  } else if (sp.shape === 'circle') {
    ctx.arc(0, 0, Math.min(w, h) * 0.5, 0, Math.PI * 2);
  } else if (sp.shape === 'ellipse') {
    ctx.ellipse(0, 0, w * 0.5, h * 0.5, 0, 0, Math.PI * 2);
  } else if (sp.shape === 'polygon') {
    const sides = Math.max(3, Math.round(sp.points || 6));
    for (let i = 0; i < sides; i++) {
      const a = (i / sides) * Math.PI * 2 - Math.PI / 2;
      const px = Math.cos(a) * w * 0.5;
      const py = Math.sin(a) * h * 0.5;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
  } else if (sp.shape === 'star') {
    const spikes = Math.max(3, Math.round(sp.points || 5));
    const inner = Math.max(0.1, Math.min(0.95, sp.innerRadius || 0.45));
    for (let i = 0; i < spikes * 2; i++) {
      const a = (i / (spikes * 2)) * Math.PI * 2 - Math.PI / 2;
      const m = i % 2 === 0 ? 1 : inner;
      const px = Math.cos(a) * w * 0.5 * m;
      const py = Math.sin(a) * h * 0.5 * m;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
  } else if (sp.shape === 'custom-path' && sp.pathPoints.length >= 2) {
    const pts = sp.pathPoints;
    ctx.moveTo(pts[0].x * targetWidth, pts[0].y * targetHeight);
    const limit = sp.closed ? pts.length : pts.length - 1;
    for (let i = 0; i < limit; i++) {
      const curr = pts[i];
      const next = pts[(i + 1) % pts.length];
      ctx.bezierCurveTo(
        (curr.x + curr.outX) * targetWidth,
        (curr.y + curr.outY) * targetHeight,
        (next.x + next.inX) * targetWidth,
        (next.y + next.inY) * targetHeight,
        next.x * targetWidth,
        next.y * targetHeight
      );
    }
    if (sp.closed) ctx.closePath();
  }

  if (sp.fillOpacity > 0) {
    ctx.save();
    ctx.globalAlpha *= sp.fillOpacity;
    ctx.fillStyle = sp.fillColor || '#E50914';
    ctx.fill();
    ctx.restore();
  }

  if (sp.strokeWidth > 0) {
    ctx.strokeStyle = sp.strokeColor || '#FFFFFF';
    ctx.lineWidth = sp.strokeWidth * (targetWidth / 1920);
    ctx.stroke();
  }
  ctx.restore();
}

const LABEL_HEX: Record<string, string> = {
  rose: '#E50914',
  amber: '#F59E0B',
  emerald: '#10B981',
  sky: '#38BDF8',
  violet: '#A855F7',
};

function drawNullLocator(
  ctx: CanvasRenderingContext2D,
  clip: TimelineClip,
  targetWidth: number,
  isSelected: boolean,
  axOff = 0,
  ayOff = 0
) {
  const accent = LABEL_HEX[clip.labelColor || 'rose'] || '#E50914';
  const s = Math.max(22, targetWidth * 0.032);
  ctx.save();
  ctx.strokeStyle = isSelected ? '#FFFFFF' : accent;
  ctx.lineWidth = isSelected ? 2.5 : 1.75;
  ctx.setLineDash([5, 4]);
  ctx.strokeRect(-s, -s, s * 2, s * 2);
  ctx.setLineDash([]);

  // Center crosshair
  ctx.beginPath();
  ctx.moveTo(-s * 0.55, 0);
  ctx.lineTo(s * 0.55, 0);
  ctx.moveTo(0, -s * 0.55);
  ctx.lineTo(0, s * 0.55);
  ctx.stroke();

  // Anchor dot (at anchor point when offset, else center)
  if (Math.abs(axOff) > 1 || Math.abs(ayOff) > 1) {
    ctx.strokeStyle = accent;
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(axOff, ayOff);
    ctx.stroke();
  }
  ctx.fillStyle = accent;
  ctx.beginPath();
  ctx.arc(axOff, ayOff, 4.5, 0, Math.PI * 2);
  ctx.fill();

  // Tag
  ctx.font = `600 ${Math.max(10, Math.round(targetWidth * 0.011))}px "JetBrains Mono", monospace`;
  ctx.fillStyle = isSelected ? '#FFFFFF' : accent;
  ctx.textAlign = 'left';
  ctx.fillText(`NULL: ${clip.name}`, -s, -s - 7);
  ctx.restore();
}

export interface HoverTargetResolution {
  targetClip: TimelineClip | null;
  adjacentPrevClip: TimelineClip | null;
  mode: 'none' | 'clip-fx' | 'text-clip' | 'text-fallback' | 'transition' | 'canvas-fallback';
}

export function resolveHoverTargetClip(
  project: StudioProject,
  playheadTime: number,
  selectedClipId?: string | null,
  hoverPreset?: ReadyMadeEffectPreset | null
): HoverTargetResolution {
  if (!hoverPreset) {
    return { targetClip: null, adjacentPrevClip: null, mode: 'none' };
  }

  const isActiveAtPlayhead = (c: TimelineClip) =>
    !c.disabled &&
    c.visible &&
    !c.muted &&
    c.type !== 'audio' &&
    c.type !== 'fx' &&
    c.type !== 'null' &&
    playheadTime >= c.startTime &&
    playheadTime <= c.startTime + c.duration;

  let selected = selectedClipId ? project.clips.find((c) => c.id === selectedClipId) || null : null;
  if (selected?.type === 'fx' && selected.fxMeta?.targetClipId) {
    selected = project.clips.find((c) => c.id === selected!.fxMeta!.targetClipId) || selected;
  }

  const trackRank = new Map<string, number>();
  project.tracks.forEach((t, idx) => {
    trackRank.set(t.id, project.tracks.length - idx);
  });

  const activeVisual = project.clips
    .filter((c) => {
      if (!isActiveAtPlayhead(c)) return false;
      const tr = project.tracks.find((t) => t.id === c.trackId);
      return Boolean(tr && tr.kind !== 'audio' && tr.visible && !tr.muted);
    })
    .sort((a, b) => (trackRank.get(b.trackId) || 0) - (trackRank.get(a.trackId) || 0));

  if (hoverPreset.category === 'text' && hoverPreset.textPreset) {
    const activeText =
      selected && selected.type === 'text' && isActiveAtPlayhead(selected)
        ? selected
        : activeVisual.find((c) => c.type === 'text') || null;
    if (activeText) {
      return { targetClip: activeText, adjacentPrevClip: null, mode: 'text-clip' };
    }
    return { targetClip: null, adjacentPrevClip: null, mode: 'text-fallback' };
  }

  const primaryTarget =
    selected && isActiveAtPlayhead(selected)
      ? selected
      : activeVisual[0] || null;

  if (hoverPreset.category === 'transition' || hoverPreset.transitionConfig) {
    if (primaryTarget) {
      const sameTrackPrev = project.clips
        .filter(
          (c) =>
            c.id !== primaryTarget.id &&
            c.trackId === primaryTarget.trackId &&
            !c.disabled &&
            c.visible &&
            c.type !== 'audio' &&
            c.type !== 'fx' &&
            c.type !== 'null' &&
            c.startTime < primaryTarget.startTime
        )
        .sort((a, b) => b.startTime + b.duration - (a.startTime + a.duration))[0] || null;
      return {
        targetClip: primaryTarget,
        adjacentPrevClip: sameTrackPrev,
        mode: 'transition',
      };
    }
    return { targetClip: null, adjacentPrevClip: null, mode: 'canvas-fallback' };
  }

  if (primaryTarget) {
    return { targetClip: primaryTarget, adjacentPrevClip: null, mode: 'clip-fx' };
  }

  return { targetClip: null, adjacentPrevClip: null, mode: 'canvas-fallback' };
}

export function renderCompositeFrame(
  ctx: CanvasRenderingContext2D,
  project: StudioProject,
  playheadTime: number,
  cache: MediaElementCache,
  targetWidth: number,
  targetHeight: number,
  options?: {
    seekVideos?: boolean;
    isPlaying?: boolean;
    isExport?: boolean;
    selectedClipId?: string | null;
    hoverPreviewPreset?: ReadyMadeEffectPreset | null;
    hoverPreviewBypass?: boolean;
    hoverPreviewClockSec?: number;
    isHoverPreview?: boolean;
    previewQuality?: PreviewQuality;
    proxyQuality?: ProxyQuality;
    isInteracting?: boolean;
    fpsDropFactor?: number;
  }
) {
  const policy = resolveRenderPolicy({
    isExport: options?.isExport,
    previewQuality: options?.previewQuality,
    proxyQuality: options?.proxyQuality,
    isInteracting: options?.isInteracting,
    isHoverPreview: options?.isHoverPreview,
    fpsDropFactor: options?.fpsDropFactor,
  });
  setActiveRenderPolicy(policy);

  const activeHoverPreset =
    options?.hoverPreviewPreset && !options?.hoverPreviewBypass && !options?.isExport
      ? options.hoverPreviewPreset
      : null;
  const hoverResolution = resolveHoverTargetClip(
    project,
    playheadTime,
    options?.selectedClipId,
    activeHoverPreset
  );
  const hoverClockSec =
    options?.hoverPreviewClockSec ??
    (typeof performance !== 'undefined' ? performance.now() / 1000 : 0);

  ctx.save();
  try {
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.clearRect(0, 0, targetWidth, targetHeight);
  ctx.fillStyle = project.backgroundColor || '#050507';
  ctx.fillRect(0, 0, targetWidth, targetHeight);

  // Camera 3D global perspective offset
  const cam: Camera3DSettings = project.camera3D;
  const camScale = cam.zoom || 1;
  const camPanX = (cam.orbitY / 45) * (targetWidth * 0.08);
  const camPanY = (cam.orbitX / 45) * (targetHeight * 0.08);

  const anySolo = project.tracks.some((t) => t.kind !== 'audio' && t.solo);
  const trackOrder = [...project.tracks].reverse(); // bottom track first (V1 -> V2 -> T1)

  for (const track of trackOrder) {
    if (track.kind === 'audio') continue;
    if (!track.visible || track.muted) continue;
    if (anySolo && !track.solo) continue;

    const activeClips = project.clips
      .filter(
        (c) =>
          c.trackId === track.id &&
          !c.disabled &&
          c.visible &&
          !c.muted &&
          playheadTime >= c.startTime &&
          playheadTime <= c.startTime + c.duration
      )
      .sort((a, b) => a.startTime - b.startTime);

    for (const clip of activeClips) {
      if (clip.type === 'null' && options?.isExport) {
        continue; // Non-rendering controller object in exports
      }

      if (clip.type === 'fx') {
        const rawLocalFx = Math.max(0, playheadTime - clip.startTime);
        const evalFx = getClipAnimationEvalTime(clip, rawLocalFx);
        const fxOpacity = evaluateKeyframeProperty(
          clip.keyframes,
          'opacity',
          evalFx,
          clip.transform.opacity
        );
        const fxBlur = evaluateKeyframeProperty(clip.keyframes, 'blur', evalFx, clip.effects.blur);
        const enabledFxStack = (clip.effectsStack || []).filter((e) => e.enabled);
        const advCC = hasAdvancedColorGrade(clip.colorGrade);

        if (cache.clipBuffer.width !== targetWidth || cache.clipBuffer.height !== targetHeight) {
          cache.clipBuffer.width = targetWidth;
          cache.clipBuffer.height = targetHeight;
        }
        const fxCtx = cache.clipBuffer.getContext('2d', { willReadFrequently: true })!;
        fxCtx.clearRect(0, 0, targetWidth, targetHeight);
        fxCtx.save();
        fxCtx.filter = advCC
          ? fxBlur > 0
            ? `blur(${fxBlur.toFixed(1)}px)`
            : 'none'
          : buildColorFilterString(clip.colorGrade, fxBlur);
        fxCtx.drawImage(ctx.canvas, 0, 0, targetWidth, targetHeight);
        fxCtx.restore();

        if (advCC) {
          applyFullColorGradeToCanvas(cache.clipBuffer, clip.colorGrade);
        }

        if (enabledFxStack.length > 0) {
          applyEffectsStackToCanvas(
            cache.clipBuffer,
            enabledFxStack,
            evalFx,
            clip.keyframes,
            clip.duration
          );
        }

        ctx.save();
        ctx.globalAlpha = Math.max(0, Math.min(1, fxOpacity));
        ctx.globalCompositeOperation = blendModeToCanvasOp(clip.blendMode);
        ctx.drawImage(cache.clipBuffer, 0, 0, targetWidth, targetHeight);
        ctx.restore();

        if (clip.effects.particles !== 'none') {
          drawParticles(
            ctx,
            clip.effects.particles,
            clip.effects.particleIntensity,
            playheadTime,
            targetWidth,
            targetHeight
          );
        }

        if (clip.effects.filmGrain > 0) {
          const grainCount = Math.max(20, Math.round(140 * policy.particleDensityMult));
          ctx.save();
          ctx.fillStyle = `rgba(255,255,255,${((clip.effects.filmGrain / 100) * 0.045).toFixed(3)})`;
          for (let g = 0; g < grainCount; g++) {
            const gx = ((Math.sin(playheadTime * 91 + g * 17) * 0.5 + 0.5) * targetWidth) | 0;
            const gy = ((Math.cos(playheadTime * 53 + g * 31) * 0.5 + 0.5) * targetHeight) | 0;
            ctx.fillRect(gx, gy, 2, 2);
          }
          ctx.restore();
        }
        continue;
      }

      const isHoveredTarget =
        Boolean(activeHoverPreset) && hoverResolution.targetClip?.id === clip.id;

      // If previewing a transition on targetClip and there's a preceding clip on the same track
      // that has already ended before playheadTime, render its end-frame underneath first
      if (
        isHoveredTarget &&
        hoverResolution.mode === 'transition' &&
        hoverResolution.adjacentPrevClip &&
        (playheadTime < hoverResolution.adjacentPrevClip.startTime ||
          playheadTime >
            hoverResolution.adjacentPrevClip.startTime +
              hoverResolution.adjacentPrevClip.duration)
      ) {
        const prevClip = hoverResolution.adjacentPrevClip;
        const prevAsset = project.assets.find((a) => a.id === prevClip.assetId);
        let prevSource: CanvasImageSource | null = null;
        let prevW = targetWidth;
        let prevH = targetHeight;
        if (prevAsset?.type === 'image') {
          const img = getOrLoadImage(cache, prevAsset);
          if (img) {
            prevSource = img;
            prevW = img.naturalWidth;
            prevH = img.naturalHeight;
          }
        } else if (prevAsset?.type === 'video') {
          const vid = getOrLoadVideo(cache, prevAsset);
          if (vid) {
            prevSource = vid;
            prevW = vid.videoWidth || prevAsset.width || targetWidth;
            prevH = vid.videoHeight || prevAsset.height || targetHeight;
          }
        }
        if (prevSource) {
          const aspectS = prevW / Math.max(1, prevH);
          const aspectD = targetWidth / targetHeight;
          const dW = aspectS > aspectD ? targetWidth : targetHeight * aspectS;
          const dH = aspectS > aspectD ? targetWidth / aspectS : targetHeight;
          ctx.save();
          ctx.translate(targetWidth * 0.5, targetHeight * 0.5);
          drawHighQualitySource(
            ctx,
            prevSource,
            prevW,
            prevH,
            -dW * 0.5,
            -dH * 0.5,
            dW,
            dH,
            cache.mipmapCanvas
          );
          ctx.restore();
        } else if (prevClip.type === 'shape' && prevClip.shapeProps) {
          ctx.save();
          ctx.translate(targetWidth * 0.5, targetHeight * 0.5);
          drawShapeClip(ctx, prevClip, targetWidth, targetHeight);
          ctx.restore();
        }
      }

      const rawLocalTime = Math.max(0, playheadTime - clip.startTime);
      const evalTime = getClipAnimationEvalTime(clip, rawLocalTime);
      const timeRemaining = Math.max(0, clip.duration - rawLocalTime);

      const local = evaluateLocalClipTransform(clip, playheadTime);
      const world = resolveWorldTransform(
        clip,
        project,
        playheadTime,
        new Set(),
        targetWidth,
        targetHeight
      );
      let modScaleX = 1;
      let modScaleY = 1;
      let modRotDeg = 0;
      let opacity = world.opacity;

      const blur = evaluateKeyframeProperty(clip.keyframes, 'blur', evalTime, clip.effects.blur);
      const glow = evaluateKeyframeProperty(clip.keyframes, 'glow', evalTime, clip.effects.glow);
      const glowRadius = evaluateKeyframeProperty(clip.keyframes, 'glowRadius', evalTime, 42);
      const effectIntensity = evaluateKeyframeProperty(clip.keyframes, 'effectIntensity', evalTime, 100) / 100;
      const distortionAmt = evaluateKeyframeProperty(clip.keyframes, 'distortion', evalTime, 0);
      const shadowAmt = evaluateKeyframeProperty(clip.keyframes, 'shadow', evalTime, 0);

      // Motion tracking oscillation
      let trackOffsetX = 0;
      let trackOffsetY = 0;
      if (clip.motionTrack.enabled) {
        trackOffsetX =
          Math.sin(rawLocalTime * clip.motionTrack.frequency * Math.PI) *
          clip.motionTrack.amplitudeX;
        trackOffsetY =
          Math.cos(rawLocalTime * clip.motionTrack.frequency * 0.8 * Math.PI) *
          clip.motionTrack.amplitudeY;
      }

      // Stabilization micro-crop + smoothing
      if (clip.effects.stabilization > 0) {
        const stab = 1 + (clip.effects.stabilization / 100) * 0.08;
        modScaleX *= stab;
        modScaleY *= stab;
      }

      // 37+ Transitions Engine (supports transitionInConfig & legacy transitionIn)
      let transOffsetX = 0;
      let transOffsetY = 0;
      let transBlur = 0;
      let flashAlpha = 0;
      let flashColor = '#FFFFFF';
      let lightLeakAlpha = 0;
      let clipMode: 'none' | 'circle' | 'rect-wipe' | 'radial-wipe' | 'diamond' = 'none';
      let clipProgress = 1;
      let clipDirection: TransitionSettings['direction'] = 'left';
      let rgbSplitTransitionPx = 0;

      const isHoverTransitionTarget =
        isHoveredTarget &&
        hoverResolution.mode === 'transition' &&
        Boolean(activeHoverPreset?.transitionConfig);

      const inCfg: TransitionSettings | null = isHoverTransitionTarget
        ? activeHoverPreset!.transitionConfig!
        : clip.transitionInConfig && clip.transitionInConfig.type !== 'none'
        ? clip.transitionInConfig
        : clip.transitionIn !== 'none'
        ? {
            ...getDefaultTransitionSettings(clip.transitionIn),
            duration: clip.transitionInDuration || 0.5,
          }
        : null;

      if (inCfg && (isHoverTransitionTarget || rawLocalTime < Math.max(0.04, inCfg.duration))) {
        const transDur = Math.max(0.25, inCfg.duration || 0.7);
        const loopCycle = transDur + 0.35;
        const p = isHoverTransitionTarget
          ? Math.min(1, (hoverClockSec % loopCycle) / transDur)
          : rawLocalTime / Math.max(0.05, inCfg.duration);
        const st = computeTransitionState(
          inCfg,
          p,
          false,
          targetWidth,
          targetHeight,
          isHoverTransitionTarget ? hoverClockSec : playheadTime
        );
        opacity *= st.opacityMult;
        transOffsetX += st.offsetX + st.shakeX;
        transOffsetY += st.offsetY + st.shakeY;
        modScaleX *= st.scaleMultX;
        modScaleY *= st.scaleMultY;
        modRotDeg += st.rotationDeg;
        transBlur += st.blurAdd;
        flashAlpha = Math.max(flashAlpha, st.flashAlpha);
        flashColor = st.flashColor;
        lightLeakAlpha = Math.max(lightLeakAlpha, st.lightLeakAlpha);
        rgbSplitTransitionPx = Math.max(rgbSplitTransitionPx, st.rgbSplitPx);
        if (st.clipMode !== 'none') {
          clipMode = st.clipMode;
          clipProgress = st.clipProgress;
          clipDirection = st.clipDirection;
        }
      }

      const outCfg: TransitionSettings | null =
        clip.transitionOutConfig && clip.transitionOutConfig.type !== 'none'
          ? clip.transitionOutConfig
          : clip.transitionOut !== 'none'
          ? {
              ...getDefaultTransitionSettings(clip.transitionOut),
              duration: clip.transitionOutDuration || 0.5,
            }
          : null;

      if (outCfg && timeRemaining < Math.max(0.04, outCfg.duration)) {
        const p = timeRemaining / Math.max(0.05, outCfg.duration);
        const st = computeTransitionState(outCfg, p, true, targetWidth, targetHeight, playheadTime);
        opacity *= st.opacityMult;
        transOffsetX += st.offsetX + st.shakeX;
        transOffsetY += st.offsetY + st.shakeY;
        modScaleX *= st.scaleMultX;
        modScaleY *= st.scaleMultY;
        modRotDeg += st.rotationDeg;
        transBlur += st.blurAdd;
        flashAlpha = Math.max(flashAlpha, st.flashAlpha);
        flashColor = st.flashColor;
        lightLeakAlpha = Math.max(lightLeakAlpha, st.lightLeakAlpha);
        rgbSplitTransitionPx = Math.max(rgbSplitTransitionPx, st.rgbSplitPx);
        if (st.clipMode !== 'none') {
          clipMode = st.clipMode;
          clipProgress = st.clipProgress;
          clipDirection = st.clipDirection;
        }
      }

      // Compute anchor offset in local pixel coordinates & true 2D affine matrix hierarchy
      const axOff = ((local.anchorX ?? 0.5) - 0.5) * targetWidth;
      const ayOff = ((local.anchorY ?? 0.5) - 0.5) * targetHeight;

      const zParallax = clip.is3DLayer ? 1 + world.zDepth * 0.002 : 1;
      const rotXScale = clip.is3DLayer ? Math.cos((local.rotX * Math.PI) / 180) : 1;
      const rotYScale = clip.is3DLayer ? Math.cos((local.rotY * Math.PI) / 180) : 1;

      const localClipMatrix = buildLocalClipMatrix2D(
        (local.lx / 100) * targetWidth,
        (local.ly / 100) * targetHeight,
        local.rotation + modRotDeg,
        local.scaleX * rotYScale * modScaleX,
        local.scaleY * rotXScale * modScaleY,
        axOff,
        ayOff
      );
      const composedLocal = multiplyMatrix2D(world.parentMatrix, localClipMatrix);
      const cameraMatrix: Matrix2D = [
        camScale,
        0,
        0,
        camScale,
        targetWidth * 0.5 + trackOffsetX + transOffsetX + camPanX * zParallax,
        targetHeight * 0.5 + trackOffsetY + transOffsetY + camPanY * zParallax,
      ];
      const finalMatrix = multiplyMatrix2D(cameraMatrix, composedLocal);

      if (clip.type === 'null') {
        ctx.save();
        ctx.globalAlpha = Math.max(0.35, opacity);
        ctx.transform(
          finalMatrix[0],
          finalMatrix[1],
          finalMatrix[2],
          finalMatrix[3],
          finalMatrix[4],
          finalMatrix[5]
        );
        drawNullLocator(
          ctx,
          clip,
          targetWidth,
          options?.selectedClipId === clip.id,
          axOff,
          ayOff
        );
        ctx.restore();
        continue;
      }

      // Non-destructive transient clip overrides for Live Effect Hover Preview
      const hoverEffectsStack =
        isHoveredTarget &&
        hoverResolution.mode === 'clip-fx' &&
        activeHoverPreset?.effectsStack?.length
          ? activeHoverPreset.effectsStack
          : [];
      const effectiveColorGrade: ColorGrade =
        isHoveredTarget &&
        hoverResolution.mode === 'clip-fx' &&
        activeHoverPreset?.colorGrade
          ? {
              ...clip.colorGrade,
              preset: 'none',
              lutIntensity: 95,
              ...(activeHoverPreset.colorGrade as Partial<ColorGrade>),
            }
          : clip.colorGrade;

      // Determine if we should route clip through clipBuffer (required for Effects Stack, full CC grade, RGB transition, or Quality Enhancer)
      const enabledStack = (clip.effectsStack || []).filter((e) => e.enabled);
      const clipHasAdvCC = hasAdvancedColorGrade(effectiveColorGrade);
      const assetForCheck = project.assets.find((a) => a.id === clip.assetId);
      const hasPreEnhancedImage =
        assetForCheck?.type === 'image' &&
        clip.qualityEnhancer?.enabled &&
        Boolean(enhancedImageCache.get(assetForCheck.id, clip.qualityEnhancer));
      const applyLiveEnhancer = Boolean(
        clip.qualityEnhancer?.enabled &&
          clip.qualityEnhancer.intensity > 0 &&
          !hasPreEnhancedImage &&
          (assetForCheck?.type === 'image' || assetForCheck?.type === 'video')
      );
      const useBuffer =
        enabledStack.length > 0 ||
        hoverEffectsStack.length > 0 ||
        rgbSplitTransitionPx > 0 ||
        clipHasAdvCC ||
        applyLiveEnhancer;

      let targetCtx = ctx;
      if (useBuffer) {
        if (cache.clipBuffer.width !== targetWidth || cache.clipBuffer.height !== targetHeight) {
          cache.clipBuffer.width = targetWidth;
          cache.clipBuffer.height = targetHeight;
        }
        targetCtx =
          cache.clipBuffer.getContext('2d', { colorSpace: 'srgb', willReadFrequently: true }) ||
          cache.clipBuffer.getContext('2d', { willReadFrequently: true })!;
        targetCtx.imageSmoothingEnabled = true;
        targetCtx.imageSmoothingQuality = 'high';
        targetCtx.clearRect(0, 0, targetWidth, targetHeight);
      }

      targetCtx.save();
      if (!useBuffer) {
        targetCtx.globalAlpha = Math.max(0, Math.min(1, opacity));
        targetCtx.globalCompositeOperation = blendModeToCanvasOp(clip.blendMode);
      }

      targetCtx.transform(
        finalMatrix[0],
        finalMatrix[1],
        finalMatrix[2],
        finalMatrix[3],
        finalMatrix[4],
        finalMatrix[5]
      );

      // Apply Transition Clip Reveals
      if (clipMode === 'circle') {
        targetCtx.beginPath();
        targetCtx.arc(0, 0, Math.max(targetWidth, targetHeight) * clipProgress * 0.75, 0, Math.PI * 2);
        targetCtx.clip();
      } else if (clipMode === 'rect-wipe') {
        targetCtx.beginPath();
        const rw = targetWidth * clipProgress;
        const rh = targetHeight * clipProgress;
        if (clipDirection === 'right') {
          targetCtx.rect(targetWidth * 0.5 - rw, -targetHeight * 0.5, rw, targetHeight);
        } else if (clipDirection === 'up') {
          targetCtx.rect(-targetWidth * 0.5, targetHeight * 0.5 - rh, targetWidth, rh);
        } else if (clipDirection === 'down') {
          targetCtx.rect(-targetWidth * 0.5, -targetHeight * 0.5, targetWidth, rh);
        } else {
          targetCtx.rect(-targetWidth * 0.5, -targetHeight * 0.5, rw, targetHeight);
        }
        targetCtx.clip();
      } else if (clipMode === 'radial-wipe') {
        targetCtx.beginPath();
        targetCtx.moveTo(0, 0);
        targetCtx.arc(
          0,
          0,
          Math.max(targetWidth, targetHeight),
          -Math.PI / 2,
          -Math.PI / 2 + Math.PI * 2 * clipProgress
        );
        targetCtx.closePath();
        targetCtx.clip();
      } else if (clipMode === 'diamond') {
        const d = Math.max(targetWidth, targetHeight) * clipProgress * 0.9;
        targetCtx.beginPath();
        targetCtx.moveTo(0, -d);
        targetCtx.lineTo(d, 0);
        targetCtx.lineTo(0, d);
        targetCtx.lineTo(-d, 0);
        targetCtx.closePath();
        targetCtx.clip();
      }

      // Apply Masking (supporting Inverted & Subtract mode via evenodd winding)
      const maskFeather = evaluateKeyframeProperty(
        clip.keyframes,
        'maskFeather',
        evalTime,
        clip.mask.feather
      );
      if (clip.mask.shape !== 'none' && clip.mask.shape !== 'radial-vignette') {
        const maskOpacityVal = evaluateKeyframeProperty(
          clip.keyframes,
          'maskOpacity',
          evalTime,
          clip.mask.opacity ?? 100
        );
        const maskOpacity = maskOpacityVal / 100;
        if (maskOpacity > 0.01) {
          const isSubtract = clip.mask.inverted || clip.mask.mode === 'subtract';
          if (isSubtract) {
            targetCtx.beginPath();
            targetCtx.rect(-targetWidth * 2, -targetHeight * 2, targetWidth * 4, targetHeight * 4);
            // Draw inner path inside same beginPath for evenodd cutout
            const mRx =
              evaluateKeyframeProperty(clip.keyframes, 'maskRadius', evalTime, clip.mask.radiusX) *
              targetWidth *
              0.5;
            const mRy = clip.mask.radiusY * targetHeight * 0.5;
            const mx = (clip.mask.centerX - 0.5) * targetWidth;
            const my = (clip.mask.centerY - 0.5) * targetHeight;
            targetCtx.ellipse(mx, my, Math.max(4, mRx), Math.max(4, mRy), 0, 0, Math.PI * 2);
            targetCtx.clip('evenodd');
          } else {
            const built = buildMaskSubpath(targetCtx, clip, evalTime, targetWidth, targetHeight);
            if (built) targetCtx.clip();
          }
        }
      }

      const totalBlur =
        blur * effectIntensity +
        transBlur +
        maskFeather * 0.12 +
        (cam.dofBlur > 0 && clip.is3DLayer ? cam.dofBlur * 0.3 : 0);
      targetCtx.filter = clipHasAdvCC
        ? totalBlur > 0
          ? `blur(${totalBlur.toFixed(1)}px)`
          : 'none'
        : buildColorFilterString(effectiveColorGrade, totalBlur);
      if (glow > 0 || shadowAmt > 0) {
        if (glow > 0) {
          targetCtx.shadowColor = clip.effects.glowColor || '#E50914';
          targetCtx.shadowBlur = (glow / 100) * glowRadius * effectIntensity;
        } else if (shadowAmt > 0) {
          targetCtx.shadowColor = 'rgba(0,0,0,0.85)';
          targetCtx.shadowBlur = shadowAmt * 0.6;
          targetCtx.shadowOffsetX = shadowAmt * 0.25;
          targetCtx.shadowOffsetY = shadowAmt * 0.35;
        }
      }
      if (distortionAmt > 0) {
        const wave = Math.sin(evalTime * 8) * (distortionAmt / 100) * 0.06;
        targetCtx.transform(1 + wave, 0, wave * 0.6, 1 - wave, 0, 0);
      }

      if (clip.type === 'text' && clip.textProps) {
        if (
          isHoveredTarget &&
          hoverResolution.mode === 'text-clip' &&
          activeHoverPreset?.textPreset
        ) {
          const tpHover = activeHoverPreset.textPreset;
          const clonedTextClip: TimelineClip = {
            ...clip,
            textProps: {
              ...clip.textProps,
              animation: tpHover.animation,
              effectSpeed: tpHover.effectSpeed,
              effectIntensity: tpHover.effectIntensity,
              effectDuration: tpHover.effectDuration,
              effectDirection: tpHover.effectDirection,
              animationStrength: tpHover.animationStrength,
              fontWeight: tpHover.fontWeight ?? clip.textProps.fontWeight,
              color: tpHover.color ?? clip.textProps.color,
              strokeColor: tpHover.strokeColor ?? clip.textProps.strokeColor,
              strokeWidth: tpHover.strokeWidth ?? clip.textProps.strokeWidth,
              shadowBlur: tpHover.shadowBlur ?? clip.textProps.shadowBlur,
              shadowColor: tpHover.shadowColor ?? clip.textProps.shadowColor,
              extrude3D: tpHover.extrude3D ?? clip.textProps.extrude3D,
              extrudeDepth: tpHover.extrudeDepth ?? clip.textProps.extrudeDepth,
              letterSpacing: tpHover.letterSpacing ?? clip.textProps.letterSpacing,
              gradientEnabled: tpHover.gradientEnabled ?? clip.textProps.gradientEnabled,
              gradientStart: tpHover.gradientStart ?? clip.textProps.gradientStart,
              gradientEnd: tpHover.gradientEnd ?? clip.textProps.gradientEnd,
            },
          };
          const hoverTextCycle = Math.max(1.2, (tpHover.effectDuration || 1.2) + 0.5);
          const hoverTextT = hoverClockSec % hoverTextCycle;
          drawTextClip(targetCtx, clonedTextClip, hoverTextT, hoverTextT, targetWidth, targetHeight);
        } else {
          drawTextClip(targetCtx, clip, rawLocalTime, evalTime, targetWidth, targetHeight);
        }
      } else if (clip.type === 'shape' && clip.shapeProps) {
        drawShapeClip(targetCtx, clip, targetWidth, targetHeight);
      } else {
        const asset = project.assets.find((a) => a.id === clip.assetId);
        if (asset) {
          let drawSource: CanvasImageSource | null = null;
          let srcW = targetWidth;
          let srcH = targetHeight;

          if (asset.type === 'image') {
            const enhancedEntry =
              clip.qualityEnhancer?.enabled && clip.qualityEnhancer.intensity > 0
                ? enhancedImageCache.get(asset.id, clip.qualityEnhancer)
                : null;
            if (enhancedEntry) {
              drawSource = enhancedEntry.canvas;
              srcW = enhancedEntry.width;
              srcH = enhancedEntry.height;
            } else {
              const img = getOrLoadImage(cache, asset);
              if (img) {
                drawSource = img;
                srcW = img.naturalWidth;
                srcH = img.naturalHeight;
              }
            }
          } else if (asset.type === 'video') {
            const slowMult = clip.smoothVideo?.enabled ? clip.smoothVideo.slowMotionSpeed : 1;
            const effectiveSpeed = clip.speed * slowMult;
            const targetMediaTime = clip.reverse
              ? Math.max(0, asset.duration - (clip.sourceOffset + rawLocalTime * effectiveSpeed))
              : clip.sourceOffset + rawLocalTime * effectiveSpeed;
            const safeTime = Math.max(0, Math.min(asset.duration, targetMediaTime));

            // Check cached Smooth Video optical-flow interpolated frame first
            const smoothFrame =
              clip.smoothVideo?.enabled && clip.smoothVideo.targetFps !== 'original'
                ? smoothVideoCache.getNearestFrame(asset.id, clip.smoothVideo, safeTime, 0.032)
                : null;

            if (smoothFrame) {
              drawSource = smoothFrame;
              srcW = smoothFrame.width;
              srcH = smoothFrame.height;
            } else {
              const vid = getOrLoadVideo(cache, asset);
              if (vid) {
                const clampedVidTime = Math.max(0, Math.min(vid.duration || asset.duration, safeTime));
                if (options?.seekVideos) {
                  if (Math.abs(vid.currentTime - clampedVidTime) > 0.04) {
                    vid.currentTime = clampedVidTime;
                  }
                } else if (options?.isPlaying) {
                  vid.playbackRate = Math.max(0.1, effectiveSpeed);
                  if (vid.paused) vid.play().catch(() => {});
                  if (Math.abs(vid.currentTime - clampedVidTime) > 0.35) {
                    vid.currentTime = clampedVidTime;
                  }
                } else {
                  if (!vid.paused) vid.pause();
                  if (Math.abs(vid.currentTime - clampedVidTime) > 0.05) {
                    vid.currentTime = clampedVidTime;
                  }
                }
                drawSource = vid;
                srcW = vid.videoWidth || asset.width || targetWidth;
                srcH = vid.videoHeight || asset.height || targetHeight;
              }
            }
          } else if (asset.type === 'model3d') {
            draw3DPlaceholderLayer(targetCtx, asset.name, rawLocalTime, targetWidth, targetHeight);
          }

          if (drawSource) {
            if (clip.chromaKey.enabled) {
              drawSource = renderChromaKeyedSource(drawSource, srcW, srcH, clip, cache.offscreen);
              srcW = cache.offscreen.width;
              srcH = cache.offscreen.height;
            }

            const aspectSrc = srcW / Math.max(1, srcH);
            const aspectDst = targetWidth / targetHeight;
            let drawW = targetWidth;
            let drawH = targetHeight;
            if (aspectSrc > aspectDst) {
              drawW = targetWidth;
              drawH = targetWidth / aspectSrc;
            } else {
              drawH = targetHeight;
              drawW = targetHeight * aspectSrc;
            }

            drawHighQualitySource(
              targetCtx,
              drawSource,
              srcW,
              srcH,
              -drawW * 0.5,
              -drawH * 0.5,
              drawW,
              drawH,
              cache.mipmapCanvas
            );

            if (!clipHasAdvCC && Math.abs(effectiveColorGrade.temperature) > 3) {
              targetCtx.fillStyle =
                effectiveColorGrade.temperature > 0
                  ? `rgba(255, 145, 45, ${(effectiveColorGrade.temperature / 450).toFixed(3)})`
                  : `rgba(56, 189, 248, ${(Math.abs(effectiveColorGrade.temperature) / 450).toFixed(3)})`;
              targetCtx.fillRect(-drawW * 0.5, -drawH * 0.5, drawW, drawH);
            }
          }
        }
      }

      targetCtx.restore();

      if (useBuffer) {
        if (applyLiveEnhancer && clip.qualityEnhancer) {
          applyClipQualityEnhancerToCanvas(
            cache.clipBuffer,
            clip.qualityEnhancer,
            assetForCheck?.type === 'video'
          );
        }
        if (clipHasAdvCC) {
          applyFullColorGradeToCanvas(cache.clipBuffer, effectiveColorGrade);
        }
        if (enabledStack.length > 0) {
          applyEffectsStackToCanvas(
            cache.clipBuffer,
            enabledStack,
            evalTime,
            clip.keyframes,
            clip.duration
          );
        }
        if (hoverEffectsStack.length > 0) {
          const hoverCycle = Math.max(0.8, activeHoverPreset?.defaultDuration || 2.5);
          const hoverEvalT = hoverClockSec % hoverCycle;
          applyEffectsStackToCanvas(
            cache.clipBuffer,
            hoverEffectsStack,
            hoverEvalT,
            [],
            hoverCycle
          );
        }
        if (rgbSplitTransitionPx > 0) {
          applyEffectsStackToCanvas(
            cache.clipBuffer,
            [
              {
                id: '__trans_rgb',
                type: 'rgb-split',
                name: 'RGB Split',
                category: 'color',
                enabled: true,
                blendMode: 'normal',
                params: { offsetX: rgbSplitTransitionPx, offsetY: 0 },
              },
            ],
            evalTime,
            [],
            clip.duration
          );
        }
        ctx.save();
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.globalAlpha = Math.max(0, Math.min(1, opacity));
        ctx.globalCompositeOperation = blendModeToCanvasOp(clip.blendMode);
        ctx.drawImage(cache.clipBuffer, 0, 0, targetWidth, targetHeight);
        ctx.restore();
      }

      // Transition Overlays (Flash / Dip / Light Leak)
      if (flashAlpha > 0.01) {
        ctx.save();
        ctx.globalAlpha = Math.min(1, flashAlpha);
        ctx.fillStyle = flashColor;
        ctx.fillRect(0, 0, targetWidth, targetHeight);
        ctx.restore();
      }
      if (lightLeakAlpha > 0.01) {
        ctx.save();
        const lg = ctx.createRadialGradient(
          targetWidth * 0.18,
          targetHeight * 0.25,
          0,
          targetWidth * 0.25,
          targetHeight * 0.35,
          targetWidth * 0.85
        );
        lg.addColorStop(0, `rgba(255, 140, 40, ${(lightLeakAlpha * 0.85).toFixed(2)})`);
        lg.addColorStop(0.45, `rgba(229, 9, 20, ${(lightLeakAlpha * 0.55).toFixed(2)})`);
        lg.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = lg;
        ctx.fillRect(0, 0, targetWidth, targetHeight);
        ctx.restore();
      }

      // Post-clip vignette & particles (in screen space)
      if ((!clipHasAdvCC && effectiveColorGrade.vignette > 0) || clip.mask.shape === 'radial-vignette') {
        const vigStrength = Math.max(
          clipHasAdvCC ? 0 : effectiveColorGrade.vignette / 100,
          clip.mask.shape === 'radial-vignette' ? 0.65 : 0
        );
        const rad = ctx.createRadialGradient(
          targetWidth * 0.5,
          targetHeight * 0.5,
          targetWidth * 0.25,
          targetWidth * 0.5,
          targetHeight * 0.5,
          targetWidth * 0.72
        );
        rad.addColorStop(0, 'rgba(0,0,0,0)');
        rad.addColorStop(1, `rgba(0,0,0,${Math.min(0.92, vigStrength * 0.88).toFixed(2)})`);
        ctx.fillStyle = rad;
        ctx.fillRect(0, 0, targetWidth, targetHeight);
      }

      if (clip.effects.particles !== 'none') {
        drawParticles(
          ctx,
          clip.effects.particles,
          clip.effects.particleIntensity,
          playheadTime,
          targetWidth,
          targetHeight
        );
      }

      if (clip.effects.filmGrain > 0) {
        const grainCount = Math.max(20, Math.round(140 * policy.particleDensityMult));
        ctx.save();
        ctx.fillStyle = `rgba(255,255,255,${((clip.effects.filmGrain / 100) * 0.04).toFixed(3)})`;
        for (let g = 0; g < grainCount; g++) {
          const gx = ((Math.sin(playheadTime * 91 + g * 17) * 0.5 + 0.5) * targetWidth) | 0;
          const gy = ((Math.cos(playheadTime * 53 + g * 31) * 0.5 + 0.5) * targetHeight) | 0;
          ctx.fillRect(gx, gy, 2, 2);
        }
        ctx.restore();
      }
    }
  }

  // Non-destructive Live Hover Preview fallback (when no specific timeline text/visual clip matched at playhead)
  if (
    activeHoverPreset &&
    (hoverResolution.mode === 'text-fallback' || hoverResolution.mode === 'canvas-fallback')
  ) {
    const hp = activeHoverPreset;
    const previewCycle = Math.max(0.8, hp.defaultDuration || 2.5);
    const localT = (playheadTime + hoverClockSec * 0.85) % previewCycle;

    if (hp.effectsStack && hp.effectsStack.length > 0) {
      if (cache.clipBuffer.width !== targetWidth || cache.clipBuffer.height !== targetHeight) {
        cache.clipBuffer.width = targetWidth;
        cache.clipBuffer.height = targetHeight;
      }
      const pCtx = cache.clipBuffer.getContext('2d', { willReadFrequently: true })!;
      pCtx.clearRect(0, 0, targetWidth, targetHeight);
      pCtx.drawImage(ctx.canvas, 0, 0, targetWidth, targetHeight);
      applyEffectsStackToCanvas(cache.clipBuffer, hp.effectsStack, localT, [], previewCycle);
      ctx.drawImage(cache.clipBuffer, 0, 0, targetWidth, targetHeight);
    } else if (hp.colorGrade) {
      if (cache.clipBuffer.width !== targetWidth || cache.clipBuffer.height !== targetHeight) {
        cache.clipBuffer.width = targetWidth;
        cache.clipBuffer.height = targetHeight;
      }
      const pCtx = cache.clipBuffer.getContext('2d', { willReadFrequently: true })!;
      pCtx.clearRect(0, 0, targetWidth, targetHeight);
      pCtx.drawImage(ctx.canvas, 0, 0, targetWidth, targetHeight);
      const mergedGrade: ColorGrade = {
        preset: 'none',
        exposure: 0,
        contrast: 0,
        saturation: 0,
        temperature: 0,
        tint: 0,
        vignette: 0,
        highlights: 0,
        shadows: 0,
        whites: 0,
        blacks: 0,
        vibrance: 0,
        lutIntensity: 95,
        ...(hp.colorGrade as Partial<ColorGrade>),
      };
      applyFullColorGradeToCanvas(cache.clipBuffer, mergedGrade);
      ctx.drawImage(cache.clipBuffer, 0, 0, targetWidth, targetHeight);
    } else if (hp.textPreset) {
      const dummyClip = {
        id: '__preview_text',
        trackId: 't',
        assetId: '',
        name: hp.name,
        type: 'text' as const,
        startTime: 0,
        duration: previewCycle,
        sourceOffset: 0,
        speed: 1,
        reverse: false,
        volume: 1,
        muted: false,
        visible: true,
        locked: false,
        fadeIn: 0,
        fadeOut: 0,
        blendMode: 'normal' as const,
        is3DLayer: false,
        transform: {
          x: 0,
          y: 0,
          scale: 1,
          rotation: 0,
          opacity: 1,
          anchorX: 0.5,
          anchorY: 0.5,
          zDepth: 0,
          rotX: 0,
          rotY: 0,
        },
        colorGrade: {
          preset: 'none' as const,
          exposure: 0,
          contrast: 0,
          saturation: 0,
          temperature: 0,
          tint: 0,
          vignette: 0,
          highlights: 0,
          shadows: 0,
        },
        chromaKey: { enabled: false, color: '#00FF00', tolerance: 30, softness: 15, spillSuppression: 40 },
        mask: { shape: 'none' as const, centerX: 0.5, centerY: 0.5, radiusX: 0.4, radiusY: 0.4, feather: 12, inverted: false },
        effects: {
          blur: 0,
          glow: 0,
          glowColor: '#E50914',
          stabilization: 0,
          filmGrain: 0,
          chromaticAberration: 0,
          particles: 'none' as const,
          particleIntensity: 0,
        },
        effectsStack: [],
        keyframes: [],
        transitionIn: 'none' as const,
        transitionInDuration: 0.5,
        transitionOut: 'none' as const,
        transitionOutDuration: 0.5,
        motionTrack: { enabled: false, targetName: '', targetX: 0.5, targetY: 0.5, amplitudeX: 0, amplitudeY: 0, frequency: 1 },
        textProps: {
          text: hp.name.toUpperCase(),
          fontFamily: 'Inter',
          fontSize: 82,
          fontWeight: hp.textPreset.fontWeight ?? 800,
          letterSpacing: hp.textPreset.letterSpacing ?? 1,
          color: hp.textPreset.color || '#FFFFFF',
          strokeColor: hp.textPreset.strokeColor || '#000000',
          strokeWidth: hp.textPreset.strokeWidth ?? 2,
          shadowColor: hp.textPreset.shadowColor || 'rgba(0,0,0,0.8)',
          shadowBlur: hp.textPreset.shadowBlur ?? 16,
          extrude3D: hp.textPreset.extrude3D,
          extrudeDepth: hp.textPreset.extrudeDepth,
          gradientEnabled: hp.textPreset.gradientEnabled,
          gradientStart: hp.textPreset.gradientStart,
          gradientEnd: hp.textPreset.gradientEnd,
          backgroundColor: 'transparent',
          animation: hp.textPreset.animation,
          effectSpeed: hp.textPreset.effectSpeed,
          effectIntensity: hp.textPreset.effectIntensity,
          effectDuration: hp.textPreset.effectDuration,
          effectDirection: hp.textPreset.effectDirection,
          animationStrength: hp.textPreset.animationStrength,
          isSubtitle: false,
          align: 'center' as const,
        },
      };
      ctx.save();
      ctx.translate(targetWidth * 0.5, targetHeight * 0.5);
      drawTextClip(ctx, dummyClip, localT, localT, targetWidth, targetHeight);
      ctx.restore();
    } else if (hp.transitionConfig) {
      const p = Math.min(1, localT / Math.max(0.25, hp.transitionConfig.duration || 0.7));
      const st = computeTransitionState(hp.transitionConfig, p, false, targetWidth, targetHeight, localT);
      if (st.flashAlpha > 0.01) {
        ctx.save();
        ctx.globalAlpha = Math.min(0.9, st.flashAlpha);
        ctx.fillStyle = st.flashColor;
        ctx.fillRect(0, 0, targetWidth, targetHeight);
        ctx.restore();
      }
      if (st.lightLeakAlpha > 0.01) {
        ctx.save();
        const lg = ctx.createRadialGradient(
          targetWidth * 0.2,
          targetHeight * 0.25,
          0,
          targetWidth * 0.25,
          targetHeight * 0.35,
          targetWidth * 0.85
        );
        lg.addColorStop(0, `rgba(255, 140, 40, ${(st.lightLeakAlpha * 0.85).toFixed(2)})`);
        lg.addColorStop(0.5, `rgba(229, 9, 20, ${(st.lightLeakAlpha * 0.55).toFixed(2)})`);
        lg.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = lg;
        ctx.fillRect(0, 0, targetWidth, targetHeight);
        ctx.restore();
      }
      if (st.rgbSplitPx > 0) {
        if (cache.clipBuffer.width !== targetWidth || cache.clipBuffer.height !== targetHeight) {
          cache.clipBuffer.width = targetWidth;
          cache.clipBuffer.height = targetHeight;
        }
        const pCtx = cache.clipBuffer.getContext('2d', { willReadFrequently: true })!;
        pCtx.drawImage(ctx.canvas, 0, 0, targetWidth, targetHeight);
        applyEffectsStackToCanvas(
          cache.clipBuffer,
          [
            {
              id: '__hover_trans_rgb',
              type: 'rgb-split',
              name: 'RGB Split',
              category: 'color',
              enabled: true,
              blendMode: 'normal',
              params: { shiftX: st.rgbSplitPx, shiftY: 0 },
            },
          ],
          localT,
          [],
          previewCycle
        );
        ctx.drawImage(cache.clipBuffer, 0, 0, targetWidth, targetHeight);
      }
    }
  }

  } finally {
    ctx.restore();
    setActiveRenderPolicy(resolveRenderPolicy({ isExport: true }));
  }
}

export interface ClipCanvasBounds {
  clip: TimelineClip;
  cx: number; // canvas px center before anchor/rot
  cy: number;
  pivotX: number; // canvas px anchor pivot
  pivotY: number;
  centerX: number; // transformed visual center X in canvas px
  centerY: number; // transformed visual center Y in canvas px
  baseWidth: number; // unscaled pixel width
  baseHeight: number; // unscaled pixel height
  scaledWidth: number; // |scaleX * camScale| * baseWidth
  scaledHeight: number; // |scaleY * camScale| * baseHeight
  rotationDeg: number;
  scaleX: number;
  scaleY: number;
  anchorX: number;
  anchorY: number;
  axOff: number;
  ayOff: number;
  camScale: number;
  matrix: Matrix2D;
  parentWorldMatrix: Matrix2D; // parent matrix including camera (for local delta inversion)
  corners: [
    { x: number; y: number },
    { x: number; y: number },
    { x: number; y: number },
    { x: number; y: number }
  ]; // TL, TR, BR, BL in canvas px
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
}

export function computeVisibleClipBounds(
  ctx: CanvasRenderingContext2D,
  project: StudioProject,
  playheadTime: number,
  cache: MediaElementCache,
  targetWidth: number,
  targetHeight: number
): ClipCanvasBounds[] {
  const results: ClipCanvasBounds[] = [];
  const cam = project.camera3D;
  const camScale = cam.zoom || 1;
  const camPanX = (cam.orbitY / 45) * (targetWidth * 0.08);
  const camPanY = (cam.orbitX / 45) * (targetHeight * 0.08);

  const anySolo = project.tracks.some((t) => t.kind !== 'audio' && t.solo);
  const trackOrder = [...project.tracks].reverse(); // bottom first -> topmost last

  for (const track of trackOrder) {
    if (track.kind === 'audio' || !track.visible || track.muted) continue;
    if (anySolo && !track.solo) continue;

    const activeClips = project.clips
      .filter(
        (c) =>
          c.trackId === track.id &&
          !c.disabled &&
          c.visible &&
          !c.muted &&
          c.type !== 'fx' &&
          playheadTime >= c.startTime &&
          playheadTime <= c.startTime + c.duration
      )
      .sort((a, b) => a.startTime - b.startTime);

    for (const clip of activeClips) {
      const local = evaluateLocalClipTransform(clip, playheadTime);
      const world = resolveWorldTransform(
        clip,
        project,
        playheadTime,
        new Set(),
        targetWidth,
        targetHeight
      );
      const scaleFactor = targetWidth / 1920;

      let baseWidth = targetWidth;
      let baseHeight = targetHeight;

      if (clip.type === 'null') {
        const s = Math.max(22, targetWidth * 0.032) * 2;
        baseWidth = s;
        baseHeight = s;
      } else if (clip.type === 'shape' && clip.shapeProps) {
        baseWidth = ((clip.shapeProps.widthPct || 36) / 100) * targetWidth;
        baseHeight = ((clip.shapeProps.heightPct || 36) / 100) * targetHeight;
      } else if (clip.type === 'text' && clip.textProps) {
        const tp = clip.textProps;
        const fontPx = Math.round(tp.fontSize * scaleFactor);
        const weight = tp.fontWeight ?? 700;
        ctx.save();
        ctx.font = `${weight} ${fontPx}px "${tp.fontFamily}", sans-serif`;
        const lines = (tp.text || 'TEXT').split('\n');
        const lineH = fontPx * (tp.lineHeight ?? 1.2);
        const totalH = lines.length * lineH;
        const maxWidth = Math.max(...lines.map((ln) => ctx.measureText(ln).width), 40);
        ctx.restore();
        baseWidth = maxWidth + 48 * scaleFactor;
        baseHeight = totalH + 28 * scaleFactor;
      } else {
        const asset = project.assets.find((a) => a.id === clip.assetId);
        let srcW = asset?.width || targetWidth;
        let srcH = asset?.height || targetHeight;
        if (asset?.type === 'image') {
          const img = getOrLoadImage(cache, asset);
          if (img) {
            srcW = img.naturalWidth || srcW;
            srcH = img.naturalHeight || srcH;
          }
        } else if (asset?.type === 'video') {
          const vid = getOrLoadVideo(cache, asset);
          if (vid && vid.videoWidth > 0) {
            srcW = vid.videoWidth;
            srcH = vid.videoHeight;
          }
        } else if (asset?.type === 'model3d') {
          srcW = Math.min(targetWidth, targetHeight) * 0.45;
          srcH = srcW;
        }
        const aspectSrc = srcW / Math.max(1, srcH);
        const aspectDst = targetWidth / targetHeight;
        if (aspectSrc > aspectDst) {
          baseWidth = targetWidth;
          baseHeight = targetWidth / aspectSrc;
        } else {
          baseHeight = targetHeight;
          baseWidth = targetHeight * aspectSrc;
        }
      }

      const zParallax = clip.is3DLayer ? 1 + world.zDepth * 0.002 : 1;
      const axOff = ((local.anchorX ?? 0.5) - 0.5) * targetWidth;
      const ayOff = ((local.anchorY ?? 0.5) - 0.5) * targetHeight;
      const rotXScale = clip.is3DLayer ? Math.cos((local.rotX * Math.PI) / 180) : 1;
      const rotYScale = clip.is3DLayer ? Math.cos((local.rotY * Math.PI) / 180) : 1;

      const localClipMatrix = buildLocalClipMatrix2D(
        (local.lx / 100) * targetWidth,
        (local.ly / 100) * targetHeight,
        local.rotation,
        local.scaleX * rotYScale,
        local.scaleY * rotXScale,
        axOff,
        ayOff
      );
      const composedLocal = multiplyMatrix2D(world.parentMatrix, localClipMatrix);
      const cameraMatrix: Matrix2D = [
        camScale,
        0,
        0,
        camScale,
        targetWidth * 0.5 + camPanX * zParallax,
        targetHeight * 0.5 + camPanY * zParallax,
      ];
      const finalMatrix = multiplyMatrix2D(cameraMatrix, composedLocal);
      const parentWorldMatrix = multiplyMatrix2D(cameraMatrix, world.parentMatrix);

      const hw = baseWidth * 0.5;
      const hh = baseHeight * 0.5;
      const tl = transformPoint2D(finalMatrix, -hw, -hh);
      const tr = transformPoint2D(finalMatrix, hw, -hh);
      const br = transformPoint2D(finalMatrix, hw, hh);
      const bl = transformPoint2D(finalMatrix, -hw, hh);
      const center = transformPoint2D(finalMatrix, 0, 0);
      const pivot = transformPoint2D(finalMatrix, axOff, ayOff);

      const cx = targetWidth * 0.5 + (world.x / 100) * targetWidth + camPanX * zParallax;
      const cy = targetHeight * 0.5 + (world.y / 100) * targetHeight + camPanY * zParallax;
      const sx = world.scaleX * camScale * rotYScale;
      const sy = world.scaleY * camScale * rotXScale;

      const xs = [tl.x, tr.x, br.x, bl.x];
      const ys = [tl.y, tr.y, br.y, bl.y];

      results.push({
        clip,
        cx,
        cy,
        pivotX: pivot.x,
        pivotY: pivot.y,
        centerX: center.x,
        centerY: center.y,
        baseWidth,
        baseHeight,
        scaledWidth: Math.hypot(tr.x - tl.x, tr.y - tl.y),
        scaledHeight: Math.hypot(bl.x - tl.x, bl.y - tl.y),
        rotationDeg: world.rotation,
        scaleX: sx,
        scaleY: sy,
        anchorX: local.anchorX ?? 0.5,
        anchorY: local.anchorY ?? 0.5,
        axOff,
        ayOff,
        camScale,
        matrix: finalMatrix,
        parentWorldMatrix,
        corners: [tl, tr, br, bl],
        minX: Math.min(...xs),
        maxX: Math.max(...xs),
        minY: Math.min(...ys),
        maxY: Math.max(...ys),
      });
    }
  }

  return results;
}

export function hitTestClipBounds(
  boundsList: ClipCanvasBounds[],
  px: number,
  py: number,
  paddingPx = 6
): ClipCanvasBounds | null {
  for (let i = boundsList.length - 1; i >= 0; i--) {
    const b = boundsList[i];
    const inv = invertMatrix2D(b.matrix);
    const pt = transformPoint2D(inv, px, py);
    const halfW = b.baseWidth * 0.5 + paddingPx / Math.max(0.1, Math.abs(b.scaleX));
    const halfH = b.baseHeight * 0.5 + paddingPx / Math.max(0.1, Math.abs(b.scaleY));
    if (Math.abs(pt.x) <= halfW && Math.abs(pt.y) <= halfH) {
      return b;
    }
  }
  return null;
}

function drawTextClip(
  ctx: CanvasRenderingContext2D,
  clip: TimelineClip,
  localTime: number,
  evalTime: number,
  targetWidth: number,
  targetHeight: number
) {
  const tp = clip.textProps!;
  const scaleFactor = targetWidth / 1920;
  const animatedFontSize = evaluateKeyframeProperty(
    clip.keyframes,
    'fontSize',
    evalTime,
    tp.fontSize
  );
  const fontPx = Math.round(animatedFontSize * scaleFactor);
  const weight = tp.fontWeight ?? 700;
  const trackingPx =
    evaluateKeyframeProperty(clip.keyframes, 'textTracking', evalTime, tp.letterSpacing ?? 0) *
    scaleFactor;
  const revealPct = tp.revealProgress ?? 100;

  let text = tp.text;
  let extraX = 0;
  let extraY = 0;
  let extraScale = 1;
  let extraRot = 0;
  let textAlpha = 1;
  let animTrackingAdd = 0;
  let rgbOffset = 0;
  let neonGlow = false;
  let fireTint = false;
  let smokeSoft = false;
  let liquidWave = false;
  let metallicFill = false;

  const fxSpeed = Math.max(0.2, tp.effectSpeed ?? 1);
  const fxInten = Math.max(0, (tp.effectIntensity ?? 100) / 100);
  const fxStrength = Math.max(0, (tp.animationStrength ?? 100) / 100);
  const fxDur = Math.max(0.2, tp.effectDuration ?? 1.0);
  const dir = tp.effectDirection || 'center';
  const tEff = localTime * fxSpeed;

  const pIn = Math.min(1, tEff / fxDur);
  const pOut = Math.min(1, Math.max(0, (clip.duration - localTime) / Math.max(0.25, fxDur * 0.7)));

  const dirVecX = dir === 'left' ? -1 : dir === 'right' ? 1 : 0;
  const dirVecY = dir === 'up' ? -1 : dir === 'down' ? 1 : 0;

  switch (tp.animation) {
    case 'fade-in':
      textAlpha = pIn;
      break;
    case 'fade-out':
      textAlpha = pOut;
      break;
    case 'fade-up':
      textAlpha = pIn;
      extraY = (1 - pIn) * (dirVecY !== 0 ? -dirVecY : 1) * 34 * scaleFactor * fxStrength;
      extraX = (1 - pIn) * -dirVecX * 34 * scaleFactor * fxStrength;
      break;
    case 'typewriter':
    case 'letter-reveal':
    case 'character-reveal': {
      const revealSpan = Math.max(0.35, Math.min(clip.duration, fxDur / fxSpeed));
      const prog = Math.min(1, localTime / revealSpan);
      const chars = Math.max(1, Math.ceil(prog * tp.text.length));
      text = tp.text.slice(0, chars);
      if (tp.animation === 'character-reveal') {
        textAlpha = Math.min(1, 0.35 + prog * 0.65);
      }
      break;
    }
    case 'word-reveal': {
      const words = tp.text.split(' ');
      const count = Math.max(1, Math.ceil(pIn * words.length));
      text = words.slice(0, count).join(' ');
      break;
    }
    case 'tracking-animation':
      animTrackingAdd = (1 - pIn) * 32 * scaleFactor * fxStrength;
      textAlpha = Math.min(1, pIn * 1.4);
      break;
    case 'text-shake':
      extraX = Math.sin(tEff * 52) * 8 * scaleFactor * fxInten * fxStrength;
      extraY = Math.cos(tEff * 66) * 6 * scaleFactor * fxInten * fxStrength;
      break;
    case 'text-bounce':
      extraY = -Math.abs(Math.sin(tEff * 5.2)) * 24 * scaleFactor * fxInten * fxStrength;
      break;
    case 'pop-up': {
      // Overshoot spring scale from 0 -> 1.15 -> 1.0
      const u = Math.min(1, tEff / Math.max(0.25, fxDur * 0.65));
      const c4 = (2 * Math.PI) / 3;
      const spring =
        u === 0
          ? 0
          : u === 1
          ? 1
          : Math.pow(2, -9 * u) * Math.sin((u * 10 - 0.75) * c4) + 1;
      extraScale = Math.max(0.05, spring * fxStrength + (1 - fxStrength));
      textAlpha = Math.min(1, u * 3);
      break;
    }
    case 'text-wave':
      liquidWave = true;
      break;
    case 'text-rotation':
      extraRot = ((1 - pIn) * -35 * Math.PI * fxStrength) / 180;
      textAlpha = pIn;
      break;
    case 'text-zoom':
    case 'kinetic-typography':
      extraScale = 1 + (1 - pIn) * 0.72 * fxStrength;
      textAlpha = Math.min(1, pIn * 1.5);
      break;
    case 'text-flip':
      ctx.scale(1, Math.max(0.08, pIn));
      textAlpha = pIn;
      break;
    case 'text-glitch': {
      const trig = Math.sin(tEff * 42);
      if (trig > 0.32) {
        extraX = Math.sin(tEff * 123) * 14 * scaleFactor * fxInten;
        rgbOffset = 8 * scaleFactor * fxInten;
      }
      break;
    }
    case 'rgb-text':
      rgbOffset = (4 + Math.sin(tEff * 6) * 3) * scaleFactor * fxInten;
      break;
    case 'velocity-text': {
      const velProgress = Math.min(1, tEff / Math.max(0.25, fxDur * 0.7));
      const eased = 1 - Math.pow(1 - velProgress, 4);
      const sx = dirVecX !== 0 ? dirVecX : -1;
      extraX = (1 - eased) * sx * targetWidth * 0.42 * fxStrength;
      extraY = (1 - eased) * dirVecY * targetHeight * 0.25 * fxStrength;
      rgbOffset = (1 - eased) * 10 * scaleFactor * fxInten;
      textAlpha = Math.min(1, velProgress * 2.4);
      break;
    }
    case 'distortion-text': {
      const skew = Math.sin(tEff * 5.4) * 0.24 * fxInten * fxStrength;
      ctx.transform(1, Math.sin(tEff * 3.1) * 0.04 * fxInten, skew, 1, 0, 0);
      liquidWave = true;
      break;
    }
    case 'neon-text':
      neonGlow = true;
      break;
    case 'fire-text':
      fireTint = true;
      break;
    case 'smoke-text':
      smokeSoft = true;
      break;
    case 'liquid-text':
      liquidWave = true;
      break;
    case 'metallic-text':
      metallicFill = true;
      break;
    case 'cinematic-title':
      animTrackingAdd = tEff * 2.4 * scaleFactor * fxStrength;
      textAlpha = Math.min(1, tEff / 0.8);
      break;
  }

  if (revealPct < 100) {
    const count = Math.max(0, Math.round((revealPct / 100) * text.length));
    text = text.slice(0, count);
  }

  ctx.save();
  ctx.globalAlpha *= Math.max(0, Math.min(1, textAlpha));
  ctx.translate(extraX, extraY);
  if (extraRot !== 0) ctx.rotate(extraRot);
  ctx.scale(extraScale, extraScale);
  ctx.font = `${weight} ${fontPx}px "${tp.fontFamily}", sans-serif`;
  ctx.textAlign = tp.align;
  ctx.textBaseline = 'middle';

  const lines = text.split('\n');
  const lineH = fontPx * (tp.lineHeight ?? 1.2);
  const totalH = lines.length * lineH;
  const maxWidth = Math.max(...lines.map((ln) => ctx.measureText(ln).width), 40);

  const padX = 24 * scaleFactor;
  const padY = 14 * scaleFactor;
  const boxW = maxWidth + padX * 2;
  const boxH = totalH + padY;

  const isCacheableStaticText =
    tp.animation === 'none' &&
    !tp.animatedGradient &&
    !liquidWave &&
    (!tp.pathMode || tp.pathMode === 'none') &&
    revealPct >= 100 &&
    rgbOffset === 0 &&
    typeof document !== 'undefined';

  let drawCtx: CanvasRenderingContext2D = ctx;
  let offscreenTextCanvas: HTMLCanvasElement | null = null;
  let cacheKey = '';

  if (isCacheableStaticText) {
    cacheKey = `txt|${tp.text}|${tp.fontFamily}|${fontPx}|${weight}|${tp.align}|${trackingPx.toFixed(2)}|${tp.lineHeight ?? 1.2}|${tp.color}|${tp.strokeColor}|${tp.strokeWidth}|${tp.outlineColor ?? ''}|${tp.outlineWidth ?? 0}|${tp.shadowColor}|${tp.shadowBlur ?? 0}|${tp.shadowOffsetX ?? 0}|${tp.shadowOffsetY ?? 0}|${tp.backgroundColor}|${tp.isSubtitle ? 1 : 0}|${tp.gradientEnabled ? `${tp.gradientStart}-${tp.gradientEnd}-${tp.gradientAngle ?? 90}` : '0'}|${tp.extrude3D ? tp.extrudeDepth ?? 8 : 0}|${scaleFactor.toFixed(4)}`;
    const cached = textBitmapCache.get(cacheKey);
    if (cached) {
      ctx.drawImage(cached, -cached.width * 0.5, -cached.height * 0.5);
      ctx.restore();
      void targetHeight;
      return;
    }

    const extraMargin = Math.ceil(
      ((tp.shadowBlur ?? 0) +
        Math.abs(tp.shadowOffsetX ?? 0) +
        Math.abs(tp.shadowOffsetY ?? 0) +
        (tp.strokeWidth ?? 0) * 2 +
        (tp.outlineWidth ?? 0) * 2 +
        (tp.extrude3D ? (tp.extrudeDepth ?? 8) * 2 : 0) +
        36) *
        Math.max(0.25, scaleFactor)
    );
    const alignPad = tp.align === 'center' ? 0 : Math.ceil(maxWidth);
    const cw = Math.max(4, Math.ceil(boxW + extraMargin * 2 + alignPad * 2));
    const ch = Math.max(4, Math.ceil(boxH + extraMargin * 2));
    if (cw <= 4096 && ch <= 2048) {
      offscreenTextCanvas = document.createElement('canvas');
      offscreenTextCanvas.width = cw;
      offscreenTextCanvas.height = ch;
      const octx = offscreenTextCanvas.getContext('2d');
      if (octx) {
        octx.save();
        octx.translate(cw * 0.5, ch * 0.5);
        octx.font = ctx.font;
        octx.textAlign = ctx.textAlign;
        octx.textBaseline = ctx.textBaseline;
        drawCtx = octx;
      } else {
        offscreenTextCanvas = null;
      }
    }
  }

  if (tp.isSubtitle || (tp.backgroundColor && tp.backgroundColor !== 'transparent')) {
    drawCtx.fillStyle = tp.isSubtitle ? 'rgba(9, 9, 11, 0.78)' : tp.backgroundColor;
    drawCtx.beginPath();
    drawCtx.roundRect(-boxW * 0.5, -boxH * 0.5, boxW, boxH, 6 * scaleFactor);
    drawCtx.fill();
  }

  const effectiveTracking = trackingPx + animTrackingAdd;
  const usePerTokenDraw =
    Math.abs(effectiveTracking) > 0.25 ||
    (tp.pathMode && tp.pathMode !== 'none') ||
    liquidWave ||
    tp.granularity === 'character';

  const renderFillStyle = (): string | CanvasGradient => {
    if (fireTint) {
      const fg = drawCtx.createLinearGradient(0, -fontPx * 0.5, 0, fontPx * 0.5);
      fg.addColorStop(0, '#FEF08A');
      fg.addColorStop(0.45, '#F97316');
      fg.addColorStop(1, '#E50914');
      return fg;
    }
    if (metallicFill) {
      const mg = drawCtx.createLinearGradient(0, -fontPx * 0.5, 0, fontPx * 0.5);
      mg.addColorStop(0, '#F8FAFC');
      mg.addColorStop(0.45, '#94A3B8');
      mg.addColorStop(0.55, '#1E293B');
      mg.addColorStop(1, '#E2E8F0');
      return mg;
    }
    if (tp.gradientEnabled) {
      const ang = ((tp.gradientAngle ?? 90) + (tp.animatedGradient ? localTime * 75 : 0)) * (Math.PI / 180);
      const r = maxWidth * 0.5;
      const gg = drawCtx.createLinearGradient(
        -Math.cos(ang) * r,
        -Math.sin(ang) * r,
        Math.cos(ang) * r,
        Math.sin(ang) * r
      );
      gg.addColorStop(0, tp.gradientStart || '#FFFFFF');
      gg.addColorStop(1, tp.gradientEnd || '#E50914');
      return gg;
    }
    return tp.color || '#FFFFFF';
  };

  if (neonGlow) {
    drawCtx.shadowColor = tp.strokeColor || '#E50914';
    drawCtx.shadowBlur = 24 * scaleFactor;
  } else if (smokeSoft) {
    drawCtx.shadowColor = 'rgba(255,255,255,0.45)';
    drawCtx.shadowBlur = 18 * scaleFactor;
  } else if (tp.shadowBlur && tp.shadowBlur > 0) {
    drawCtx.shadowColor = tp.shadowColor || 'rgba(0,0,0,0.8)';
    drawCtx.shadowBlur = tp.shadowBlur * scaleFactor;
    drawCtx.shadowOffsetX = (tp.shadowOffsetX ?? 0) * scaleFactor;
    drawCtx.shadowOffsetY = (tp.shadowOffsetY ?? 4) * scaleFactor;
  }

  lines.forEach((line, li) => {
    const ly = -totalH * 0.5 + lineH * (li + 0.5);

    if (rgbOffset > 0) {
      drawCtx.save();
      drawCtx.globalCompositeOperation = 'screen';
      drawCtx.fillStyle = 'rgba(255,0,55,0.85)';
      drawCtx.fillText(line, -rgbOffset, ly);
      drawCtx.fillStyle = 'rgba(0,220,255,0.85)';
      drawCtx.fillText(line, rgbOffset, ly);
      drawCtx.restore();
    }

    if (tp.extrude3D || tp.animation === '3d-extrude') {
      const depthMax = tp.extrudeDepth ?? 8;
      for (let d = depthMax; d >= 1; d--) {
        drawCtx.fillStyle = d > depthMax * 0.5 ? '#3A050A' : '#8A0812';
        drawCtx.fillText(line, d * 1.4 * scaleFactor, ly + d * 1.4 * scaleFactor);
      }
    }

    if (usePerTokenDraw) {
      const chars = Array.from(line);
      const charWidths = chars.map((c) => drawCtx.measureText(c).width);
      const totalLineW =
        charWidths.reduce((a, b) => a + b, 0) + Math.max(0, chars.length - 1) * effectiveTracking;
      let cursorX = tp.align === 'left' ? 0 : tp.align === 'right' ? -totalLineW : -totalLineW * 0.5;
      const curveAmt = (tp.pathCurvature ?? 35) * scaleFactor;

      chars.forEach((ch, ci) => {
        const cw = charWidths[ci];
        const charCenterX = cursorX + cw * 0.5;
        let cy = ly;
        if (liquidWave || tp.pathMode === 'wave') {
          cy += Math.sin(localTime * 4.5 + ci * 0.55) * (liquidWave ? 9 : curveAmt * 0.35) * scaleFactor;
        } else if (tp.pathMode === 'arc') {
          const norm = totalLineW > 0 ? charCenterX / (totalLineW * 0.5) : 0;
          cy += norm * norm * curveAmt;
        } else if (tp.pathMode === 'circle') {
          const ang = (ci / Math.max(1, chars.length)) * Math.PI * 2 - Math.PI / 2;
          const rad = Math.max(fontPx * 1.6, totalLineW / (Math.PI * 2));
          drawCtx.save();
          drawCtx.translate(Math.cos(ang) * rad, Math.sin(ang) * rad);
          drawCtx.rotate(ang + Math.PI / 2);
          drawCtx.fillStyle = renderFillStyle();
          drawCtx.fillText(ch, 0, 0);
          drawCtx.restore();
          cursorX += cw + effectiveTracking;
          return;
        }

        drawCtx.save();
        drawCtx.textAlign = 'center';
        if (tp.outlineWidth && tp.outlineWidth > 0) {
          drawCtx.strokeStyle = tp.outlineColor || '#000000';
          drawCtx.lineWidth = tp.outlineWidth * scaleFactor * 2;
          drawCtx.strokeText(ch, charCenterX, cy);
        }
        if (tp.strokeWidth > 0) {
          drawCtx.strokeStyle = tp.strokeColor || '#E50914';
          drawCtx.lineWidth = tp.strokeWidth * scaleFactor * 2;
          drawCtx.strokeText(ch, charCenterX, cy);
        }
        drawCtx.fillStyle = renderFillStyle();
        drawCtx.fillText(ch, charCenterX, cy);
        drawCtx.restore();

        cursorX += cw + effectiveTracking;
      });
    } else {
      if (tp.outlineWidth && tp.outlineWidth > 0) {
        drawCtx.strokeStyle = tp.outlineColor || '#000000';
        drawCtx.lineWidth = tp.outlineWidth * scaleFactor * 2;
        drawCtx.strokeText(line, 0, ly);
      }
      if (tp.strokeWidth > 0) {
        drawCtx.strokeStyle = tp.strokeColor || '#E50914';
        drawCtx.lineWidth = tp.strokeWidth * scaleFactor * 2;
        drawCtx.strokeText(line, 0, ly);
      }
      drawCtx.fillStyle = renderFillStyle();
      drawCtx.fillText(line, 0, ly);
    }
  });

  if (offscreenTextCanvas && drawCtx !== ctx) {
    drawCtx.restore();
    textBitmapCache.set(
      cacheKey,
      offscreenTextCanvas,
      offscreenTextCanvas.width * offscreenTextCanvas.height * 4
    );
    ctx.drawImage(
      offscreenTextCanvas,
      -offscreenTextCanvas.width * 0.5,
      -offscreenTextCanvas.height * 0.5
    );
  }

  ctx.restore();
  void targetHeight;
}

function draw3DPlaceholderLayer(
  ctx: CanvasRenderingContext2D,
  name: string,
  localTime: number,
  w: number,
  h: number
) {
  ctx.save();
  const radius = Math.min(w, h) * 0.16;
  ctx.strokeStyle = 'rgba(229, 9, 20, 0.85)';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + localTime * 0.9;
    const x = Math.cos(a) * radius;
    const y = Math.sin(a) * radius * 0.65;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.stroke();
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.font = `600 ${Math.round(w * 0.018)}px "Outfit", sans-serif`;
  ctx.textAlign = 'center';
  ctx.fillText(`3D LAYER · ${name}`, 0, radius * 0.9);
  ctx.restore();
}
