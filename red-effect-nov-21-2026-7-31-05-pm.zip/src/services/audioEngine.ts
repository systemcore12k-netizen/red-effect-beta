import { MediaAsset, StudioProject } from '../types/studio';

interface ActiveAudioSource {
  clipId: string;
  assetUrl: string;
  element: HTMLMediaElement;
  sourceNode: MediaElementAudioSourceNode;
  gainNode: GainNode;
  panNode: StereoPannerNode;
}

type AudioContextWithSink = AudioContext & {
  setSinkId?: (sinkId: string) => Promise<void>;
};

type MediaElementWithSink = HTMLMediaElement & {
  setSinkId?: (sinkId: string) => Promise<void>;
};

export interface AudioOutputDeviceInfo {
  deviceId: string;
  label: string;
}

export async function listAudioOutputDevices(): Promise<AudioOutputDeviceInfo[]> {
  if (!navigator.mediaDevices?.enumerateDevices) {
    return [{ deviceId: 'default', label: 'System Default Output' }];
  }
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const outputs = devices
      .filter((d) => d.kind === 'audiooutput')
      .map((d, idx) => ({
        deviceId: d.deviceId || 'default',
        label:
          d.label ||
          (d.deviceId === 'default'
            ? 'System Default Output'
            : d.deviceId === 'communications'
            ? 'Default Communications Device'
            : `Audio Output ${idx + 1}`),
      }));
    if (outputs.length === 0) {
      return [{ deviceId: 'default', label: 'System Default Speakers / Headphones' }];
    }
    return outputs;
  } catch {
    return [{ deviceId: 'default', label: 'System Default Speakers / Headphones' }];
  }
}

export class StudioAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private sources = new Map<string, ActiveAudioSource>();
  private dataArray = new Uint8Array(64);
  public masterVolume = 1;
  public masterMuted = false;
  public outputDeviceId = 'default';

  public ensureContext(sampleRate?: number) {
    if (!this.ctx) {
      const options: AudioContextOptions = {};
      if (sampleRate && [44100, 48000, 96000].includes(sampleRate)) {
        options.sampleRate = sampleRate;
      }
      this.ctx = new AudioContext(options);
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.masterMuted ? 0 : this.masterVolume;
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 128;
      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
      this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);

      if (this.outputDeviceId && this.outputDeviceId !== 'default') {
        void this.applySinkToContext(this.outputDeviceId);
      }
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  private async applySinkToContext(deviceId: string): Promise<boolean> {
    if (!this.ctx) return false;
    const sinkCtx = this.ctx as AudioContextWithSink;
    if (typeof sinkCtx.setSinkId === 'function') {
      try {
        await sinkCtx.setSinkId(deviceId);
        return true;
      } catch {
        // Fallback to per-element setSinkId below
      }
    }
    let applied = false;
    for (const entry of this.sources.values()) {
      const el = entry.element as MediaElementWithSink;
      if (typeof el.setSinkId === 'function') {
        try {
          await el.setSinkId(deviceId);
          applied = true;
        } catch {
          // Ignore individual element failure
        }
      }
    }
    return applied;
  }

  public async setOutputDevice(deviceId: string): Promise<{ supported: boolean }> {
    this.outputDeviceId = deviceId || 'default';
    this.ensureContext();
    const ok = await this.applySinkToContext(this.outputDeviceId);
    const hasApi =
      typeof (this.ctx as AudioContextWithSink)?.setSinkId === 'function' ||
      typeof (HTMLMediaElement.prototype as MediaElementWithSink).setSinkId === 'function';
    return { supported: ok || hasApi };
  }

  public setMasterVolume(vol: number) {
    this.masterVolume = Math.max(0, Math.min(2, vol));
    if (this.masterGain && this.ctx) {
      const target = this.masterMuted ? 0 : this.masterVolume;
      this.masterGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.015);
    }
  }

  public setMasterMuted(muted: boolean) {
    this.masterMuted = muted;
    if (this.masterGain && this.ctx) {
      const target = this.masterMuted ? 0 : this.masterVolume;
      this.masterGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.015);
    }
  }

  public syncPlayback(project: StudioProject, playheadTime: number, isPlaying: boolean) {
    if (!isPlaying) {
      this.pauseAll();
      return;
    }

    this.ensureContext(project.audioSampleRate);
    if (!this.ctx || !this.masterGain) return;

    const anySolo = project.tracks.some((t) => t.solo);
    const activeIds = new Set<string>();

    for (const clip of project.clips) {
      const asset = project.assets.find((a) => a.id === clip.assetId);
      if (!asset) continue;
      if (asset.type !== 'audio' && asset.type !== 'video') continue;
      if (asset.type === 'video' && asset.hasAudio === false) continue;
      if (playheadTime < clip.startTime || playheadTime > clip.startTime + clip.duration) continue;

      const track = project.tracks.find((t) => t.id === clip.trackId);
      if (!track || track.muted || clip.muted) continue;
      if (anySolo && !track.solo) continue;

      activeIds.add(clip.id);
      let entry = this.sources.get(clip.id);

      if (entry && entry.assetUrl !== asset.url) {
        entry.element.pause();
        try {
          entry.sourceNode.disconnect();
          entry.gainNode.disconnect();
          entry.panNode.disconnect();
        } catch {
          // Ignore cleanup errors
        }
        this.sources.delete(clip.id);
        entry = undefined;
      }

      if (!entry) {
        const el: HTMLMediaElement =
          asset.type === 'video' ? document.createElement('video') : new Audio();
        if (!asset.url.startsWith('blob:') && !asset.url.startsWith('data:')) {
          el.crossOrigin = 'anonymous';
        }
        el.preload = 'auto';
        el.muted = false;
        el.volume = 1;
        if (el instanceof HTMLVideoElement) {
          el.playsInline = true;
        }
        el.src = asset.url;

        const srcNode = this.ctx.createMediaElementSource(el);
        const gainNode = this.ctx.createGain();
        const panNode = this.ctx.createStereoPanner();
        srcNode.connect(gainNode);
        gainNode.connect(panNode);
        panNode.connect(this.masterGain);

        if (
          this.outputDeviceId !== 'default' &&
          typeof (this.ctx as AudioContextWithSink).setSinkId !== 'function'
        ) {
          const sinkEl = el as MediaElementWithSink;
          sinkEl.setSinkId?.(this.outputDeviceId).catch(() => {});
        }

        entry = {
          clipId: clip.id,
          assetUrl: asset.url,
          element: el,
          sourceNode: srcNode,
          gainNode,
          panNode,
        };
        this.sources.set(clip.id, entry);
      }

      const localTime = Math.max(0, playheadTime - clip.startTime);
      const rawAudioTime = clip.reverse
        ? Math.max(0, asset.duration - (clip.sourceOffset + localTime * clip.speed))
        : clip.sourceOffset + localTime * clip.speed;
      const maxDur = Number.isFinite(entry.element.duration) && entry.element.duration > 0
        ? entry.element.duration
        : asset.duration;
      const targetAudioTime = Math.max(0, Math.min(maxDur, rawAudioTime));

      if (Math.abs(entry.element.currentTime - targetAudioTime) > 0.075) {
        try {
          entry.element.currentTime = targetAudioTime;
        } catch {
          // Element may still be loading metadata
        }
      }

      const safeRate = Math.max(0.25, Math.min(4, clip.speed || 1));
      if (Math.abs(entry.element.playbackRate - safeRate) > 0.01) {
        entry.element.playbackRate = safeRate;
      }

      // Apply fade in / fade out envelope
      let env = 1;
      if (clip.fadeIn > 0 && localTime < clip.fadeIn) {
        env = Math.max(0.01, localTime / clip.fadeIn);
      }
      const remaining = clip.duration - localTime;
      if (clip.fadeOut > 0 && remaining < clip.fadeOut) {
        env = Math.min(env, Math.max(0.01, remaining / clip.fadeOut));
      }

      const gainVal = Math.max(0, clip.volume * track.volume * env);
      entry.gainNode.gain.setTargetAtTime(gainVal, this.ctx.currentTime, 0.015);
      entry.panNode.pan.setTargetAtTime(track.pan, this.ctx.currentTime, 0.015);

      if (entry.element.paused && targetAudioTime < maxDur - 0.03) {
        entry.element.play().catch(() => {});
      }
    }

    // Pause clips no longer under playhead
    for (const [id, entry] of this.sources.entries()) {
      if (!activeIds.has(id) && !entry.element.paused) {
        entry.element.pause();
      }
    }
  }

  public seekTo(project: StudioProject, playheadTime: number) {
    for (const clip of project.clips) {
      const entry = this.sources.get(clip.id);
      if (!entry) continue;
      const asset = project.assets.find((a) => a.id === clip.assetId);
      if (!asset) continue;
      const localTime = Math.max(0, playheadTime - clip.startTime);
      const rawAudioTime = clip.reverse
        ? Math.max(0, asset.duration - (clip.sourceOffset + localTime * clip.speed))
        : clip.sourceOffset + localTime * clip.speed;
      const maxDur =
        Number.isFinite(entry.element.duration) && entry.element.duration > 0
          ? entry.element.duration
          : asset.duration;
      const targetAudioTime = Math.max(0, Math.min(maxDur, rawAudioTime));
      try {
        if (Math.abs(entry.element.currentTime - targetAudioTime) > 0.025) {
          entry.element.currentTime = targetAudioTime;
        }
      } catch {
        // Ignore seek errors before metadata ready
      }
    }
  }

  public pauseAll() {
    for (const entry of this.sources.values()) {
      if (!entry.element.paused) {
        entry.element.pause();
      }
    }
  }

  public getPeakLevels(): { left: number; right: number } {
    if (!this.analyser || this.masterMuted) return { left: 0, right: 0 };
    this.analyser.getByteFrequencyData(this.dataArray);
    let sumL = 0;
    let sumR = 0;
    const half = Math.max(1, Math.floor(this.dataArray.length / 2));
    for (let i = 0; i < half; i++) {
      sumL += this.dataArray[i];
      sumR += this.dataArray[i + half] ?? this.dataArray[i];
    }
    return {
      left: Math.min(1, sumL / (half * 210)),
      right: Math.min(1, sumR / (half * 210)),
    };
  }

  public dispose() {
    this.pauseAll();
    for (const entry of this.sources.values()) {
      try {
        entry.sourceNode.disconnect();
        entry.gainNode.disconnect();
        entry.panNode.disconnect();
      } catch {
        // Ignore cleanup errors
      }
    }
    this.sources.clear();
    if (this.ctx) {
      this.ctx.close().catch(() => {});
      this.ctx = null;
    }
  }
}

export async function generateAudioWaveform(
  asset: MediaAsset
): Promise<{ peaks: number[]; hasAudio: boolean }> {
  try {
    const resp = await fetch(asset.url);
    const buf = await resp.arrayBuffer();
    const ctx = new AudioContext();
    const decoded = await ctx.decodeAudioData(buf);
    if (!decoded || decoded.numberOfChannels === 0 || decoded.length === 0) {
      await ctx.close();
      return { peaks: [], hasAudio: false };
    }
    const channel = decoded.getChannelData(0);
    const samples = 240;
    const blockSize = Math.max(1, Math.floor(channel.length / samples));
    const peaks: number[] = [];
    let energySum = 0;
    for (let i = 0; i < samples; i++) {
      let max = 0;
      const start = i * blockSize;
      const step = Math.max(1, Math.floor(blockSize / 32));
      for (let j = 0; j < blockSize; j += step) {
        const v = Math.abs(channel[start + j] || 0);
        if (v > max) max = v;
      }
      energySum += max;
      peaks.push(Math.round(Math.min(1, max) * 1000) / 1000);
    }
    await ctx.close();
    const hasAudio = energySum > 0.001;
    return { peaks: hasAudio ? peaks : [], hasAudio };
  } catch {
    if (asset.type === 'audio') {
      return {
        peaks: Array.from({ length: 120 }, (_, i) => 0.25 + Math.abs(Math.sin(i * 0.45)) * 0.6),
        hasAudio: true,
      };
    }
    return { peaks: [], hasAudio: false };
  }
}
