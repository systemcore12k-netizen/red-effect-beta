import {
  MediaAsset,
  NewProjectConfig,
  ShortcutMap,
  StudioProject,
  StudioSettings,
  TimelineClip,
  TimelineTrack,
  UiThemeSettings,
} from '../types/studio';

export const DEFAULT_SHORTCUTS: ShortcutMap = {
  newProject: 'Ctrl+N',
  openProject: 'Ctrl+O',
  saveProject: 'Ctrl+S',
  saveAs: 'Ctrl+Shift+S',
  importMedia: 'Ctrl+I',
  undo: 'Ctrl+Z',
  redo: 'Ctrl+Shift+Z',
  playPause: 'Space',
  cutTool: 'C',
  selectTool: 'V',
  textTool: 'T',
  keyPosition: 'P',
  keyScale: 'S',
  keyRotation: 'R',
  keyAnchor: 'A',
  keyOpacity: 'O',
  showAnimated: 'U',
  easyEase: 'F9',
  duplicateClip: 'Ctrl+D',
  deleteClip: 'Delete',
  renameClip: 'F2',
  exportVideo: 'Ctrl+M',
  copyClip: 'Ctrl+C',
  pasteClip: 'Ctrl+V',
  selectAll: 'Ctrl+A',
  addMarker: 'M',
};

export const DEFAULT_UI_THEME: UiThemeSettings = {
  surface: 'gray',
  accentPreset: 'gray',
  customAccentHex: '#71717A',
  uiScale: 'normal',
  borderRadius: 'rounded',
};

export const DEFAULT_SETTINGS: StudioSettings = {
  autoSaveIntervalSec: 30,
  proxyQuality: 'full',
  previewQuality: 'high',
  performanceMode: false,
  autoDownscalePreview: true,
  hoverPreviewEnabled: true,
  hardwareAcceleration: true,
  defaultFps: 30,
  defaultResolution: '1080p',
  audioOutputDeviceId: 'default',
  shortcuts: DEFAULT_SHORTCUTS,
  uiTheme: DEFAULT_UI_THEME,
};

export const DEFAULT_PROJECT_FOLDERS: string[] = [
  'Media/Videos',
  'Media/Images',
  'Media/Audio',
  'Graphics',
  'Text',
  'Effects',
  'Transitions',
  '3D Models',
  'Animations',
  'Exports',
  'Project Files',
];

export function createStarterAssets(): MediaAsset[] {
  const now = Date.now();
  return [
    {
      id: 'asset-cinema-street',
      name: 'Night_Rain_Street.jpg',
      type: 'image',
      mimeType: 'image/jpeg',
      url: '/src/assets/images/starter_cinema_street_1794826556326.jpg',
      duration: 6,
      width: 1920,
      height: 1080,
      folder: 'Media/Images',
      createdAt: now - 3000,
      isStarter: true,
    },
    {
      id: 'asset-car-sunset',
      name: 'Apex_Coupe_Twilight.jpg',
      type: 'image',
      mimeType: 'image/jpeg',
      url: '/src/assets/images/starter_car_sunset_1794826557013.jpg',
      duration: 6,
      width: 1920,
      height: 1080,
      folder: 'Media/Images',
      createdAt: now - 2000,
      isStarter: true,
    },
    {
      id: 'asset-portrait-subject',
      name: 'Director_Studio_Portrait.jpg',
      type: 'image',
      mimeType: 'image/jpeg',
      url: '/src/assets/images/starter_portrait_subject_1794826556163.jpg',
      duration: 5,
      width: 1600,
      height: 1200,
      folder: 'Media/Images',
      createdAt: now - 1000,
      isStarter: true,
    },
  ];
}

export function createDefaultTracks(): TimelineTrack[] {
  return [
    { id: 'T1', name: 'T1 · Titles', kind: 'text', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'amber', collapsed: true },
    { id: 'V2', name: 'V2 · Overlay', kind: 'video', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'violet', collapsed: true },
    { id: 'V1', name: 'V1 · Main', kind: 'video', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'sky', collapsed: true },
    { id: 'A1', name: 'A1 · Dialogue', kind: 'audio', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'emerald', collapsed: true },
    { id: 'A2', name: 'A2 · Music', kind: 'audio', muted: false, solo: false, locked: false, visible: true, volume: 0.85, pan: 0, color: 'emerald', collapsed: true },
  ];
}

export function createDefaultTransform(): TimelineClip['transform'] {
  return {
    x: 0,
    y: 0,
    scale: 1,
    rotation: 0,
    opacity: 1,
    anchorX: 0.5,
    anchorY: 0.5,
    zDepth: 0,
    rotX: 0,
    rotY: 0,
  };
}

export function createDefaultColorGrade(): TimelineClip['colorGrade'] {
  return {
    preset: 'none',
    exposure: 0,
    contrast: 0,
    saturation: 0,
    temperature: 0,
    tint: 0,
    vignette: 0,
    highlights: 0,
    shadows: 0,
    whites: 0,
    blacks: 0,
    vibrance: 0,
    rgbCurves: { master: 0, red: 0, green: 0, blue: 0 },
    colorBalance: {
      shadowsRed: 0,
      shadowsGreen: 0,
      shadowsBlue: 0,
      highlightsRed: 0,
      highlightsGreen: 0,
      highlightsBlue: 0,
    },
    lutIntensity: 85,
  };
}

export function createDefaultChromaKey(): TimelineClip['chromaKey'] {
  return {
    enabled: false,
    color: '#00ff00',
    tolerance: 35,
    softness: 15,
    spillSuppression: 50,
  };
}

export function createDefaultMask(): TimelineClip['mask'] {
  return {
    shape: 'none',
    centerX: 0.5,
    centerY: 0.5,
    radiusX: 0.42,
    radiusY: 0.42,
    feather: 18,
    inverted: false,
  };
}

export function createDefaultEffects(): TimelineClip['effects'] {
  return {
    blur: 0,
    glow: 0,
    glowColor: '#E11D48',
    stabilization: 0,
    filmGrain: 0,
    chromaticAberration: 0,
    particles: 'none',
    particleIntensity: 60,
  };
}

export function createDefaultMotionTrack(): TimelineClip['motionTrack'] {
  return {
    enabled: false,
    targetX: 0.5,
    targetY: 0.5,
    amplitudeX: 12,
    amplitudeY: 6,
    frequency: 1.5,
  };
}

export function createClipDefaults(
  partial: Partial<TimelineClip> & Pick<TimelineClip, 'id' | 'assetId' | 'trackId' | 'name' | 'type'>
): TimelineClip {
  const sanitizedPartial = Object.fromEntries(
    Object.entries(partial).filter(([, value]) => value !== undefined)
  ) as Partial<TimelineClip> & Pick<TimelineClip, 'id' | 'assetId' | 'trackId' | 'name' | 'type'>;

  const defColorGrade = createDefaultColorGrade();
  const defTransform = createDefaultTransform();
  const defChromaKey = createDefaultChromaKey();
  const defMask = createDefaultMask();
  const defEffects = createDefaultEffects();
  const defMotionTrack = createDefaultMotionTrack();

  return {
    startTime: 0,
    duration: 5,
    sourceOffset: 0,
    speed: 1,
    reverse: false,
    volume: 1,
    fadeIn: 0,
    fadeOut: 0,
    muted: false,
    visible: true,
    locked: false,
    blendMode: 'normal',
    is3DLayer: false,
    transitionIn: 'none',
    transitionInDuration: 0.6,
    transitionOut: 'none',
    transitionOutDuration: 0.6,
    keyframes: [],
    ...sanitizedPartial,
    transform: { ...defTransform, ...(sanitizedPartial.transform || {}) },
    colorGrade: {
      ...defColorGrade,
      ...(sanitizedPartial.colorGrade || {}),
      rgbCurves: sanitizedPartial.colorGrade?.rgbCurves
        ? { ...defColorGrade.rgbCurves!, ...sanitizedPartial.colorGrade.rgbCurves }
        : defColorGrade.rgbCurves,
      colorBalance: sanitizedPartial.colorGrade?.colorBalance
        ? { ...defColorGrade.colorBalance!, ...sanitizedPartial.colorGrade.colorBalance }
        : defColorGrade.colorBalance,
    },
    chromaKey: { ...defChromaKey, ...(sanitizedPartial.chromaKey || {}) },
    mask: { ...defMask, ...(sanitizedPartial.mask || {}) },
    effects: { ...defEffects, ...(sanitizedPartial.effects || {}) },
    motionTrack: { ...defMotionTrack, ...(sanitizedPartial.motionTrack || {}) },
  };
}

export function normalizeProject(project: StudioProject): StudioProject {
  return {
    ...project,
    markers: (project.markers ?? []).map((m) => {
      const timestampMs =
        typeof m.timestampMs === 'number' && Number.isFinite(m.timestampMs)
          ? Math.max(0, Math.round(m.timestampMs))
          : Math.max(0, Math.round((m.time || 0) * 1000));
      return {
        ...m,
        timestampMs,
        time: timestampMs / 1000,
      };
    }),
    clips: (project.clips || []).map((c) => createClipDefaults(c)),
  };
}

export function createStarterProject(name = 'Crimson_Showreel_01'): StudioProject {
  const assets = createStarterAssets();
  const tracks = createDefaultTracks();
  const now = Date.now();

  const clips: TimelineClip[] = [
    createClipDefaults({
      id: 'clip-1',
      assetId: 'asset-cinema-street',
      trackId: 'V1',
      name: 'Night_Rain_Street.jpg',
      type: 'image',
      startTime: 0,
      duration: 5,
      transitionIn: 'dip-to-black',
      transitionInDuration: 0.7,
      transitionOut: 'cross-dissolve',
      transitionOutDuration: 0.8,
      colorGrade: {
        preset: 'crimson-noir',
        exposure: 4,
        contrast: 16,
        saturation: 12,
        temperature: -8,
        tint: 6,
        vignette: 32,
        highlights: 10,
        shadows: -12,
      },
      effects: {
        blur: 0,
        glow: 12,
        glowColor: '#E11D48',
        stabilization: 0,
        filmGrain: 15,
        chromaticAberration: 2,
        particles: 'rain',
        particleIntensity: 45,
      },
      keyframes: [
        { id: 'kf-1', time: 0, property: 'scale', value: 1.0, easing: 'easeInOut' },
        { id: 'kf-2', time: 5, property: 'scale', value: 1.12, easing: 'easeInOut' },
      ],
    }),
    createClipDefaults({
      id: 'clip-2',
      assetId: 'asset-car-sunset',
      trackId: 'V1',
      name: 'Apex_Coupe_Twilight.jpg',
      type: 'image',
      startTime: 5,
      duration: 5,
      transitionIn: 'cross-dissolve',
      transitionInDuration: 0.8,
      transitionOut: 'dip-to-black',
      transitionOutDuration: 0.7,
      colorGrade: {
        preset: 'golden-hour',
        exposure: 6,
        contrast: 14,
        saturation: 18,
        temperature: 16,
        tint: 0,
        vignette: 26,
        highlights: 8,
        shadows: -8,
      },
      keyframes: [
        { id: 'kf-3', time: 0, property: 'scale', value: 1.06, easing: 'easeOut' },
        { id: 'kf-4', time: 5, property: 'scale', value: 1.0, easing: 'easeOut' },
      ],
    }),
    createClipDefaults({
      id: 'clip-title-1',
      assetId: 'text-asset',
      trackId: 'T1',
      name: 'Title · RED EFFECT',
      type: 'text',
      startTime: 0.4,
      duration: 4.2,
      textProps: {
        text: 'RED EFFECT STUDIO',
        fontFamily: 'Outfit',
        fontSize: 64,
        color: '#FFFFFF',
        strokeColor: '#E11D48',
        strokeWidth: 2,
        backgroundColor: 'transparent',
        animation: 'fade-up',
        isSubtitle: false,
        align: 'center',
      },
      transform: {
        x: 0,
        y: 28,
        scale: 1,
        rotation: 0,
        opacity: 1,
        anchorX: 0.5,
        anchorY: 0.5,
        zDepth: 0,
        rotX: 0,
        rotY: 0,
      },
    }),
  ];

  return {
    id: `proj-${now}`,
    name,
    location: 'Local Studio Workspace',
    width: 1920,
    height: 1080,
    fps: 30,
    aspectRatio: '16:9',
    videoFormat: 'mp4',
    audioSampleRate: 48000,
    backgroundColor: '#050507',
    defaultClipDuration: 5,
    createdAt: now,
    updatedAt: now,
    tracks,
    clips,
    markers: [
      {
        id: 'marker-intro',
        time: 0,
        label: 'Intro Beat',
        notes: 'Opening fade-in & rain ambience cue',
        color: 'rose',
      },
      {
        id: 'marker-cut',
        time: 5,
        label: 'Scene Cut',
        notes: 'Transition to twilight coupe shot',
        color: 'amber',
      },
    ],
    assets,
    folders: [...DEFAULT_PROJECT_FOLDERS],
    camera3D: {
      fov: 50,
      orbitX: 0,
      orbitY: 0,
      zoom: 1,
      dofBlur: 0,
    },
    snapEnabled: true,
    proxyQuality: 'full',
    previewQuality: 'high',
  };
}

export function createCustomProject(config: NewProjectConfig): StudioProject {
  const now = Date.now();
  const tracks: TimelineTrack[] = [
    {
      id: 'T1',
      name: 'T1 · Titles',
      kind: 'text',
      muted: false,
      solo: false,
      locked: false,
      visible: true,
      volume: 1,
      pan: 0,
      color: 'amber',
      collapsed: true,
    },
  ];

  const vCount = Math.max(1, Math.min(8, config.videoTrackCount || 2));
  for (let i = vCount; i >= 1; i--) {
    tracks.push({
      id: `V${i}`,
      name: i === 1 ? 'V1 · Main Video' : `V${i} · Overlay`,
      kind: 'video',
      muted: false,
      solo: false,
      locked: false,
      visible: true,
      volume: 1,
      pan: 0,
      color: i === 1 ? 'sky' : 'violet',
      collapsed: true,
    });
  }

  const aCount = Math.max(1, Math.min(8, config.audioTrackCount || 2));
  for (let i = 1; i <= aCount; i++) {
    tracks.push({
      id: `A${i}`,
      name: i === 1 ? 'A1 · Main Audio' : i === 2 ? 'A2 · Music' : `A${i} · Audio`,
      kind: 'audio',
      muted: false,
      solo: false,
      locked: false,
      visible: true,
      volume: i === 2 ? 0.85 : 1,
      pan: 0,
      color: 'emerald',
      collapsed: true,
    });
  }

  return {
    id: `proj-${now}`,
    name: config.name.trim() || 'Untitled_Project',
    location: config.location.trim() || 'Local Studio Workspace',
    width: Math.max(256, Math.round(config.width)),
    height: Math.max(256, Math.round(config.height)),
    fps: config.fps,
    aspectRatio: config.aspectRatio,
    videoFormat: config.videoFormat,
    audioSampleRate: config.audioSampleRate,
    backgroundColor: config.backgroundColor || '#050507',
    defaultClipDuration: config.defaultClipDuration || 5,
    createdAt: now,
    updatedAt: now,
    tracks,
    clips: [],
    markers: [],
    assets: [],
    folders: [...DEFAULT_PROJECT_FOLDERS],
    camera3D: {
      fov: 50,
      orbitX: 0,
      orbitY: 0,
      zoom: 1,
      dofBlur: 0,
    },
    snapEnabled: config.snapEnabled,
    proxyQuality: 'full',
    previewQuality: 'high',
  };
}

// IndexedDB Persistence
const DB_NAME = 'redeffect_studio_db';
const DB_VERSION = 1;
const STORE_PROJECTS = 'projects';
const STORE_SETTINGS = 'settings';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
        db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveProjectToDB(project: StudioProject): Promise<void> {
  const db = await openDB();
  // Strip transient blob URLs if needed? Blob URLs stay valid within session;
  // for starter assets & data URLs they persist permanently.
  const tx = db.transaction(STORE_PROJECTS, 'readwrite');
  const store = tx.objectStore(STORE_PROJECTS);
  store.put({ ...project, updatedAt: Date.now() });
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function loadAllProjectsFromDB(): Promise<StudioProject[]> {
  const db = await openDB();
  const tx = db.transaction(STORE_PROJECTS, 'readonly');
  const store = tx.objectStore(STORE_PROJECTS);
  const req = store.getAll();
  return new Promise((resolve, reject) => {
    req.onsuccess = () => {
      const list = ((req.result as StudioProject[]) || []).map((p) => normalizeProject(p));
      list.sort((a, b) => b.updatedAt - a.updatedAt);
      resolve(list);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function deleteProjectFromDB(projectId: string): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(STORE_PROJECTS, 'readwrite');
  tx.objectStore(STORE_PROJECTS).delete(projectId);
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function saveSettingsToDB(settings: StudioSettings): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(STORE_SETTINGS, 'readwrite');
  tx.objectStore(STORE_SETTINGS).put({ key: 'studio_settings', value: settings });
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function loadSettingsFromDB(): Promise<StudioSettings> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_SETTINGS, 'readonly');
    const req = tx.objectStore(STORE_SETTINGS).get('studio_settings');
    return await new Promise((resolve) => {
      req.onsuccess = () => {
        if (req.result?.value) {
          resolve({
            ...DEFAULT_SETTINGS,
            ...req.result.value,
            shortcuts: {
              ...DEFAULT_SHORTCUTS,
              ...(req.result.value.shortcuts || {}),
            },
            uiTheme: {
              ...DEFAULT_UI_THEME,
              ...(req.result.value.uiTheme || {}),
            },
          });
        } else {
          resolve(DEFAULT_SETTINGS);
        }
      };
      req.onerror = () => resolve(DEFAULT_SETTINGS);
    });
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export interface SavedFileResult {
  fileName: string;
  usedNativeDialog: boolean;
  previewUrl: string;
  sizeBytes: number;
  cancelled?: boolean;
}

type SaveFilePickerFn = (options?: {
  suggestedName?: string;
  types?: Array<{ description?: string; accept: Record<string, string[]> }>;
}) => Promise<{
  name: string;
  createWritable: () => Promise<{
    write: (data: Blob) => Promise<void>;
    close: () => Promise<void>;
  }>;
}>;

type OpenFilePickerFn = (options?: {
  multiple?: boolean;
  types?: Array<{ description?: string; accept: Record<string, string[]> }>;
}) => Promise<Array<{ getFile: () => Promise<File> }>>;

export async function saveBlobWithWindowsDialog(
  blob: Blob,
  suggestedName: string,
  mimeAccept: Record<string, string[]>,
  description: string
): Promise<SavedFileResult> {
  const previewUrl = URL.createObjectURL(blob);
  const picker = (window as unknown as { showSaveFilePicker?: SaveFilePickerFn }).showSaveFilePicker;

  if (picker) {
    try {
      const handle = await picker({
        suggestedName,
        types: [{ description, accept: mimeAccept }],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return {
        fileName: handle.name || suggestedName,
        usedNativeDialog: true,
        previewUrl,
        sizeBytes: blob.size,
      };
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        URL.revokeObjectURL(previewUrl);
        return {
          fileName: suggestedName,
          usedNativeDialog: true,
          previewUrl: '',
          sizeBytes: 0,
          cancelled: true,
        };
      }
      // Fallback if iframe blocks showSaveFilePicker with SecurityError
    }
  }

  // Fallback standard browser save download
  const a = document.createElement('a');
  a.href = previewUrl;
  a.download = suggestedName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  return {
    fileName: suggestedName,
    usedNativeDialog: false,
    previewUrl,
    sizeBytes: blob.size,
  };
}

export async function openProjectFileFromDisk(): Promise<StudioProject | null> {
  const picker = (window as unknown as { showOpenFilePicker?: OpenFilePickerFn }).showOpenFilePicker;
  if (picker) {
    try {
      const [handle] = await picker({
        multiple: false,
        types: [
          {
            description: 'RED EFFECT Project (.redeffect.json)',
            accept: { 'application/json': ['.json', '.redeffect'] },
          },
        ],
      });
      if (!handle) return null;
      const file = await handle.getFile();
      const text = await file.text();
      return normalizeProject(JSON.parse(text) as StudioProject);
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        return null;
      }
    }
  }

  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,.redeffect';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return resolve(null);
      try {
        const text = await file.text();
        resolve(normalizeProject(JSON.parse(text) as StudioProject));
      } catch {
        resolve(null);
      }
    };
    input.click();
  });
}

export async function pickWindowsDirectoryLabel(): Promise<string | null> {
  const picker = (
    window as unknown as {
      showDirectoryPicker?: () => Promise<{ name: string }>;
    }
  ).showDirectoryPicker;
  if (!picker) return null;
  try {
    const dirHandle = await picker();
    return dirHandle?.name || null;
  } catch {
    return null;
  }
}

export async function exportProjectFileToDisk(project: StudioProject): Promise<SavedFileResult> {
  const json = JSON.stringify(project, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const safeName = `${project.name.replace(/[^a-zA-Z0-9_-]/g, '_')}.redeffect.json`;
  return saveBlobWithWindowsDialog(
    blob,
    safeName,
    { 'application/json': ['.json'] },
    'RED EFFECT Project File'
  );
}
