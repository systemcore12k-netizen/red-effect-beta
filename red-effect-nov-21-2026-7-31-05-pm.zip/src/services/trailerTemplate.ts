import { createEffectInstance, getDefaultTransitionSettings } from './effectsCatalog';
import { createClipDefaults, DEFAULT_PROJECT_FOLDERS } from './projectStorage';
import {
  MediaAsset,
  StudioProject,
  TextProperties,
  TimelineClip,
  TimelineMarker,
  TimelineTrack,
} from '../types/studio';
import { EffectInstance, ShapeProperties, TextAnimationEffect } from '../types/effects';

export interface TrailerSectionText {
  id: string;
  label: string;
  timeRange: string;
  startTime: number;
  endTime: number;
  mainText: string;
  subText: string;
}

export interface TrailerTemplateCustomization {
  templateName: string;
  fontFamily: string;
  primaryColor: string;
  accentColor: string;
  shakeStrength: number; // 0.2 to 2.0 (1 = default)
  effectIntensity: number; // 0.2 to 2.0 (1 = default)
  animationSpeed: number; // 0.5 to 2.0 (1 = default)
  customMusicAsset?: MediaAsset | null;
  sections: TrailerSectionText[];
}

export interface SavedCustomTemplate {
  id: string;
  name: string;
  category: string;
  duration: number;
  aspectRatio: '16:9';
  width: number;
  height: number;
  fps: number;
  createdAt: number;
  customization: TrailerTemplateCustomization;
}

export const CUSTOM_TEMPLATES_STORAGE_KEY = 'redeffect_custom_templates_v1';

export const RED_REBELLION_META = {
  id: 'tpl-red-rebellion',
  name: 'RED REBELLION',
  category: '2D Typography',
  duration: 20,
  aspectRatio: '16:9' as const,
  width: 1920,
  height: 1080,
  fps: 60,
  description:
    '20-second 12-layer dark red cinematic 2D typography trailer with beat-synced camera shakes, RGB glitches, red smoke & embers, and synthesized trailer audio.',
};

export function createDefaultRedRebellionCustomization(): TrailerTemplateCustomization {
  return {
    templateName: 'RED REBELLION',
    fontFamily: 'Outfit',
    primaryColor: '#FFFFFF',
    accentColor: '#E50914',
    shakeStrength: 1,
    effectIntensity: 1,
    animationSpeed: 1,
    customMusicAsset: null,
    sections: [
      {
        id: 'sec-intro',
        label: 'INTRO',
        timeRange: '00:00 – 00:03',
        startTime: 0,
        endTime: 3,
        mainText: 'THE WORLD IS FALLING',
        subText: 'CHAPTER 01 // THE COLLAPSE',
      },
      {
        id: 'sec-impact',
        label: 'IMPACT',
        timeRange: '00:03 – 00:06',
        startTime: 3,
        endTime: 6,
        mainText: 'NO MERCY',
        subText: 'ZERO HESITATION',
      },
      {
        id: 'sec-chaos',
        label: 'CHAOS',
        timeRange: '00:06 – 00:09',
        startTime: 6,
        endTime: 9,
        mainText: 'NO TURNING BACK',
        subText: 'SYSTEM OVERRIDE',
      },
      {
        id: 'sec-intense',
        label: 'INTENSE SECTION',
        timeRange: '00:09 – 00:12',
        startTime: 9,
        endTime: 12,
        mainText: 'RISE FROM THE ASHES',
        subText: 'UNLEASH THE STORM',
      },
      {
        id: 'sec-war',
        label: 'MAIN IMPACT',
        timeRange: '00:12 – 00:15',
        startTime: 12,
        endTime: 15,
        mainText: 'THIS IS WAR',
        subText: 'FINAL RECKONING',
      },
      {
        id: 'sec-buildup',
        label: 'FINAL BUILDUP',
        timeRange: '00:15 – 00:18',
        startTime: 15,
        endTime: 18,
        mainText: 'THE TIME IS NOW',
        subText: 'BRACE FOR IMPACT',
      },
      {
        id: 'sec-title',
        label: 'FINAL TITLE',
        timeRange: '00:18 – 00:20',
        startTime: 18,
        endTime: 20,
        mainText: 'RED REBELLION',
        subText: 'COMING SOON',
      },
    ],
  };
}

// =========================================================================
// Procedural Royalty-Free WAV Audio Synthesis (Persists cleanly in IndexedDB)
// =========================================================================

function encodeFloatSamplesToWavDataUrl(samples: Float32Array, sampleRate: number): string {
  const numSamples = samples.length;
  const bytesPerSample = 2;
  const dataSize = numSamples * bytesPerSample;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeAscii = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeAscii(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeAscii(8, 'WAVE');
  writeAscii(12, 'fmt ');
  view.setUint32(16, 16, true); // PCM chunk size
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, 1, true); // mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * bytesPerSample, true);
  view.setUint16(32, bytesPerSample, true);
  view.setUint16(34, 16, true); // 16-bit
  writeAscii(36, 'data');
  view.setUint32(40, dataSize, true);

  let pos = 44;
  for (let i = 0; i < numSamples; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(pos, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    pos += 2;
  }

  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }

  if (typeof btoa === 'function') {
    return `data:audio/wav;base64,${btoa(binary)}`;
  }
  return `data:audio/wav;base64,${Buffer.from(bytes).toString('base64')}`;
}

function computePeaksFromSamples(samples: Float32Array, barCount = 96): number[] {
  const peaks: number[] = [];
  const blockSize = Math.max(1, Math.floor(samples.length / barCount));
  for (let i = 0; i < barCount; i++) {
    const start = i * blockSize;
    const end = Math.min(samples.length, start + blockSize);
    let maxVal = 0;
    for (let j = start; j < end; j += 4) {
      const a = Math.abs(samples[j]);
      if (a > maxVal) maxVal = a;
    }
    peaks.push(Math.max(0.08, Math.min(1, Number(maxVal.toFixed(3)))));
  }
  return peaks;
}

let cachedMusicStem: { url: string; peaks: number[] } | null = null;
let cachedSfxStem: { url: string; peaks: number[] } | null = null;

export function generateTrailerMusicStem(): { url: string; peaks: number[] } {
  if (cachedMusicStem) return cachedMusicStem;
  const sampleRate = 16000;
  const duration = 20;
  const total = sampleRate * duration;
  const out = new Float32Array(total);
  const beatTimes = [3, 6, 9, 12, 15, 18];

  for (let i = 0; i < total; i++) {
    const t = i / sampleRate;
    let val = 0;

    // Deep dark D-minor trailer drone (55 Hz + 110 Hz saw-sub)
    const droneEnv = t < 18 ? 0.24 : Math.max(0, 1 - (t - 18) / 2.0) * 0.28;
    const freq = t >= 12 && t < 18 ? 65.41 : 55.0; // A1 -> C2 lift at Main Impact
    val += Math.sin(2 * Math.PI * freq * t) * droneEnv;
    val += Math.sin(2 * Math.PI * freq * 2 * t) * droneEnv * 0.35;

    // 120 BPM driving industrial pulse starting at 3.0s until 17.8s
    if (t >= 3 && t < 18) {
      const beatPhase = (t * 2) % 1; // 2 beats/sec = 120 BPM
      const kickEnv = Math.exp(-beatPhase * 11);
      const kickFreq = 125 * Math.exp(-beatPhase * 14) + 42;
      val += Math.sin(2 * Math.PI * kickFreq * beatPhase) * kickEnv * 0.42;

      // Tension eighth-note dark bass arpeggio from 6s to 18s
      if (t >= 6) {
        const eighth = (t * 4) % 1;
        const arpEnv = Math.exp(-eighth * 7);
        const notes = [110, 130.81, 146.83, 164.81];
        const nIdx = Math.floor(t * 4) % notes.length;
        val += Math.sin(2 * Math.PI * notes[nIdx] * t) * arpEnv * 0.18;
      }
    }

    // Section Drop Swells
    for (const bt of beatTimes) {
      const dt = t - bt;
      if (dt >= 0 && dt < 1.2) {
        const dropEnv = Math.exp(-dt * 4.5);
        val += Math.sin(2 * Math.PI * (78 * Math.exp(-dt * 2) + 34) * dt) * dropEnv * 0.35;
      }
    }

    // Clean fade-in (0.3s) & final fade-out (19.2s -> 20s)
    const fadeIn = Math.min(1, t / 0.35);
    const fadeOut = t > 19.2 ? Math.max(0, (20 - t) / 0.8) : 1;
    out[i] = Math.tanh(val * 1.15) * 0.82 * fadeIn * fadeOut;
  }

  cachedMusicStem = {
    url: encodeFloatSamplesToWavDataUrl(out, sampleRate),
    peaks: computePeaksFromSamples(out),
  };
  return cachedMusicStem;
}

export function generateTrailerSfxStem(): { url: string; peaks: number[] } {
  if (cachedSfxStem) return cachedSfxStem;
  const sampleRate = 16000;
  const duration = 20;
  const total = sampleRate * duration;
  const out = new Float32Array(total);
  const hitTimes = [0.02, 3.0, 6.0, 9.0, 12.0, 15.0, 18.0];
  const riserEnds = [3.0, 12.0, 18.0];

  let noiseSeed = 1337;
  const randNoise = () => {
    noiseSeed = (noiseSeed * 1664525 + 1013904223) >>> 0;
    return (noiseSeed / 0xffffffff) * 2 - 1;
  };

  for (let i = 0; i < total; i++) {
    const t = i / sampleRate;
    let val = 0;
    const n = randNoise();

    // Cinematic sub-bass impact hits on major beat markers
    for (const ht of hitTimes) {
      const dt = t - ht;
      if (dt >= 0 && dt < 1.35) {
        const subEnv = Math.exp(-dt * 3.8);
        const subFreq = 160 * Math.exp(-dt * 12) + 36;
        val += Math.sin(2 * Math.PI * subFreq * dt) * subEnv * 0.65;
        // Transient metallic crack
        if (dt < 0.14) {
          val += n * Math.exp(-dt * 32) * 0.45;
        }
      }
    }

    // Metallic risers leading up to key drops
    for (const rt of riserEnds) {
      const pre = rt - t;
      if (pre > 0 && pre <= 0.85) {
        const prog = 1 - pre / 0.85;
        const riserFreq = 180 + prog * 1100;
        val += (Math.sin(2 * Math.PI * riserFreq * t) * 0.18 + n * 0.22) * prog * prog;
      }
    }

    // Glitch zaps at 6.0s and 15.0s..17.5s
    if ((t >= 6.0 && t < 6.45) || (t >= 15.0 && t < 17.6 && ((t * 4) % 1) < 0.12)) {
      val += n * 0.22 + Math.sin(2 * Math.PI * 840 * t) * 0.12;
    }

    const fadeOut = t > 19.3 ? Math.max(0, (20 - t) / 0.7) : 1;
    out[i] = Math.tanh(val) * 0.85 * fadeOut;
  }

  cachedSfxStem = {
    url: encodeFloatSamplesToWavDataUrl(out, sampleRate),
    peaks: computePeaksFromSamples(out),
  };
  return cachedSfxStem;
}

export type BuiltinAudioKind = 'trailer-beat' | 'sub-impact' | 'riser-whoosh' | 'glitch-pulse';

export function createBuiltinAudioAsset(kind: BuiltinAudioKind): MediaAsset {
  const sampleRate = 16000;
  const dur = kind === 'trailer-beat' ? 8 : kind === 'sub-impact' ? 2 : 3;
  const len = sampleRate * dur;
  const out = new Float32Array(len);
  let seed = 4242;
  const rnd = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return (seed / 0xffffffff) * 2 - 1;
  };

  for (let i = 0; i < len; i++) {
    const t = i / sampleRate;
    let v = 0;
    if (kind === 'trailer-beat') {
      const p = (t * 2) % 1;
      v = Math.sin(2 * Math.PI * (120 * Math.exp(-p * 12) + 45) * p) * Math.exp(-p * 9) * 0.6;
      v += Math.sin(2 * Math.PI * 55 * t) * 0.2;
    } else if (kind === 'sub-impact') {
      v =
        Math.sin(2 * Math.PI * (180 * Math.exp(-t * 10) + 36) * t) * Math.exp(-t * 3.5) * 0.8 +
        rnd() * Math.exp(-t * 24) * 0.4;
    } else if (kind === 'riser-whoosh') {
      const prog = t / dur;
      v = (rnd() * 0.4 + Math.sin(2 * Math.PI * (120 + prog * 950) * t) * 0.3) * Math.pow(prog, 1.5);
    } else {
      const gate = ((t * 8) % 1) < 0.35 ? 1 : 0.1;
      v = (rnd() * 0.35 + Math.sin(2 * Math.PI * 440 * t) * 0.25) * gate * Math.exp(-t * 0.8);
    }
    out[i] = Math.tanh(v) * 0.85;
  }

  const labels: Record<BuiltinAudioKind, string> = {
    'trailer-beat': 'Crimson_Trailer_Pulse_120BPM.wav',
    'sub-impact': 'Cinematic_Sub_Boom.wav',
    'riser-whoosh': 'Tension_Riser_Whoosh.wav',
    'glitch-pulse': 'Digital_Glitch_Burst.wav',
  };

  return {
    id: `asset-builtin-${kind}-${Date.now()}`,
    name: labels[kind],
    type: 'audio',
    mimeType: 'audio/wav',
    url: encodeFloatSamplesToWavDataUrl(out, sampleRate),
    duration: dur,
    folder: 'Media/Audio',
    createdAt: Date.now(),
    hasAudio: true,
    waveformPeaks: computePeaksFromSamples(out, 48),
  };
}

// =========================================================================
// Helper Builders for FX Stack & Clips
// =========================================================================

function makeFx(type: string, paramOverrides: Record<string, number | string | boolean>): EffectInstance {
  const base = createEffectInstance(type);
  if (base) {
    return {
      ...base,
      params: { ...base.params, ...paramOverrides },
    };
  }
  return {
    id: `fx-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    type,
    name: type,
    category: 'glitch',
    enabled: true,
    blendMode: 'normal',
    params: paramOverrides,
  };
}

function makeTextClip(opts: {
  id: string;
  trackId: string;
  name: string;
  text: string;
  startTime: number;
  duration: number;
  fontFamily: string;
  fontSize: number;
  color: string;
  accentColor: string;
  y?: number;
  letterSpacing?: number;
  extrude3D?: boolean;
  animation: TextAnimationEffect;
  effectSpeed?: number;
  effectIntensity?: number;
  keyframes?: TimelineClip['keyframes'];
  transitionIn?: TimelineClip['transitionIn'];
  transitionOut?: TimelineClip['transitionOut'];
  mask?: Partial<TimelineClip['mask']>;
}): TimelineClip {
  const tp: TextProperties = {
    text: opts.text,
    fontFamily: opts.fontFamily,
    fontSize: opts.fontSize,
    fontWeight: 900,
    letterSpacing: opts.letterSpacing ?? 6,
    lineHeight: 1.05,
    color: opts.color,
    strokeColor: opts.accentColor,
    strokeWidth: opts.fontSize >= 80 ? 3 : 1,
    shadowColor: opts.accentColor,
    shadowBlur: opts.fontSize >= 80 ? 28 : 14,
    shadowOffsetX: 0,
    shadowOffsetY: 4,
    extrude3D: Boolean(opts.extrude3D),
    extrudeDepth: opts.extrude3D ? 10 : 0,
    granularity: 'character',
    pathMode: 'none',
    revealProgress: 100,
    backgroundColor: 'transparent',
    animation: opts.animation,
    effectSpeed: opts.effectSpeed ?? 1,
    effectIntensity: opts.effectIntensity ?? 110,
    effectDuration: Math.min(1.4, opts.duration * 0.65),
    effectDirection: 'center',
    animationStrength: 115,
    isSubtitle: opts.fontSize < 45,
    align: 'center',
  };

  return createClipDefaults({
    id: opts.id,
    assetId: 'text-asset',
    trackId: opts.trackId,
    name: opts.name,
    type: 'text',
    startTime: opts.startTime,
    duration: opts.duration,
    labelColor: opts.fontSize >= 70 ? 'amber' : 'rose',
    transitionIn: opts.transitionIn ?? 'none',
    transitionInDuration: 0.35,
    transitionInConfig: getDefaultTransitionSettings(opts.transitionIn ?? 'none'),
    transitionOut: opts.transitionOut ?? 'none',
    transitionOutDuration: 0.3,
    transitionOutConfig: getDefaultTransitionSettings(opts.transitionOut ?? 'none'),
    transform: {
      x: 0,
      y: opts.y ?? 0,
      scale: 1,
      rotation: 0,
      opacity: 1,
      anchorX: 0.5,
      anchorY: 0.5,
      zDepth: 0,
      rotX: 0,
      rotY: 0,
    },
    keyframes: opts.keyframes ?? [],
    textProps: tp,
    mask: {
      shape: 'none',
      centerX: 0.5,
      centerY: 0.5,
      radiusX: 0.48,
      radiusY: 0.48,
      feather: 14,
      inverted: false,
      ...(opts.mask || {}),
    },
  });
}

// =========================================================================
// Main RED REBELLION 20-Second 12-Layer Project Generator
// =========================================================================

export function buildRedRebellionProject(
  custom?: Partial<TrailerTemplateCustomization>
): StudioProject {
  const defaults = createDefaultRedRebellionCustomization();
  const cfg: TrailerTemplateCustomization = {
    ...defaults,
    ...custom,
    sections: custom?.sections?.length === 7 ? custom.sections : defaults.sections,
  };

  const now = Date.now();
  const shakeM = Math.max(0.1, cfg.shakeStrength);
  const fxM = Math.max(0.1, cfg.effectIntensity);
  const spdM = Math.max(0.3, cfg.animationSpeed);
  const clampPct = (v: number, max = 100) => Math.max(0, Math.min(max, Math.round(v)));

  const musicStem = generateTrailerMusicStem();
  const sfxStem = generateTrailerSfxStem();

  const musicAsset: MediaAsset = cfg.customMusicAsset
    ? cfg.customMusicAsset
    : {
        id: 'asset-rr-music',
        name: 'RED_REBELLION_Score_120BPM.wav',
        type: 'audio',
        mimeType: 'audio/wav',
        url: musicStem.url,
        duration: 20,
        folder: 'Media/Audio',
        createdAt: now,
        hasAudio: true,
        waveformPeaks: musicStem.peaks,
        isStarter: true,
      };

  const sfxAsset: MediaAsset = {
    id: 'asset-rr-sfx',
    name: 'RED_REBELLION_Impacts_SFX.wav',
    type: 'audio',
    mimeType: 'audio/wav',
    url: sfxStem.url,
    duration: 20,
    folder: 'Media/Audio',
    createdAt: now,
    hasAudio: true,
    waveformPeaks: sfxStem.peaks,
    isStarter: true,
  };

  // Exact 12-Layer Architecture (Top-to-bottom in Timeline = Composite order Bottom-to-Top)
  const tracks: TimelineTrack[] = [
    { id: 'L10_GRAIN', name: 'Film Grain', kind: 'fx', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'amber', collapsed: true },
    { id: 'L09_CC', name: 'Cinematic CC', kind: 'fx', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'rose', collapsed: true },
    { id: 'L08_SHAKE', name: 'Shake Effects', kind: 'fx', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'rose', collapsed: true },
    { id: 'L07_GLITCH', name: 'Glitch Effects', kind: 'fx', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'sky', collapsed: true },
    { id: 'L06_LIGHT', name: 'Light Effects', kind: 'shape', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'amber', collapsed: true },
    { id: 'L05_SUBTXT', name: 'Secondary Typography', kind: 'text', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'amber', collapsed: true },
    { id: 'L04_MAINTXT', name: 'Main Typography', kind: 'text', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'rose', collapsed: true },
    { id: 'L03_PARTICLES', name: 'Red Particles', kind: 'fx', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'rose', collapsed: true },
    { id: 'L02_SMOKE', name: 'Red Smoke', kind: 'fx', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'violet', collapsed: true },
    { id: 'L01_BG', name: 'Background', kind: 'shape', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0, color: 'sky', collapsed: true },
    { id: 'L11_MUSIC', name: 'Music', kind: 'audio', muted: false, solo: false, locked: false, visible: true, volume: 0.9, pan: 0, color: 'emerald', collapsed: true },
    { id: 'L12_SFX', name: 'Sound Effects', kind: 'audio', muted: false, solo: false, locked: false, visible: true, volume: 1.0, pan: 0, color: 'emerald', collapsed: true },
  ];

  const [s1, s2, s3, s4, s5, s6, s7] = cfg.sections;
  const clips: TimelineClip[] = [
    // ==================== LAYER 1: BACKGROUND ====================
    createClipDefaults({
      id: 'rr-bg-main',
      assetId: 'shape-asset',
      trackId: 'L01_BG',
      name: 'Obsidian Crimson Backdrop',
      type: 'shape',
      startTime: 0,
      duration: 18,
      labelColor: 'sky',
      shapeProps: {
        shape: 'rectangle',
        fillColor: '#140407',
        fillOpacity: 1,
        strokeColor: cfg.accentColor,
        strokeWidth: 0,
        cornerRadius: 0,
        points: 4,
        innerRadius: 0.5,
        widthPct: 105,
        heightPct: 105,
        pathPoints: [],
        closed: true,
      } satisfies ShapeProperties,
      keyframes: [
        { id: 'rr-kf-bg1', time: 0, property: 'opacity', value: 0.45, easing: 'easeOut' },
        { id: 'rr-kf-bg2', time: 2.8, property: 'opacity', value: 0.95, easing: 'easeInOut' },
        { id: 'rr-kf-bg3', time: 12.0, property: 'opacity', value: 1.0, easing: 'easeInOut' },
      ],
    }),
    createClipDefaults({
      id: 'rr-bg-final-black',
      assetId: 'shape-asset',
      trackId: 'L01_BG',
      name: 'Title Cut Blackout',
      type: 'shape',
      startTime: 18,
      duration: 2,
      labelColor: 'sky',
      shapeProps: {
        shape: 'rectangle',
        fillColor: '#020203',
        fillOpacity: 1,
        strokeColor: '#000000',
        strokeWidth: 0,
        cornerRadius: 0,
        points: 4,
        innerRadius: 0.5,
        widthPct: 105,
        heightPct: 105,
        pathPoints: [],
        closed: true,
      } satisfies ShapeProperties,
      keyframes: [
        { id: 'rr-kf-bgb1', time: 0, property: 'opacity', value: 1, easing: 'linear' },
        { id: 'rr-kf-bgb2', time: 1.4, property: 'opacity', value: 1, easing: 'easeIn' },
        { id: 'rr-kf-bgb3', time: 2.0, property: 'opacity', value: 0, easing: 'easeOut' },
      ],
    }),

    // ==================== LAYER 2: RED SMOKE ====================
    createClipDefaults({
      id: 'rr-smoke-1',
      assetId: 'fx-layer',
      trackId: 'L02_SMOKE',
      name: 'Volumetric Red Smoke',
      type: 'fx',
      startTime: 0,
      duration: 18,
      labelColor: 'violet',
      fxMeta: { presetId: 'red-smoke', presetName: 'Red Smoke', category: 'cinematic' },
      effects: {
        blur: 0,
        glow: 0,
        glowColor: cfg.accentColor,
        stabilization: 0,
        filmGrain: 0,
        chromaticAberration: 0,
        particles: 'red-smoke',
        particleIntensity: clampPct(72 * fxM),
      },
    }),

    // ==================== LAYER 3: RED PARTICLES ====================
    createClipDefaults({
      id: 'rr-particles-main',
      assetId: 'fx-layer',
      trackId: 'L03_PARTICLES',
      name: 'Crimson Sparks & Embers',
      type: 'fx',
      startTime: 0,
      duration: 18,
      labelColor: 'rose',
      fxMeta: { presetId: 'red-embers', presetName: 'Crimson Embers', category: 'cinematic' },
      effects: {
        blur: 0,
        glow: 0,
        glowColor: cfg.accentColor,
        stabilization: 0,
        filmGrain: 0,
        chromaticAberration: 0,
        particles: 'fire-embers',
        particleIntensity: clampPct(78 * fxM),
      },
    }),
    createClipDefaults({
      id: 'rr-particles-title',
      assetId: 'fx-layer',
      trackId: 'L03_PARTICLES',
      name: 'Subtle Title Embers',
      type: 'fx',
      startTime: 18,
      duration: 2,
      labelColor: 'rose',
      fxMeta: { presetId: 'red-embers-soft', presetName: 'Subtle Embers', category: 'cinematic' },
      effects: {
        blur: 0,
        glow: 0,
        glowColor: cfg.accentColor,
        stabilization: 0,
        filmGrain: 0,
        chromaticAberration: 0,
        particles: 'fire-embers',
        particleIntensity: clampPct(28 * fxM),
      },
      keyframes: [
        { id: 'rr-pt-1', time: 0, property: 'opacity', value: 0.9, easing: 'easeOut' },
        { id: 'rr-pt-2', time: 1.4, property: 'opacity', value: 0.7, easing: 'easeIn' },
        { id: 'rr-pt-3', time: 2.0, property: 'opacity', value: 0, easing: 'easeIn' },
      ],
    }),

    // ==================== LAYER 4: LIGHT EFFECTS ====================
    createClipDefaults({
      id: 'rr-light-intro-reveal',
      assetId: 'shape-asset',
      trackId: 'L06_LIGHT',
      name: 'Red Light Reveal Aura',
      type: 'shape',
      startTime: 0,
      duration: 3,
      blendMode: 'screen',
      labelColor: 'amber',
      shapeProps: {
        shape: 'circle',
        fillColor: cfg.accentColor,
        fillOpacity: 0.65,
        strokeColor: cfg.accentColor,
        strokeWidth: 0,
        cornerRadius: 0,
        points: 4,
        innerRadius: 0.5,
        widthPct: 78,
        heightPct: 78,
        pathPoints: [],
        closed: true,
      } satisfies ShapeProperties,
      effects: {
        blur: 28,
        glow: 55,
        glowColor: cfg.accentColor,
        stabilization: 0,
        filmGrain: 0,
        chromaticAberration: 0,
        particles: 'none',
        particleIntensity: 0,
      },
      keyframes: [
        { id: 'rr-li-1', time: 0, property: 'scale', value: 0.35, easing: 'easeOut' },
        { id: 'rr-li-2', time: 2.4, property: 'scale', value: 1.35, easing: 'easeInOut' },
        { id: 'rr-li-3', time: 0, property: 'opacity', value: 0.05, easing: 'easeOut' },
        { id: 'rr-li-4', time: 1.2, property: 'opacity', value: 0.55, easing: 'easeInOut' },
        { id: 'rr-li-5', time: 3.0, property: 'opacity', value: 0.2, easing: 'easeIn' },
      ],
    }),
    createClipDefaults({
      id: 'rr-light-flash-3s',
      assetId: 'shape-asset',
      trackId: 'L06_LIGHT',
      name: 'Red Impact Flash (3s)',
      type: 'shape',
      startTime: 3.0,
      duration: 0.38,
      blendMode: 'screen',
      labelColor: 'amber',
      shapeProps: {
        shape: 'rectangle',
        fillColor: cfg.accentColor,
        fillOpacity: 0.85,
        strokeColor: '#FFFFFF',
        strokeWidth: 0,
        cornerRadius: 0,
        points: 4,
        innerRadius: 0.5,
        widthPct: 105,
        heightPct: 105,
        pathPoints: [],
        closed: true,
      } satisfies ShapeProperties,
      keyframes: [
        { id: 'rr-fl3-1', time: 0, property: 'opacity', value: 0.85, easing: 'easeOut' },
        { id: 'rr-fl3-2', time: 0.38, property: 'opacity', value: 0, easing: 'easeOut' },
      ],
    }),
    createClipDefaults({
      id: 'rr-light-flash-6s',
      assetId: 'shape-asset',
      trackId: 'L06_LIGHT',
      name: 'Chaos Flash Pulse (6s)',
      type: 'shape',
      startTime: 6.0,
      duration: 0.32,
      blendMode: 'screen',
      labelColor: 'amber',
      shapeProps: {
        shape: 'rectangle',
        fillColor: cfg.accentColor,
        fillOpacity: 0.8,
        strokeColor: cfg.accentColor,
        strokeWidth: 0,
        cornerRadius: 0,
        points: 4,
        innerRadius: 0.5,
        widthPct: 105,
        heightPct: 105,
        pathPoints: [],
        closed: true,
      } satisfies ShapeProperties,
      keyframes: [
        { id: 'rr-fl6-1', time: 0, property: 'opacity', value: 0.72, easing: 'easeOut' },
        { id: 'rr-fl6-2', time: 0.32, property: 'opacity', value: 0, easing: 'easeOut' },
      ],
    }),
    createClipDefaults({
      id: 'rr-light-lines-9s',
      assetId: 'shape-asset',
      trackId: 'L06_LIGHT',
      name: 'Animated Red Laser Lines',
      type: 'shape',
      startTime: 9.0,
      duration: 3.0,
      blendMode: 'screen',
      labelColor: 'amber',
      shapeProps: {
        shape: 'rectangle',
        fillColor: cfg.accentColor,
        fillOpacity: 0.95,
        strokeColor: '#FFFFFF',
        strokeWidth: 0,
        cornerRadius: 0,
        points: 4,
        innerRadius: 0.5,
        widthPct: 92,
        heightPct: 1.5,
        pathPoints: [],
        closed: true,
      } satisfies ShapeProperties,
      effects: {
        blur: 0,
        glow: 75,
        glowColor: cfg.accentColor,
        stabilization: 0,
        filmGrain: 0,
        chromaticAberration: 0,
        particles: 'none',
        particleIntensity: 0,
      },
      transform: {
        x: 0,
        y: 16,
        scale: 1,
        rotation: 0,
        opacity: 0.9,
        anchorX: 0.5,
        anchorY: 0.5,
        zDepth: 0,
        rotX: 0,
        rotY: 0,
      },
      keyframes: [
        { id: 'rr-ln-1', time: 0, property: 'scaleX', value: 0.05, easing: 'easeOut' },
        { id: 'rr-ln-2', time: 0.45, property: 'scaleX', value: 1.1, easing: 'easeOut' },
        { id: 'rr-ln-3', time: 2.8, property: 'scaleX', value: 1.35, easing: 'easeIn' },
      ],
    }),
    createClipDefaults({
      id: 'rr-light-flash-12s',
      assetId: 'shape-asset',
      trackId: 'L06_LIGHT',
      name: 'War Impact Flash (12s)',
      type: 'shape',
      startTime: 12.0,
      duration: 0.45,
      blendMode: 'screen',
      labelColor: 'amber',
      shapeProps: {
        shape: 'rectangle',
        fillColor: cfg.accentColor,
        fillOpacity: 0.95,
        strokeColor: '#FFFFFF',
        strokeWidth: 0,
        cornerRadius: 0,
        points: 4,
        innerRadius: 0.5,
        widthPct: 105,
        heightPct: 105,
        pathPoints: [],
        closed: true,
      } satisfies ShapeProperties,
      keyframes: [
        { id: 'rr-fl12-1', time: 0, property: 'opacity', value: 0.95, easing: 'easeOut' },
        { id: 'rr-fl12-2', time: 0.45, property: 'opacity', value: 0, easing: 'easeOut' },
      ],
    }),
    createClipDefaults({
      id: 'rr-light-strobe-15s',
      assetId: 'shape-asset',
      trackId: 'L06_LIGHT',
      name: 'Buildup Red Light Strobe',
      type: 'shape',
      startTime: 15.0,
      duration: 3.0,
      blendMode: 'screen',
      labelColor: 'amber',
      shapeProps: {
        shape: 'rectangle',
        fillColor: cfg.accentColor,
        fillOpacity: 0.85,
        strokeColor: cfg.accentColor,
        strokeWidth: 0,
        cornerRadius: 0,
        points: 4,
        innerRadius: 0.5,
        widthPct: 105,
        heightPct: 105,
        pathPoints: [],
        closed: true,
      } satisfies ShapeProperties,
      keyframes: [
        { id: 'rr-st-1', time: 0, property: 'opacity', value: 0.65, easing: 'easeOut' },
        { id: 'rr-st-2', time: 0.35, property: 'opacity', value: 0.05, easing: 'linear' },
        { id: 'rr-st-3', time: 0.75, property: 'opacity', value: 0.72, easing: 'easeOut' },
        { id: 'rr-st-4', time: 1.15, property: 'opacity', value: 0.05, easing: 'linear' },
        { id: 'rr-st-5', time: 1.5, property: 'opacity', value: 0.8, easing: 'easeOut' },
        { id: 'rr-st-6', time: 2.0, property: 'opacity', value: 0.1, easing: 'linear' },
        { id: 'rr-st-7', time: 2.25, property: 'opacity', value: 0.9, easing: 'easeOut' },
        { id: 'rr-st-8', time: 2.95, property: 'opacity', value: 0, easing: 'easeOut' },
      ],
    }),
    createClipDefaults({
      id: 'rr-light-title-18s',
      assetId: 'shape-asset',
      trackId: 'L06_LIGHT',
      name: 'Title Red Rim Glow (18s)',
      type: 'shape',
      startTime: 18.0,
      duration: 2.0,
      blendMode: 'screen',
      labelColor: 'amber',
      shapeProps: {
        shape: 'circle',
        fillColor: cfg.accentColor,
        fillOpacity: 0.6,
        strokeColor: cfg.accentColor,
        strokeWidth: 0,
        cornerRadius: 0,
        points: 4,
        innerRadius: 0.5,
        widthPct: 68,
        heightPct: 45,
        pathPoints: [],
        closed: true,
      } satisfies ShapeProperties,
      effects: {
        blur: 32,
        glow: 60,
        glowColor: cfg.accentColor,
        stabilization: 0,
        filmGrain: 0,
        chromaticAberration: 0,
        particles: 'none',
        particleIntensity: 0,
      },
      keyframes: [
        { id: 'rr-tl-1', time: 0, property: 'opacity', value: 0.55, easing: 'easeOut' },
        { id: 'rr-tl-2', time: 1.2, property: 'opacity', value: 0.45, easing: 'easeInOut' },
        { id: 'rr-tl-3', time: 2.0, property: 'opacity', value: 0, easing: 'easeIn' },
      ],
    }),

    // ==================== LAYER 5: MAIN TYPOGRAPHY (7 BEATS) ====================
    // 00:00 – 00:03 | INTRO
    makeTextClip({
      id: 'rr-txt-1',
      trackId: 'L04_MAINTXT',
      name: `01 Intro · ${s1.mainText}`,
      text: s1.mainText,
      startTime: 0,
      duration: 3.0,
      fontFamily: cfg.fontFamily,
      fontSize: 82,
      color: cfg.primaryColor,
      accentColor: cfg.accentColor,
      animation: 'cinematic-title',
      effectSpeed: spdM,
      effectIntensity: 100 * fxM,
      transitionIn: 'fade-in',
      transitionOut: 'glitch-cut',
      keyframes: [
        { id: 'rr-t1-s0', time: 0, property: 'scale', value: 0.88, easing: 'easeOut' },
        { id: 'rr-t1-s1', time: 3.0, property: 'scale', value: 1.12, easing: 'easeIn' },
        { id: 'rr-t1-o0', time: 0, property: 'opacity', value: 0, easing: 'easeOut' },
        { id: 'rr-t1-o1', time: 0.65, property: 'opacity', value: 1, easing: 'easeInOut' },
      ],
    }),
    // 00:03 – 00:06 | IMPACT
    makeTextClip({
      id: 'rr-txt-2',
      trackId: 'L04_MAINTXT',
      name: `02 Impact · ${s2.mainText}`,
      text: s2.mainText,
      startTime: 3.0,
      duration: 3.0,
      fontFamily: cfg.fontFamily,
      fontSize: 132,
      color: cfg.primaryColor,
      accentColor: cfg.accentColor,
      animation: 'velocity-text',
      effectSpeed: 1.25 * spdM,
      effectIntensity: 140 * fxM,
      transitionIn: 'zoom-in',
      transitionOut: 'flash-transition',
      keyframes: [
        { id: 'rr-t2-s0', time: 0, property: 'scale', value: 1.75, easing: 'easeOut' },
        { id: 'rr-t2-s1', time: 0.35, property: 'scale', value: 1.0, easing: 'bezier', bezier: [0.16, 1, 0.3, 1] },
        { id: 'rr-t2-s2', time: 2.7, property: 'scale', value: 1.16, easing: 'easeIn' },
        { id: 'rr-t2-s3', time: 3.0, property: 'scale', value: 0.72, easing: 'easeIn' },
      ],
    }),
    // 00:06 – 00:09 | CHAOS
    makeTextClip({
      id: 'rr-txt-3',
      trackId: 'L04_MAINTXT',
      name: `03 Chaos · ${s3.mainText}`,
      text: s3.mainText,
      startTime: 6.0,
      duration: 3.0,
      fontFamily: cfg.fontFamily,
      fontSize: 96,
      color: cfg.primaryColor,
      accentColor: cfg.accentColor,
      animation: 'text-glitch',
      effectSpeed: 1.4 * spdM,
      effectIntensity: 150 * fxM,
      transitionIn: 'rgb-split-transition',
      transitionOut: 'whip-pan',
      keyframes: [
        { id: 'rr-t3-s0', time: 0, property: 'scale', value: 0.9, easing: 'easeOut' },
        { id: 'rr-t3-s1', time: 1.4, property: 'scale', value: 1.06, easing: 'easeInOut' },
        { id: 'rr-t3-s2', time: 3.0, property: 'scale', value: 1.32, easing: 'easeIn' },
      ],
    }),
    // 00:09 – 00:12 | INTENSE SECTION
    makeTextClip({
      id: 'rr-txt-4',
      trackId: 'L04_MAINTXT',
      name: `04 Intense · ${s4.mainText}`,
      text: s4.mainText,
      startTime: 9.0,
      duration: 3.0,
      fontFamily: cfg.fontFamily,
      fontSize: 108,
      color: cfg.primaryColor,
      accentColor: cfg.accentColor,
      animation: 'kinetic-typography',
      effectSpeed: 1.35 * spdM,
      effectIntensity: 150 * fxM,
      transitionIn: 'glitch-cut',
      transitionOut: 'zoom-in',
      mask: { shape: 'rectangle', radiusX: 0.5, radiusY: 0.5, feather: 12 },
      keyframes: [
        { id: 'rr-t4-s0', time: 0, property: 'scale', value: 1.45, easing: 'easeOut' },
        { id: 'rr-t4-s1', time: 0.38, property: 'scale', value: 1.04, easing: 'easeOut' },
        { id: 'rr-t4-s2', time: 3.0, property: 'scale', value: 1.24, easing: 'easeIn' },
      ],
    }),
    // 00:12 – 00:15 | MAIN IMPACT
    makeTextClip({
      id: 'rr-txt-5',
      trackId: 'L04_MAINTXT',
      name: `05 Main Impact · ${s5.mainText}`,
      text: s5.mainText,
      startTime: 12.0,
      duration: 3.0,
      fontFamily: cfg.fontFamily,
      fontSize: 138,
      color: cfg.primaryColor,
      accentColor: cfg.accentColor,
      extrude3D: true,
      animation: '3d-extrude',
      effectSpeed: 1.5 * spdM,
      effectIntensity: 165 * fxM,
      transitionIn: 'flash-transition',
      transitionOut: 'glitch-cut',
      keyframes: [
        { id: 'rr-t5-r0', time: 0, property: 'rotation', value: -7, easing: 'easeOut' },
        { id: 'rr-t5-r1', time: 0.45, property: 'rotation', value: 0, easing: 'bezier', bezier: [0.16, 1, 0.3, 1] },
        { id: 'rr-t5-s0', time: 0, property: 'scale', value: 1.85, easing: 'easeOut' },
        { id: 'rr-t5-s1', time: 0.4, property: 'scale', value: 1.02, easing: 'easeOut' },
        { id: 'rr-t5-s2', time: 3.0, property: 'scale', value: 1.22, easing: 'easeIn' },
      ],
    }),
    // 00:15 – 00:18 | FINAL BUILDUP (Rapid Beat Cuts)
    makeTextClip({
      id: 'rr-txt-6a',
      trackId: 'L04_MAINTXT',
      name: `06 Buildup Cut 1 · ${s6.mainText}`,
      text: s6.mainText,
      startTime: 15.0,
      duration: 1.5,
      fontFamily: cfg.fontFamily,
      fontSize: 102,
      color: cfg.primaryColor,
      accentColor: cfg.accentColor,
      animation: 'rgb-text',
      effectSpeed: 1.8 * spdM,
      effectIntensity: 160 * fxM,
      keyframes: [
        { id: 'rr-t6a-s0', time: 0, property: 'scale', value: 1.35, easing: 'easeOut' },
        { id: 'rr-t6a-s1', time: 0.3, property: 'scale', value: 1.0, easing: 'easeOut' },
        { id: 'rr-t6a-s2', time: 1.5, property: 'scale', value: 1.18, easing: 'easeIn' },
      ],
    }),
    makeTextClip({
      id: 'rr-txt-6b',
      trackId: 'L04_MAINTXT',
      name: `06 Buildup Cut 2 · ${s6.mainText}`,
      text: s6.mainText,
      startTime: 16.5,
      duration: 1.5,
      fontFamily: cfg.fontFamily,
      fontSize: 112,
      color: cfg.accentColor,
      accentColor: '#FFFFFF',
      animation: 'text-shake',
      effectSpeed: 2.0 * spdM,
      effectIntensity: 175 * fxM,
      keyframes: [
        { id: 'rr-t6b-s0', time: 0, property: 'scale', value: 1.05, easing: 'easeIn' },
        { id: 'rr-t6b-s1', time: 1.5, property: 'scale', value: 1.55, easing: 'easeIn' },
      ],
    }),
    // 00:18 – 00:20 | FINAL TITLE
    makeTextClip({
      id: 'rr-txt-7',
      trackId: 'L04_MAINTXT',
      name: `07 Final Title · ${s7.mainText}`,
      text: s7.mainText,
      startTime: 18.0,
      duration: 2.0,
      fontFamily: cfg.fontFamily,
      fontSize: 122,
      color: cfg.primaryColor,
      accentColor: cfg.accentColor,
      letterSpacing: 12,
      animation: 'neon-text',
      effectSpeed: 1.0 * spdM,
      effectIntensity: 125 * fxM,
      transitionIn: 'fade-in',
      keyframes: [
        { id: 'rr-t7-s0', time: 0, property: 'scale', value: 0.88, easing: 'easeOut' },
        { id: 'rr-t7-s1', time: 1.5, property: 'scale', value: 1.08, easing: 'easeInOut' },
        { id: 'rr-t7-o0', time: 0, property: 'opacity', value: 0, easing: 'easeOut' },
        { id: 'rr-t7-o1', time: 0.32, property: 'opacity', value: 1, easing: 'easeOut' },
        { id: 'rr-t7-o2', time: 1.4, property: 'opacity', value: 1, easing: 'easeIn' },
        { id: 'rr-t7-o3', time: 2.0, property: 'opacity', value: 0, easing: 'easeIn' },
      ],
    }),

    // ==================== LAYER 6: SECONDARY TYPOGRAPHY ====================
    ...[s1, s2, s3, s4, s5, s6, s7].map((sec, idx) =>
      makeTextClip({
        id: `rr-sub-${idx + 1}`,
        trackId: 'L05_SUBTXT',
        name: `Sub 0${idx + 1} · ${sec.subText}`,
        text: sec.subText,
        startTime: sec.startTime + 0.12,
        duration: Math.max(0.8, sec.endTime - sec.startTime - 0.16),
        fontFamily: 'JetBrains Mono',
        fontSize: 28,
        color: idx === 6 ? '#D4D4D8' : cfg.accentColor,
        accentColor: '#000000',
        y: 19,
        letterSpacing: 10,
        animation: idx % 2 === 0 ? 'tracking-animation' : 'letter-reveal',
        effectSpeed: 1.15 * spdM,
        effectIntensity: 95,
        keyframes: [
          { id: `rr-subkf-${idx}-0`, time: 0, property: 'opacity', value: 0, easing: 'easeOut' },
          { id: `rr-subkf-${idx}-1`, time: 0.25, property: 'opacity', value: 0.95, easing: 'easeOut' },
          {
            id: `rr-subkf-${idx}-2`,
            time: Math.max(0.5, sec.endTime - sec.startTime - 0.55),
            property: 'opacity',
            value: idx === 6 ? 0.95 : 0.9,
            easing: 'easeIn',
          },
          {
            id: `rr-subkf-${idx}-3`,
            time: Math.max(0.7, sec.endTime - sec.startTime - 0.18),
            property: 'opacity',
            value: idx === 6 ? 0 : 0.2,
            easing: 'easeIn',
          },
        ],
      })
    ),

    // ==================== LAYER 7: GLITCH EFFECTS ====================
    createClipDefaults({
      id: 'rr-fx-glitch-intro',
      assetId: 'fx-layer',
      trackId: 'L07_GLITCH',
      name: 'Subtle Intro Chromatic',
      type: 'fx',
      startTime: 2.35,
      duration: 0.65,
      labelColor: 'sky',
      fxMeta: { presetId: 'chromatic-aberration', presetName: 'Chromatic Fringe', category: 'glitch' },
      effectsStack: [
        makeFx('chromatic-aberration', { amount: Math.round(14 * fxM), falloff: 75 }),
      ],
    }),
    createClipDefaults({
      id: 'rr-fx-glitch-3s',
      assetId: 'fx-layer',
      trackId: 'L07_GLITCH',
      name: 'RGB Split Impact (3s)',
      type: 'fx',
      startTime: 3.0,
      duration: 0.75,
      labelColor: 'sky',
      fxMeta: { presetId: 'rgb-split', presetName: 'RGB Split', category: 'rgb' },
      effectsStack: [
        makeFx('rgb-split', { distance: Math.round(18 * fxM), angle: 12 }),
      ],
    }),
    createClipDefaults({
      id: 'rr-fx-glitch-6s',
      assetId: 'fx-layer',
      trackId: 'L07_GLITCH',
      name: 'Chaos Horizontal Glitch & Blur',
      type: 'fx',
      startTime: 6.0,
      duration: 3.0,
      labelColor: 'sky',
      fxMeta: { presetId: 'horizontal-glitch', presetName: 'Horizontal Glitch', category: 'glitch' },
      effectsStack: [
        makeFx('horizontal-glitch', { intensity: clampPct(58 * fxM), bandHeight: 14, rate: 16 }),
        makeFx('motion-blur', { amount: Math.round(14 * fxM), direction: 0, shutterAngle: 180, samples: 6 }),
      ],
    }),
    createClipDefaults({
      id: 'rr-fx-glitch-12s',
      assetId: 'fx-layer',
      trackId: 'L07_GLITCH',
      name: 'War RGB Distortion (12s)',
      type: 'fx',
      startTime: 12.0,
      duration: 2.4,
      labelColor: 'sky',
      fxMeta: { presetId: 'rgb-glitch', presetName: 'RGB Distortion', category: 'glitch' },
      effectsStack: [
        makeFx('rgb-glitch', { intensity: clampPct(62 * fxM), shift: Math.round(16 * fxM), rate: 14 }),
        makeFx('glitch-distortion', { intensity: clampPct(48 * fxM), blockSize: 20, speed: 12 }),
      ],
    }),
    createClipDefaults({
      id: 'rr-fx-glitch-15s',
      assetId: 'fx-layer',
      trackId: 'L07_GLITCH',
      name: 'Buildup RGB Flash Overlay',
      type: 'fx',
      startTime: 15.0,
      duration: 2.9,
      labelColor: 'sky',
      fxMeta: { presetId: 'rgb-flash', presetName: 'RGB Flash', category: 'glitch' },
      effectsStack: [
        makeFx('rgb-flash', { intensity: clampPct(65 * fxM), speed: 16, split: Math.round(18 * fxM) }),
      ],
    }),

    // ==================== LAYER 8: SHAKE EFFECTS ====================
    createClipDefaults({
      id: 'rr-fx-shake-intro',
      assetId: 'fx-layer',
      trackId: 'L08_SHAKE',
      name: 'Subtle Intro Shake',
      type: 'fx',
      startTime: 0,
      duration: 3.0,
      labelColor: 'rose',
      fxMeta: { presetId: 'smooth-shake', presetName: 'Subtle Camera Shake', category: 'shake' },
      effectsStack: [
        makeFx('camera-shake', {
          intensity: clampPct(22 * shakeM),
          speed: 0.9,
          frequency: 5,
          rotation: 1.5,
          posX: 25,
          posY: 22,
          zoomStrength: 4,
          motionBlur: 15,
          waveProfile: 'smooth',
        }),
      ],
    }),
    createClipDefaults({
      id: 'rr-fx-shake-3s',
      assetId: 'fx-layer',
      trackId: 'L08_SHAKE',
      name: 'Hard Camera Shake (3s)',
      type: 'fx',
      startTime: 3.0,
      duration: 1.8,
      labelColor: 'rose',
      fxMeta: { presetId: 'hard-shake', presetName: 'Hard Camera Shake', category: 'shake' },
      effectsStack: [
        makeFx('camera-shake', {
          intensity: clampPct(74 * shakeM),
          speed: 1.9,
          frequency: 14,
          rotation: 6,
          posX: 65,
          posY: 55,
          zoomStrength: 20,
          motionBlur: 45,
          startStrength: 100,
          endStrength: 15,
          waveProfile: 'impact',
        }),
      ],
    }),
    createClipDefaults({
      id: 'rr-fx-shake-9s',
      assetId: 'fx-layer',
      trackId: 'L08_SHAKE',
      name: 'Rise Multi-Impact Shake',
      type: 'fx',
      startTime: 9.0,
      duration: 2.8,
      labelColor: 'rose',
      fxMeta: { presetId: 'beat-shake', presetName: 'Beat Impact Shake', category: 'shake' },
      effectsStack: [
        makeFx('camera-shake', {
          intensity: clampPct(66 * shakeM),
          speed: 1.7,
          frequency: 12,
          rotation: 4.5,
          posX: 52,
          posY: 48,
          zoomStrength: 16,
          motionBlur: 40,
          waveProfile: 'beat',
        }),
      ],
    }),
    createClipDefaults({
      id: 'rr-fx-shake-12s',
      assetId: 'fx-layer',
      trackId: 'L08_SHAKE',
      name: 'Heavy War Shake (12s)',
      type: 'fx',
      startTime: 12.0,
      duration: 2.6,
      labelColor: 'rose',
      fxMeta: { presetId: 'extreme-shake', presetName: 'Extreme War Shake', category: 'shake' },
      effectsStack: [
        makeFx('camera-shake', {
          intensity: clampPct(86 * shakeM),
          speed: 2.2,
          frequency: 18,
          rotation: 8,
          posX: 78,
          posY: 68,
          zoomStrength: 26,
          motionBlur: 55,
          startStrength: 100,
          endStrength: 25,
          waveProfile: 'hard',
        }),
      ],
    }),
    createClipDefaults({
      id: 'rr-fx-shake-15s',
      assetId: 'fx-layer',
      trackId: 'L08_SHAKE',
      name: 'Velocity Whip Shake (15s)',
      type: 'fx',
      startTime: 15.0,
      duration: 2.9,
      labelColor: 'rose',
      fxMeta: { presetId: 'velocity-shake', presetName: 'Velocity Whip Shake', category: 'shake' },
      effectsStack: [
        makeFx('camera-shake', {
          intensity: clampPct(72 * shakeM),
          speed: 2.4,
          frequency: 16,
          rotation: 5,
          posX: 60,
          posY: 50,
          zoomStrength: 22,
          motionBlur: 48,
          waveProfile: 'whip',
        }),
      ],
    }),

    // ==================== LAYER 9: CINEMATIC CC ====================
    createClipDefaults({
      id: 'rr-fx-cc-main',
      assetId: 'fx-layer',
      trackId: 'L09_CC',
      name: 'Crimson Noir Cinematic CC',
      type: 'fx',
      startTime: 0,
      duration: 20,
      labelColor: 'rose',
      fxMeta: { presetId: 'crimson-noir-cc', presetName: 'Crimson Noir CC', category: 'cc' },
      colorGrade: {
        preset: 'crimson-noir',
        exposure: 2,
        contrast: clampPct(24 * fxM, 60),
        saturation: 12,
        temperature: -6,
        tint: 8,
        vignette: 42,
        highlights: 14,
        shadows: -18,
        whites: 8,
        blacks: -14,
        vibrance: 10,
        lutIntensity: 92,
      },
    }),

    // ==================== LAYER 10: FILM GRAIN ====================
    createClipDefaults({
      id: 'rr-fx-grain-main',
      assetId: 'fx-layer',
      trackId: 'L10_GRAIN',
      name: '35mm Cinema Film Grain',
      type: 'fx',
      startTime: 0,
      duration: 20,
      labelColor: 'amber',
      fxMeta: { presetId: 'film-grain', presetName: 'Film Grain', category: 'cinematic' },
      effects: {
        blur: 0,
        glow: 0,
        glowColor: cfg.accentColor,
        stabilization: 0,
        filmGrain: clampPct(42 * fxM),
        chromaticAberration: 0,
        particles: 'none',
        particleIntensity: 0,
      },
      effectsStack: [makeFx('film-grain', { amount: clampPct(30 * fxM), size: 1.5 })],
    }),

    // ==================== LAYER 11 & 12: AUDIO ====================
    createClipDefaults({
      id: 'rr-audio-music',
      assetId: musicAsset.id,
      trackId: 'L11_MUSIC',
      name: musicAsset.name,
      type: 'audio',
      startTime: 0,
      duration: Math.min(20, musicAsset.duration || 20),
      volume: 0.9,
      fadeIn: 0.35,
      fadeOut: 0.85,
      labelColor: 'emerald',
    }),
    createClipDefaults({
      id: 'rr-audio-sfx',
      assetId: sfxAsset.id,
      trackId: 'L12_SFX',
      name: 'Beat Drops, Risers & Impacts',
      type: 'audio',
      startTime: 0,
      duration: 20,
      volume: 1.0,
      fadeIn: 0.02,
      fadeOut: 0.5,
      labelColor: 'emerald',
    }),
  ];

  // Synchronized Beat Markers across all 7 Narrative Sections
  const markers: TimelineMarker[] = [
    { id: 'rr-mk-0', time: 0, label: '01 Intro · Falling', notes: 'Red light reveal + smoke', color: 'rose' },
    { id: 'rr-mk-3', time: 3, label: '02 Impact · No Mercy', notes: 'Beat drop 1 + hard camera shake', color: 'amber' },
    { id: 'rr-mk-6', time: 6, label: '03 Chaos · Glitch', notes: 'Horizontal glitch + red flash', color: 'sky' },
    { id: 'rr-mk-9', time: 9, label: '04 Rise · Ashes', notes: 'Giant text + laser bars', color: 'violet' },
    { id: 'rr-mk-12', time: 12, label: '05 War · Main Drop', notes: '3D shadow title + extreme shake', color: 'rose' },
    { id: 'rr-mk-15', time: 15, label: '06 Buildup · Fast Cuts', notes: 'Rapid beat cuts + whip shake', color: 'amber' },
    { id: 'rr-mk-18', time: 18, label: '07 Title · Red Rebellion', notes: 'Cut to black + title reveal', color: 'emerald' },
    { id: 'rr-mk-20', time: 20, label: 'Fade Out', notes: 'Clean blackout fade', color: 'rose' },
  ];

  return {
    id: `proj-rr-${now}`,
    name: cfg.templateName || RED_REBELLION_META.name,
    location: 'Local Studio Workspace',
    width: 1920,
    height: 1080,
    fps: 60,
    aspectRatio: '16:9',
    videoFormat: 'mp4',
    audioSampleRate: 48000,
    backgroundColor: '#050507',
    defaultClipDuration: 3,
    createdAt: now,
    updatedAt: now,
    tracks,
    clips,
    markers,
    assets: [musicAsset, sfxAsset],
    folders: [...DEFAULT_PROJECT_FOLDERS],
    camera3D: { fov: 50, orbitX: 0, orbitY: 0, zoom: 1, dofBlur: 0 },
    snapEnabled: true,
    proxyQuality: 'full',
    previewQuality: 'high',
  };
}

// =========================================================================
// LocalStorage Custom Template Persistence
// =========================================================================

export function loadSavedCustomTemplates(): SavedCustomTemplate[] {
  try {
    const raw = localStorage.getItem(CUSTOM_TEMPLATES_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as SavedCustomTemplate[]) : [];
  } catch {
    return [];
  }
}

export function saveCustomTemplate(template: SavedCustomTemplate): SavedCustomTemplate[] {
  const existing = loadSavedCustomTemplates();
  const next = [template, ...existing.filter((t) => t.id !== template.id)];
  try {
    localStorage.setItem(CUSTOM_TEMPLATES_STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Ignore quota errors
  }
  return next;
}

export function deleteCustomTemplate(id: string): SavedCustomTemplate[] {
  const next = loadSavedCustomTemplates().filter((t) => t.id !== id);
  try {
    localStorage.setItem(CUSTOM_TEMPLATES_STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Ignore quota errors
  }
  return next;
}
