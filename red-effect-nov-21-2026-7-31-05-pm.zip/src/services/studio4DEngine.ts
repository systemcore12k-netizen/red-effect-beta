import * as THREE from 'three';
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { OBJExporter } from 'three/addons/exporters/OBJExporter.js';
import {
  CharacterMotionPreset,
  FacialRigState,
  Hyper4DConfig,
  Keyframe4D,
  ObjectAnimPreset,
  ParticleConfig4D,
  PhysicsConfig4D,
  SceneNodeInfo,
} from '../types/studio4d';

const _tempBox = new THREE.Box3();
const _tempVec = new THREE.Vector3();

export function cloneTransferableObject(obj: THREE.Object3D): THREE.Object3D {
  const cloned = SkeletonUtils.clone(obj);
  cloned.traverse((node) => {
    if (node instanceof THREE.Mesh) {
      node.castShadow = true;
      node.receiveShadow = true;
    }
  });
  return cloned;
}

export function collectSceneNodes(root: THREE.Object3D): SceneNodeInfo[] {
  const result: SceneNodeInfo[] = [];
  const walk = (node: THREE.Object3D, depth: number) => {
    if (node.userData?.isEditorHelper) return;
    const isMesh = node instanceof THREE.Mesh;
    const isSkinned = node instanceof THREE.SkinnedMesh;
    const isBone = node instanceof THREE.Bone;
    const isLight = node instanceof THREE.Light;
    const isCam = node instanceof THREE.Camera;

    result.push({
      uuid: node.uuid,
      name: node.name || node.type || 'Node',
      type: node.type,
      depth,
      visible: node.visible,
      hasGeometry: isMesh,
      hasMaterial: isMesh,
      isBone,
      isSkinnedMesh: isSkinned,
      isLight,
      isCamera: isCam,
      morphCount: isMesh && node.morphTargetInfluences ? node.morphTargetInfluences.length : 0,
    });

    for (const child of node.children) {
      walk(child, depth + 1);
    }
  };
  walk(root, 0);
  return result;
}

export function findBonesInObject(root: THREE.Object3D): THREE.Bone[] {
  const bones: THREE.Bone[] = [];
  root.traverse((obj) => {
    if (obj instanceof THREE.Bone) bones.push(obj);
  });
  return bones;
}

export function saveBasePoses(root: THREE.Object3D): void {
  root.traverse((obj) => {
    if (!obj.userData.basePose4D) {
      obj.userData.basePose4D = {
        pos: [obj.position.x, obj.position.y, obj.position.z],
        rot: [obj.rotation.x, obj.rotation.y, obj.rotation.z],
        scale: [obj.scale.x, obj.scale.y, obj.scale.z],
      };
    }
  });
}

export function restoreBasePoses(root: THREE.Object3D): void {
  root.traverse((obj) => {
    const bp = obj.userData.basePose4D as
      | { pos: [number, number, number]; rot: [number, number, number]; scale: [number, number, number] }
      | undefined;
    if (bp) {
      obj.position.set(bp.pos[0], bp.pos[1], bp.pos[2]);
      obj.rotation.set(bp.rot[0], bp.rot[1], bp.rot[2]);
      obj.scale.set(bp.scale[0], bp.scale[1], bp.scale[2]);
    }
  });
}

/**
 * Generates an explicit humanoid bone hierarchy attached visually + bound to procedural character parts,
 * or returns existing skeleton bones if already rigged.
 */
export function autoRigObject(root: THREE.Object3D): { boneCount: number; alreadyRigged: boolean } {
  const existing = findBonesInObject(root);
  if (existing.length > 0) {
    return { boneCount: existing.length, alreadyRigged: true };
  }

  saveBasePoses(root);
  _tempBox.setFromObject(root);
  const size = _tempBox.getSize(new THREE.Vector3());
  const center = _tempBox.getCenter(new THREE.Vector3());
  const minY = Number.isFinite(_tempBox.min.y) ? _tempBox.min.y : 0;
  const h = Math.max(0.8, size.y || 2);

  const hips = new THREE.Bone();
  hips.name = 'Hips';
  hips.position.set(center.x, minY + h * 0.48, center.z);

  const spine = new THREE.Bone();
  spine.name = 'Spine';
  spine.position.set(0, h * 0.2, 0);
  hips.add(spine);

  const head = new THREE.Bone();
  head.name = 'Head';
  head.position.set(0, h * 0.26, 0);
  spine.add(head);

  const leftArm = new THREE.Bone();
  leftArm.name = 'LeftArm';
  leftArm.position.set(-Math.max(0.25, size.x * 0.28), h * 0.14, 0);
  spine.add(leftArm);

  const rightArm = new THREE.Bone();
  rightArm.name = 'RightArm';
  rightArm.position.set(Math.max(0.25, size.x * 0.28), h * 0.14, 0);
  spine.add(rightArm);

  const leftLeg = new THREE.Bone();
  leftLeg.name = 'LeftLeg';
  leftLeg.position.set(-Math.max(0.14, size.x * 0.12), -h * 0.04, 0);
  hips.add(leftLeg);

  const rightLeg = new THREE.Bone();
  rightLeg.name = 'RightLeg';
  rightLeg.position.set(Math.max(0.14, size.x * 0.12), -h * 0.04, 0);
  hips.add(rightLeg);

  root.add(hips);
  saveBasePoses(hips);

  return { boneCount: 7, alreadyRigged: false };
}

/**
 * Procedural Character Gait & Action Solver:
 * Drives skeletal bones if present AND semantic named child parts (arm/leg/head/torso/wing/wheel)
 * so Walk, Run, Jump, Dance, Wave, and Idle execute on both rigged GLB/FBX models and procedural characters.
 */
export function applyProceduralCharacterMotion(
  root: THREE.Object3D,
  preset: CharacterMotionPreset,
  time: number,
  speed = 1
): void {
  if (preset === 'none') return;
  saveBasePoses(root);

  const t = time * speed;
  const freq =
    preset === 'run'
      ? 9.5
      : preset === 'walk'
      ? 5.2
      : preset === 'dance'
      ? 6.4
      : preset === 'jump'
      ? 3.6
      : preset === 'wave'
      ? 5.5
      : 2.2;

  const swing =
    preset === 'run'
      ? 0.85
      : preset === 'walk'
      ? 0.48
      : preset === 'dance'
      ? 0.65
      : preset === 'idle'
      ? 0.06
      : 0.3;

  const s = Math.sin(t * freq);
  const c = Math.cos(t * freq);
  const bounce =
    preset === 'jump'
      ? Math.max(0, Math.sin(t * freq)) * 0.55
      : preset === 'run'
      ? Math.abs(Math.sin(t * freq)) * 0.12
      : preset === 'walk'
      ? Math.abs(Math.sin(t * freq)) * 0.05
      : preset === 'dance'
      ? Math.abs(Math.sin(t * freq)) * 0.09
      : Math.sin(t * 2.1) * 0.015;

  const rootBase = root.userData.basePose4D as
    | { pos: [number, number, number]; rot: [number, number, number] }
    | undefined;
  if (rootBase) {
    root.position.y = rootBase.pos[1] + bounce;
    if (preset === 'run') {
      root.rotation.x = rootBase.rot[0] + 0.12;
    } else if (preset === 'dance') {
      root.rotation.y = rootBase.rot[1] + Math.sin(t * 2.5) * 0.35;
    }
  }

  root.traverse((node) => {
    if (node === root || node.userData?.isEditorHelper) return;
    const bp = node.userData.basePose4D as
      | { pos: [number, number, number]; rot: [number, number, number] }
      | undefined;
    if (!bp) return;

    const n = node.name.toLowerCase();
    const isLeft = /left|_l\b|\.l\b|l_/.test(n) || bp.pos[0] < -0.18;
    const isRight = /right|_r\b|\.r\b|r_/.test(n) || bp.pos[0] > 0.18;

    if (/leg|thigh|calf|foot|shin|knee/.test(n)) {
      const dir = isLeft ? 1 : -1;
      node.rotation.x = bp.rot[0] + s * swing * dir;
    } else if (/arm|shoulder|hand|forearm|wing/.test(n)) {
      if (preset === 'wave' && (isRight || !isLeft)) {
        node.rotation.z = bp.rot[2] - 1.35 + Math.sin(t * 7.5) * 0.45;
        node.rotation.x = bp.rot[0] - 0.3;
      } else if (preset === 'jump') {
        node.rotation.z = bp.rot[2] + (isLeft ? 0.9 : -0.9) * Math.max(0.2, Math.sin(t * freq));
      } else {
        const dir = isLeft ? -1 : 1;
        node.rotation.x = bp.rot[0] + s * swing * 0.9 * dir;
        if (preset === 'dance') {
          node.rotation.z = bp.rot[2] + c * 0.4 * dir;
        }
      }
    } else if (/head|neck|visor|helmet|face/.test(n)) {
      node.rotation.y = bp.rot[1] + (preset === 'idle' ? Math.sin(t * 1.4) * 0.12 : s * 0.08);
      node.rotation.x = bp.rot[0] + Math.sin(t * 2.6) * 0.05;
    } else if (/spine|torso|chest|hips|body/.test(n)) {
      node.rotation.y = bp.rot[1] + c * (swing * 0.14);
      node.rotation.z = bp.rot[2] + s * (swing * 0.06);
    } else if (/wheel|rotor|prop/.test(n)) {
      node.rotation.z = bp.rot[2] + t * 5.5;
    }
  });
}

export function applyObjectAnimationPreset(
  obj: THREE.Object3D,
  preset: ObjectAnimPreset,
  time: number,
  speed = 1
): void {
  if (preset === 'none') return;
  saveBasePoses(obj);
  const bp = obj.userData.basePose4D as
    | { pos: [number, number, number]; rot: [number, number, number]; scale: [number, number, number] }
    | undefined;
  if (!bp) return;

  const t = time * speed;
  if (preset === 'rotate-y') {
    obj.rotation.y = bp.rot[1] + t * 1.4;
  } else if (preset === 'orbit') {
    obj.position.x = bp.pos[0] + Math.cos(t * 1.2) * 1.6;
    obj.position.z = bp.pos[2] + Math.sin(t * 1.2) * 1.6;
    obj.rotation.y = bp.rot[1] - t * 1.2;
  } else if (preset === 'bounce') {
    obj.position.y = bp.pos[1] + Math.abs(Math.sin(t * 3.2)) * 0.85;
  } else if (preset === 'pulse-scale') {
    const f = 1 + Math.sin(t * 3.5) * 0.16;
    obj.scale.set(bp.scale[0] * f, bp.scale[1] * f, bp.scale[2] * f);
  } else if (preset === 'hover') {
    obj.position.y = bp.pos[1] + Math.sin(t * 2.2) * 0.25;
    obj.rotation.z = bp.rot[2] + Math.sin(t * 1.5) * 0.06;
  }
}

export function applyFacialRigState(root: THREE.Object3D, facial: FacialRigState): void {
  root.traverse((obj) => {
    if (obj instanceof THREE.Mesh && obj.morphTargetInfluences && obj.morphTargetDictionary) {
      const dict = obj.morphTargetDictionary;
      const setMorph = (keys: string[], val: number) => {
        for (const k of Object.keys(dict)) {
          if (keys.some((pattern) => k.toLowerCase().includes(pattern))) {
            obj.morphTargetInfluences![dict[k]] = val;
          }
        }
      };
      setMorph(['smile', 'happy', 'mouthsmile'], facial.smile);
      setMorph(['blink', 'eyeclose', 'eyeblink'], facial.blink);
      setMorph(['brow', 'eyebrow'], facial.browRaise);
      setMorph(['jaw', 'mouthopen', 'open'], facial.jawOpen);
      setMorph(['surprise', 'shock', 'wide'], facial.surprise);
    }

    // Fallback subtle articulation for procedural facial parts if named
    const n = obj.name.toLowerCase();
    const bp = obj.userData.basePose4D as
      | { pos: [number, number, number]; rot: [number, number, number]; scale: [number, number, number] }
      | undefined;
    if (!bp) return;

    if (/jaw|chin|mouth/.test(n)) {
      obj.rotation.x = bp.rot[0] + facial.jawOpen * 0.45 - facial.smile * 0.1;
    } else if (/eye|pupil/.test(n)) {
      obj.scale.y = Math.max(0.1, bp.scale[1] * (1 - facial.blink * 0.88 + facial.surprise * 0.2));
    } else if (/brow/.test(n)) {
      obj.position.y = bp.pos[1] + (facial.browRaise + facial.surprise * 0.7) * 0.08;
    }
  });
}

// ---------- Keyframe Evaluation Engine ----------
function interpolateValue(
  k1: Keyframe4D,
  k2: Keyframe4D,
  time: number
): number {
  if (k1.interpolation === 'step') return k1.value;
  const span = Math.max(0.0001, k2.time - k1.time);
  let t = Math.max(0, Math.min(1, (time - k1.time) / span));
  if (k1.interpolation === 'smooth') {
    t = t * t * (3 - 2 * t);
  }
  return k1.value + (k2.value - k1.value) * t;
}

export function evaluateKeyframes4D(
  keyframes: Keyframe4D[],
  root: THREE.Object3D,
  time: number
): void {
  if (keyframes.length === 0) return;

  const grouped = new Map<string, Keyframe4D[]>();
  for (const kf of keyframes) {
    const key = `${kf.objectUuid}::${kf.property}`;
    const arr = grouped.get(key) || [];
    arr.push(kf);
    grouped.set(key, arr);
  }

  for (const [compoundKey, list] of grouped.entries()) {
    list.sort((a, b) => a.time - b.time);
    const [uuid, prop] = compoundKey.split('::');
    const target = root.getObjectByProperty('uuid', uuid);
    if (!target) continue;

    let val = list[0].value;
    if (time <= list[0].time) {
      val = list[0].value;
    } else if (time >= list[list.length - 1].time) {
      val = list[list.length - 1].value;
    } else {
      for (let i = 0; i < list.length - 1; i++) {
        if (time >= list[i].time && time <= list[i + 1].time) {
          val = interpolateValue(list[i], list[i + 1], time);
          break;
        }
      }
    }

    switch (prop) {
      case 'position.x':
        target.position.x = val;
        break;
      case 'position.y':
        target.position.y = val;
        break;
      case 'position.z':
        target.position.z = val;
        break;
      case 'rotation.x':
        target.rotation.x = val;
        break;
      case 'rotation.y':
        target.rotation.y = val;
        break;
      case 'rotation.z':
        target.rotation.z = val;
        break;
      case 'scale.x':
        target.scale.x = Math.max(0.02, val);
        break;
      case 'scale.y':
        target.scale.y = Math.max(0.02, val);
        break;
      case 'scale.z':
        target.scale.z = Math.max(0.02, val);
        break;
      case 'material.metalness':
        if (target instanceof THREE.Mesh && !Array.isArray(target.material)) {
          const mat = target.material as THREE.MeshStandardMaterial;
          if ('metalness' in mat) mat.metalness = val;
        }
        break;
      case 'material.roughness':
        if (target instanceof THREE.Mesh && !Array.isArray(target.material)) {
          const mat = target.material as THREE.MeshStandardMaterial;
          if ('roughness' in mat) mat.roughness = val;
        }
        break;
      case 'material.emissiveIntensity':
        if (target instanceof THREE.Mesh && !Array.isArray(target.material)) {
          const mat = target.material as THREE.MeshStandardMaterial;
          if ('emissiveIntensity' in mat) mat.emissiveIntensity = val;
        }
        break;
    }
  }
}

// ---------- Experimental Mathematical 4D Hypercube / Orthoplex Projector ----------
const TESSERACT_VERTICES_4D: [number, number, number, number][] = [];
for (let i = 0; i < 16; i++) {
  TESSERACT_VERTICES_4D.push([
    i & 1 ? 1 : -1,
    i & 2 ? 1 : -1,
    i & 4 ? 1 : -1,
    i & 8 ? 1 : -1,
  ]);
}
const TESSERACT_EDGES: [number, number][] = [];
for (let i = 0; i < 16; i++) {
  for (let bit = 0; bit < 4; bit++) {
    const j = i ^ (1 << bit);
    if (i < j) TESSERACT_EDGES.push([i, j]);
  }
}

const CELL16_VERTICES_4D: [number, number, number, number][] = [
  [1.4, 0, 0, 0],
  [-1.4, 0, 0, 0],
  [0, 1.4, 0, 0],
  [0, -1.4, 0, 0],
  [0, 0, 1.4, 0],
  [0, 0, -1.4, 0],
  [0, 0, 0, 1.4],
  [0, 0, 0, -1.4],
];
const CELL16_EDGES: [number, number][] = [];
for (let i = 0; i < 8; i++) {
  for (let j = i + 1; j < 8; j++) {
    if (Math.floor(i / 2) !== Math.floor(j / 2)) {
      CELL16_EDGES.push([i, j]);
    }
  }
}

export function createHyper4DObject(): THREE.LineSegments {
  const maxEdges = Math.max(TESSERACT_EDGES.length, CELL16_EDGES.length);
  const positions = new Float32Array(maxEdges * 2 * 3);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const mat = new THREE.LineBasicMaterial({
    color: 0xe11d48,
    transparent: true,
    opacity: 0.9,
  });
  const lines = new THREE.LineSegments(geo, mat);
  lines.name = 'Math_4D_Projection';
  lines.position.set(0, 1.6, 0);
  lines.userData.isEditorHelper = true;
  lines.frustumCulled = false;
  return lines;
}

export function updateHyper4DObject(
  lines: THREE.LineSegments,
  config: Hyper4DConfig,
  elapsedTime: number
): void {
  lines.visible = config.enabled;
  if (!config.enabled) return;

  const mat = lines.material as THREE.LineBasicMaterial;
  mat.color.set(config.color || '#E11D48');

  const verts = config.shape === '16-cell' ? CELL16_VERTICES_4D : TESSERACT_VERTICES_4D;
  const edges = config.shape === '16-cell' ? CELL16_EDGES : TESSERACT_EDGES;

  const xw = config.wAngleXW + elapsedTime * config.spin4DSpeed;
  const yw = config.wAngleYW + elapsedTime * config.spin4DSpeed * 0.65;
  const zw = config.wAngleZW;

  const cosXW = Math.cos(xw), sinXW = Math.sin(xw);
  const cosYW = Math.cos(yw), sinYW = Math.sin(yw);
  const cosZW = Math.cos(zw), sinZW = Math.sin(zw);

  const projected: [number, number, number][] = verts.map(([vx, vy, vz, vw]) => {
    // 4D XW rotation
    const x1 = vx * cosXW - vw * sinXW;
    const w1 = vx * sinXW + vw * cosXW;
    // 4D YW rotation
    const y2 = vy * cosYW - w1 * sinYW;
    const w2 = vy * sinYW + w1 * cosYW;
    // 4D ZW rotation
    const z3 = vz * cosZW - w2 * sinZW;
    const w3 = vz * sinZW + w2 * cosZW;

    const wDist = Math.max(1.35, 3.0 - (w3 + config.wSlice));
    const factor = 2.2 / wDist;
    return [x1 * factor, y2 * factor, z3 * factor];
  });

  const attr = lines.geometry.getAttribute('position') as THREE.BufferAttribute;
  const arr = attr.array as Float32Array;
  arr.fill(0);
  let idx = 0;
  for (const [a, b] of edges) {
    const pa = projected[a];
    const pb = projected[b];
    arr[idx++] = pa[0];
    arr[idx++] = pa[1];
    arr[idx++] = pa[2];
    arr[idx++] = pb[0];
    arr[idx++] = pb[1];
    arr[idx++] = pb[2];
  }
  lines.geometry.setDrawRange(0, edges.length * 2);
  attr.needsUpdate = true;
}

// ---------- GPU Particle System ----------
const MAX_PARTICLES = 600;

export function createParticleSystem4D(): THREE.Points {
  const positions = new Float32Array(MAX_PARTICLES * 3);
  const velocities = new Float32Array(MAX_PARTICLES * 3);

  for (let i = 0; i < MAX_PARTICLES; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 6;
    positions[i * 3 + 1] = Math.random() * 4;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 6;
    velocities[i * 3] = (Math.random() - 0.5) * 0.4;
    velocities[i * 3 + 1] = 0.5 + Math.random();
    velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.4;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const mat = new THREE.PointsMaterial({
    color: 0xe11d48,
    size: 0.08,
    transparent: true,
    opacity: 0.85,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });

  const pts = new THREE.Points(geo, mat);
  pts.name = 'Particle_Emitter_4D';
  pts.userData.velocities = velocities;
  pts.userData.isEditorHelper = true;
  pts.frustumCulled = false;
  return pts;
}

export function stepParticleSystem4D(
  pts: THREE.Points,
  cfg: ParticleConfig4D,
  dt: number
): void {
  pts.visible = cfg.enabled && cfg.preset !== 'none';
  if (!pts.visible) return;

  const mat = pts.material as THREE.PointsMaterial;
  mat.size = cfg.size;
  mat.color.set(
    cfg.preset === 'fire-embers'
      ? '#FB923C'
      : cfg.preset === 'cyber-rain'
      ? '#38BDF8'
      : cfg.preset === 'volumetric-smoke'
      ? '#9F1239'
      : cfg.color || '#E11D48'
  );
  mat.opacity = cfg.preset === 'volumetric-smoke' ? 0.35 : 0.85;

  const count = Math.min(MAX_PARTICLES, Math.max(20, cfg.count));
  pts.geometry.setDrawRange(0, count);

  const attr = pts.geometry.getAttribute('position') as THREE.BufferAttribute;
  const pos = attr.array as Float32Array;
  const vel = pts.userData.velocities as Float32Array;

  const stepDt = Math.min(0.05, dt) * cfg.speed;

  for (let i = 0; i < count; i++) {
    const i3 = i * 3;
    if (cfg.preset === 'cyber-rain') {
      pos[i3 + 1] -= 4.5 * stepDt;
      pos[i3] += Math.sin(i + pos[i3 + 1]) * cfg.turbulence * 0.05 * stepDt;
      if (pos[i3 + 1] < 0) {
        pos[i3 + 1] = 4.2;
        pos[i3] = (Math.random() - 0.5) * 6;
        pos[i3 + 2] = (Math.random() - 0.5) * 6;
      }
    } else if (cfg.preset === 'stardust') {
      const angle = stepDt * 0.7;
      const x = pos[i3];
      const z = pos[i3 + 2];
      pos[i3] = x * Math.cos(angle) - z * Math.sin(angle);
      pos[i3 + 2] = x * Math.sin(angle) + z * Math.cos(angle);
      pos[i3 + 1] += Math.sin(i + x) * 0.25 * stepDt;
    } else {
      // Sparks / Smoke / Embers rise upward with turbulence
      pos[i3] += (vel[i3] + Math.sin(pos[i3 + 1] * 2 + i) * cfg.turbulence * 0.4) * stepDt;
      pos[i3 + 1] += vel[i3 + 1] * stepDt;
      pos[i3 + 2] += (vel[i3 + 2] + Math.cos(pos[i3 + 1] * 2 + i) * cfg.turbulence * 0.4) * stepDt;

      if (pos[i3 + 1] > 4.2 || Math.abs(pos[i3]) > 4 || Math.abs(pos[i3 + 2]) > 4) {
        pos[i3] = (Math.random() - 0.5) * 2.2;
        pos[i3 + 1] = 0.05;
        pos[i3 + 2] = (Math.random() - 0.5) * 2.2;
      }
    }
  }
  attr.needsUpdate = true;
}

// ---------- Rigid-Body Physics Simulation Solver ----------
export interface PhysicsBodyState {
  vx: number;
  vy: number;
  vz: number;
  angularY: number;
}

export function stepPhysicsSimulation4D(
  sceneRoot: THREE.Object3D,
  cfg: PhysicsConfig4D,
  bodies: Map<string, PhysicsBodyState>,
  dt: number
): void {
  if (!cfg.enabled) return;
  const h = Math.min(0.04, dt);

  for (const child of sceneRoot.children) {
    if (child.userData?.isEditorHelper || child.userData?.physicsStatic) continue;

    let state = bodies.get(child.uuid);
    if (!state) {
      state = { vx: 0, vy: 0, vz: 0, angularY: 0 };
      bodies.set(child.uuid, state);
    }

    // Apply gravity & wind
    state.vy -= cfg.gravity * h;
    state.vx += cfg.windX * h;

    // Air drag
    const damp = Math.max(0, 1 - cfg.drag * h);
    state.vx *= damp;
    state.vy *= damp;
    state.vz *= damp;

    child.position.x += state.vx * h;
    child.position.y += state.vy * h;
    child.position.z += state.vz * h;
    child.rotation.y += state.angularY * h;

    // Ground plane collision
    _tempBox.setFromObject(child);
    const bottomY = Number.isFinite(_tempBox.min.y) ? _tempBox.min.y : child.position.y;
    if (bottomY < cfg.floorY) {
      const penetration = cfg.floorY - bottomY;
      child.position.y += penetration;
      if (state.vy < 0) {
        state.vy = -state.vy * cfg.restitution;
        if (Math.abs(state.vy) < 0.12) state.vy = 0;
        state.vx *= 0.88;
        state.vz *= 0.88;
      }
    }
  }
}

// ---------- Mesh, UV & Texture Editing Operations ----------
export function applyVertexNoiseSculpt(mesh: THREE.Mesh, amount = 0.06): void {
  const geo = mesh.geometry;
  const pos = geo.getAttribute('position');
  if (!pos) return;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    const wave = Math.sin(x * 7 + y * 5 + z * 9) * amount;
    pos.setXYZ(i, x * (1 + wave), y * (1 + wave), z * (1 + wave));
  }
  pos.needsUpdate = true;
  geo.computeVertexNormals();
  geo.computeBoundingSphere();
}

export function applyBoxUVProjection(mesh: THREE.Mesh): void {
  const geo = mesh.geometry;
  const pos = geo.getAttribute('position');
  if (!pos) return;
  const uvs = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    uvs[i * 2] = (x + z) * 0.5 + 0.5;
    uvs[i * 2 + 1] = y * 0.5 + 0.5;
  }
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
}

export function applyProceduralFinishTexture(
  mesh: THREE.Mesh,
  finish: 'none' | 'brushed-metal' | 'carbon-weave' | 'grid' | 'checker',
  colorHex: string
): void {
  const applyToMat = (mat: THREE.Material) => {
    if (!(mat instanceof THREE.MeshStandardMaterial)) return;
    if (finish === 'none') {
      mat.map = null;
      mat.needsUpdate = true;
      return;
    }
    const size = 256;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = colorHex || '#E11D48';
    ctx.fillRect(0, 0, size, size);

    if (finish === 'brushed-metal') {
      for (let y = 0; y < size; y += 2) {
        ctx.fillStyle = y % 4 === 0 ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.14)';
        ctx.fillRect(0, y, size, 1);
      }
    } else if (finish === 'carbon-weave') {
      for (let y = 0; y < size; y += 16) {
        for (let x = 0; x < size; x += 16) {
          ctx.fillStyle = (x + y) % 32 === 0 ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.28)';
          ctx.fillRect(x, y, 8, 8);
        }
      }
    } else if (finish === 'grid') {
      ctx.strokeStyle = 'rgba(255,255,255,0.35)';
      ctx.lineWidth = 2;
      for (let i = 0; i <= size; i += 32) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, size);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(size, i);
        ctx.stroke();
      }
    } else if (finish === 'checker') {
      for (let y = 0; y < size; y += 32) {
        for (let x = 0; x < size; x += 32) {
          if (((x + y) / 32) % 2 === 0) {
            ctx.fillStyle = 'rgba(0,0,0,0.35)';
            ctx.fillRect(x, y, 32, 32);
          }
        }
      }
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(2, 2);
    mat.map = tex;
    mat.needsUpdate = true;
  };

  if (Array.isArray(mesh.material)) mesh.material.forEach(applyToMat);
  else if (mesh.material) applyToMat(mesh.material);
}

export async function applyImageFileAsTexture(mesh: THREE.Mesh, file: File): Promise<void> {
  const url = URL.createObjectURL(file);
  const tex = await new Promise<THREE.Texture>((resolve, reject) => {
    new THREE.TextureLoader().load(
      url,
      (loaded) => {
        loaded.colorSpace = THREE.SRGBColorSpace;
        loaded.wrapS = THREE.RepeatWrapping;
        loaded.wrapT = THREE.RepeatWrapping;
        resolve(loaded);
      },
      undefined,
      reject
    );
  });

  const setMap = (mat: THREE.Material) => {
    if (mat instanceof THREE.MeshStandardMaterial) {
      mat.map = tex;
      mat.needsUpdate = true;
    }
  };

  if (Array.isArray(mesh.material)) mesh.material.forEach(setMap);
  else if (mesh.material) setMap(mesh.material);
}

// ---------- Multi-Format Exporters (GLB / GLTF / FBX / OBJ) ----------
export function export4DToGLB(
  root: THREE.Object3D,
  animations: THREE.AnimationClip[] = []
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const exporter = new GLTFExporter();
    exporter.parse(
      root,
      (res) => {
        if (res instanceof ArrayBuffer) {
          resolve(new Blob([res], { type: 'model/gltf-binary' }));
        } else {
          resolve(new Blob([JSON.stringify(res, null, 2)], { type: 'model/gltf+json' }));
        }
      },
      reject,
      { binary: true, animations }
    );
  });
}

export function export4DToGLTF(
  root: THREE.Object3D,
  animations: THREE.AnimationClip[] = []
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const exporter = new GLTFExporter();
    exporter.parse(
      root,
      (res) => {
        resolve(new Blob([JSON.stringify(res, null, 2)], { type: 'model/gltf+json' }));
      },
      reject,
      { binary: false, animations }
    );
  });
}

export function export4DToOBJ(root: THREE.Object3D): Blob {
  const exporter = new OBJExporter();
  const txt = exporter.parse(root);
  return new Blob([txt], { type: 'text/plain;charset=utf-8' });
}

/**
 * Generates an Autodesk FBX 7.4 ASCII file preserving mesh vertices, polygon indices,
 * normals, UVs, and transforms cleanly for compatibility with Blender/Maya/Unreal/Unity.
 */
export function export4DToFBXAscii(root: THREE.Object3D): Blob {
  const meshes: THREE.Mesh[] = [];
  root.updateMatrixWorld(true);
  root.traverse((obj) => {
    if (obj instanceof THREE.Mesh && obj.geometry && !obj.userData?.isEditorHelper) {
      meshes.push(obj);
    }
  });

  const defs: string[] = [];
  const objs: string[] = [];
  const conns: string[] = [];

  let nextId = 100000;
  for (const mesh of meshes) {
    const geoId = nextId++;
    const modelId = nextId++;
    const matId = nextId++;

    const geo = mesh.geometry;
    const pos = geo.getAttribute('position');
    const norm = geo.getAttribute('normal');
    const uv = geo.getAttribute('uv');
    const idxAttr = geo.getIndex();

    const verts: number[] = [];
    for (let i = 0; i < pos.count; i++) {
      _tempVec.set(pos.getX(i), pos.getY(i), pos.getZ(i));
      verts.push(
        Number(_tempVec.x.toFixed(5)),
        Number(_tempVec.y.toFixed(5)),
        Number(_tempVec.z.toFixed(5))
      );
    }

    const polyIndices: number[] = [];
    if (idxAttr) {
      for (let i = 0; i < idxAttr.count; i += 3) {
        polyIndices.push(idxAttr.getX(i), idxAttr.getX(i + 1), -(idxAttr.getX(i + 2) + 1));
      }
    } else {
      for (let i = 0; i < pos.count; i += 3) {
        polyIndices.push(i, i + 1, -(i + 2 + 1));
      }
    }

    const normalFloats: number[] = [];
    if (norm) {
      for (let i = 0; i < norm.count; i++) {
        normalFloats.push(
          Number(norm.getX(i).toFixed(4)),
          Number(norm.getY(i).toFixed(4)),
          Number(norm.getZ(i).toFixed(4))
        );
      }
    }

    const uvFloats: number[] = [];
    if (uv) {
      for (let i = 0; i < uv.count; i++) {
        uvFloats.push(Number(uv.getX(i).toFixed(4)), Number(uv.getY(i).toFixed(4)));
      }
    }

    const safeName = (mesh.name || `Mesh_${modelId}`).replace(/[^a-zA-Z0-9_]/g, '_');
    const matColor =
      !Array.isArray(mesh.material) && mesh.material instanceof THREE.MeshStandardMaterial
        ? mesh.material.color
        : new THREE.Color('#E11D48');

    objs.push(`
  Geometry: ${geoId}, "Geometry::${safeName}", "Mesh" {
    Vertices: *${verts.length} {
      a: ${verts.join(',')}
    }
    PolygonVertexIndex: *${polyIndices.length} {
      a: ${polyIndices.join(',')}
    }
    ${
      normalFloats.length > 0
        ? `LayerElementNormal: 0 {
      Version: 101
      MappingInformationType: "ByVertice"
      ReferenceInformationType: "Direct"
      Normals: *${normalFloats.length} {
        a: ${normalFloats.join(',')}
      }
    }`
        : ''
    }
    ${
      uvFloats.length > 0
        ? `LayerElementUV: 0 {
      Version: 101
      MappingInformationType: "ByVertice"
      ReferenceInformationType: "Direct"
      UV: *${uvFloats.length} {
        a: ${uvFloats.join(',')}
      }
    }`
        : ''
    }
  }
  Model: ${modelId}, "Model::${safeName}", "Mesh" {
    Version: 232
    Properties70: {
      P: "Lcl Translation", "Lcl Translation", "", "A",${mesh.position.x.toFixed(4)},${mesh.position.y.toFixed(4)},${mesh.position.z.toFixed(4)}
      P: "Lcl Rotation", "Lcl Rotation", "", "A",${THREE.MathUtils.radToDeg(mesh.rotation.x).toFixed(3)},${THREE.MathUtils.radToDeg(mesh.rotation.y).toFixed(3)},${THREE.MathUtils.radToDeg(mesh.rotation.z).toFixed(3)}
      P: "Lcl Scaling", "Lcl Scaling", "", "A",${mesh.scale.x.toFixed(4)},${mesh.scale.y.toFixed(4)},${mesh.scale.z.toFixed(4)}
    }
  }
  Material: ${matId}, "Material::${safeName}_Mat", "" {
    Version: 102
    Properties70: {
      P: "DiffuseColor", "Color", "", "A",${matColor.r.toFixed(4)},${matColor.g.toFixed(4)},${matColor.b.toFixed(4)}
    }
  }`);

    conns.push(`  C: "OO",${geoId},${modelId}`);
    conns.push(`  C: "OO",${matId},${modelId}`);
    conns.push(`  C: "OO",${modelId},0`);
  }

  defs.push(`  ObjectType: "Geometry" { Count: ${meshes.length} }`);
  defs.push(`  ObjectType: "Model" { Count: ${meshes.length} }`);
  defs.push(`  ObjectType: "Material" { Count: ${meshes.length} }`);

  const fbxText = `; FBX 7.4.0 project file
; Generated by RED EFFECT 4D Studio
FBXHeaderExtension: {
  FBXHeaderVersion: 1003
  FBXVersion: 7400
  Creator: "RED EFFECT 4D Studio"
}
Definitions: {
${defs.join('\n')}
}
Objects: {
${objs.join('\n')}
}
Connections: {
${conns.join('\n')}
}
`;
  return new Blob([fbxText], { type: 'text/plain;charset=utf-8' });
}
