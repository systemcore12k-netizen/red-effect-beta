import {
  EffectDefinition,
  ReadyMadeCategoryId,
  ReadyMadeEffectPreset,
  TextAnimationEffect,
  TransitionDefinition,
  TransitionSettings,
} from '../types/effects';
import { TextProperties } from '../types/studio';
import { createEffectInstance } from './effectsCatalog';

const MAX_HOVER_SNAPSHOTS = 18;

class HoverPreviewCache {
  private map = new Map<string, HTMLCanvasElement>();

  get(key: string): HTMLCanvasElement | null {
    const hit = this.map.get(key);
    if (!hit) return null;
    // Promote LRU
    this.map.delete(key);
    this.map.set(key, hit);
    return hit;
  }

  set(key: string, sourceCanvas: HTMLCanvasElement): void {
    if (typeof document === 'undefined') return;
    if (this.map.has(key)) {
      this.map.delete(key);
    } else if (this.map.size >= MAX_HOVER_SNAPSHOTS) {
      const oldestKey = this.map.keys().next().value;
      if (oldestKey) this.map.delete(oldestKey);
    }
    const copy = document.createElement('canvas');
    copy.width = sourceCanvas.width;
    copy.height = sourceCanvas.height;
    const cctx = copy.getContext('2d');
    if (cctx) {
      cctx.drawImage(sourceCanvas, 0, 0);
      this.map.set(key, copy);
    }
  }

  clear(): void {
    this.map.clear();
  }
}

export const hoverPreviewCache = new HoverPreviewCache();

export function clearHoverPreviewCache(): void {
  hoverPreviewCache.clear();
}

const ANIMATED_EFFECT_TYPES = new Set([
  'camera-shake',
  'glitch',
  'rgb-glitch',
  'rgb-flash',
  'digital-distortion',
  'pixel-sort',
  'scanlines',
  'vhs-glitch',
  'crt-flicker',
  'bad-tv',
  'signal-drop',
  'datamosh',
  'wave-warp',
  'ripple',
  'turbulent-displace',
  'light-leak',
  'film-grain',
  'strobe-flash',
  'shake-pulse',
]);

export function isHoverPresetAnimated(preset: ReadyMadeEffectPreset | null | undefined): boolean {
  if (!preset) return false;
  if (preset.category === 'shake' || preset.category === 'glitch' || preset.category === 'transition') {
    return true;
  }
  if (preset.transitionConfig || preset.textPreset) {
    return true;
  }
  if (preset.effectsStack && preset.effectsStack.length > 0) {
    return preset.effectsStack.some((fx) => ANIMATED_EFFECT_TYPES.has(fx.type));
  }
  return false;
}

export function catalogEffectToHoverPreset(ef: EffectDefinition): ReadyMadeEffectPreset | null {
  const inst = createEffectInstance(ef.type);
  if (!inst) return null;
  const catMap: Record<string, ReadyMadeCategoryId> = {
    shake: 'shake',
    glitch: 'glitch',
    blur: 'blur',
    distortion: 'distortion',
    color: 'rgb',
    glow: 'cinematic',
    shadow: 'cinematic',
    texture: 'cinematic',
    stylize: 'cinematic',
  };
  return {
    id: `__catalog_hover_${ef.type}`,
    name: ef.name,
    category: catMap[ef.category] || 'cinematic',
    description: ef.description,
    accentColor: '#E50914',
    defaultDuration: 2.2,
    effectsStack: [inst],
  };
}

export function transitionDefToHoverPreset(
  def: TransitionDefinition,
  settings?: TransitionSettings
): ReadyMadeEffectPreset {
  const cfg = settings || def.defaultSettings;
  return {
    id: `__trans_hover_${def.type}_${cfg.direction}_${cfg.duration.toFixed(2)}`,
    name: def.name,
    category: 'transition',
    description: def.description,
    accentColor: '#10B981',
    defaultDuration: Math.max(0.45, cfg.duration || 0.7),
    transitionConfig: cfg,
  };
}

export function textStyleToHoverPreset(
  id: string,
  name: string,
  animation: TextAnimationEffect,
  overrides?: Partial<TextProperties>
): ReadyMadeEffectPreset {
  return {
    id: `__text_hover_${id}`,
    name,
    category: 'text',
    description: `${name} kinetic typography style`,
    accentColor: '#F59E0B',
    defaultDuration: 1.8,
    textPreset: {
      animation,
      effectSpeed: overrides?.effectSpeed ?? 1.1,
      effectIntensity: overrides?.effectIntensity ?? 85,
      effectDuration: overrides?.effectDuration ?? 1.1,
      effectDirection: overrides?.effectDirection ?? 'center',
      animationStrength: overrides?.animationStrength ?? 95,
      fontWeight: overrides?.fontWeight ?? 800,
      color: overrides?.color,
      strokeColor: overrides?.strokeColor,
      strokeWidth: overrides?.strokeWidth,
      shadowBlur: overrides?.shadowBlur,
      shadowColor: overrides?.shadowColor,
      extrude3D: overrides?.extrude3D,
      extrudeDepth: overrides?.extrudeDepth,
      letterSpacing: overrides?.letterSpacing,
      gradientEnabled: overrides?.gradientEnabled,
      gradientStart: overrides?.gradientStart,
      gradientEnd: overrides?.gradientEnd,
    },
  };
}
