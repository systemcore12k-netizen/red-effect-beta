import {
  AdvancedTransitionType,
  EffectBlendMode,
  EffectCategoryId,
  EffectDefinition,
  EffectInstance,
  EffectParamSchema,
  StudioPreset,
  TransitionCategoryId,
  TransitionDefinition,
  TransitionSettings,
} from '../types/effects';

export const EFFECT_CATEGORIES: Array<{ id: EffectCategoryId; label: string }> = [
  { id: 'blur', label: 'Blur Effects' },
  { id: 'glow', label: 'Glow & Light' },
  { id: 'color', label: 'Color Effects' },
  { id: 'distortion', label: 'Distortion' },
  { id: 'glitch', label: 'Glitch Effects' },
  { id: 'shadow', label: 'Shadow Effects' },
  { id: 'texture', label: 'Texture & Noise' },
  { id: 'stylize', label: 'Stylize Effects' },
  { id: 'shake', label: 'Shake Effects' },
];

export const TRANSITION_CATEGORIES: Array<{ id: TransitionCategoryId; label: string }> = [
  { id: 'basic', label: 'Basic' },
  { id: 'motion', label: 'Motion' },
  { id: 'cinematic', label: 'Cinematic' },
  { id: 'mask', label: 'Mask' },
  { id: 'advanced', label: 'Advanced' },
];

const BLEND_OPTIONS: Array<{ value: EffectBlendMode; label: string }> = [
  { value: 'normal', label: 'Normal' },
  { value: 'screen', label: 'Screen' },
  { value: 'add', label: 'Add (Linear Dodge)' },
  { value: 'overlay', label: 'Overlay' },
  { value: 'multiply', label: 'Multiply' },
  { value: 'soft-light', label: 'Soft Light' },
];

function numParam(
  key: string,
  label: string,
  defaultValue: number,
  min: number,
  max: number,
  step = 1,
  unit = ''
): EffectParamSchema {
  return { key, label, type: 'slider', defaultValue, min, max, step, unit };
}

function colorParam(key: string, label: string, defaultValue: string): EffectParamSchema {
  return { key, label, type: 'color', defaultValue };
}

function boolParam(key: string, label: string, defaultValue: boolean): EffectParamSchema {
  return { key, label, type: 'boolean', defaultValue };
}

function selectParam(
  key: string,
  label: string,
  defaultValue: string,
  options: Array<{ value: string; label: string }>
): EffectParamSchema {
  return { key, label, type: 'select', defaultValue, options };
}

export const EFFECTS_CATALOG: EffectDefinition[] = [
  // ======================== BLUR EFFECTS (9) ========================
  {
    type: 'gaussian-blur',
    name: 'Gaussian Blur',
    category: 'blur',
    description: 'Smooth optical defocus with directional H/V weights',
    params: [
      numParam('amount', 'Blur Amount', 10, 0, 60, 0.5, 'px'),
      numParam('horizontal', 'Horizontal Blur', 100, 0, 200, 1, '%'),
      numParam('vertical', 'Vertical Blur', 100, 0, 200, 1, '%'),
      selectParam('quality', 'Quality', 'high', [
        { value: 'draft', label: 'Draft' },
        { value: 'medium', label: 'Medium' },
        { value: 'high', label: 'High' },
      ]),
      boolParam('repeatEdge', 'Repeat Edge Pixels', true),
    ],
  },
  {
    type: 'motion-blur',
    name: 'Motion Blur',
    category: 'blur',
    description: 'Multi-sample directional shutter blur',
    params: [
      numParam('shutterAngle', 'Shutter Angle', 180, 0, 360, 5, '°'),
      numParam('samples', 'Samples', 8, 2, 16, 1),
      numParam('amount', 'Blur Amount', 18, 0, 60, 1, 'px'),
      numParam('direction', 'Direction', 0, -180, 180, 1, '°'),
    ],
  },
  {
    type: 'directional-blur',
    name: 'Directional Blur',
    category: 'blur',
    description: 'Linear smear along a chosen angle',
    params: [
      numParam('length', 'Blur Length', 16, 0, 60, 1, 'px'),
      numParam('angle', 'Direction Angle', 35, -180, 180, 1, '°'),
      numParam('samples', 'Samples', 8, 2, 16, 1),
    ],
  },
  {
    type: 'radial-blur',
    name: 'Radial Blur',
    category: 'blur',
    description: 'Rotational spin blur around anchor point',
    params: [
      numParam('amount', 'Spin Amount', 14, 0, 45, 1, '°'),
      numParam('centerX', 'Center X', 50, 0, 100, 1, '%'),
      numParam('centerY', 'Center Y', 50, 0, 100, 1, '%'),
      numParam('samples', 'Samples', 8, 3, 14, 1),
    ],
  },
  {
    type: 'zoom-blur',
    name: 'Zoom Blur',
    category: 'blur',
    description: 'High-speed radial burst from focal point',
    params: [
      numParam('strength', 'Zoom Strength', 28, 0, 100, 1, '%'),
      numParam('centerX', 'Focal X', 50, 0, 100, 1, '%'),
      numParam('centerY', 'Focal Y', 50, 0, 100, 1, '%'),
      numParam('samples', 'Samples', 8, 3, 14, 1),
    ],
  },
  {
    type: 'lens-blur',
    name: 'Lens Blur',
    category: 'blur',
    description: 'Cinema iris depth-of-field defocus',
    params: [
      numParam('radius', 'Iris Radius', 10, 0, 40, 0.5, 'px'),
      numParam('bladeCurvature', 'Highlight Bloom', 40, 0, 100, 1, '%'),
      numParam('threshold', 'Specular Threshold', 180, 50, 255, 1),
    ],
  },
  {
    type: 'box-blur',
    name: 'Box Blur',
    category: 'blur',
    description: 'Fast uniform kernel blur',
    params: [
      numParam('radius', 'Box Radius', 6, 0, 30, 1, 'px'),
      numParam('iterations', 'Iterations', 2, 1, 4, 1),
    ],
  },
  {
    type: 'edge-blur',
    name: 'Edge Blur',
    category: 'blur',
    description: 'Selectively soften high-contrast edges',
    params: [
      numParam('amount', 'Edge Blur', 8, 0, 25, 0.5, 'px'),
      numParam('threshold', 'Edge Threshold', 35, 5, 120, 1),
    ],
  },
  {
    type: 'bokeh-blur',
    name: 'Bokeh Blur',
    category: 'blur',
    description: 'Disc bokeh specular highlights with soft field',
    params: [
      numParam('amount', 'Defocus', 8, 0, 32, 0.5, 'px'),
      numParam('bokehGain', 'Bokeh Glow', 55, 0, 100, 1, '%'),
      numParam('threshold', 'Highlight Threshold', 190, 80, 255, 1),
    ],
  },

  // ======================== GLOW & LIGHT EFFECTS (10) ========================
  {
    type: 'glow',
    name: 'Glow',
    category: 'glow',
    description: 'Radiant luminance threshold bloom',
    params: [
      numParam('intensity', 'Glow Intensity', 65, 0, 200, 1, '%'),
      numParam('radius', 'Glow Radius', 20, 1, 80, 1, 'px'),
      numParam('threshold', 'Glow Threshold', 140, 0, 255, 1),
      colorParam('color', 'Glow Color', '#E50914'),
      selectParam('blend', 'Blend Mode', 'screen', BLEND_OPTIONS),
    ],
  },
  {
    type: 'inner-glow',
    name: 'Inner Glow',
    category: 'glow',
    description: 'Soft luminous vignette inside layer bounds',
    params: [
      numParam('intensity', 'Intensity', 55, 0, 150, 1, '%'),
      numParam('size', 'Glow Size', 45, 5, 100, 1, '%'),
      colorParam('color', 'Glow Color', '#E50914'),
    ],
  },
  {
    type: 'outer-glow',
    name: 'Outer Glow',
    category: 'glow',
    description: 'Exterior atmospheric halo around alpha/frame',
    params: [
      numParam('intensity', 'Intensity', 70, 0, 200, 1, '%'),
      numParam('spread', 'Spread Radius', 26, 2, 80, 1, 'px'),
      colorParam('color', 'Halo Color', '#FF3B30'),
    ],
  },
  {
    type: 'neon-glow',
    name: 'Neon Glow',
    category: 'glow',
    description: 'High-saturation edge neon tube radiance',
    params: [
      numParam('intensity', 'Tube Power', 85, 0, 200, 1, '%'),
      numParam('radius', 'Spread', 18, 2, 60, 1, 'px'),
      colorParam('color', 'Neon Color', '#FF1E42'),
      numParam('edgeBoost', 'Edge Boost', 60, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'light-rays',
    name: 'Light Rays',
    category: 'glow',
    description: 'Volumetric directional sun/spotlight shafts',
    params: [
      numParam('intensity', 'Ray Intensity', 65, 0, 150, 1, '%'),
      numParam('length', 'Ray Length', 55, 10, 100, 1, '%'),
      numParam('sourceX', 'Source X', 50, 0, 100, 1, '%'),
      numParam('sourceY', 'Source Y', 20, 0, 100, 1, '%'),
      colorParam('color', 'Ray Color', '#FFD6A5'),
    ],
  },
  {
    type: 'lens-flare',
    name: 'Lens Flare',
    category: 'glow',
    description: 'Anamorphic optical flare & chromatic ghosts',
    params: [
      numParam('brightness', 'Flare Brightness', 70, 0, 150, 1, '%'),
      numParam('sourceX', 'Light X', 28, 0, 100, 1, '%'),
      numParam('sourceY', 'Light Y', 24, 0, 100, 1, '%'),
      numParam('anamorphic', 'Anamorphic Streak', 75, 0, 100, 1, '%'),
      colorParam('color', 'Tint Color', '#E50914'),
    ],
  },
  {
    type: 'light-leak',
    name: 'Light Leak',
    category: 'glow',
    description: 'Warm organic 35mm film gate leak wash',
    params: [
      numParam('intensity', 'Leak Opacity', 55, 0, 100, 1, '%'),
      numParam('angle', 'Angle', 35, 0, 360, 1, '°'),
      colorParam('primaryColor', 'Primary Leak', '#E50914'),
      colorParam('secondaryColor', 'Warm Edge', '#FF9F1C'),
    ],
  },
  {
    type: 'bloom',
    name: 'Bloom',
    category: 'glow',
    description: 'Filmic specular highlight halation',
    params: [
      numParam('intensity', 'Bloom Amount', 60, 0, 180, 1, '%'),
      numParam('radius', 'Softness', 28, 4, 80, 1, 'px'),
      numParam('threshold', 'Threshold', 175, 50, 250, 1),
    ],
  },
  {
    type: 'god-rays',
    name: 'God Rays',
    category: 'glow',
    description: 'Atmospheric volumetric crepuscular beams',
    params: [
      numParam('intensity', 'Density', 70, 0, 150, 1, '%'),
      numParam('sourceX', 'Origin X', 50, 0, 100, 1, '%'),
      numParam('sourceY', 'Origin Y', 10, 0, 100, 1, '%'),
      numParam('rayCount', 'Beam Count', 7, 3, 14, 1),
      colorParam('color', 'Beam Color', '#FDE68A'),
    ],
  },
  {
    type: 'light-streaks',
    name: 'Light Streaks',
    category: 'glow',
    description: 'Horizontal cinema specular light trails',
    params: [
      numParam('intensity', 'Intensity', 70, 0, 150, 1, '%'),
      numParam('length', 'Streak Width', 45, 5, 100, 1, '%'),
      numParam('angle', 'Streak Angle', 0, -90, 90, 1, '°'),
      colorParam('color', 'Streak Tint', '#E50914'),
    ],
  },

  // ======================== COLOR EFFECTS (14) ========================
  {
    type: 'brightness',
    name: 'Brightness',
    category: 'color',
    description: 'Linear luminance gain adjustment',
    params: [numParam('value', 'Brightness', 15, -100, 100, 1, '%')],
  },
  {
    type: 'contrast',
    name: 'Contrast',
    category: 'color',
    description: 'S-curve tonal contrast multiplier',
    params: [numParam('value', 'Contrast', 22, -100, 100, 1, '%')],
  },
  {
    type: 'exposure',
    name: 'Exposure',
    category: 'color',
    description: 'Photographic EV stop exposure shift',
    params: [
      numParam('ev', 'Exposure (EV)', 0.4, -3, 3, 0.05, 'EV'),
      numParam('gamma', 'Gamma', 1, 0.4, 2.2, 0.05),
    ],
  },
  {
    type: 'saturation',
    name: 'Saturation',
    category: 'color',
    description: 'Color vibrancy and chroma intensity',
    params: [numParam('value', 'Saturation', 25, -100, 100, 1, '%')],
  },
  {
    type: 'hue',
    name: 'Hue Shift',
    category: 'color',
    description: 'Rotate chromatic hue spectrum',
    params: [numParam('angle', 'Hue Angle', 24, -180, 180, 1, '°')],
  },
  {
    type: 'color-balance',
    name: 'Color Balance',
    category: 'color',
    description: 'RGB split toning across shadows & highlights',
    params: [
      numParam('red', 'Red Balance', 12, -100, 100, 1),
      numParam('green', 'Green Balance', 0, -100, 100, 1),
      numParam('blue', 'Blue Balance', -8, -100, 100, 1),
    ],
  },
  {
    type: 'color-correction',
    name: 'Color Correction',
    category: 'color',
    description: 'Primary Lift / Gamma / Gain balancing',
    params: [
      numParam('lift', 'Lift (Shadows)', -6, -50, 50, 1),
      numParam('gamma', 'Gamma (Midtones)', 4, -50, 50, 1),
      numParam('gain', 'Gain (Highlights)', 8, -50, 50, 1),
      numParam('saturation', 'Saturation', 8, -100, 100, 1, '%'),
    ],
  },
  {
    type: 'color-grading',
    name: 'Color Grading',
    category: 'color',
    description: 'Full cinema colorist suite',
    params: [
      numParam('temperature', 'Temperature', 8, -100, 100, 1),
      numParam('tint', 'Tint', 0, -100, 100, 1),
      numParam('exposure', 'Exposure', 6, -100, 100, 1),
      numParam('contrast', 'Contrast', 18, -100, 100, 1),
      numParam('highlights', 'Highlights', 10, -100, 100, 1),
      numParam('shadows', 'Shadows', -10, -100, 100, 1),
      numParam('saturation', 'Saturation', 15, -100, 100, 1),
    ],
  },
  {
    type: 'rgb-split',
    name: 'RGB Split',
    category: 'color',
    description: 'Separate Red/Green/Blue channel offset',
    params: [
      numParam('distance', 'Split Distance', 10, 0, 50, 1, 'px'),
      numParam('angle', 'Split Angle', 0, -180, 180, 1, '°'),
    ],
  },
  {
    type: 'tint',
    name: 'Tint / Duotone',
    category: 'color',
    description: 'Wash frame with custom color blend',
    params: [
      colorParam('color', 'Tint Color', '#E50914'),
      numParam('amount', 'Tint Mix', 40, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'black-and-white',
    name: 'Black and White',
    category: 'color',
    description: 'Panchromatic luminance monochrome',
    params: [
      numParam('contrast', 'Mono Contrast', 22, -50, 100, 1, '%'),
      numParam('redWeight', 'Red Channel', 35, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'negative',
    name: 'Negative',
    category: 'color',
    description: 'Photographic color inversion',
    params: [numParam('mix', 'Invert Mix', 100, 0, 100, 1, '%')],
  },
  {
    type: 'gradient-map',
    name: 'Gradient Map',
    category: 'color',
    description: 'Remap luminance from shadow color to highlight color',
    params: [
      colorParam('shadowColor', 'Shadow Color', '#0E0A14'),
      colorParam('highlightColor', 'Highlight Color', '#E50914'),
      numParam('mix', 'Blend Mix', 70, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'lut',
    name: 'LUT Support',
    category: 'color',
    description: 'Apply film emulation LUT profiles (.cube / presets)',
    params: [
      selectParam('preset', 'LUT Profile', 'kodak-2383', [
        { value: 'kodak-2383', label: 'Kodak 2383 Print' },
        { value: 'teal-orange', label: 'Blockbuster Teal & Orange' },
        { value: 'crimson-cinema', label: 'RED Crimson Cinema' },
        { value: 'fuji-eterna', label: 'Fuji Eterna 250D' },
        { value: 'cyber-night', label: 'Neon Night Grade' },
      ]),
      numParam('strength', 'LUT Strength', 80, 0, 100, 1, '%'),
    ],
  },

  // ======================== DISTORTION EFFECTS (10) ========================
  {
    type: 'wave-warp',
    name: 'Wave Warp',
    category: 'distortion',
    description: 'Animated sinusoidal wave displacement',
    params: [
      numParam('amplitude', 'Wave Height', 14, 0, 60, 1, 'px'),
      numParam('frequency', 'Wave Frequency', 3.5, 0.5, 15, 0.1),
      numParam('speed', 'Wave Speed', 2.0, 0, 10, 0.1),
      selectParam('axis', 'Wave Axis', 'horizontal', [
        { value: 'horizontal', label: 'Horizontal' },
        { value: 'vertical', label: 'Vertical' },
      ]),
    ],
  },
  {
    type: 'displacement-map',
    name: 'Displacement Map',
    category: 'distortion',
    description: 'Procedural noise field XY pixel displacement',
    params: [
      numParam('scaleX', 'Max Horizontal', 18, -80, 80, 1, 'px'),
      numParam('scaleY', 'Max Vertical', 14, -80, 80, 1, 'px'),
      numParam('detail', 'Map Scale', 6, 1, 20, 0.5),
    ],
  },
  {
    type: 'ripple',
    name: 'Ripple',
    category: 'distortion',
    description: 'Concentric water ripple ring distortion',
    params: [
      numParam('amplitude', 'Ripple Strength', 14, 0, 50, 1, 'px'),
      numParam('frequency', 'Ring Density', 14, 2, 40, 1),
      numParam('speed', 'Ripple Speed', 3, 0, 10, 0.2),
      numParam('centerX', 'Center X', 50, 0, 100, 1, '%'),
      numParam('centerY', 'Center Y', 50, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'twirl',
    name: 'Twirl',
    category: 'distortion',
    description: 'Vortex spiral twist around center',
    params: [
      numParam('angle', 'Twirl Angle', 110, -360, 360, 5, '°'),
      numParam('radius', 'Twirl Radius', 48, 10, 100, 1, '%'),
      numParam('centerX', 'Center X', 50, 0, 100, 1, '%'),
      numParam('centerY', 'Center Y', 50, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'pinch',
    name: 'Pinch',
    category: 'distortion',
    description: 'Inward spherical pinch compression',
    params: [
      numParam('strength', 'Pinch Strength', 45, 0, 100, 1, '%'),
      numParam('radius', 'Effect Radius', 55, 10, 100, 1, '%'),
    ],
  },
  {
    type: 'bulge',
    name: 'Bulge',
    category: 'distortion',
    description: 'Outward fisheye lens magnification bulge',
    params: [
      numParam('strength', 'Bulge Strength', 50, 0, 100, 1, '%'),
      numParam('radius', 'Effect Radius', 55, 10, 100, 1, '%'),
    ],
  },
  {
    type: 'turbulent-displace',
    name: 'Turbulent Displace',
    category: 'distortion',
    description: 'Organic fractal turbulence distortion',
    params: [
      numParam('amount', 'Displacement', 24, 0, 80, 1, 'px'),
      numParam('size', 'Complexity', 5, 1, 15, 0.5),
      numParam('evolution', 'Evolution Speed', 1.5, 0, 8, 0.1),
    ],
  },
  {
    type: 'glitch-distortion',
    name: 'Glitch Distortion',
    category: 'distortion',
    description: 'Horizontal slice shear & block jitter',
    params: [
      numParam('intensity', 'Shear Intensity', 55, 0, 100, 1, '%'),
      numParam('blockSize', 'Slice Height', 18, 4, 60, 1, 'px'),
      numParam('speed', 'Jitter Rate', 8, 1, 20, 1),
    ],
  },
  {
    type: 'lens-distortion',
    name: 'Lens Distortion',
    category: 'distortion',
    description: 'Optical wide-angle barrel or pincushion warp',
    params: [
      numParam('curvature', 'Curvature', -35, -100, 100, 1, '%'),
      numParam('scale', 'Edge Zoom Comp', 105, 80, 140, 1, '%'),
    ],
  },
  {
    type: 'perspective-distortion',
    name: 'Perspective Distortion',
    category: 'distortion',
    description: '3D trapezoid keystone tilt warp',
    params: [
      numParam('tiltX', 'Horizontal Keystone', 22, -60, 60, 1, '%'),
      numParam('tiltY', 'Vertical Skew', 0, -45, 45, 1, '%'),
    ],
  },

  // ======================== GLITCH EFFECTS (9) ========================
  {
    type: 'rgb-glitch',
    name: 'RGB Glitch',
    category: 'glitch',
    description: 'Animated chromatic strip tears & channel desync',
    params: [
      numParam('intensity', 'Glitch Strength', 60, 0, 100, 1, '%'),
      numParam('shift', 'Color Split', 14, 1, 45, 1, 'px'),
      numParam('rate', 'Pulse Rate', 10, 1, 24, 1),
    ],
  },
  {
    type: 'digital-glitch',
    name: 'Digital Glitch',
    category: 'glitch',
    description: 'MPEG macroblock corruption & bit tears',
    params: [
      numParam('intensity', 'Block Corruption', 50, 0, 100, 1, '%'),
      numParam('blocks', 'Block Density', 14, 3, 32, 1),
    ],
  },
  {
    type: 'vhs-glitch',
    name: 'VHS Glitch',
    category: 'glitch',
    description: 'Analog tape wobble, tracking bar & chroma bleed',
    params: [
      numParam('tracking', 'Tracking Noise', 55, 0, 100, 1, '%'),
      numParam('chromaBleed', 'Tape Color Bleed', 10, 0, 30, 1, 'px'),
      numParam('wobble', 'Horizontal Wobble', 35, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'pixel-sorting',
    name: 'Pixel Sorting',
    category: 'glitch',
    description: 'Luminance-threshold directional pixel row sort',
    params: [
      numParam('threshold', 'Luma Threshold', 110, 10, 240, 2),
      numParam('strength', 'Sort Length', 65, 5, 100, 1, '%'),
    ],
  },
  {
    type: 'scan-lines',
    name: 'Scan Lines',
    category: 'glitch',
    description: 'CRT broadcast phosphor scanline grille',
    params: [
      numParam('density', 'Line Spacing', 4, 2, 14, 1, 'px'),
      numParam('opacity', 'Line Darkness', 45, 0, 95, 1, '%'),
    ],
  },
  {
    type: 'chromatic-aberration',
    name: 'Chromatic Aberration',
    category: 'glitch',
    description: 'Optical radial red/blue lens fringe',
    params: [
      numParam('amount', 'Fringe Shift', 12, 0, 45, 1, 'px'),
      numParam('falloff', 'Edge Falloff', 75, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'digital-noise',
    name: 'Digital Noise',
    category: 'glitch',
    description: 'High-ISO RGB sensor chromatic speckle',
    params: [
      numParam('amount', 'Noise Amount', 35, 0, 100, 1, '%'),
      boolParam('colored', 'Chroma RGB Noise', true),
    ],
  },
  {
    type: 'signal-interference',
    name: 'Signal Interference',
    category: 'glitch',
    description: 'RF broadcast static wave & sync tearing',
    params: [
      numParam('intensity', 'RF Static', 55, 0, 100, 1, '%'),
      numParam('bandSize', 'Sync Tear Band', 24, 5, 80, 1, 'px'),
    ],
  },
  {
    type: 'datamosh',
    name: 'Datamosh Motion Smear',
    category: 'glitch',
    description: 'P-frame vector smear & block echo distortion',
    params: [
      numParam('smear', 'Smear Distance', 36, 4, 100, 1, 'px'),
      numParam('threshold', 'Luma Lock', 95, 10, 220, 2),
    ],
  },
  {
    type: 'horizontal-glitch',
    name: 'Horizontal Glitch',
    category: 'glitch',
    description: 'High-speed lateral scan strip displacement & RGB tear',
    params: [
      numParam('intensity', 'Tear Strength', 65, 0, 100, 1, '%'),
      numParam('bandHeight', 'Band Height', 12, 2, 64, 1, 'px'),
      numParam('rate', 'Rate', 14, 1, 30, 1),
    ],
  },
  {
    type: 'vertical-glitch',
    name: 'Vertical Glitch',
    category: 'glitch',
    description: 'Vertical column slip & sync roll corruption',
    params: [
      numParam('intensity', 'Column Slip', 60, 0, 100, 1, '%'),
      numParam('columnWidth', 'Column Width', 16, 2, 64, 1, 'px'),
      numParam('rate', 'Rate', 12, 1, 30, 1),
    ],
  },
  {
    type: 'screen-tear',
    name: 'Screen Tear',
    category: 'glitch',
    description: 'V-Sync tear split bands with digital luminance flash',
    params: [
      numParam('intensity', 'Tear Power', 70, 0, 100, 1, '%'),
      numParam('splits', 'Tear Bands', 4, 1, 12, 1),
      numParam('rate', 'Tear Speed', 14, 1, 30, 1),
    ],
  },
  {
    type: 'data-corruption',
    name: 'Data Corruption',
    category: 'glitch',
    description: 'Bit-block inversion & heavy codec packet loss',
    params: [
      numParam('intensity', 'Corruption', 65, 0, 100, 1, '%'),
      numParam('blockSize', 'Packet Size', 24, 6, 80, 1, 'px'),
      numParam('rate', 'Packet Rate', 10, 1, 24, 1),
    ],
  },
  {
    type: 'rgb-flash',
    name: 'RGB Flash',
    category: 'glitch',
    description: 'Strobe RGB color channel pulse with prism dispersion',
    params: [
      numParam('intensity', 'Flash Strength', 70, 0, 100, 1, '%'),
      numParam('speed', 'Flash Speed', 12, 1, 30, 1),
      numParam('split', 'RGB Offset', 16, 0, 45, 1, 'px'),
    ],
  },

  // ======================== SHAKE EFFECTS (1) ========================
  {
    type: 'camera-shake',
    name: 'Camera Shake',
    category: 'shake',
    description: 'Customizable kinetic camera shake with motion blur & falloff',
    params: [
      numParam('intensity', 'Shake Intensity', 55, 0, 100, 1, '%'),
      numParam('speed', 'Speed', 1.4, 0.2, 5.0, 0.05, 'x'),
      numParam('frequency', 'Frequency', 8, 1, 30, 0.5, 'Hz'),
      numParam('rotation', 'Rotation', 4, 0, 45, 0.5, '°'),
      numParam('posX', 'Position X', 45, 0, 100, 1, '%'),
      numParam('posY', 'Position Y', 40, 0, 100, 1, '%'),
      numParam('zoomStrength', 'Zoom Strength', 12, 0, 60, 1, '%'),
      numParam('motionBlur', 'Motion Blur', 35, 0, 100, 1, '%'),
      numParam('duration', 'Duration', 2.5, 0.2, 15, 0.1, 's'),
      numParam('smoothness', 'Smoothness', 50, 0, 100, 1, '%'),
      numParam('startStrength', 'Start Strength', 100, 0, 100, 1, '%'),
      numParam('endStrength', 'End Strength', 25, 0, 100, 1, '%'),
      selectParam('waveProfile', 'Shake Curve', 'smooth', [
        { value: 'smooth', label: 'Smooth Drift' },
        { value: 'hard', label: 'Hard Punch' },
        { value: 'impact', label: 'Impact Decay' },
        { value: 'beat', label: 'Beat Pulse' },
        { value: 'whip', label: 'Velocity Whip' },
      ]),
    ],
  },

  // ======================== SHADOW EFFECTS (5) ========================
  {
    type: 'drop-shadow',
    name: 'Drop Shadow',
    category: 'shadow',
    description: 'Soft directional cast shadow behind layer',
    params: [
      numParam('distance', 'Distance', 16, 0, 80, 1, 'px'),
      numParam('angle', 'Angle', 135, -180, 180, 1, '°'),
      numParam('blur', 'Softness', 18, 0, 60, 1, 'px'),
      numParam('opacity', 'Opacity', 75, 0, 100, 1, '%'),
      colorParam('color', 'Shadow Color', '#000000'),
    ],
  },
  {
    type: 'inner-shadow',
    name: 'Inner Shadow',
    category: 'shadow',
    description: 'Recessed interior bevel shadow',
    params: [
      numParam('depth', 'Depth', 22, 2, 80, 1, 'px'),
      numParam('opacity', 'Opacity', 65, 0, 100, 1, '%'),
      colorParam('color', 'Shadow Color', '#000000'),
    ],
  },
  {
    type: 'long-shadow',
    name: 'Long Shadow',
    category: 'shadow',
    description: 'Flat motion graphics 45° extruded shadow',
    params: [
      numParam('length', 'Extrude Length', 36, 4, 100, 1, 'px'),
      numParam('angle', 'Angle', 45, -180, 180, 1, '°'),
      numParam('opacity', 'Opacity', 60, 0, 100, 1, '%'),
      colorParam('color', 'Shadow Color', '#4C0519'),
    ],
  },
  {
    type: 'soft-shadow',
    name: 'Soft Shadow',
    category: 'shadow',
    description: 'Diffused ambient contact shadow',
    params: [
      numParam('spread', 'Spread', 32, 4, 90, 1, 'px'),
      numParam('offsetY', 'Vertical Drop', 14, -40, 80, 1, 'px'),
      numParam('opacity', 'Opacity', 65, 0, 100, 1, '%'),
    ],
  },
  {
    type: '3d-shadow',
    name: '3D Floor Shadow',
    category: 'shadow',
    description: 'Perspective cast ground shadow below subject',
    params: [
      numParam('offsetY', 'Floor Offset', 28, 0, 90, 1, '%'),
      numParam('skew', 'Perspective Skew', 25, -60, 60, 1, '%'),
      numParam('blur', 'Softness', 16, 0, 50, 1, 'px'),
      numParam('opacity', 'Opacity', 65, 0, 100, 1, '%'),
    ],
  },

  // ======================== TEXTURE & NOISE (10) ========================
  {
    type: 'film-grain',
    name: 'Film Grain',
    category: 'texture',
    description: 'Organic 35mm silver halide grain',
    params: [
      numParam('amount', 'Grain Intensity', 35, 0, 100, 1, '%'),
      numParam('size', 'Grain Size', 1.5, 1, 4, 0.5, 'px'),
    ],
  },
  {
    type: 'noise',
    name: 'Noise',
    category: 'texture',
    description: 'Uniform luminance micro-texture noise',
    params: [numParam('amount', 'Noise Level', 25, 0, 100, 1, '%')],
  },
  {
    type: 'dust',
    name: 'Film Dust',
    category: 'texture',
    description: 'Vintage archival cinema dust specks',
    params: [
      numParam('density', 'Dust Density', 40, 0, 100, 1, '%'),
      numParam('opacity', 'Spec Contrast', 55, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'scratches',
    name: 'Film Scratches',
    category: 'texture',
    description: 'Vertical celluloid gate hairlines & flickers',
    params: [
      numParam('count', 'Scratch Density', 45, 0, 100, 1, '%'),
      numParam('opacity', 'Opacity', 45, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'paper-texture',
    name: 'Paper Texture',
    category: 'texture',
    description: 'Tactile cold-press cardstock grain overlay',
    params: [
      numParam('strength', 'Fiber Mix', 40, 0, 100, 1, '%'),
      numParam('warmth', 'Paper Warmth', 20, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'vignette',
    name: 'Vignette',
    category: 'texture',
    description: 'Optical corner falloff darkening',
    params: [
      numParam('amount', 'Darkness', 55, 0, 100, 1, '%'),
      numParam('midpoint', 'Radius', 48, 10, 90, 1, '%'),
      colorParam('color', 'Vignette Color', '#000000'),
    ],
  },
  {
    type: 'sharpen',
    name: 'Sharpen',
    category: 'texture',
    description: '3x3 convolution crisp edge enhancement',
    params: [numParam('amount', 'Sharpness', 55, 0, 100, 1, '%')],
  },
  {
    type: 'emboss',
    name: 'Emboss',
    category: 'texture',
    description: 'Directional bas-relief contour shading',
    params: [
      numParam('strength', 'Relief Depth', 70, 0, 100, 1, '%'),
      numParam('mix', 'Blend with Original', 65, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'mosaic',
    name: 'Mosaic',
    category: 'texture',
    description: 'Geometric tile grid sub-sampling',
    params: [numParam('tileSize', 'Tile Size', 14, 2, 64, 1, 'px')],
  },
  {
    type: 'pixelate',
    name: 'Pixelate',
    category: 'texture',
    description: 'Crisp retro 8-bit/16-bit pixel block filter',
    params: [numParam('pixelSize', 'Block Size', 10, 2, 56, 1, 'px')],
  },

  // ======================== STYLIZE EFFECTS (9) ========================
  {
    type: 'cartoon',
    name: 'Cartoon / Cel Shade',
    category: 'stylize',
    description: 'Quantized cel colors with black ink contours',
    params: [
      numParam('levels', 'Color Bands', 5, 2, 12, 1),
      numParam('edgeStrength', 'Ink Line Weight', 65, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'sketch',
    name: 'Pencil Sketch',
    category: 'stylize',
    description: 'High-contrast graphite line illustration',
    params: [
      numParam('threshold', 'Line Sensitivity', 45, 5, 100, 1),
      boolParam('invertPaper', 'Dark Charcoal Paper', false),
    ],
  },
  {
    type: 'posterize',
    name: 'Posterize',
    category: 'stylize',
    description: 'Graphic tonal step quantization',
    params: [numParam('levels', 'Color Levels', 5, 2, 16, 1)],
  },
  {
    type: 'edge-detection',
    name: 'Edge Detection',
    category: 'stylize',
    description: 'Sobel gradient structural contour map',
    params: [
      numParam('gain', 'Edge Gain', 140, 20, 300, 5, '%'),
      numParam('mix', 'Overlay Mix', 100, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'oil-painting',
    name: 'Oil Painting',
    category: 'stylize',
    description: 'Impasto painterly brush stroke clustering',
    params: [
      numParam('brushSize', 'Brush Radius', 3, 1, 6, 1),
      numParam('levels', 'Pigment Richness', 12, 4, 32, 1),
    ],
  },
  {
    type: 'watercolor',
    name: 'Watercolor',
    category: 'stylize',
    description: 'Soft wash bleed with dark pigment boundaries',
    params: [
      numParam('softness', 'Wash Bleed', 55, 10, 100, 1, '%'),
      numParam('edgePigment', 'Pigment Edge', 50, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'halftone',
    name: 'Halftone',
    category: 'stylize',
    description: 'Print-press halftone screen dot matrix',
    params: [
      numParam('dotSize', 'Cell Size', 8, 4, 24, 1, 'px'),
      boolParam('colored', 'CMYK Color Dots', false),
    ],
  },
  {
    type: 'outline',
    name: 'Outline',
    category: 'stylize',
    description: 'Detect contours and stroke with custom color',
    params: [
      colorParam('color', 'Stroke Color', '#E50914'),
      numParam('threshold', 'Threshold', 40, 5, 120, 1),
      numParam('mix', 'Mix', 85, 0, 100, 1, '%'),
    ],
  },
  {
    type: 'glow-edges',
    name: 'Glow Edges',
    category: 'stylize',
    description: 'Luminous neon edge trace composited over layer',
    params: [
      colorParam('color', 'Edge Color', '#E50914'),
      numParam('intensity', 'Glow Power', 85, 10, 200, 1, '%'),
      numParam('threshold', 'Sensitivity', 35, 5, 120, 1),
    ],
  },
];

export function getEffectDefinition(type: string): EffectDefinition | undefined {
  return EFFECTS_CATALOG.find((e) => e.type === type);
}

export function createEffectInstance(type: string): EffectInstance | null {
  const def = getEffectDefinition(type);
  if (!def) return null;
  const params: Record<string, number | string | boolean> = {};
  for (const p of def.params) {
    params[p.key] = p.defaultValue;
  }
  const blendParam = params.blend;
  const blendMode: EffectBlendMode =
    typeof blendParam === 'string' &&
    ['normal', 'screen', 'multiply', 'overlay', 'add', 'soft-light'].includes(blendParam)
      ? (blendParam as EffectBlendMode)
      : 'normal';

  return {
    id: `fx-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    type: def.type,
    name: def.name,
    category: def.category,
    enabled: true,
    blendMode,
    params,
  };
}

// =========================================================================
// TRANSITION LIBRARY (37 Transitions across 5 Categories)
// =========================================================================

function makeTransition(
  type: AdvancedTransitionType,
  name: string,
  category: TransitionCategoryId,
  description: string,
  overrides: Partial<TransitionSettings> = {}
): TransitionDefinition {
  return {
    type,
    name,
    category,
    description,
    defaultSettings: {
      type,
      duration: 0.7,
      speed: 1,
      direction: 'left',
      intensity: 75,
      smoothness: 65,
      easing: 'easeInOut',
      ...overrides,
    },
  };
}

export const TRANSITIONS_CATALOG: TransitionDefinition[] = [
  // Basic Transitions (6)
  makeTransition('fade-in', 'Fade In', 'basic', 'Linear or eased opacity ramp in'),
  makeTransition('fade-out', 'Fade Out', 'basic', 'Smooth opacity fade out'),
  makeTransition('cross-dissolve', 'Cross Dissolve', 'basic', 'Optical alpha blend across cut'),
  makeTransition('cut', 'Hard Cut', 'basic', 'Instantaneous zero-frame editorial cut', { duration: 0.05 }),
  makeTransition('dip-to-black', 'Dip to Black', 'basic', 'Fade down through #000000 black'),
  makeTransition('dip-to-white', 'Dip to White', 'basic', 'Clean exposure fade through #FFFFFF'),

  // Motion Transitions (10)
  makeTransition('zoom-in', 'Zoom In', 'motion', 'Smooth high-velocity scale punch in', { direction: 'center' }),
  makeTransition('zoom-out', 'Zoom Out', 'motion', 'Pull-back wide reveal zoom out', { direction: 'center' }),
  makeTransition('push', 'Push', 'motion', 'Directional frame push across viewport'),
  makeTransition('slide-left', 'Slide Left', 'motion', 'Lateral slide from right to left', { direction: 'left' }),
  makeTransition('slide-right', 'Slide Right', 'motion', 'Lateral slide from left to right', { direction: 'right' }),
  makeTransition('slide-up', 'Slide Up', 'motion', 'Vertical slide upward into frame', { direction: 'up' }),
  makeTransition('slide-down', 'Slide Down', 'motion', 'Vertical slide downward into frame', { direction: 'down' }),
  makeTransition('rotation-transition', 'Rotation Swing', 'motion', 'Dynamic 45° rotational swing'),
  makeTransition('spin-transition', '360° Spin', 'motion', 'Full high-speed rotational vortex spin'),
  makeTransition('whip-pan', 'Whip Pan', 'motion', 'Fast swish-pan camera sweep with tilt'),

  // Cinematic Transitions (9)
  makeTransition('camera-shake', 'Camera Shake', 'cinematic', 'Impact handheld kinetic shake cut'),
  makeTransition('motion-blur-transition', 'Motion Blur Cut', 'cinematic', 'Directional velocity blur transition'),
  makeTransition('flash-transition', 'Flash Exposure', 'cinematic', 'Camera shutter overexposure flash'),
  makeTransition('light-leak-transition', 'Light Leak Wash', 'cinematic', '35mm crimson/amber film burn leak'),
  makeTransition('glitch-cut', 'Glitch Cut', 'cinematic', 'Digital sync tear & slice offset'),
  makeTransition('rgb-split-transition', 'RGB Split Cut', 'cinematic', 'High-energy chromatic prism split'),
  makeTransition('film-burn', 'Film Burn', 'cinematic', 'Organic celluloid blister melt'),
  makeTransition('lens-zoom', 'Lens Snap Zoom', 'cinematic', 'Snap telephoto lens punch with blur'),
  makeTransition('cinematic-blur', 'Cinematic Defocus', 'cinematic', 'Rack-focus optical blur transition'),

  // Mask Transitions (6)
  makeTransition('circle-reveal', 'Circle Reveal', 'mask', 'Circular aperture iris expand', { direction: 'center' }),
  makeTransition('linear-wipe', 'Linear Wipe', 'mask', 'Clean feathered straight edge wipe'),
  makeTransition('radial-wipe', 'Radial Wipe', 'mask', 'Clock-sweep radial sector reveal', { direction: 'center' }),
  makeTransition('shape-reveal', 'Shape Reveal', 'mask', 'Geometric diamond/star mask expand', { direction: 'center' }),
  makeTransition('luma-matte', 'Luma Matte', 'mask', 'Soft luminance threshold reveal'),
  makeTransition('mask-expansion', 'Mask Expansion', 'mask', 'Expanding rounded frame matte', { direction: 'center' }),

  // Advanced Transitions (6)
  makeTransition('liquid-transition', 'Liquid Melt', 'advanced', 'Fluid sine wave organic melt transition'),
  makeTransition('warp-transition', 'Warp Tunnel', 'advanced', 'Hyper-warp scale & radial pinch'),
  makeTransition('morph-transition', 'Morph Blend', 'advanced', 'Smooth scale-skew elastic morph'),
  makeTransition('distortion-transition', 'Distortion Rip', 'advanced', 'Swirl & chromatic displacement cut'),
  makeTransition('particle-transition', 'Particle Burst', 'advanced', 'Crimson ember & spark scatter cut'),
  makeTransition('3d-cube-transition', '3D Cube Turn', 'advanced', 'Simulated 3D perspective face rotation'),
];

export function getDefaultTransitionSettings(type: AdvancedTransitionType): TransitionSettings {
  if (type === 'none') {
    return {
      type: 'none',
      duration: 0.6,
      speed: 1,
      direction: 'left',
      intensity: 75,
      smoothness: 65,
      easing: 'easeInOut',
    };
  }
  const found = TRANSITIONS_CATALOG.find((t) => t.type === type);
  if (found) return { ...found.defaultSettings };
  return {
    type,
    duration: 0.7,
    speed: 1,
    direction: 'left',
    intensity: 75,
    smoothness: 65,
    easing: 'easeInOut',
  };
}

// =========================================================================
// BUILT-IN PRESET LIBRARY (Trending, Cinematic, Velocity, Anime, Typography, Glitch, 3D, Social Media)
// =========================================================================

export const BUILT_IN_PRESETS: StudioPreset[] = [
  {
    id: 'preset-crimson-blockbuster',
    name: 'Crimson Blockbuster Look',
    category: 'Cinematic',
    kind: 'effects-stack',
    description: 'Cinema color grade, subtle film grain, bloom & corner vignette',
    isBuiltIn: true,
    createdAt: 1,
    effectsStack: [
      {
        id: 'bp-1',
        type: 'color-grading',
        name: 'Color Grading',
        category: 'color',
        enabled: true,
        blendMode: 'normal',
        params: {
          temperature: -8,
          tint: 4,
          exposure: 4,
          contrast: 22,
          highlights: 12,
          shadows: -16,
          saturation: 14,
        },
      },
      {
        id: 'bp-2',
        type: 'bloom',
        name: 'Bloom',
        category: 'glow',
        enabled: true,
        blendMode: 'screen',
        params: { intensity: 48, radius: 24, threshold: 170 },
      },
      {
        id: 'bp-3',
        type: 'film-grain',
        name: 'Film Grain',
        category: 'texture',
        enabled: true,
        blendMode: 'normal',
        params: { amount: 24, size: 1.5 },
      },
    ],
  },
  {
    id: 'preset-velocity-punch',
    name: 'Velocity Snap Punch',
    category: 'Velocity',
    kind: 'animation',
    description: 'Alight-style elastic zoom-in & ease-out velocity curve',
    isBuiltIn: true,
    createdAt: 2,
    keyframes: [
      { timeRatio: 0, property: 'scale', value: 1.45, easing: 'easeOut' },
      { timeRatio: 0.25, property: 'scale', value: 1.0, easing: 'bezier', bezier: [0.16, 1, 0.3, 1] },
      { timeRatio: 0.85, property: 'scale', value: 1.06, easing: 'easeIn' },
      { timeRatio: 1, property: 'scale', value: 1.32, easing: 'easeIn' },
    ],
  },
  {
    id: 'preset-anime-aura',
    name: 'Anime Crimson Aura',
    category: 'Anime',
    kind: 'effects-stack',
    description: 'Glowing cel edges, neon crimson bloom & chromatic fringe',
    isBuiltIn: true,
    createdAt: 3,
    effectsStack: [
      {
        id: 'bp-a1',
        type: 'glow-edges',
        name: 'Glow Edges',
        category: 'stylize',
        enabled: true,
        blendMode: 'screen',
        params: { color: '#E50914', intensity: 110, threshold: 35 },
      },
      {
        id: 'bp-a2',
        type: 'chromatic-aberration',
        name: 'Chromatic Aberration',
        category: 'glitch',
        enabled: true,
        blendMode: 'normal',
        params: { amount: 10, falloff: 70 },
      },
    ],
  },
  {
    id: 'preset-cyber-glitch',
    name: 'Trending RGB Glitch Pack',
    category: 'Glitch',
    kind: 'effects-stack',
    description: 'RGB Glitch + VHS tracking + CRT scan lines',
    isBuiltIn: true,
    createdAt: 4,
    effectsStack: [
      {
        id: 'bp-g1',
        type: 'rgb-glitch',
        name: 'RGB Glitch',
        category: 'glitch',
        enabled: true,
        blendMode: 'normal',
        params: { intensity: 55, shift: 14, rate: 12 },
      },
      {
        id: 'bp-g2',
        type: 'scan-lines',
        name: 'Scan Lines',
        category: 'glitch',
        enabled: true,
        blendMode: 'normal',
        params: { density: 4, opacity: 40 },
      },
    ],
  },
  {
    id: 'preset-kinetic-title',
    name: 'Kinetic Neon Title',
    category: 'Typography',
    kind: 'text-style',
    description: 'Bold extruded Outfit title with crimson neon glow & character wave',
    isBuiltIn: true,
    createdAt: 5,
    textStyle: {
      fontFamily: 'Outfit',
      fontWeight: 800,
      fontSize: 74,
      color: '#FFFFFF',
      strokeColor: '#E50914',
      strokeWidth: 2,
      shadowColor: '#E50914',
      shadowBlur: 22,
      extrude3D: true,
      extrudeDepth: 8,
      animation: 'neon-text',
      granularity: 'character',
    },
  },
  {
    id: 'preset-social-reel-pop',
    name: 'Social Reel Whip + Pop',
    category: 'Social Media',
    kind: 'transition',
    description: 'High-retention whip pan entrance & snap zoom exit',
    isBuiltIn: true,
    createdAt: 6,
    transitionIn: {
      type: 'whip-pan',
      duration: 0.45,
      speed: 1.4,
      direction: 'left',
      intensity: 85,
      smoothness: 70,
      easing: 'easeOut',
    },
    transitionOut: {
      type: 'zoom-in',
      duration: 0.4,
      speed: 1.3,
      direction: 'center',
      intensity: 80,
      smoothness: 65,
      easing: 'easeIn',
    },
  },
  {
    id: 'preset-trending-3d-tilt',
    name: '3D Parallax Card Drift',
    category: '3D',
    kind: 'animation',
    description: 'Smooth 3D camera parallax hover across scale and rotation',
    isBuiltIn: true,
    createdAt: 7,
    keyframes: [
      { timeRatio: 0, property: 'rotY', value: -14, easing: 'easeInOut' },
      { timeRatio: 0.5, property: 'rotY', value: 14, easing: 'easeInOut' },
      { timeRatio: 1, property: 'rotY', value: -14, easing: 'easeInOut' },
    ],
  },
  {
    id: 'preset-trending-blur-ramp',
    name: 'Trending Lens Blur Entrance',
    category: 'Trending',
    kind: 'effects-stack',
    description: 'Soft dreamy lens blur + warm light leak overlay',
    isBuiltIn: true,
    createdAt: 8,
    effectsStack: [
      {
        id: 'bp-t1',
        type: 'lens-blur',
        name: 'Lens Blur',
        category: 'blur',
        enabled: true,
        blendMode: 'normal',
        params: { radius: 8, bladeCurvature: 60, threshold: 175 },
      },
      {
        id: 'bp-t2',
        type: 'light-leak',
        name: 'Light Leak',
        category: 'glow',
        enabled: true,
        blendMode: 'screen',
        params: { intensity: 45, angle: 35, primaryColor: '#E50914', secondaryColor: '#FF9F1C' },
      },
    ],
  },
];
