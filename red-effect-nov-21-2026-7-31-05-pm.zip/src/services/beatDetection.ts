import { MediaAsset, TimelineClip, TimelineMarker } from '../types/studio';

export interface DecodedAudioPCM {
  url: string;
  sampleRate: number;
  durationSec: number;
  mono: Float32Array;
  highResPeaks: number[];
}

export type BeatDetectionFocus = 'balanced' | 'kick' | 'transients';

export interface BeatDetectionOptions {
  sensitivity: number; // 0 to 100
  focus?: BeatDetectionFocus;
  minGapMs?: number;
}

export interface DetectedBeatPoint {
  timestampMs: number;
  time: number;
  strength: number; // 0 to 1
  clipId: string;
}

export interface BeatDetectionResult {
  beats: DetectedBeatPoint[];
  bpm: number;
  durationSec: number;
  usedDecodedPcm: boolean;
}

const MAX_PCM_CACHE_ENTRIES = 8;
const pcmCache = new Map<string, DecodedAudioPCM>();

export function msToSec(ms: number): number {
  return Math.max(0, Math.round(ms)) / 1000;
}

export function secToMs(sec: number): number {
  if (!Number.isFinite(sec)) return 0;
  return Math.max(0, Math.round(sec * 1000));
}

export function formatTimecodeMs(timeSecOrMs: number, isMs = false): string {
  const totalMs = isMs ? Math.max(0, Math.round(timeSecOrMs)) : secToMs(timeSecOrMs);
  const mins = Math.floor(totalMs / 60000);
  const secs = Math.floor((totalMs % 60000) / 1000);
  const ms = totalMs % 1000;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(ms).padStart(
    3,
    '0'
  )}`;
}

export function getMarkerTimestampMs(marker: TimelineMarker): number {
  if (typeof marker.timestampMs === 'number' && Number.isFinite(marker.timestampMs)) {
    return Math.max(0, Math.round(marker.timestampMs));
  }
  return secToMs(marker.time || 0);
}

export function isDuplicateBeatMarker(
  markers: TimelineMarker[],
  candidateMs: number,
  trackId?: string,
  thresholdMs = 80
): TimelineMarker | null {
  for (const m of markers) {
    // Isolate per audio track when trackId is specified
    if (trackId && m.trackId && m.trackId !== trackId) continue;
    if (trackId && !m.trackId && m.kind !== 'beat') continue;
    const existingMs = getMarkerTimestampMs(m);
    if (Math.abs(existingMs - candidateMs) < thresholdMs) {
      return m;
    }
  }
  return null;
}

export function extractHighResWaveformPeaks(
  mono: Float32Array,
  targetBins = 480
): number[] {
  const len = mono.length;
  if (len === 0 || targetBins <= 0) return [];
  const bins = Math.min(targetBins, len);
  const blockSize = Math.max(1, len / bins);
  const peaks: number[] = new Array(bins);
  let globalMax = 0.0001;

  for (let i = 0; i < bins; i++) {
    const start = Math.floor(i * blockSize);
    const end = Math.min(len, Math.floor((i + 1) * blockSize));
    const span = Math.max(1, end - start);
    const step = Math.max(1, Math.floor(span / 48));
    let maxVal = 0;
    let sumSq = 0;
    let count = 0;
    for (let j = start; j < end; j += step) {
      const s = mono[j];
      const a = s < 0 ? -s : s;
      if (a > maxVal) maxVal = a;
      sumSq += s * s;
      count++;
    }
    const rms = count > 0 ? Math.sqrt(sumSq / count) : 0;
    const blended = maxVal * 0.72 + rms * 0.48;
    if (blended > globalMax) globalMax = blended;
    peaks[i] = blended;
  }

  const norm = globalMax > 0.02 ? 1 / globalMax : 1;
  for (let i = 0; i < bins; i++) {
    peaks[i] = Math.round(Math.min(1, peaks[i] * norm) * 1000) / 1000;
  }
  return peaks;
}

export function getCachedDecodedAudio(url: string): DecodedAudioPCM | null {
  return pcmCache.get(url) || null;
}

export async function decodeAssetAudioPCM(asset: MediaAsset): Promise<DecodedAudioPCM | null> {
  if (!asset.url) return null;
  const cached = pcmCache.get(asset.url);
  if (cached) return cached;

  if (typeof AudioContext === 'undefined' && typeof (globalThis as { webkitAudioContext?: unknown }).webkitAudioContext === 'undefined') {
    return null;
  }

  let ctx: AudioContext | null = null;
  try {
    const resp = await fetch(asset.url);
    if (!resp.ok) return null;
    const arrayBuf = await resp.arrayBuffer();
    const AudioCtxCtor =
      AudioContext ||
      (globalThis as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AudioCtxCtor();
    const audioBuffer = await ctx.decodeAudioData(arrayBuf);
    if (!audioBuffer || audioBuffer.numberOfChannels === 0 || audioBuffer.length === 0) {
      return null;
    }

    const len = audioBuffer.length;
    const channels = audioBuffer.numberOfChannels;
    const mono = new Float32Array(len);
    for (let ch = 0; ch < channels; ch++) {
      const chData = audioBuffer.getChannelData(ch);
      const scale = 1 / channels;
      for (let i = 0; i < len; i++) {
        mono[i] += chData[i] * scale;
      }
    }

    const highResPeaks = extractHighResWaveformPeaks(mono, Math.min(720, Math.max(240, Math.round(audioBuffer.duration * 24))));
    const entry: DecodedAudioPCM = {
      url: asset.url,
      sampleRate: audioBuffer.sampleRate,
      durationSec: audioBuffer.duration,
      mono,
      highResPeaks,
    };

    if (pcmCache.size >= MAX_PCM_CACHE_ENTRIES) {
      const firstKey = pcmCache.keys().next().value;
      if (firstKey) pcmCache.delete(firstKey);
    }
    pcmCache.set(asset.url, entry);
    return entry;
  } catch {
    return null;
  } finally {
    if (ctx) {
      ctx.close().catch(() => {});
    }
  }
}

export function estimateBpmFromTimestamps(timestampsMs: number[]): number {
  if (timestampsMs.length < 3) return 0;
  const sorted = [...timestampsMs].sort((a, b) => a - b);
  const histogram = new Map<number, number>();
  for (let i = 1; i < sorted.length; i++) {
    const deltaMs = sorted[i] - sorted[i - 1];
    if (deltaMs < 220 || deltaMs > 1600) continue;
    let bpm = Math.round(60000 / deltaMs);
    while (bpm < 70) bpm *= 2;
    while (bpm > 180) bpm = Math.round(bpm / 2);
    const bucket = Math.round(bpm / 2) * 2;
    histogram.set(bucket, (histogram.get(bucket) || 0) + 1);
  }
  let bestBpm = 0;
  let bestVotes = 0;
  for (const [bpm, votes] of histogram.entries()) {
    if (votes > bestVotes) {
      bestVotes = votes;
      bestBpm = bpm;
    }
  }
  return bestBpm;
}

/**
 * Multi-band onset / spectral-flux beat detector operating directly on decoded mono PCM.
 * Returns beats mapped accurately from source media time -> clip timeline milliseconds.
 */
export function detectBeatsFromMonoPCM(
  mono: Float32Array,
  sampleRate: number,
  clip: TimelineClip,
  assetDurationSec: number,
  options: BeatDetectionOptions
): BeatDetectionResult {
  const sensitivity = Math.max(5, Math.min(100, options.sensitivity));
  const focus = options.focus || 'balanced';

  const clipSpeed = Math.max(0.25, Math.min(4, clip.speed || 1));
  const srcDurationSec = assetDurationSec > 0 ? assetDurationSec : mono.length / sampleRate;
  const srcStartSec = Math.max(0, Math.min(srcDurationSec, clip.sourceOffset || 0));
  const srcSpanSec = Math.min(srcDurationSec - srcStartSec, clip.duration * clipSpeed);
  if (srcSpanSec <= 0.05) {
    return { beats: [], bpm: 0, durationSec: srcDurationSec, usedDecodedPcm: true };
  }

  // Analysis hop ~10.7ms (512 samples @ 48kHz, scaled safely for any sample rate)
  const hopSize = Math.max(128, Math.round(sampleRate * 0.011));
  const startSample = Math.max(0, Math.floor(srcStartSec * sampleRate));
  const endSample = Math.min(mono.length, Math.ceil((srcStartSec + srcSpanSec) * sampleRate));
  const totalHops = Math.floor((endSample - startSample) / hopSize);
  if (totalHops < 6) {
    return { beats: [], bpm: 0, durationSec: srcDurationSec, usedDecodedPcm: true };
  }

  const hopDurationSec = hopSize / sampleRate;

  // 1-pole low-pass filter (~155 Hz) separates sub/kick energy from crisp high transients
  const rc = 1 / (2 * Math.PI * 155);
  const dt = 1 / sampleRate;
  const lpAlpha = dt / (rc + dt);

  const energyCurve = new Float32Array(totalHops);
  let lpState = 0;
  let prevSample = startSample > 0 ? mono[startSample - 1] : 0;

  for (let h = 0; h < totalHops; h++) {
    const segStart = startSample + h * hopSize;
    const segEnd = Math.min(endSample, segStart + hopSize);
    let lowEnergy = 0;
    let fullEnergy = 0;
    let highFlux = 0;
    const count = Math.max(1, segEnd - segStart);

    for (let i = segStart; i < segEnd; i++) {
      const s = mono[i];
      lpState = lpState + lpAlpha * (s - lpState);
      const hp = s - prevSample;
      prevSample = s;

      lowEnergy += lpState * lpState;
      fullEnergy += s * s;
      highFlux += Math.abs(hp);
    }

    const lowRms = Math.sqrt(lowEnergy / count);
    const fullRms = Math.sqrt(fullEnergy / count);
    const highMean = highFlux / count;

    if (focus === 'kick') {
      energyCurve[h] = lowRms * 1.45 + fullRms * 0.35;
    } else if (focus === 'transients') {
      energyCurve[h] = highMean * 1.35 + fullRms * 0.55;
    } else {
      energyCurve[h] = lowRms * 0.9 + fullRms * 0.65 + highMean * 0.7;
    }
  }

  // Half-wave rectified onset flux function
  const flux = new Float32Array(totalHops);
  let maxFlux = 0.00001;
  for (let h = 1; h < totalHops; h++) {
    const diff = energyCurve[h] - energyCurve[h - 1] * 0.85;
    const v = diff > 0 ? diff : 0;
    flux[h] = v;
    if (v > maxFlux) maxFlux = v;
  }

  // Normalize onset flux to 0..1
  for (let h = 0; h < totalHops; h++) {
    flux[h] /= maxFlux;
  }

  // Adaptive threshold over local +/- 0.35s neighborhood
  const halfWin = Math.max(4, Math.round(0.35 / hopDurationSec));
  // Map sensitivity (5..100) to threshold multiplier (2.6 down to 0.75) & minGapMs (420ms down to 145ms)
  const normSens = (sensitivity - 5) / 95;
  const thresholdMult = 2.45 - normSens * 1.65;
  const absFloor = 0.14 - normSens * 0.095;
  const minGapMs = options.minGapMs ?? Math.round(390 - normSens * 235);

  const pickedHops: Array<{ hop: number; strength: number }> = [];
  let lastPickedTimelineMs = -Infinity;

  for (let h = 2; h < totalHops - 2; h++) {
    const val = flux[h];
    if (val < absFloor) continue;
    // Strict local peak inside +/-2 hops (~40ms window)
    if (val < flux[h - 1] || val < flux[h + 1] || val < flux[h - 2] || val < flux[h + 2]) {
      continue;
    }

    const wStart = Math.max(0, h - halfWin);
    const wEnd = Math.min(totalHops - 1, h + halfWin);
    const wLen = wEnd - wStart + 1;
    let sum = 0;
    for (let k = wStart; k <= wEnd; k++) sum += flux[k];
    const mean = sum / wLen;

    let varSum = 0;
    for (let k = wStart; k <= wEnd; k++) {
      const d = flux[k] - mean;
      varSum += d * d;
    }
    const std = Math.sqrt(varSum / wLen);
    const localThresh = mean + thresholdMult * std;

    if (val < localThresh) continue;

    // Convert hop index -> source offset time -> timeline time
    const sourceSec = srcStartSec + h * hopDurationSec;
    const localPlaySec = clip.reverse
      ? (srcDurationSec - sourceSec - srcStartSec) / clipSpeed
      : (sourceSec - srcStartSec) / clipSpeed;
    if (localPlaySec < 0 || localPlaySec > clip.duration) continue;

    const timelineMs = Math.round((clip.startTime + localPlaySec) * 1000);
    if (Math.abs(timelineMs - lastPickedTimelineMs) < minGapMs) {
      // If stronger peak appears slightly later within debounce window, keep stronger one
      if (pickedHops.length > 0 && val > pickedHops[pickedHops.length - 1].strength) {
        pickedHops[pickedHops.length - 1] = { hop: h, strength: Math.min(1, val) };
        lastPickedTimelineMs = timelineMs;
      }
      continue;
    }

    pickedHops.push({ hop: h, strength: Math.min(1, val) });
    lastPickedTimelineMs = timelineMs;
  }

  const beats: DetectedBeatPoint[] = [];
  for (const p of pickedHops) {
    const sourceSec = srcStartSec + p.hop * hopDurationSec;
    const localPlaySec = clip.reverse
      ? (srcDurationSec - sourceSec - srcStartSec) / clipSpeed
      : (sourceSec - srcStartSec) / clipSpeed;
    const timestampMs = Math.max(0, Math.round((clip.startTime + localPlaySec) * 1000));
    beats.push({
      timestampMs,
      time: timestampMs / 1000,
      strength: Math.round(p.strength * 100) / 100,
      clipId: clip.id,
    });
  }

  beats.sort((a, b) => a.timestampMs - b.timestampMs);
  const bpm = estimateBpmFromTimestamps(beats.map((b) => b.timestampMs));

  return {
    beats,
    bpm,
    durationSec: srcDurationSec,
    usedDecodedPcm: true,
  };
}

/**
 * Deterministic waveform envelope beat detector used only if Web Audio decoding is unavailable.
 */
function detectBeatsFromWaveformPeaks(
  peaks: number[],
  clip: TimelineClip,
  assetDurationSec: number,
  options: BeatDetectionOptions
): BeatDetectionResult {
  if (peaks.length < 4) {
    return { beats: [], bpm: 0, durationSec: assetDurationSec, usedDecodedPcm: false };
  }
  const sens = Math.max(5, Math.min(100, options.sensitivity));
  const normSens = (sens - 5) / 95;
  const minGapMs = options.minGapMs ?? Math.round(390 - normSens * 235);
  const threshFactor = 1.65 - normSens * 0.95;

  const avg = peaks.reduce((s, v) => s + v, 0) / peaks.length;
  const beats: DetectedBeatPoint[] = [];
  let lastMs = -Infinity;

  for (let i = 1; i < peaks.length - 1; i++) {
    const v = peaks[i];
    const diff = Math.max(0, v - peaks[i - 1] * 0.85);
    if (v >= peaks[i - 1] && v >= peaks[i + 1] && v > avg * threshFactor && diff > 0.05) {
      const frac = i / peaks.length;
      const srcTime = frac * assetDurationSec;
      const rel = (srcTime - clip.sourceOffset) / Math.max(0.25, clip.speed || 1);
      if (rel < 0 || rel > clip.duration) continue;
      const timestampMs = Math.round((clip.startTime + rel) * 1000);
      if (timestampMs - lastMs < minGapMs) continue;
      lastMs = timestampMs;
      beats.push({
        timestampMs,
        time: timestampMs / 1000,
        strength: Math.min(1, v),
        clipId: clip.id,
      });
    }
  }

  return {
    beats,
    bpm: estimateBpmFromTimestamps(beats.map((b) => b.timestampMs)),
    durationSec: assetDurationSec,
    usedDecodedPcm: false,
  };
}

export async function analyzeAudioTrackBeats(
  clips: TimelineClip[],
  assets: MediaAsset[],
  options: BeatDetectionOptions
): Promise<BeatDetectionResult> {
  const orderedClips = [...clips].sort((a, b) => a.startTime - b.startTime);
  const allBeats: DetectedBeatPoint[] = [];
  let maxDur = 0;
  let usedDecodedPcm = false;

  for (const clip of orderedClips) {
    const asset = assets.find((a) => a.id === clip.assetId);
    if (!asset) continue;
    maxDur = Math.max(maxDur, asset.duration || clip.duration);

    const decoded = await decodeAssetAudioPCM(asset);
    if (decoded) {
      usedDecodedPcm = true;
      const res = detectBeatsFromMonoPCM(
        decoded.mono,
        decoded.sampleRate,
        clip,
        decoded.durationSec,
        options
      );
      allBeats.push(...res.beats);
    } else if (asset.waveformPeaks && asset.waveformPeaks.length > 0) {
      const res = detectBeatsFromWaveformPeaks(
        asset.waveformPeaks,
        clip,
        asset.duration || clip.duration,
        options
      );
      allBeats.push(...res.beats);
    }
  }

  allBeats.sort((a, b) => a.timestampMs - b.timestampMs);
  // Deduplicate overlapping beat points across contiguous clips within 80ms
  const deduped: DetectedBeatPoint[] = [];
  for (const b of allBeats) {
    const prev = deduped[deduped.length - 1];
    if (!prev || Math.abs(b.timestampMs - prev.timestampMs) >= 80) {
      deduped.push(b);
    } else if (b.strength > prev.strength) {
      deduped[deduped.length - 1] = b;
    }
  }

  return {
    beats: deduped,
    bpm: estimateBpmFromTimestamps(deduped.map((b) => b.timestampMs)),
    durationSec: maxDur,
    usedDecodedPcm,
  };
}
