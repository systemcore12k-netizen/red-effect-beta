import { ArrayBufferTarget, Muxer } from 'mp4-muxer';
import { ExportSettings, StudioProject } from '../types/studio';
import {
  createMediaCache,
  renderCompositeFrame,
  seekVideosForTime,
} from './videoCompositor';
import { releasePooledBuffers } from './performanceEngine';
import {
  renderOpticalFlowFrameCanvas,
  serializeSmoothSignature,
  smoothVideoCache,
} from './smoothVideoEngine';

export function getResolutionDimensions(
  res: ExportSettings['resolution'],
  project?: StudioProject
): { width: number; height: number } {
  switch (res) {
    case 'project':
      return {
        width: Math.max(256, project?.width || 1920),
        height: Math.max(256, project?.height || 1080),
      };
    case '720p':
      return { width: 1280, height: 720 };
    case '2k':
    case '1440p':
      return { width: 2560, height: 1440 };
    case '4k':
      return { width: 3840, height: 2160 };
    case '8k':
      return { width: 7680, height: 4320 };
    case '1080p':
    default:
      return { width: 1920, height: 1080 };
  }
}

export async function detectSupportedVideoCodecs(
  width = 1920,
  height = 1080,
  fps = 60
): Promise<{ h264: boolean; h265: boolean }> {
  if (typeof VideoEncoder === 'undefined') {
    return { h264: false, h265: false };
  }
  const h264Codec = width >= 2560 ? 'avc1.640033' : 'avc1.640028';
  const [r264, r265] = await Promise.all([
    VideoEncoder.isConfigSupported({
      codec: h264Codec,
      width,
      height,
      bitrate: 14_000_000,
      framerate: fps,
    }).catch(() => ({ supported: false })),
    VideoEncoder.isConfigSupported({
      codec: 'hvc1.1.6.L153.B0',
      width,
      height,
      bitrate: 14_000_000,
      framerate: fps,
    }).catch(() => ({ supported: false })),
  ]);
  return {
    h264: Boolean(r264.supported),
    h265: Boolean(r265.supported),
  };
}

export function getProjectEndTime(project: StudioProject): number {
  if (project.clips.length === 0) return 5;
  return Math.max(1, ...project.clips.map((c) => c.startTime + c.duration));
}

function encodeAudioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = Math.min(2, buffer.numberOfChannels);
  const sampleRate = buffer.sampleRate;
  const length = buffer.length * numChannels * 2;
  const arrayBuffer = new ArrayBuffer(44 + length);
  const view = new DataView(arrayBuffer);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + length, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * numChannels * 2, true);
  view.setUint16(32, numChannels * 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, length, true);

  let offset = 44;
  for (let i = 0; i < buffer.length; i++) {
    for (let ch = 0; ch < numChannels; ch++) {
      const sample = Math.max(-1, Math.min(1, buffer.getChannelData(ch)[i]));
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
      offset += 2;
    }
  }

  return new Blob([arrayBuffer], { type: 'audio/wav' });
}

export async function mixTimelineAudioBuffer(
  project: StudioProject,
  sampleRateOverride?: number
): Promise<{ buffer: AudioBuffer; hasAudio: boolean }> {
  const duration = getProjectEndTime(project);
  const sampleRate = sampleRateOverride || project.audioSampleRate || 48000;
  const totalSamples = Math.max(sampleRate, Math.ceil(duration * sampleRate));
  const offline = new OfflineAudioContext(2, totalSamples, sampleRate);

  const anySolo = project.tracks.some((t) => t.solo);
  const audioClips = project.clips.filter((c) => {
    const asset = project.assets.find((a) => a.id === c.assetId);
    if (!asset) return false;
    if (asset.type !== 'audio' && asset.type !== 'video') return false;
    if (asset.type === 'video' && asset.hasAudio === false) return false;
    return !c.muted;
  });

  let scheduledCount = 0;

  for (const clip of audioClips) {
    const track = project.tracks.find((t) => t.id === clip.trackId);
    if (track?.muted) continue;
    if (anySolo && track && !track.solo) continue;

    const asset = project.assets.find((a) => a.id === clip.assetId);
    if (!asset) continue;

    try {
      const resp = await fetch(asset.url);
      const arrBuf = await resp.arrayBuffer();
      const decoded = await offline.decodeAudioData(arrBuf).catch(() => null);
      if (!decoded) continue;

      const source = offline.createBufferSource();
      source.buffer = decoded;
      const slowMult = clip.smoothVideo?.enabled ? clip.smoothVideo.slowMotionSpeed : 1;
      const safeRate = Math.max(0.08, Math.min(4, (clip.speed || 1) * slowMult));
      source.playbackRate.value = safeRate;

      const gainNode = offline.createGain();
      const baseVol = Math.max(0, clip.volume * (track?.volume ?? 1));
      const tStart = Math.max(0, clip.startTime);
      const tEnd = tStart + clip.duration;

      if (clip.fadeIn > 0) {
        gainNode.gain.setValueAtTime(0.0001, tStart);
        gainNode.gain.linearRampToValueAtTime(
          baseVol,
          tStart + Math.min(clip.fadeIn, clip.duration * 0.5)
        );
      } else {
        gainNode.gain.setValueAtTime(baseVol, tStart);
      }

      if (clip.fadeOut > 0) {
        const fadeStart = Math.max(tStart, tEnd - Math.min(clip.fadeOut, clip.duration * 0.5));
        gainNode.gain.setValueAtTime(baseVol, fadeStart);
        gainNode.gain.linearRampToValueAtTime(0.0001, tEnd);
      }

      const panner = offline.createStereoPanner();
      panner.pan.value = track?.pan ?? 0;

      source.connect(gainNode);
      gainNode.connect(panner);
      panner.connect(offline.destination);

      const offsetSec = Math.max(0, Math.min(decoded.duration - 0.02, clip.sourceOffset || 0));
      const sourcePlayDuration = Math.min(
        Math.max(0.05, decoded.duration - offsetSec),
        clip.duration * safeRate
      );
      source.start(tStart, offsetSec, sourcePlayDuration);
      scheduledCount++;
    } catch {
      // Ignore silent or non-audio clips
    }
  }

  const buffer = await offline.startRendering();
  return { buffer, hasAudio: scheduledCount > 0 };
}

export async function exportProjectMedia(
  project: StudioProject,
  settings: ExportSettings,
  playheadTime: number,
  onProgress: (pct: number, stage: string) => void,
  signal?: AbortSignal
): Promise<{ blob: Blob; suggestedFileName: string; mimeType: string; extension: string }> {
  const throwIfAborted = () => {
    if (signal?.aborted) {
      throw new DOMException('Export cancelled by user', 'AbortError');
    }
  };

  const smoothPairDecoders = new Map<string, HTMLVideoElement>();

  const seekSingleVideo = (vid: HTMLVideoElement, tSec: number) =>
    new Promise<void>((resolve) => {
      const safe = Math.max(0, Math.min(vid.duration || tSec, tSec));
      if (Math.abs(vid.currentTime - safe) <= 0.008 && vid.readyState >= 2) {
        resolve();
        return;
      }
      let done = false;
      const fin = () => {
        if (done) return;
        done = true;
        vid.removeEventListener('seeked', fin);
        resolve();
      };
      vid.addEventListener('seeked', fin);
      try {
        vid.currentTime = safe;
      } catch {
        fin();
      }
      setTimeout(fin, 220);
    });

  const prepareSmoothFramesForTime = async (
    proj: StudioProject,
    tTimeline: number,
    cache: ReturnType<typeof createMediaCache>
  ) => {
    for (const clip of proj.clips) {
      if (!clip.smoothVideo?.enabled || clip.smoothVideo.targetFps === 'original') continue;
      if (tTimeline < clip.startTime || tTimeline > clip.startTime + clip.duration) continue;
      const asset = proj.assets.find((a) => a.id === clip.assetId);
      if (!asset || asset.type !== 'video') continue;

      const rawLocalTime = Math.max(0, tTimeline - clip.startTime);
      const effectiveSpeed = clip.speed * clip.smoothVideo.slowMotionSpeed;
      const targetMediaTime = clip.reverse
        ? Math.max(0, asset.duration - (clip.sourceOffset + rawLocalTime * effectiveSpeed))
        : clip.sourceOffset + rawLocalTime * effectiveSpeed;
      const safeTime = Math.max(0, Math.min(asset.duration, targetMediaTime));

      if (smoothVideoCache.getNearestFrame(asset.id, clip.smoothVideo, safeTime, 0.012)) {
        continue;
      }

      const srcFps = asset.sourceFps || 30;
      const srcStep = 1 / Math.max(12, srcFps);
      const pairIdx = Math.floor(safeTime / srcStep);
      const tA = Math.max(0, Math.min(asset.duration, pairIdx * srcStep));
      const tB = Math.max(0, Math.min(asset.duration, (pairIdx + 1) * srcStep));
      const alpha = Math.max(0, Math.min(1, (safeTime - tA) / Math.max(0.0001, tB - tA)));
      if (alpha < 0.05 || alpha > 0.95) continue;

      const vidA = cache.videos.get(asset.id);
      if (!vidA || vidA.readyState < 2) continue;

      let vidB = smoothPairDecoders.get(asset.id);
      if (!vidB) {
        vidB = document.createElement('video');
        vidB.muted = true;
        vidB.playsInline = true;
        vidB.preload = 'auto';
        const srcUrl = asset.originalUrl || asset.url;
        if (!srcUrl.startsWith('blob:') && !srcUrl.startsWith('data:')) {
          vidB.crossOrigin = 'anonymous';
        }
        vidB.src = srcUrl;
        smoothPairDecoders.set(asset.id, vidB);
        await new Promise<void>((resolve) => {
          const ok = () => {
            vidB!.removeEventListener('loadeddata', ok);
            resolve();
          };
          vidB!.addEventListener('loadeddata', ok);
          setTimeout(resolve, 1000);
        });
      }

      await Promise.all([seekSingleVideo(vidA, tA), seekSingleVideo(vidB, tB)]);
      const outW = vidA.videoWidth || asset.width || 1280;
      const outH = vidA.videoHeight || asset.height || 720;
      const synth = renderOpticalFlowFrameCanvas(
        vidA,
        vidB,
        outW,
        outH,
        alpha,
        clip.smoothVideo.processingQuality,
        clip.smoothVideo.artifactSuppression
      );
      smoothVideoCache.putFrame(asset.id, serializeSmoothSignature(clip.smoothVideo), safeTime, synth);
    }
  };

  const cleanupCache = (cache: ReturnType<typeof createMediaCache>) => {
    cache.videos.forEach((v) => {
      try {
        v.pause();
        v.removeAttribute('src');
        v.load();
      } catch {
        // Ignore cleanup errors
      }
    });
    smoothPairDecoders.forEach((v) => {
      try {
        v.pause();
        v.removeAttribute('src');
        v.load();
      } catch {
        // Ignore cleanup errors
      }
    });
    smoothPairDecoders.clear();
    cache.videos.clear();
    cache.images.clear();
    releasePooledBuffers();
  };

  const safeBase = (settings.fileName || project.name || 'RED_EFFECT_Export').replace(
    /[^a-zA-Z0-9_-]/g,
    '_'
  );

  // 1. Single-frame Image Export (PNG / JPG)
  if (settings.format === 'png' || settings.format === 'jpg') {
    throwIfAborted();
    onProgress(25, 'Rendering high-resolution frame...');
    const { width, height } = getResolutionDimensions(settings.resolution, project);
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d')!;
    const cache = createMediaCache();

    try {
      await preloadProjectImages(project, cache);
      throwIfAborted();
      await seekVideosForTime(project, playheadTime, cache);
      throwIfAborted();
      renderCompositeFrame(ctx, project, playheadTime, cache, width, height, {
        seekVideos: true,
        isExport: true,
      });

      const mime = settings.format === 'png' ? 'image/png' : 'image/jpeg';
      const blob = await new Promise<Blob>((resolve) =>
        canvas.toBlob((b) => resolve(b || new Blob()), mime, 0.96)
      );
      onProgress(100, 'Frame ready');
      return {
        blob,
        suggestedFileName: `${safeBase}.${settings.format}`,
        mimeType: mime,
        extension: `.${settings.format}`,
      };
    } finally {
      cleanupCache(cache);
    }
  }

  // 2. Audio-Only Export (WAV / MP3 mixdown)
  if (settings.format === 'wav' || settings.format === 'mp3') {
    throwIfAborted();
    onProgress(30, 'Mixing multi-track audio...');
    const { buffer } = await mixTimelineAudioBuffer(project);
    throwIfAborted();
    onProgress(85, 'Encoding audio stream...');
    const wavBlob = encodeAudioBufferToWav(buffer);
    onProgress(100, 'Audio mixdown complete');
    return {
      blob: wavBlob,
      suggestedFileName: `${safeBase}.wav`,
      mimeType: 'audio/wav',
      extension: '.wav',
    };
  }

  // 3. Video Export (MP4 / MOV / WebM) WITH Synchronized Audio
  const { width, height } = getResolutionDimensions(settings.resolution, project);
  const fps = settings.fps || 30;
  const duration = getProjectEndTime(project);
  const totalFrames = Math.max(1, Math.round(duration * fps));
  const videoBitrate = (settings.bitrateMbps || 12) * 1_000_000;
  const audioBitrate = Number(settings.audioQuality || '192') * 1000;
  const sampleRate = project.audioSampleRate || 48000;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { colorSpace: 'srgb' }) || canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  const cache = createMediaCache();

  try {
    throwIfAborted();
    onProgress(4, 'Preloading visual & audio assets...');
    await preloadProjectImages(project, cache);
    throwIfAborted();

    let mixedAudio: { buffer: AudioBuffer; hasAudio: boolean } = {
      buffer: new AudioContext({ sampleRate }).createBuffer(2, sampleRate, sampleRate),
      hasAudio: false,
    };

    if (settings.audioEnabled !== false) {
      onProgress(8, 'Mixing timeline & video audio tracks...');
      mixedAudio = await mixTimelineAudioBuffer(project, sampleRate);
      throwIfAborted();
    }

    const includeAudio = settings.audioEnabled !== false && mixedAudio.hasAudio;

    // Check WebCodecs H.264 + AAC support for MP4 / MOV
    const canUseWebCodecs =
      (settings.format === 'mp4' || settings.format === 'mov') &&
      typeof VideoEncoder !== 'undefined' &&
      typeof VideoFrame !== 'undefined';

  if (canUseWebCodecs) {
    try {
      const wantH265 = settings.codec === 'h265';
      const h264Candidate = width >= 3840 ? 'avc1.640034' : width >= 2560 ? 'avc1.640033' : 'avc1.640028';
      const h265Candidate = 'hvc1.1.6.L153.B0';
      let chosenCodec = h264Candidate;
      let muxerCodec: 'avc' | 'hevc' = 'avc';

      let videoSupport = await VideoEncoder.isConfigSupported({
        codec: wantH265 ? h265Candidate : h264Candidate,
        width,
        height,
        bitrate: videoBitrate,
        framerate: fps,
      }).catch(() => ({ supported: false }));

      if (wantH265 && videoSupport.supported) {
        chosenCodec = h265Candidate;
        muxerCodec = 'hevc';
      } else if (wantH265 && !videoSupport.supported) {
        // Fallback to H.264 if HEVC encoder isn't present on this device
        videoSupport = await VideoEncoder.isConfigSupported({
          codec: h264Candidate,
          width,
          height,
          bitrate: videoBitrate,
          framerate: fps,
        }).catch(() => ({ supported: false }));
      }

      let audioSupport: AudioEncoderSupport | null = null;
      if (includeAudio && typeof AudioEncoder !== 'undefined' && typeof AudioData !== 'undefined') {
        audioSupport = await AudioEncoder.isConfigSupported({
          codec: 'mp4a.40.2',
          numberOfChannels: 2,
          sampleRate,
          bitrate: audioBitrate,
        }).catch(() => null);
      }

      const canMuxAudioInWebCodecs = !includeAudio || Boolean(audioSupport?.supported);

      if (videoSupport.supported && canMuxAudioInWebCodecs) {
        onProgress(
          12,
          includeAudio
            ? `Initializing ${muxerCodec.toUpperCase()} + AAC Muxer...`
            : `Initializing ${muxerCodec.toUpperCase()} Muxer...`
        );
        const muxerTarget = new ArrayBufferTarget();
        const muxer = new Muxer({
          target: muxerTarget,
          video: {
            codec: muxerCodec,
            width,
            height,
          },
          ...(includeAudio
            ? {
                audio: {
                  codec: 'aac',
                  numberOfChannels: 2,
                  sampleRate,
                },
              }
            : {}),
          fastStart: 'in-memory',
        });

        let encodeError: Error | null = null;
        const videoEncoder = new VideoEncoder({
          output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
          error: (e) => {
            encodeError = e;
          },
        });

        videoEncoder.configure({
          codec: chosenCodec,
          width,
          height,
          bitrate: videoBitrate,
          framerate: fps,
        });

        let audioEncoder: AudioEncoder | null = null;
        if (includeAudio) {
          audioEncoder = new AudioEncoder({
            output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
            error: (e) => {
              encodeError = e;
            },
          });
          audioEncoder.configure({
            codec: 'mp4a.40.2',
            numberOfChannels: 2,
            sampleRate,
            bitrate: audioBitrate,
          });

          // Feed mixed AudioBuffer into AAC AudioEncoder in 1024-sample planar chunks
          const totalAudioSamples = mixedAudio.buffer.length;
          const ch0 = mixedAudio.buffer.getChannelData(0);
          const ch1 =
            mixedAudio.buffer.numberOfChannels > 1 ? mixedAudio.buffer.getChannelData(1) : ch0;
          const chunkSize = 1024;
          for (let offset = 0; offset < totalAudioSamples; offset += chunkSize) {
            const frameCount = Math.min(chunkSize, totalAudioSamples - offset);
            const planar = new Float32Array(frameCount * 2);
            planar.set(ch0.subarray(offset, offset + frameCount), 0);
            planar.set(ch1.subarray(offset, offset + frameCount), frameCount);
            const audioData = new AudioData({
              format: 'f32-planar',
              sampleRate,
              numberOfFrames: frameCount,
              numberOfChannels: 2,
              timestamp: Math.round((offset / sampleRate) * 1_000_000),
              data: planar,
            });
            audioEncoder.encode(audioData);
            audioData.close();
          }
        }

        for (let f = 0; f < totalFrames; f++) {
          if (signal?.aborted) {
            try {
              videoEncoder.close();
              audioEncoder?.close();
            } catch {
              // ignore close errors
            }
            throw new DOMException('Export cancelled by user', 'AbortError');
          }
          if (encodeError) throw encodeError;
          const t = f / fps;
          await seekVideosForTime(project, t, cache);
          await prepareSmoothFramesForTime(project, t, cache);
          renderCompositeFrame(ctx, project, t, cache, width, height, {
            seekVideos: true,
            isExport: true,
          });

          const frame = new VideoFrame(canvas, {
            timestamp: Math.round((f * 1_000_000) / fps),
            duration: Math.round(1_000_000 / fps),
          });
          videoEncoder.encode(frame, { keyFrame: f % (Math.max(1, fps) * 2) === 0 });
          frame.close();

          if (f % 4 === 0) {
            onProgress(
              15 + Math.round((f / totalFrames) * 80),
              `Encoding frame ${f + 1}/${totalFrames}`
            );
            await new Promise((r) => setTimeout(r, 0));
          }
        }

        await videoEncoder.flush();
        videoEncoder.close();
        if (audioEncoder) {
          await audioEncoder.flush();
          audioEncoder.close();
        }
        muxer.finalize();

        const blob = new Blob([muxerTarget.buffer], {
          type: settings.format === 'mov' ? 'video/quicktime' : 'video/mp4',
        });
        onProgress(100, 'Export complete with audio');
        return {
          blob,
          suggestedFileName: `${safeBase}.${settings.format}`,
          mimeType: settings.format === 'mov' ? 'video/quicktime' : 'video/mp4',
          extension: `.${settings.format}`,
        };
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        throw err;
      }
      console.warn('WebCodecs muxer fallback to MediaRecorder with audio:', err);
    }
  }

  // Real-time MediaRecorder with Video + Mixed Audio Track (preserves sound reliably)
  throwIfAborted();
  onProgress(14, includeAudio ? 'Recording composite video + audio stream...' : 'Recording video stream...');
  const canvasStream = canvas.captureStream(fps);
  const combinedTracks: MediaStreamTrack[] = [...canvasStream.getVideoTracks()];

  let liveAudioCtx: AudioContext | null = null;
  let audioSource: AudioBufferSourceNode | null = null;

  if (includeAudio) {
    liveAudioCtx = new AudioContext({ sampleRate });
    const dest = liveAudioCtx.createMediaStreamDestination();
    audioSource = liveAudioCtx.createBufferSource();
    audioSource.buffer = mixedAudio.buffer;
    audioSource.connect(dest);
    combinedTracks.push(...dest.stream.getAudioTracks());
  }

  const finalStream = new MediaStream(combinedTracks);
  const mimeCandidates =
    settings.format === 'webm'
      ? ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
      : [
          'video/mp4;codecs=avc1,mp4a.40.2',
          'video/mp4',
          'video/webm;codecs=vp9,opus',
          'video/webm;codecs=vp8,opus',
          'video/webm',
        ];
  const chosenMime =
    mimeCandidates.find((m) => MediaRecorder.isTypeSupported(m)) || 'video/webm';

  const recorder = new MediaRecorder(finalStream, {
    mimeType: chosenMime,
    videoBitsPerSecond: videoBitrate,
    audioBitsPerSecond: audioBitrate,
  });

  const chunks: BlobPart[] = [];
  recorder.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };

  const stopPromise = new Promise<Blob>((resolve) => {
    recorder.onstop = () => resolve(new Blob(chunks, { type: chosenMime }));
  });

  recorder.start(150);
  if (audioSource) {
    audioSource.start(0);
  }

  const frameMs = 1000 / fps;
  try {
    for (let f = 0; f < totalFrames; f++) {
      throwIfAborted();
      const t = f / fps;
      await seekVideosForTime(project, t, cache);
      await prepareSmoothFramesForTime(project, t, cache);
      renderCompositeFrame(ctx, project, t, cache, width, height, {
        seekVideos: true,
        isExport: true,
      });
      onProgress(15 + Math.round((f / totalFrames) * 82), `Rendering frame ${f + 1}/${totalFrames}`);
      await new Promise((r) => setTimeout(r, frameMs));
    }

    recorder.stop();
    try {
      audioSource?.stop();
    } catch {
      // Already stopped
    }
    const blob = await stopPromise;
    onProgress(100, 'Export complete');

    const actualExt = chosenMime.includes('mp4')
      ? settings.format === 'mov'
        ? 'mov'
        : 'mp4'
      : 'webm';
    return {
      blob,
      suggestedFileName: `${safeBase}.${actualExt}`,
      mimeType: chosenMime,
      extension: `.${actualExt}`,
    };
  } catch (err) {
    try {
      if (recorder.state !== 'inactive') recorder.stop();
    } catch {
      // ignore
    }
    try {
      audioSource?.stop();
    } catch {
      // ignore
    }
    throw err;
  } finally {
    if (liveAudioCtx) {
      liveAudioCtx.close().catch(() => {});
    }
  }
  } finally {
    cleanupCache(cache);
  }
}

async function preloadProjectImages(
  project: StudioProject,
  cache: ReturnType<typeof createMediaCache>
) {
  const promises: Promise<void>[] = [];
  for (const asset of project.assets) {
    if (asset.type === 'image') {
      promises.push(
        new Promise((resolve) => {
          const img = new Image();
          if (!asset.url.startsWith('blob:') && !asset.url.startsWith('data:')) {
            img.crossOrigin = 'anonymous';
          }
          img.onload = () => {
            cache.images.set(asset.id, img);
            resolve();
          };
          img.onerror = () => resolve();
          img.src = asset.url;
        })
      );
    }
  }
  await Promise.all(promises);
}
