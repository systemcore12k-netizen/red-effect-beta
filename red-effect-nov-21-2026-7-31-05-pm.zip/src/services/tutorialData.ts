import {
  MediaAsset,
  PanelId,
  StudioProject,
  TimelineClip,
  TimelineTrack,
  WorkspaceMode,
} from '../types/studio';
import { createClipDefaults, DEFAULT_PROJECT_FOLDERS } from './projectStorage';
import { createEffectInstance, getDefaultTransitionSettings } from './effectsCatalog';

export const TUTORIAL_PROJECT_ID = 'proj-redeffect-learn-basics';
export const TUTORIAL_PROJECT_NAME = 'RED EFFECT - LEARN THE BASICS';
export const FIRST_LAUNCH_DONE_KEY = 'redeffect_first_launch_done_v1';
export const TUTORIAL_PROGRESS_KEY = 'redeffect_tutorial_progress_v1';

export interface TutorialCompletionContext {
  project: StudioProject;
  selectedClip: TimelineClip | null;
  workspaceMode: WorkspaceMode;
  slots: {
    leftTop: PanelId;
    leftBottom: PanelId;
    center: PanelId;
    right: PanelId;
    bottom: PanelId;
  };
  playheadTime: number;
  isPlaying: boolean;
  autoKeyframeEnabled: boolean;
  exportModalOpen: boolean;
}

export interface TutorialStep {
  id: string;
  chapterId: number;
  chapterTitle: string;
  stepNumberLabel: string;
  title: string;
  description: string;
  actionHint: string;
  targetSelector: string;
  recommendedWorkspace?: WorkspaceMode;
  recommendedLeftTop?: PanelId;
  recommendedLeftBottom?: PanelId;
  recommendedRight?: PanelId;
  recommendedBottom?: PanelId;
  checkCompleted?: (ctx: TutorialCompletionContext) => boolean;
}

export interface TutorialChapter {
  id: number;
  title: string;
  summary: string;
}

export const TUTORIAL_CHAPTERS: TutorialChapter[] = [
  { id: 1, title: 'Interface Introduction', summary: 'Home screen, toolbar, workspaces & docking layout' },
  { id: 2, title: 'Media Import', summary: 'Import PC video, images, music & browse assets' },
  { id: 3, title: 'Timeline', summary: 'Multi-track video, audio, text, overlay & zoom' },
  { id: 4, title: 'Preview Monitor', summary: 'Transport controls, scrubbing & direct canvas transforms' },
  { id: 5, title: 'Basic Editing', summary: 'Select, razor split, merge, copy/paste & timeline markers' },
  { id: 6, title: 'Text & Shape Tools', summary: 'Animated typography, styles, vector shapes & masking' },
  { id: 7, title: 'Effects & Transitions', summary: 'Stack FX glow/blur/color grading & clip transitions' },
  { id: 8, title: 'Null Objects & Parenting', summary: 'Create Null rigs, parent child layers & drive group motion' },
  { id: 9, title: 'Keyframes & Graph Editor', summary: 'Diamond toggles, 13 easing presets & custom Bezier curves' },
  { id: 10, title: 'Export', summary: 'Resolution, FPS, bitrate, audio mixdown & final render' },
];

export const TUTORIAL_STEPS: TutorialStep[] = [
  // CHAPTER 1: Interface Introduction
  {
    id: 'ch1-toolbar',
    chapterId: 1,
    chapterTitle: 'CHAPTER 1: Interface Introduction',
    stepNumberLabel: '1.1',
    title: 'Main Menu & Studio Toolbar',
    description:
      'Welcome to RED EFFECT! The top toolbar gives you quick access to File, Edit, Project Settings, Clip & Sequence actions, Undo/Redo, Master Audio volume, and Export.',
    actionHint: 'Explore the menu bar or switch workspaces from the top bar.',
    targetSelector: '[data-tutorial-target="main-toolbar"]',
    recommendedWorkspace: 'editing',
    recommendedLeftTop: 'media',
    recommendedLeftBottom: 'effects',
    recommendedRight: 'properties',
    recommendedBottom: 'timeline',
  },
  {
    id: 'ch1-workspaces',
    chapterId: 1,
    chapterTitle: 'CHAPTER 1: Interface Introduction',
    stepNumberLabel: '1.2',
    title: 'Workspace Switcher & Home Screen',
    description:
      'Use the left Studio Sidebar or top workspace tabs to move cleanly between Video Editor, Motion Graphics, 3D Studio, 4D Studio, and Audio Studio. Click Home anytime to create or open projects.',
    actionHint: 'Click any workspace tab or use Home to manage New/Open Project.',
    targetSelector: '[data-tutorial-target="sidebar-workspaces"]',
    recommendedWorkspace: 'editing',
  },

  // CHAPTER 2: Media Import
  {
    id: 'ch2-media-explorer',
    chapterId: 2,
    chapterTitle: 'CHAPTER 2: Media Import',
    stepNumberLabel: '2.1',
    title: 'Media Explorer & Project Assets',
    description:
      'Media Explorer stores every video, photo, music track, and 3D model in your project. You can drag any asset directly onto a timeline track or click "+" to insert it at the playhead.',
    actionHint: 'Click any sample clip card inside Media Explorer to preview its asset info.',
    targetSelector: '[data-tutorial-target="media-explorer"]',
    recommendedWorkspace: 'editing',
    recommendedLeftTop: 'media',
    recommendedBottom: 'timeline',
  },
  {
    id: 'ch2-import-btn',
    chapterId: 2,
    chapterTitle: 'CHAPTER 2: Media Import',
    stepNumberLabel: '2.2',
    title: 'Import Video, Image & Audio from PC',
    description:
      'Click "Import Media" (or press Ctrl+I) to load MP4, MOV, WebM, PNG, JPG, MP3, WAV, AAC, or 3D GLB/OBJ files from your computer. Video audio tracks are automatically decoded with waveforms.',
    actionHint: 'Locate the crimson Import Media button at the top of Media Explorer.',
    targetSelector: '[data-tutorial-target="import-media-btn"]',
    recommendedWorkspace: 'editing',
    recommendedLeftTop: 'media',
  },

  // CHAPTER 3: Timeline
  {
    id: 'ch3-tracks',
    chapterId: 3,
    chapterTitle: 'CHAPTER 3: Timeline',
    stepNumberLabel: '3.1',
    title: 'Multi-Track Layers (Video, Text, Overlay, Null, Audio)',
    description:
      'Your tutorial project already includes a Null rig track (N1), Title track (T1), Overlay (V2), Main Video (V1), and stereo Audio beat (A1). Use track buttons to Mute (M), Solo (S), Lock (L), or Hide.',
    actionHint: 'Click any clip in the Timeline tracks to inspect its layers and keyframes.',
    targetSelector: '[data-tutorial-target="timeline-tracks"]',
    recommendedWorkspace: 'editing',
    recommendedBottom: 'timeline',
    checkCompleted: (ctx) => Boolean(ctx.selectedClip),
  },
  {
    id: 'ch3-zoom',
    chapterId: 3,
    chapterTitle: 'CHAPTER 3: Timeline',
    stepNumberLabel: '3.2',
    title: 'Timeline Zoom & Navigation',
    description:
      'Adjust Timeline Zoom or click Fit to view your full edit at once, or zoom in closely to align cuts and keyframe diamonds with audio waveforms.',
    actionHint: 'Drag the Timeline Zoom slider or press Fit to reframe the timeline.',
    targetSelector: '[data-tutorial-target="timeline-zoom"]',
    recommendedWorkspace: 'editing',
    recommendedBottom: 'timeline',
  },

  // CHAPTER 4: Preview Monitor
  {
    id: 'ch4-playback',
    chapterId: 4,
    chapterTitle: 'CHAPTER 4: Preview Monitor',
    stepNumberLabel: '4.1',
    title: 'Play, Scrub & Watch Real-Time Motion',
    description:
      'Press Space or click Play in the transport bar to watch the pre-built RED EFFECT tutorial animation—complete with Null parenting, kinetic typography, crimson glow, and stereo music.',
    actionHint: 'Press Play (or Space) to preview the tutorial sequence.',
    targetSelector: '[data-tutorial-target="playback-controls"]',
    recommendedWorkspace: 'editing',
    recommendedBottom: 'timeline',
    checkCompleted: (ctx) => ctx.isPlaying || ctx.playheadTime > 0.25,
  },
  {
    id: 'ch4-canvas-tools',
    chapterId: 4,
    chapterTitle: 'CHAPTER 4: Preview Monitor',
    stepNumberLabel: '4.2',
    title: 'Direct Canvas Transform & Tools',
    description:
      'With Select active, drag any visual layer directly in the Preview Monitor or drag its corner handles to scale and rotate. You can also switch to Text, Shape, Pen Mask, or Snap Grid toggles here.',
    actionHint: 'Try dragging a layer on the monitor or toggling Snap Grid.',
    targetSelector: '[data-tutorial-target="canvas-tools"]',
    recommendedWorkspace: 'editing',
  },

  // CHAPTER 5: Basic Editing
  {
    id: 'ch5-edit-tools',
    chapterId: 5,
    chapterTitle: 'CHAPTER 5: Basic Editing',
    stepNumberLabel: '5.1',
    title: 'Cut, Split, Merge, Copy/Paste & Markers',
    description:
      'Use Select (V) to move/trim clips or Razor (C) to slice clips anywhere. Click Split at Playhead, Merge, Copy/Paste, or press M to drop colored Timeline Markers aligned to beats.',
    actionHint: 'Try selecting the Razor or Split button or dropping a Marker (M).',
    targetSelector: '[data-tutorial-target="timeline-edit-tools"]',
    recommendedWorkspace: 'editing',
    recommendedBottom: 'timeline',
  },

  // CHAPTER 6: Text & Shape Tools
  {
    id: 'ch6-text-studio',
    chapterId: 6,
    chapterTitle: 'CHAPTER 6: Text & Shape Tools',
    stepNumberLabel: '6.1',
    title: 'Text Animation Studio',
    description:
      'Create kinetic titles, gradients, 3D extrusions, and subtitles. Each text layer supports character/word reveal animations plus ◆ keyframeable Font Size and Tracking.',
    actionHint: 'Edit the title text, pick an animation preset, or click Add Title.',
    targetSelector: '[data-tutorial-target="text-studio-panel"]',
    recommendedWorkspace: 'motion',
    recommendedLeftTop: 'effects',
    recommendedLeftBottom: 'textStudio',
  },
  {
    id: 'ch6-shapes-mask',
    chapterId: 6,
    chapterTitle: 'CHAPTER 6: Text & Shape Tools',
    stepNumberLabel: '6.2',
    title: 'Vector Shapes & Bezier Masking',
    description:
      'Add geometric vector cards, stars, or custom Bezier paths—and apply animated masks with ◆ keyframeable Radius, Feather, and Expansion to any clip.',
    actionHint: 'Inspect the tutorial shape card or click a Shape/Mask button.',
    targetSelector: '[data-tutorial-target="shapes-mask-panel"]',
    recommendedWorkspace: 'editing',
    recommendedLeftBottom: 'shapes',
  },

  // CHAPTER 7: Effects & Transitions
  {
    id: 'ch7-effects',
    chapterId: 7,
    chapterTitle: 'CHAPTER 7: Effects & Transitions',
    stepNumberLabel: '7.1',
    title: 'Effects Library & Stackable FX',
    description:
      'Browse Blur, Glow, Color, Distortion, Glitch, Shadow, and Stylize effects. Click or drag any effect onto a clip to stack multiple real-time GPU/Canvas effects together.',
    actionHint: 'Browse the Effects Library or click "+ Add" on any effect.',
    targetSelector: '[data-tutorial-target="effects-panel"]',
    recommendedWorkspace: 'editing',
    recommendedLeftBottom: 'effects',
    recommendedRight: 'properties',
  },
  {
    id: 'ch7-transitions',
    chapterId: 7,
    chapterTitle: 'CHAPTER 7: Effects & Transitions',
    stepNumberLabel: '7.2',
    title: 'Clip In/Out Transitions',
    description:
      'Apply Cross Dissolve, Dip to Black, Whip Pan, Glitch Cut, or 3D Cube transitions to the start or end of any clip with custom duration and curve speed.',
    actionHint: 'Select a clip and click "Apply In" or "Apply Out" on any transition.',
    targetSelector: '[data-tutorial-target="transitions-panel"]',
    recommendedWorkspace: 'editing',
    recommendedLeftTop: 'transitions',
  },

  // CHAPTER 8: Null Objects & Parenting
  {
    id: 'ch8-null-parenting',
    chapterId: 8,
    chapterTitle: 'CHAPTER 8: Null Objects & Parenting',
    stepNumberLabel: '8.1',
    title: 'Null Objects & Layer Parenting',
    description:
      'A Null Object ("Master Motion Null") is an invisible controller visible only in the editor (automatically hidden on Export). Parent text, shapes, or footage to a Null so one animation drives multiple layers together!',
    actionHint: 'Notice how the Shape & Title follow "Master Motion Null". Try changing a parent link or creating a Null.',
    targetSelector: '[data-tutorial-target="null-hierarchy-panel"]',
    recommendedWorkspace: 'editing',
    recommendedBottom: 'nullHierarchy',
    checkCompleted: (ctx) =>
      ctx.project.clips.some((c) => c.type === 'null') &&
      ctx.project.clips.some((c) => Boolean(c.parentClipId)),
  },

  // CHAPTER 9: Keyframes & Graph Editor
  {
    id: 'ch9-keyframe-controls',
    chapterId: 9,
    chapterTitle: 'CHAPTER 9: Keyframes & Graph Editor',
    stepNumberLabel: '9.1',
    title: 'Keyframe Controls & ◆ Diamond Toggles',
    description:
      'Every animatable property has a ◆ diamond toggle. Click ◆ to add/remove a keyframe at the playhead, use "< Prev / Next >" to jump between keys, or toggle "Auto ON" to record slider/drag changes automatically!',
    actionHint: 'Click a ◆ diamond toggle or enable Auto Keyframe in the Inspector.',
    targetSelector: '[data-tutorial-target="keyframe-controls"]',
    recommendedWorkspace: 'editing',
    recommendedRight: 'properties',
    recommendedBottom: 'timeline',
    checkCompleted: (ctx) =>
      ctx.autoKeyframeEnabled || Boolean(ctx.selectedClip && ctx.selectedClip.keyframes.length >= 2),
  },
  {
    id: 'ch9-graph-editor',
    chapterId: 9,
    chapterTitle: 'CHAPTER 9: Keyframes & Graph Editor',
    stepNumberLabel: '9.2',
    title: 'Alight Motion-Style Graph Editor & Bezier Curves',
    description:
      'Shape smooth acceleration using 13 built-in easing presets (Linear, Smooth, Overshoot, Bounce, Elastic, Anticipation) or drag the red/blue Bezier handles (P1/P2) directly on the curve! Switch between Easing Curve & Value Graph anytime.',
    actionHint: 'Drag a Bezier handle or pick a curve preset on the right of the Graph Editor.',
    targetSelector: '[data-tutorial-target="graph-editor-panel"]',
    recommendedWorkspace: 'motion',
    recommendedBottom: 'keyframes',
    checkCompleted: (ctx) =>
      ctx.slots.bottom === 'keyframes' &&
      Boolean(ctx.selectedClip && ctx.selectedClip.keyframes.some((k) => Boolean(k.bezier))),
  },

  // CHAPTER 10: Export
  {
    id: 'ch10-export',
    chapterId: 10,
    chapterTitle: 'CHAPTER 10: Export',
    stepNumberLabel: '10.1',
    title: 'Export Final Video & Audio',
    description:
      'When your edit is complete, click Export (Ctrl+M) in the top right or sidebar to choose MP4, MOV, WebM, PNG/JPG frame, or WAV/MP3 audio mixdown—up to 4K 120 FPS with full synchronized sound.',
    actionHint: 'Click the crimson Export button to inspect final render settings.',
    targetSelector: '[data-tutorial-target="export-button"]',
    recommendedWorkspace: 'editing',
    recommendedBottom: 'timeline',
    checkCompleted: (ctx) => ctx.exportModalOpen,
  },
];

/**
 * Generates a real playable 4.5-second stereo WAV music beat as a persistent Data URL
 * plus crisp normalized waveform peaks for the timeline display.
 */
function generateTutorialBeatWav(): {
  dataUrl: string;
  duration: number;
  waveformPeaks: number[];
} {
  const sampleRate = 22050;
  const duration = 6.0;
  const numSamples = Math.floor(sampleRate * duration);
  const numChannels = 2;
  const bitsPerSample = 16;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const byteRate = sampleRate * blockAlign;
  const dataSize = numSamples * blockAlign;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  writeStr(12, 'fmt ');
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitsPerSample, true);
  writeStr(36, 'data');
  view.setUint32(40, dataSize, true);

  const bpm = 120;
  const beatLen = 60 / bpm; // 0.5s per beat
  const rootNotes = [110, 110, 130.81, 146.83, 164.81, 146.83]; // A2 cinematic pulse

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const beatPos = (t % beatLen) / beatLen;
    const barIdx = Math.floor(t / beatLen) % rootNotes.length;
    const freq = rootNotes[barIdx];

    // Kick thump at start of each beat
    const kickEnv = Math.exp(-beatPos * 14);
    const kickFreq = 46 + 90 * Math.exp(-beatPos * 22);
    const kick = Math.sin(2 * Math.PI * kickFreq * t) * kickEnv * 0.58;

    // Warm dark synth bass + subtle stereo shimmer
    const padEnv = Math.min(1, t * 2) * Math.min(1, (duration - t) * 2.5);
    const bass =
      (Math.sin(2 * Math.PI * freq * t) * 0.25 +
        Math.sin(2 * Math.PI * freq * 2 * t) * 0.1) *
      padEnv;

    // Crisp offbeat hi-hat shimmer
    const halfBeat = ((t + beatLen * 0.5) % beatLen) / beatLen;
    const hatEnv = Math.exp(-halfBeat * 28);
    const pseudoNoise = Math.sin(i * 12.9898) * 43758.5453;
    const noise = (pseudoNoise - Math.floor(pseudoNoise)) * 2 - 1;
    const hat = noise * hatEnv * 0.14;

    const shimmerL = Math.sin(2 * Math.PI * (freq * 3) * t + 0.3) * 0.06 * padEnv;
    const shimmerR = Math.sin(2 * Math.PI * (freq * 3) * t - 0.3) * 0.06 * padEnv;

    const left = Math.max(-0.95, Math.min(0.95, kick + bass + hat + shimmerL));
    const right = Math.max(-0.95, Math.min(0.95, kick + bass + hat + shimmerR));

    const offset = 44 + i * 4;
    view.setInt16(offset, Math.round(left * 32767), true);
    view.setInt16(offset + 2, Math.round(right * 32767), true);
  }

  // Convert ArrayBuffer to Base64 in safe chunks
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  const base64 = btoa(binary);
  const dataUrl = `data:audio/wav;base64,${base64}`;

  // Build 48 crisp waveform peaks matching the beat
  const peakCount = 48;
  const waveformPeaks: number[] = [];
  const step = Math.floor(numSamples / peakCount);
  for (let p = 0; p < peakCount; p++) {
    let maxAmp = 0;
    const start = p * step;
    for (let s = start; s < start + step; s += 8) {
      const sample = Math.abs(view.getInt16(44 + s * 4, true) / 32767);
      if (sample > maxAmp) maxAmp = sample;
    }
    waveformPeaks.push(Math.round(Math.max(0.12, Math.min(1, maxAmp)) * 100) / 100);
  }

  return { dataUrl, duration, waveformPeaks };
}

/**
 * Generates a fast, real playable crimson motion WebM video sample (~400ms render -> 3s clip)
 * as a persistent Data URL so Sample Video clips work immediately in Preview & Export.
 */
async function generateTutorialSampleVideo(): Promise<{
  url: string;
  thumbnailUrl: string;
  duration: number;
  width: number;
  height: number;
  mimeType: string;
}> {
  const width = 640;
  const height = 360;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  const drawFrame = (progress: number) => {
    if (!ctx) return;
    const bg = ctx.createLinearGradient(0, 0, width, height);
    bg.addColorStop(0, '#07070B');
    bg.addColorStop(0.55, '#19060B');
    bg.addColorStop(1, '#09090D');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    // Subtle cinematic perspective grid
    ctx.strokeStyle = 'rgba(229, 9, 20, 0.16)';
    ctx.lineWidth = 1;
    const shift = progress * 40;
    for (let x = -40; x < width + 40; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x + (shift % 40), 0);
      ctx.lineTo(x + (shift % 40), height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Glowing crimson energy rings
    const cx = width / 2 + Math.sin(progress * Math.PI * 2) * 56;
    const cy = height / 2 + Math.cos(progress * Math.PI * 2) * 18;
    const rad = ctx.createRadialGradient(cx, cy, 8, cx, cy, 175);
    rad.addColorStop(0, 'rgba(229, 9, 20, 0.55)');
    rad.addColorStop(0.45, 'rgba(190, 18, 60, 0.22)');
    rad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = rad;
    ctx.fillRect(0, 0, width, height);

    // Floating light streaks
    for (let i = 0; i < 6; i++) {
      const px = ((i * 127 + progress * 360) % (width + 120)) - 60;
      const py = 55 + ((i * 53) % (height - 110));
      ctx.fillStyle = 'rgba(253, 164, 175, 0.45)';
      ctx.beginPath();
      ctx.arc(px, py, 2.5 + (i % 3), 0, Math.PI * 2);
      ctx.fill();
    }

    // Center diamond watermark
    ctx.save();
    ctx.translate(width / 2, height / 2);
    ctx.rotate(progress * Math.PI * 0.5);
    ctx.strokeStyle = 'rgba(229, 9, 20, 0.72)';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(-42, -42, 84, 84);
    ctx.restore();
  };

  drawFrame(0.2);
  const thumbnailUrl = canvas.toDataURL('image/jpeg', 0.85);

  if (typeof MediaRecorder === 'undefined' || typeof canvas.captureStream !== 'function') {
    return {
      url: thumbnailUrl,
      thumbnailUrl,
      duration: 3.5,
      width,
      height,
      mimeType: 'image/jpeg',
    };
  }

  const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
    ? 'video/webm;codecs=vp9'
    : MediaRecorder.isTypeSupported('video/webm')
    ? 'video/webm'
    : '';

  if (!mimeType) {
    return {
      url: thumbnailUrl,
      thumbnailUrl,
      duration: 3.5,
      width,
      height,
      mimeType: 'image/jpeg',
    };
  }

  return new Promise((resolve) => {
    try {
      const stream = canvas.captureStream(24);
      const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 1_200_000 });
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) chunks.push(ev.data);
      };

      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, { type: mimeType });
        const reader = new FileReader();
        reader.onloadend = () => {
          const dataUrl = typeof reader.result === 'string' ? reader.result : thumbnailUrl;
          resolve({
            url: dataUrl,
            thumbnailUrl,
            duration: 3.5,
            width,
            height,
            mimeType: mimeType.split(';')[0],
          });
        };
        reader.onerror = () => {
          resolve({
            url: thumbnailUrl,
            thumbnailUrl,
            duration: 3.5,
            width,
            height,
            mimeType: 'image/jpeg',
          });
        };
        reader.readAsDataURL(blob);
      };

      recorder.start();
      const totalMs = 450;
      const start = performance.now();
      const step = () => {
        const elapsed = performance.now() - start;
        const p = Math.min(1, elapsed / totalMs);
        drawFrame(p);
        if (p < 1) {
          requestAnimationFrame(step);
        } else if (recorder.state !== 'inactive') {
          recorder.stop();
        }
      };
      requestAnimationFrame(step);
    } catch {
      resolve({
        url: thumbnailUrl,
        thumbnailUrl,
        duration: 3.5,
        width,
        height,
        mimeType: 'image/jpeg',
      });
    }
  });
}

/**
 * Builds the complete pre-configured, fully editable first-launch project:
 * "RED EFFECT - LEARN THE BASICS"
 */
export async function buildAndPrepareTutorialProject(): Promise<StudioProject> {
  const now = Date.now();
  const [videoSample, beatWav] = await Promise.all([
    generateTutorialSampleVideo(),
    Promise.resolve(generateTutorialBeatWav()),
  ]);

  const isActualVideo = videoSample.mimeType.startsWith('video/');

  const assets: MediaAsset[] = [
    {
      id: 'tut-asset-video',
      name: isActualVideo ? 'Crimson_Motion_Backdrop.webm' : 'Crimson_Motion_Backdrop.jpg',
      type: isActualVideo ? 'video' : 'image',
      mimeType: videoSample.mimeType,
      url: videoSample.url,
      thumbnailUrl: videoSample.thumbnailUrl,
      duration: 5.0,
      width: videoSample.width,
      height: videoSample.height,
      folder: 'Media/Videos',
      createdAt: now - 4000,
      isStarter: true,
    },
    {
      id: 'tut-asset-street',
      name: 'Night_Rain_Street.jpg',
      type: 'image',
      mimeType: 'image/jpeg',
      url: '/src/assets/images/starter_cinema_street_1794826556326.jpg',
      duration: 5.0,
      width: 1920,
      height: 1080,
      folder: 'Media/Images',
      createdAt: now - 3000,
      isStarter: true,
    },
    {
      id: 'tut-asset-car',
      name: 'Apex_Coupe_Twilight.jpg',
      type: 'image',
      mimeType: 'image/jpeg',
      url: '/src/assets/images/starter_car_sunset_1794826557013.jpg',
      duration: 5.0,
      width: 1920,
      height: 1080,
      folder: 'Media/Images',
      createdAt: now - 2000,
      isStarter: true,
    },
    {
      id: 'tut-asset-beat',
      name: 'Crimson_Pulse_Beat_120BPM.wav',
      type: 'audio',
      mimeType: 'audio/wav',
      url: beatWav.dataUrl,
      duration: beatWav.duration,
      folder: 'Media/Audio',
      createdAt: now - 1000,
      waveformPeaks: beatWav.waveformPeaks,
      hasAudio: true,
      isStarter: true,
    },
  ];

  const tracks: TimelineTrack[] = [
    { id: 'N1', name: 'N1 · Null Rig', kind: 'null', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0 },
    { id: 'T1', name: 'T1 · Titles', kind: 'text', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0 },
    { id: 'S1', name: 'S1 · Shapes', kind: 'shape', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0 },
    { id: 'V2', name: 'V2 · Overlay', kind: 'video', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0 },
    { id: 'V1', name: 'V1 · Main Video', kind: 'video', muted: false, solo: false, locked: false, visible: true, volume: 1, pan: 0 },
    { id: 'A1', name: 'A1 · Music Beat', kind: 'audio', muted: false, solo: false, locked: false, visible: true, volume: 0.9, pan: 0 },
  ];

  const glowFx = createEffectInstance('glow');
  const vignetteFx = createEffectInstance('vignette');

  const clips: TimelineClip[] = [
    // 1. Sample Video Clip (0s -> 3.5s)
    createClipDefaults({
      id: 'clip-tut-video',
      assetId: 'tut-asset-video',
      trackId: 'V1',
      name: 'Sample Video · Crimson Backdrop',
      type: isActualVideo ? 'video' : 'image',
      startTime: 0,
      duration: 3.5,
      transitionIn: 'dip-to-black',
      transitionInDuration: 0.6,
      transitionInConfig: getDefaultTransitionSettings('dip-to-black'),
      transitionOut: 'cross-dissolve',
      transitionOutDuration: 0.6,
      transitionOutConfig: getDefaultTransitionSettings('cross-dissolve'),
      colorGrade: {
        preset: 'crimson-noir',
        exposure: 4,
        contrast: 14,
        saturation: 10,
        temperature: -6,
        tint: 4,
        vignette: 28,
        highlights: 8,
        shadows: -10,
      },
      effects: {
        blur: 0,
        glow: 14,
        glowColor: '#E50914',
        stabilization: 0,
        filmGrain: 10,
        chromaticAberration: 2,
        particles: 'red-smoke',
        particleIntensity: 42,
      },
      effectsStack: vignetteFx ? [vignetteFx] : [],
      keyframes: [
        {
          id: 'tut-kf-vid-s1',
          time: 0,
          property: 'scale',
          value: 1.0,
          easing: 'smooth',
          bezier: [0.25, 0.1, 0.25, 1],
        },
        {
          id: 'tut-kf-vid-s2',
          time: 3.5,
          property: 'scale',
          value: 1.14,
          easing: 'smoothEnd',
          bezier: [0.22, 0.61, 0.36, 1],
        },
      ],
    }),

    // 2. Sample Second Video/Image Shot (3.5s -> 6.0s)
    createClipDefaults({
      id: 'clip-tut-scene2',
      assetId: 'tut-asset-car',
      trackId: 'V1',
      name: 'Apex_Coupe_Twilight.jpg',
      type: 'image',
      startTime: 3.5,
      duration: 2.5,
      transitionIn: 'cross-dissolve',
      transitionInDuration: 0.6,
      transitionOut: 'dip-to-black',
      transitionOutDuration: 0.5,
      colorGrade: {
        preset: 'golden-hour',
        exposure: 6,
        contrast: 16,
        saturation: 14,
        temperature: 12,
        tint: 0,
        vignette: 24,
        highlights: 10,
        shadows: -8,
      },
      keyframes: [
        {
          id: 'tut-kf-sc2-1',
          time: 0,
          property: 'scale',
          value: 1.08,
          easing: 'easeOut',
          bezier: [0, 0, 0.58, 1],
        },
        {
          id: 'tut-kf-sc2-2',
          time: 2.5,
          property: 'scale',
          value: 1.0,
          easing: 'easeOut',
          bezier: [0, 0, 0.58, 1],
        },
      ],
    }),

    // 3. Picture-in-Picture / Overlay Image Layer (1.0s -> 5.0s)
    createClipDefaults({
      id: 'clip-tut-overlay',
      assetId: 'tut-asset-street',
      trackId: 'V2',
      name: 'Overlay · Night_Rain_Street.jpg',
      type: 'image',
      startTime: 1.0,
      duration: 4.0,
      blendMode: 'screen',
      transitionIn: 'fade-in',
      transitionInDuration: 0.5,
      transitionOut: 'fade-out',
      transitionOutDuration: 0.5,
      transform: {
        x: 24,
        y: -16,
        scale: 0.36,
        rotation: -3,
        opacity: 0.88,
        anchorX: 0.5,
        anchorY: 0.5,
        zDepth: 0,
        rotX: 0,
        rotY: 0,
      },
      mask: {
        shape: 'rectangle',
        centerX: 0.5,
        centerY: 0.5,
        radiusX: 0.44,
        radiusY: 0.4,
        feather: 14,
        inverted: false,
      },
      keyframes: [
        {
          id: 'tut-kf-ov-1',
          time: 0,
          property: 'x',
          value: 34,
          easing: 'overshoot',
          bezier: [0.22, 1.38, 0.44, 1],
        },
        {
          id: 'tut-kf-ov-2',
          time: 1.2,
          property: 'x',
          value: 22,
          easing: 'smoothEnd',
          bezier: [0.22, 0.61, 0.36, 1],
        },
      ],
    }),

    // 4. Null Object Controller driving Shape + Title together (0s -> 6.0s)
    createClipDefaults({
      id: 'clip-tut-null',
      assetId: 'null-controller',
      trackId: 'N1',
      name: 'Master Motion Null',
      type: 'null',
      startTime: 0,
      duration: 6.0,
      transform: {
        x: 0,
        y: 0,
        scale: 1,
        rotation: 0,
        opacity: 1,
        anchorX: 0.5,
        anchorY: 0.5,
        zDepth: 0,
        rotX: 0,
        rotY: 0,
      },
      keyframes: [
        {
          id: 'tut-kf-null-x1',
          time: 0,
          property: 'x',
          value: -18,
          easing: 'overshoot',
          bezier: [0.22, 1.38, 0.44, 1],
        },
        {
          id: 'tut-kf-null-x2',
          time: 1.4,
          property: 'x',
          value: 0,
          easing: 'smooth',
          bezier: [0.25, 0.1, 0.25, 1],
        },
        {
          id: 'tut-kf-null-x3',
          time: 5.5,
          property: 'x',
          value: 4,
          easing: 'easeInOut',
          bezier: [0.42, 0, 0.58, 1],
        },
        {
          id: 'tut-kf-null-y1',
          time: 0,
          property: 'y',
          value: 14,
          easing: 'easeOut',
          bezier: [0, 0, 0.58, 1],
        },
        {
          id: 'tut-kf-null-y2',
          time: 1.4,
          property: 'y',
          value: 0,
          easing: 'easeInOut',
          bezier: [0.42, 0, 0.58, 1],
        },
        {
          id: 'tut-kf-null-s1',
          time: 0,
          property: 'scale',
          value: 0.82,
          easing: 'overshoot',
          bezier: [0.22, 1.38, 0.44, 1],
        },
        {
          id: 'tut-kf-null-s2',
          time: 1.4,
          property: 'scale',
          value: 1.0,
          easing: 'smoothEnd',
          bezier: [0.22, 0.61, 0.36, 1],
        },
        {
          id: 'tut-kf-null-s3',
          time: 5.8,
          property: 'scale',
          value: 1.05,
          easing: 'easeInOut',
          bezier: [0.42, 0, 0.58, 1],
        },
        {
          id: 'tut-kf-null-r1',
          time: 0,
          property: 'rotation',
          value: -6,
          easing: 'back',
          bezier: [0.68, -0.55, 0.27, 1.55],
        },
        {
          id: 'tut-kf-null-r2',
          time: 1.4,
          property: 'rotation',
          value: 0,
          easing: 'smooth',
          bezier: [0.25, 0.1, 0.25, 1],
        },
        {
          id: 'tut-kf-null-o1',
          time: 0,
          property: 'opacity',
          value: 0,
          easing: 'easeOut',
          bezier: [0, 0, 0.58, 1],
        },
        {
          id: 'tut-kf-null-o2',
          time: 0.5,
          property: 'opacity',
          value: 1,
          easing: 'linear',
          bezier: [0, 0, 1, 1],
        },
      ],
    }),

    // 5. Shape Layer Parented to Master Motion Null (0.2s -> 5.6s)
    createClipDefaults({
      id: 'clip-tut-shape',
      assetId: 'shape-vector',
      trackId: 'S1',
      name: 'Shape · Crimson Badge',
      type: 'shape',
      startTime: 0.2,
      duration: 5.4,
      parentClipId: 'clip-tut-null',
      shapeProps: {
        shape: 'rectangle',
        fillColor: '#16070B',
        fillOpacity: 0.86,
        strokeColor: '#E50914',
        strokeWidth: 4,
        cornerRadius: 22,
        points: 6,
        innerRadius: 0.5,
        widthPct: 50,
        heightPct: 22,
        closed: true,
        pathPoints: [],
      },
      effects: {
        blur: 0,
        glow: 26,
        glowColor: '#E50914',
        stabilization: 0,
        filmGrain: 0,
        chromaticAberration: 0,
        particles: 'none',
        particleIntensity: 40,
      },
      effectsStack: glowFx ? [glowFx] : [],
      transform: {
        x: 0,
        y: 0,
        scale: 1,
        rotation: 0,
        opacity: 1,
        anchorX: 0.5,
        anchorY: 0.5,
        zDepth: 0,
        rotX: 0,
        rotY: 0,
      },
      keyframes: [
        {
          id: 'tut-kf-sh-r1',
          time: 0,
          property: 'rotation',
          value: -2,
          easing: 'smooth',
          bezier: [0.25, 0.1, 0.25, 1],
        },
        {
          id: 'tut-kf-sh-r2',
          time: 2.5,
          property: 'rotation',
          value: 0,
          easing: 'easeInOut',
          bezier: [0.42, 0, 0.58, 1],
        },
      ],
    }),

    // 6. Kinetic Text Layer Parented to Master Motion Null (0.3s -> 5.5s)
    createClipDefaults({
      id: 'clip-tut-text',
      assetId: 'text-asset',
      trackId: 'T1',
      name: 'Title · RED EFFECT',
      type: 'text',
      startTime: 0.3,
      duration: 5.2,
      parentClipId: 'clip-tut-null',
      textProps: {
        text: 'RED EFFECT',
        fontFamily: 'Outfit',
        fontSize: 66,
        fontWeight: 800,
        color: '#FFFFFF',
        strokeColor: '#E50914',
        strokeWidth: 2,
        backgroundColor: 'transparent',
        animation: 'fade-up',
        isSubtitle: false,
        align: 'center',
        letterSpacing: 4,
        lineHeight: 1.15,
        revealProgress: 100,
        granularity: 'character',
        pathMode: 'none',
        shadowBlur: 18,
        shadowColor: 'rgba(229,9,20,0.75)',
        extrude3D: false,
        extrudeDepth: 0,
      },
      transform: {
        x: 0,
        y: 0,
        scale: 1,
        rotation: 0,
        opacity: 1,
        anchorX: 0.5,
        anchorY: 0.5,
        zDepth: 0,
        rotX: 0,
        rotY: 0,
      },
      keyframes: [
        {
          id: 'tut-kf-txt-1',
          time: 0,
          property: 'fontSize',
          value: 52,
          easing: 'overshoot',
          bezier: [0.22, 1.38, 0.44, 1],
        },
        {
          id: 'tut-kf-txt-2',
          time: 1.0,
          property: 'fontSize',
          value: 68,
          easing: 'smoothEnd',
          bezier: [0.22, 0.61, 0.36, 1],
        },
      ],
    }),

    // 7. Audio Track (0s -> 6.0s)
    createClipDefaults({
      id: 'clip-tut-audio',
      assetId: 'tut-asset-beat',
      trackId: 'A1',
      name: 'Crimson_Pulse_Beat_120BPM.wav',
      type: 'audio',
      startTime: 0,
      duration: 6.0,
      volume: 0.85,
      fadeIn: 0.4,
      fadeOut: 0.7,
    }),
  ];

  return {
    id: TUTORIAL_PROJECT_ID,
    name: TUTORIAL_PROJECT_NAME,
    location: 'RED EFFECT Tutorial',
    width: 1920,
    height: 1080,
    fps: 30,
    aspectRatio: '16:9',
    videoFormat: 'mp4',
    audioSampleRate: 48000,
    backgroundColor: '#050507',
    defaultClipDuration: 5,
    createdAt: now,
    updatedAt: now,
    tracks,
    clips,
    markers: [
      {
        id: 'tut-m1',
        time: 0,
        label: 'Intro Null Pop',
        notes: 'Null object scales & rotates children into frame',
        color: 'rose',
      },
      {
        id: 'tut-m2',
        time: 1.4,
        label: 'Bezier Settle',
        notes: 'Overshoot curve settles onto center lock',
        color: 'amber',
      },
      {
        id: 'tut-m3',
        time: 3.5,
        label: 'Scene Cut',
        notes: 'Cross dissolve into Apex Coupe twilight shot',
        color: 'sky',
      },
    ],
    assets,
    folders: [...DEFAULT_PROJECT_FOLDERS],
    camera3D: {
      fov: 50,
      orbitX: 0,
      orbitY: 0,
      zoom: 1,
      dofBlur: 0,
    },
    snapEnabled: true,
    proxyQuality: 'full',
  };
}
