import {
  UiAccentPresetId,
  UiSurfaceMode,
  UiThemeSettings,
} from '../types/studio';

export interface UiSurfacePalette {
  id: UiSurfaceMode;
  label: string;
  shortLabel: string;
  description: string;
  isLight: boolean;
  bgMain: string;
  bgDeep: string;
  bgPanel: string;
  bgSecondary: string;
  bgHover: string;
  bgHoverAlt: string;
  border: string;
  borderSubtle: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  checkerA: string;
  checkerB: string;
}

export interface UiAccentPreset {
  id: Exclude<UiAccentPresetId, 'custom'>;
  label: string;
  hex: string;
  hoverHex: string;
  lightHex: string;
}

export interface CuratedUiCombo {
  id: string;
  label: string;
  surface: UiSurfaceMode;
  accentPreset: UiAccentPresetId;
  customAccentHex?: string;
}

export const UI_SURFACE_PRESETS: UiSurfacePalette[] = [
  {
    id: 'gray',
    label: 'Studio Gray',
    shortLabel: 'Gray',
    description: 'Neutral charcoal gray workspace (Default)',
    isLight: false,
    bgMain: '#18181A',
    bgDeep: '#141416',
    bgPanel: '#222225',
    bgSecondary: '#2C2C30',
    bgHover: '#343439',
    bgHoverAlt: '#3E3E44',
    border: '#3E3E44',
    borderSubtle: 'rgba(62, 62, 68, 0.6)',
    textPrimary: '#F4F4F5',
    textSecondary: '#A1A1AA',
    textMuted: '#6E7280',
    checkerA: '#222225',
    checkerB: '#2C2C30',
  },
  {
    id: 'white',
    label: 'Pure White',
    shortLabel: 'White',
    description: 'Clean bright daylight white studio UI',
    isLight: true,
    bgMain: '#F1F2F6',
    bgDeep: '#E6E8EF',
    bgPanel: '#FFFFFF',
    bgSecondary: '#ECEEF3',
    bgHover: '#E0E3EB',
    bgHoverAlt: '#D4D8E2',
    border: '#D4D7E0',
    borderSubtle: 'rgba(200, 204, 214, 0.75)',
    textPrimary: '#111827',
    textSecondary: '#4B5563',
    textMuted: '#6B7280',
    checkerA: '#F3F4F6',
    checkerB: '#E5E7EB',
  },
  {
    id: 'dark',
    label: 'Pitch Black',
    shortLabel: 'Black',
    description: 'Deep high-contrast AMOLED dark workspace',
    isLight: false,
    bgMain: '#0D0D10',
    bgDeep: '#08080A',
    bgPanel: '#16161A',
    bgSecondary: '#202026',
    bgHover: '#2A2A32',
    bgHoverAlt: '#34343E',
    border: '#2E2E36',
    borderSubtle: 'rgba(46, 46, 54, 0.65)',
    textPrimary: '#FAFAFA',
    textSecondary: '#A1A1AA',
    textMuted: '#71717A',
    checkerA: '#16161A',
    checkerB: '#202026',
  },
  {
    id: 'slate',
    label: 'Cool Slate',
    shortLabel: 'Slate',
    description: 'Steel blue-slate broadcast studio look',
    isLight: false,
    bgMain: '#121722',
    bgDeep: '#0D1119',
    bgPanel: '#1A2130',
    bgSecondary: '#232C3F',
    bgHover: '#2D374E',
    bgHoverAlt: '#36425C',
    border: '#333F57',
    borderSubtle: 'rgba(51, 63, 87, 0.65)',
    textPrimary: '#F1F5F9',
    textSecondary: '#94A3B8',
    textMuted: '#64748B',
    checkerA: '#1A2130',
    checkerB: '#232C3F',
  },
  {
    id: 'midnight',
    label: 'Midnight Plum',
    shortLabel: 'Midnight',
    description: 'Deep nocturnal violet-tinted dark studio',
    isLight: false,
    bgMain: '#12101B',
    bgDeep: '#0C0B13',
    bgPanel: '#1B1828',
    bgSecondary: '#252136',
    bgHover: '#302B46',
    bgHoverAlt: '#3A3454',
    border: '#373050',
    borderSubtle: 'rgba(55, 48, 80, 0.65)',
    textPrimary: '#F5F3FF',
    textSecondary: '#A79EC4',
    textMuted: '#766E96',
    checkerA: '#1B1828',
    checkerB: '#252136',
  },
  {
    id: 'warm',
    label: 'Warm Stone',
    shortLabel: 'Warm',
    description: 'Soft warm titanium & stone grading room',
    isLight: false,
    bgMain: '#1B1917',
    bgDeep: '#141210',
    bgPanel: '#24211E',
    bgSecondary: '#2F2B27',
    bgHover: '#3A3530',
    bgHoverAlt: '#46403A',
    border: '#443E38',
    borderSubtle: 'rgba(68, 62, 56, 0.65)',
    textPrimary: '#F5F5F4',
    textSecondary: '#A8A29E',
    textMuted: '#78716C',
    checkerA: '#24211E',
    checkerB: '#2F2B27',
  },
];

export const UI_ACCENT_PRESETS: UiAccentPreset[] = [
  { id: 'gray', label: 'Gray', hex: '#52525B', hoverHex: '#6B7280', lightHex: '#D4D4D8' },
  { id: 'white', label: 'White', hex: '#E4E4E7', hoverHex: '#FFFFFF', lightHex: '#FFFFFF' },
  { id: 'red', label: 'Red', hex: '#FF3030', hoverHex: '#FF5252', lightHex: '#FCA5A5' },
  { id: 'crimson', label: 'Crimson', hex: '#DC2626', hoverHex: '#EF4444', lightHex: '#FCA5A5' },
  { id: 'rose', label: 'Rose', hex: '#F43F5E', hoverHex: '#FB7185', lightHex: '#FDA4AF' },
  { id: 'pink', label: 'Pink', hex: '#EC4899', hoverHex: '#F472B6', lightHex: '#F9A8D4' },
  { id: 'purple', label: 'Purple', hex: '#8B5CF6', hoverHex: '#9D75FA', lightHex: '#C4B5FD' },
  { id: 'violet', label: 'Blue-Violet', hex: '#7C3AED', hoverHex: '#8B5CF6', lightHex: '#C4B5FD' },
  { id: 'indigo', label: 'Indigo', hex: '#6366F1', hoverHex: '#818CF8', lightHex: '#A5B4FC' },
  { id: 'blue', label: 'Blue', hex: '#3B82F6', hoverHex: '#60A5FA', lightHex: '#93C5FD' },
  { id: 'sky', label: 'Sky', hex: '#0EA5E9', hoverHex: '#38BDF8', lightHex: '#7DD3FC' },
  { id: 'cyan', label: 'Cyan', hex: '#06B6D4', hoverHex: '#22D3EE', lightHex: '#67E8F9' },
  { id: 'teal', label: 'Teal', hex: '#14B8A6', hoverHex: '#2DD4BF', lightHex: '#5EEAD4' },
  { id: 'emerald', label: 'Emerald', hex: '#10B981', hoverHex: '#34D399', lightHex: '#6EE7B7' },
  { id: 'green', label: 'Green', hex: '#22C55E', hoverHex: '#4ADE80', lightHex: '#86EFAC' },
  { id: 'lime', label: 'Lime', hex: '#84CC16', hoverHex: '#A3E635', lightHex: '#BEF264' },
  { id: 'yellow', label: 'Yellow', hex: '#EAB308', hoverHex: '#FACC15', lightHex: '#FDE047' },
  { id: 'amber', label: 'Amber', hex: '#F59E0B', hoverHex: '#FBBF24', lightHex: '#FCD34D' },
  { id: 'orange', label: 'Orange', hex: '#F97316', hoverHex: '#FB923C', lightHex: '#FDBA74' },
];

export const CURATED_UI_COMBOS: CuratedUiCombo[] = [
  { id: 'classic-gray', label: 'Classic Gray', surface: 'gray', accentPreset: 'gray' },
  { id: 'white-studio', label: 'Pure White', surface: 'white', accentPreset: 'gray' },
  { id: 'red-effect', label: 'Red & Black', surface: 'dark', accentPreset: 'red' },
  { id: 'purple-studio', label: 'Purple Studio', surface: 'midnight', accentPreset: 'purple' },
  { id: 'white-red', label: 'White & Red', surface: 'white', accentPreset: 'red' },
  { id: 'white-purple', label: 'White & Purple', surface: 'white', accentPreset: 'purple' },
  { id: 'slate-blue', label: 'Slate Blue', surface: 'slate', accentPreset: 'blue' },
  { id: 'emerald-pro', label: 'Emerald Pro', surface: 'gray', accentPreset: 'emerald' },
];

export function normalizeHex(hex: string, fallback = '#71717A'): string {
  const cleaned = (hex || '').trim();
  if (/^#[0-9A-Fa-f]{6}$/.test(cleaned)) {
    return cleaned.toUpperCase();
  }
  if (/^[0-9A-Fa-f]{6}$/.test(cleaned)) {
    return `#${cleaned.toUpperCase()}`;
  }
  if (/^#[0-9A-Fa-f]{3}$/.test(cleaned)) {
    const r = cleaned[1];
    const g = cleaned[2];
    const b = cleaned[3];
    return `#${r}${r}${g}${g}${b}${b}`.toUpperCase();
  }
  return fallback;
}

export function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const norm = normalizeHex(hex);
  return {
    r: parseInt(norm.slice(1, 3), 16),
    g: parseInt(norm.slice(3, 5), 16),
    b: parseInt(norm.slice(5, 7), 16),
  };
}

export function getRelativeLuminance(hex: string): number {
  const { r, g, b } = hexToRgb(hex);
  const srgb = [r, g, b].map((c) => {
    const v = c / 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * srgb[0] + 0.7152 * srgb[1] + 0.0722 * srgb[2];
}

export function getContrastTextHex(bgHex: string): string {
  return getRelativeLuminance(bgHex) > 0.44 ? '#111827' : '#FFFFFF';
}

export function mixHex(hexA: string, hexB: string, weightB: number): string {
  const a = hexToRgb(hexA);
  const b = hexToRgb(hexB);
  const w = Math.max(0, Math.min(1, weightB));
  const r = Math.round(a.r * (1 - w) + b.r * w);
  const g = Math.round(a.g * (1 - w) + b.g * w);
  const bl = Math.round(a.b * (1 - w) + b.b * w);
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${bl
    .toString(16)
    .padStart(2, '0')}`.toUpperCase();
}

export interface ResolvedUiTokens {
  surface: UiSurfacePalette;
  accentHex: string;
  accentHoverHex: string;
  accentOnHex: string;
  accentTextHex: string;
  accentLightHex: string;
  accentSoft: string;
  accentSoftStrong: string;
  accentBorder: string;
  accentBorderStrong: string;
  uiScale: 'compact' | 'normal' | 'comfortable';
  borderRadius: 'sharp' | 'rounded' | 'pill';
  isDefaultGray: boolean;
}

export function resolveUiThemeTokens(uiTheme?: UiThemeSettings): ResolvedUiTokens {
  const surfaceId: UiSurfaceMode = uiTheme?.surface || 'gray';
  const surface =
    UI_SURFACE_PRESETS.find((s) => s.id === surfaceId) || UI_SURFACE_PRESETS[0];

  const accentId: UiAccentPresetId = uiTheme?.accentPreset || 'gray';
  const matchedAccent =
    accentId === 'custom'
      ? null
      : UI_ACCENT_PRESETS.find((a) => a.id === accentId) || UI_ACCENT_PRESETS[0];

  let accentHex = matchedAccent
    ? matchedAccent.hex
    : normalizeHex(uiTheme?.customAccentHex || '#8B5CF6');
  let accentHoverHex = matchedAccent
    ? matchedAccent.hoverHex
    : mixHex(accentHex, surface.isLight ? '#000000' : '#FFFFFF', 0.16);
  let accentLightHex = matchedAccent
    ? matchedAccent.lightHex
    : mixHex(accentHex, '#FFFFFF', 0.35);

  // Adaptive safeguard: if user selects 'white' accent on 'white' surface, map active button ink to crisp dark graphite
  if (surface.isLight && (accentId === 'white' || getRelativeLuminance(accentHex) > 0.85)) {
    accentHex = '#18181B';
    accentHoverHex = '#27272A';
    accentLightHex = '#3F3F46';
  }

  // On light surfaces, accent text / active icons need enough contrast against white panels
  const accentTextHex =
    accentId === 'gray' && !surface.isLight
      ? '#D4D4D8'
      : accentId === 'gray' && surface.isLight
      ? '#18181B'
      : surface.isLight
      ? mixHex(accentHex, '#111827', getRelativeLuminance(accentHex) > 0.42 ? 0.38 : 0.12)
      : accentLightHex;

  const accentOnHex = getContrastTextHex(accentHex);
  const { r, g, b } = hexToRgb(accentHex);
  const isDefaultGray = surface.id === 'gray' && accentId === 'gray';

  return {
    surface,
    accentHex,
    accentHoverHex,
    accentOnHex,
    accentTextHex,
    accentLightHex,
    accentSoft: isDefaultGray ? 'rgba(113, 113, 122, 0.18)' : `rgba(${r}, ${g}, ${b}, 0.16)`,
    accentSoftStrong: isDefaultGray
      ? 'rgba(113, 113, 122, 0.28)'
      : `rgba(${r}, ${g}, ${b}, 0.28)`,
    accentBorder: isDefaultGray ? 'rgba(161, 161, 170, 0.5)' : `rgba(${r}, ${g}, ${b}, 0.55)`,
    accentBorderStrong: isDefaultGray ? '#A1A1AA' : accentHex,
    uiScale: uiTheme?.uiScale || 'normal',
    borderRadius: uiTheme?.borderRadius || 'rounded',
    isDefaultGray,
  };
}

export function applyUiThemeToDocument(uiTheme?: UiThemeSettings): ResolvedUiTokens {
  const tokens = resolveUiThemeTokens(uiTheme);
  if (typeof document === 'undefined') {
    return tokens;
  }

  const root = document.documentElement;
  const { surface } = tokens;

  root.dataset.uiThemed = 'true';
  root.dataset.uiSurface = surface.id;
  root.dataset.uiAccent = uiTheme?.accentPreset || 'gray';
  root.dataset.uiLight = surface.isLight ? 'true' : 'false';
  root.dataset.uiScale = tokens.uiScale;
  root.dataset.uiRadius = tokens.borderRadius;

  if (surface.isLight) {
    root.classList.remove('dark');
    root.classList.add('light');
  } else {
    root.classList.remove('light');
    root.classList.add('dark');
  }
  root.style.colorScheme = surface.isLight ? 'light' : 'dark';

  root.style.setProperty('--re-bg-main', surface.bgMain);
  root.style.setProperty('--re-bg-deep', surface.bgDeep);
  root.style.setProperty('--re-bg-panel', surface.bgPanel);
  root.style.setProperty('--re-bg-secondary', surface.bgSecondary);
  root.style.setProperty('--re-bg-hover', surface.bgHover);
  root.style.setProperty('--re-bg-hover-alt', surface.bgHoverAlt);
  root.style.setProperty('--re-border', surface.border);
  root.style.setProperty('--re-border-subtle', surface.borderSubtle);
  root.style.setProperty('--re-text-primary', surface.textPrimary);
  root.style.setProperty('--re-text-secondary', surface.textSecondary);
  root.style.setProperty('--re-text-muted', surface.textMuted);
  root.style.setProperty('--re-checker-a', surface.checkerA);
  root.style.setProperty('--re-checker-b', surface.checkerB);

  root.style.setProperty('--re-accent', tokens.accentHex);
  root.style.setProperty('--re-accent-hover', tokens.accentHoverHex);
  root.style.setProperty('--re-accent-on', tokens.accentOnHex);
  root.style.setProperty('--re-accent-text', tokens.accentTextHex);
  root.style.setProperty('--re-accent-light', tokens.accentLightHex);
  root.style.setProperty('--re-accent-soft', tokens.accentSoft);
  root.style.setProperty('--re-accent-soft-strong', tokens.accentSoftStrong);
  root.style.setProperty('--re-accent-border', tokens.accentBorder);
  root.style.setProperty('--re-accent-border-strong', tokens.accentBorderStrong);

  const fontPx =
    tokens.uiScale === 'compact'
      ? '15px'
      : tokens.uiScale === 'comfortable'
      ? '17px'
      : '16px';
  root.style.fontSize = fontPx;

  return tokens;
}
