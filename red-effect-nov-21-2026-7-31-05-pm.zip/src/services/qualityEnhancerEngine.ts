import {
  EnhancementProcessingQuality,
  QualityEnhancerSettings,
  UpscaleResolutionTarget,
} from '../types/studio';
import { detectHardwareProfile } from './performanceEngine';

export function createDefaultQualityEnhancerSettings(): QualityEnhancerSettings {
  return {
    enabled: false,
    processingQuality: 'balanced',
    intensity: 65,
    targetResolution: 'original',
    upscaling: false,
    sharpening: 35,
    detailRecovery: 30,
    noiseReduction: 20,
    deblurring: 15,
    textureEnhancement: 25,
    faceDetailEnhancement: 0,
    colorEnhancement: 20,
    colorCorrection: 20,
    lowLightEnhancement: 0,
    compressionArtifactReduction: 25,
  };
}

export function serializeEnhancerSignature(s: QualityEnhancerSettings): string {
  return JSON.stringify([
    s.enabled,
    s.processingQuality,
    Math.round(s.intensity),
    s.targetResolution,
    s.upscaling,
    Math.round(s.sharpening),
    Math.round(s.detailRecovery),
    Math.round(s.noiseReduction),
    Math.round(s.deblurring),
    Math.round(s.textureEnhancement),
    Math.round(s.faceDetailEnhancement),
    Math.round(s.colorEnhancement),
    Math.round(s.colorCorrection),
    Math.round(s.lowLightEnhancement),
    Math.round(s.compressionArtifactReduction),
  ]);
}

export interface TargetResolutionInfo {
  width: number;
  height: number;
  scaleFactor: number;
  clampedByHardware: boolean;
  reason?: string;
}

export function computeEnhancementTargetSize(
  srcWidth: number,
  srcHeight: number,
  target: UpscaleResolutionTarget,
  quality: EnhancementProcessingQuality,
  upscaleEnabled: boolean
): TargetResolutionInfo {
  const safeW = Math.max(16, Math.round(srcWidth));
  const safeH = Math.max(16, Math.round(srcHeight));
  const hw = detectHardwareProfile();
  const maxLongEdge =
    hw.tier === 'low-end'
      ? quality === 'high'
        ? 3840
        : 2560
      : hw.tier === 'mid-range'
      ? 4096
      : 7680;

  if (!upscaleEnabled || target === 'original') {
    const scale = Math.min(1, maxLongEdge / Math.max(safeW, safeH));
    return {
      width: Math.max(16, Math.round(safeW * scale)),
      height: Math.max(16, Math.round(safeH * scale)),
      scaleFactor: scale,
      clampedByHardware: scale < 1,
    };
  }

  const presetHeights: Record<Exclude<UpscaleResolutionTarget, 'original'>, number> = {
    '720p': 720,
    '1080p': 1080,
    '2k': 1440,
    '4k': 2160,
  };

  const targetH = presetHeights[target];
  const aspect = safeW / safeH;
  let desiredW: number;
  let desiredH: number;

  if (aspect >= 1) {
    desiredH = Math.max(safeH, targetH);
    desiredW = Math.round(desiredH * aspect);
  } else {
    desiredW = Math.max(safeW, targetH);
    desiredH = Math.round(desiredW / aspect);
  }

  // Cap max 3.0x upscale (e.g. 720p -> 4K) for faithful edge-guided super-resolution
  const maxResRatio = 3.0;
  if (desiredW / safeW > maxResRatio) {
    desiredW = Math.round(safeW * maxResRatio);
    desiredH = Math.round(safeH * maxResRatio);
  }

  let clamped = false;
  let reason: string | undefined;
  const longEdge = Math.max(desiredW, desiredH);
  if (longEdge > maxLongEdge) {
    const s = maxLongEdge / longEdge;
    desiredW = Math.round(desiredW * s);
    desiredH = Math.round(desiredH * s);
    clamped = true;
    reason = `Clamped to ${desiredW}x${desiredH} for ${hw.tier} PC stability`;
  }

  // Ensure even dimensions for video encoders
  desiredW = Math.max(16, desiredW - (desiredW % 2));
  desiredH = Math.max(16, desiredH - (desiredH % 2));

  return {
    width: desiredW,
    height: desiredH,
    scaleFactor: desiredW / safeW,
    clampedByHardware: clamped,
    reason,
  };
}

// Separable Lanczos-3 kernel weight
function lanczos3(x: number): number {
  const ax = Math.abs(x);
  if (ax < 1e-6) return 1;
  if (ax >= 3) return 0;
  const px = Math.PI * ax;
  return (Math.sin(px) / px) * (Math.sin(px / 3) / (px / 3));
}

// High-precision Lanczos-3 resampling (tiled for large images so UI stays responsive)
export async function resampleLanczos3Async(
  srcData: Uint8ClampedArray,
  srcW: number,
  srcH: number,
  dstW: number,
  dstH: number,
  onProgress?: (pct: number) => void,
  signal?: AbortSignal
): Promise<Uint8ClampedArray> {
  if (srcW === dstW && srcH === dstH) {
    return new Uint8ClampedArray(srcData);
  }

  const tmp = new Float32Array(dstW * srcH * 4);
  const ratioX = srcW / dstW;
  const supportX = ratioX > 1 ? 3 * ratioX : 3;
  const scaleX = ratioX > 1 ? 1 / ratioX : 1;

  // Horizontal pass
  for (let y = 0; y < srcH; y++) {
    if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
    const srcRow = y * srcW * 4;
    const dstRow = y * dstW * 4;
    for (let x = 0; x < dstW; x++) {
      const center = (x + 0.5) * ratioX - 0.5;
      const start = Math.max(0, Math.floor(center - supportX));
      const end = Math.min(srcW - 1, Math.ceil(center + supportX));
      let r = 0,
        g = 0,
        b = 0,
        a = 0,
        wSum = 0;
      for (let ix = start; ix <= end; ix++) {
        const w = lanczos3((ix - center) * scaleX);
        if (w === 0) continue;
        const idx = srcRow + ix * 4;
        r += srcData[idx] * w;
        g += srcData[idx + 1] * w;
        b += srcData[idx + 2] * w;
        a += srcData[idx + 3] * w;
        wSum += w;
      }
      const invW = wSum !== 0 ? 1 / wSum : 1;
      const outIdx = dstRow + x * 4;
      tmp[outIdx] = r * invW;
      tmp[outIdx + 1] = g * invW;
      tmp[outIdx + 2] = b * invW;
      tmp[outIdx + 3] = a * invW;
    }
    if (y % 64 === 63) {
      onProgress?.(Math.round((y / srcH) * 45));
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  // Vertical pass
  const out = new Uint8ClampedArray(dstW * dstH * 4);
  const ratioY = srcH / dstH;
  const supportY = ratioY > 1 ? 3 * ratioY : 3;
  const scaleY = ratioY > 1 ? 1 / ratioY : 1;

  for (let y = 0; y < dstH; y++) {
    if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
    const center = (y + 0.5) * ratioY - 0.5;
    const start = Math.max(0, Math.floor(center - supportY));
    const end = Math.min(srcH - 1, Math.ceil(center + supportY));
    const outRow = y * dstW * 4;

    for (let x = 0; x < dstW; x++) {
      let r = 0,
        g = 0,
        b = 0,
        a = 0,
        wSum = 0;
      for (let iy = start; iy <= end; iy++) {
        const w = lanczos3((iy - center) * scaleY);
        if (w === 0) continue;
        const idx = (iy * dstW + x) * 4;
        r += tmp[idx] * w;
        g += tmp[idx + 1] * w;
        b += tmp[idx + 2] * w;
        a += tmp[idx + 3] * w;
        wSum += w;
      }
      const invW = wSum !== 0 ? 1 / wSum : 1;
      const oIdx = outRow + x * 4;
      out[oIdx] = Math.max(0, Math.min(255, Math.round(r * invW)));
      out[oIdx + 1] = Math.max(0, Math.min(255, Math.round(g * invW)));
      out[oIdx + 2] = Math.max(0, Math.min(255, Math.round(b * invW)));
      out[oIdx + 3] = Math.max(0, Math.min(255, Math.round(a * invW)));
    }

    if (y % 64 === 63) {
      onProgress?.(45 + Math.round((y / dstH) * 45));
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  return out;
}

// Fast WebGL2 real-time shader pipeline for Quality Enhancer (used during preview playback & GPU-available systems)
class WebGL2QualityEnhancer {
  private canvas: HTMLCanvasElement | null = null;
  private gl: WebGL2RenderingContext | null = null;
  private program: WebGLProgram | null = null;
  private texture: WebGLTexture | null = null;
  private failed = false;

  private ensureInit(): boolean {
    if (this.failed) return false;
    if (this.gl && this.program) return true;
    try {
      this.canvas = document.createElement('canvas');
      const gl = this.canvas.getContext('webgl2', {
        premultipliedAlpha: false,
        preserveDrawingBuffer: true,
        antialias: false,
      });
      if (!gl) {
        this.failed = true;
        return false;
      }
      const vsSrc = `#version 300 es
        in vec2 aPos;
        out vec2 vUv;
        void main() {
          vUv = aPos * 0.5 + 0.5;
          vUv.y = 1.0 - vUv.y;
          gl_Position = vec4(aPos, 0.0, 1.0);
        }
      `;
      const fsSrc = `#version 300 es
        precision highp float;
        uniform sampler2D uTex;
        uniform vec2 uTexSize;
        uniform float uSharpen;
        uniform float uDetail;
        uniform float uDenoise;
        uniform float uDeblur;
        uniform float uTexture;
        uniform float uFace;
        uniform float uColor;
        uniform float uLowLight;
        uniform float uDeblock;
        in vec2 vUv;
        out vec4 fragColor;

        float luma(vec3 c) {
          return dot(c, vec3(0.2126, 0.7152, 0.0722));
        }

        void main() {
          vec2 px = 1.0 / uTexSize;
          vec4 base = texture(uTex, vUv);
          vec3 c = base.rgb;

          vec3 n  = texture(uTex, vUv + vec2(0.0, -px.y)).rgb;
          vec3 s  = texture(uTex, vUv + vec2(0.0,  px.y)).rgb;
          vec3 e  = texture(uTex, vUv + vec2( px.x, 0.0)).rgb;
          vec3 w  = texture(uTex, vUv + vec2(-px.x, 0.0)).rgb;
          vec3 ne = texture(uTex, vUv + vec2( px.x, -px.y)).rgb;
          vec3 nw = texture(uTex, vUv + vec2(-px.x, -px.y)).rgb;
          vec3 se = texture(uTex, vUv + vec2( px.x,  px.y)).rgb;
          vec3 sw = texture(uTex, vUv + vec2(-px.x,  px.y)).rgb;

          // 1. Compression Artifact Reduction (8x8 DCT block-boundary smoothing)
          if (uDeblock > 0.005) {
            vec2 coord = vUv * uTexSize;
            float modX = mod(coord.x, 8.0);
            float modY = mod(coord.y, 8.0);
            if (modX < 1.1 || modX > 6.9 || modY < 1.1 || modY > 6.9) {
              vec3 avg4 = (n + s + e + w) * 0.25;
              float diff = length(c - avg4);
              float weight = clamp(1.0 - diff * 7.5, 0.0, 1.0) * uDeblock * 0.65;
              c = mix(c, avg4, weight);
            }
          }

          // 2. Edge-preserving Bilateral Noise Reduction
          if (uDenoise > 0.005) {
            vec3 acc = c;
            float wSum = 1.0;
            float invSig2 = 1.0 / max(0.0005, 0.006 + uDenoise * 0.035);
            vec3 nb[8] = vec3[8](n, s, e, w, ne, nw, se, sw);
            for (int i = 0; i < 8; i++) {
              vec3 d = nb[i] - c;
              float bw = exp(-dot(d, d) * invSig2);
              acc += nb[i] * bw;
              wSum += bw;
            }
            c = mix(c, acc / wSum, clamp(uDenoise * 0.9, 0.0, 0.92));
          }

          // 3. Low-Light Enhancement (adaptive shadow lift preserving highlights)
          if (uLowLight > 0.005) {
            float y = luma(c);
            float lift = pow(max(y, 0.0001), 1.0 - uLowLight * 0.42);
            float ratio = clamp(lift / max(y, 0.001), 1.0, 2.4);
            vec3 lifted = c * mix(1.0, ratio, smoothstep(0.65, 0.02, y));
            c = mix(c, clamp(lifted, 0.0, 1.0), uLowLight * 0.85);
          }

          // 4. Face & Skin Detail Enhancement (YCbCr skin flat smoothing + crisp feature edges)
          if (uFace > 0.005) {
            float cb = 0.5 - 0.168736 * c.r - 0.331264 * c.g + 0.5 * c.b;
            float cr = 0.5 + 0.5 * c.r - 0.418688 * c.g - 0.081312 * c.b;
            float skinMask = smoothstep(0.28, 0.36, cb) * (1.0 - smoothstep(0.46, 0.53, cb))
                           * smoothstep(0.51, 0.55, cr) * (1.0 - smoothstep(0.66, 0.72, cr));
            vec3 blur9 = (c + n + s + e + w + ne + nw + se + sw) / 9.0;
            float edge = length(c - blur9);
            float smoothAmt = skinMask * (1.0 - smoothstep(0.02, 0.08, edge)) * uFace * 0.55;
            float sharpAmt = (1.0 - skinMask * 0.4) * smoothstep(0.02, 0.12, edge) * uFace * 0.45;
            c = mix(c, blur9, smoothAmt) + (c - blur9) * sharpAmt;
          }

          // 5. Detail Recovery + Texture Micro-Contrast + Deblurring + Adaptive Sharpening
          vec3 blurAvg = (c * 4.0 + (n + s + e + w) * 2.0 + (ne + nw + se + sw)) / 16.0;
          vec3 wideAvg = (
            texture(uTex, vUv + vec2(-px.x * 2.0, -px.y * 2.0)).rgb +
            texture(uTex, vUv + vec2( px.x * 2.0, -px.y * 2.0)).rgb +
            texture(uTex, vUv + vec2(-px.x * 2.0,  px.y * 2.0)).rgb +
            texture(uTex, vUv + vec2( px.x * 2.0,  px.y * 2.0)).rgb +
            blurAvg
          ) * 0.2;

          vec3 highPass = c - blurAvg;
          vec3 midPass = blurAvg - wideAvg;

          // Halo clamp prevents harsh white outlines
          vec3 minNB = min(min(min(n, s), min(e, w)), c);
          vec3 maxNB = max(max(max(n, s), max(e, w)), c);

          float sharpGain = uSharpen * 1.15 + uDeblur * 1.45;
          vec3 sharpened = c + highPass * sharpGain;
          // Anti-ringing clamp for deblur/sharpen
          sharpened = clamp(sharpened, minNB - vec3(0.05), maxNB + vec3(0.05));

          float midMask = 1.0 - smoothstep(0.35, 0.5, abs(luma(c) - 0.5));
          sharpened += midPass * (uDetail * 1.15 + uTexture * 0.95 * midMask);
          c = clamp(sharpened, 0.0, 1.0);

          // 6. Color Enhancement / Correction (contrast S-curve + vibrance)
          if (uColor > 0.005) {
            float maxC = max(c.r, max(c.g, c.b));
            float minC = min(c.r, min(c.g, c.b));
            float sat = maxC - minC;
            float avg = (c.r + c.g + c.b) / 3.0;
            float vibScale = (1.0 - sat * 0.65) * uColor * 0.55;
            c = clamp(mix(vec3(avg), c, 1.0 + vibScale), 0.0, 1.0);
            vec3 sCurve = c * c * (3.0 - 2.0 * c);
            c = mix(c, sCurve, uColor * 0.22);
          }

          fragColor = vec4(clamp(c, 0.0, 1.0), base.a);
        }
      `;

      const compile = (type: number, src: string) => {
        const sh = gl.createShader(type)!;
        gl.shaderSource(sh, src);
        gl.compileShader(sh);
        if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
          throw new Error(gl.getShaderInfoLog(sh) || 'Shader error');
        }
        return sh;
      };

      const vs = compile(gl.VERTEX_SHADER, vsSrc);
      const fs = compile(gl.FRAGMENT_SHADER, fsSrc);
      const prog = gl.createProgram()!;
      gl.attachShader(prog, vs);
      gl.attachShader(prog, fs);
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
        throw new Error(gl.getProgramInfoLog(prog) || 'Program link error');
      }

      const vbo = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(prog, 'aPos');
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

      this.gl = gl;
      this.program = prog;
      this.texture = tex;
      return true;
    } catch {
      this.failed = true;
      return false;
    }
  }

  public processCanvas(
    sourceCanvas: HTMLCanvasElement,
    settings: QualityEnhancerSettings,
    isVideo: boolean
  ): HTMLCanvasElement | null {
    if (!this.ensureInit() || !this.gl || !this.program || !this.canvas || !this.texture) {
      return null;
    }
    const gl = this.gl;
    const w = Math.max(1, sourceCanvas.width);
    const h = Math.max(1, sourceCanvas.height);
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }

    gl.viewport(0, 0, w, h);
    gl.useProgram(this.program);
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, sourceCanvas);

    const master = Math.max(0, Math.min(1, settings.intensity / 100));
    const qualMult =
      settings.processingQuality === 'high'
        ? 1.05
        : settings.processingQuality === 'balanced'
        ? 1.0
        : 0.85;

    const u = (name: string, val: number) => {
      const loc = gl.getUniformLocation(this.program!, name);
      if (loc) gl.uniform1f(loc, val);
    };
    const uTexSize = gl.getUniformLocation(this.program, 'uTexSize');
    if (uTexSize) gl.uniform2f(uTexSize, w, h);

    u('uSharpen', (settings.sharpening / 100) * master * qualMult);
    u('uDetail', (settings.detailRecovery / 100) * master * qualMult);
    u('uDenoise', (settings.noiseReduction / 100) * master);
    u('uDeblur', (settings.deblurring / 100) * master * qualMult);
    u('uTexture', isVideo ? 0 : (settings.textureEnhancement / 100) * master);
    u('uFace', isVideo ? 0 : (settings.faceDetailEnhancement / 100) * master);
    u(
      'uColor',
      ((isVideo ? settings.colorCorrection : settings.colorEnhancement) / 100) * master
    );
    u('uLowLight', isVideo ? (settings.lowLightEnhancement / 100) * master : 0);
    u('uDeblock', isVideo ? (settings.compressionArtifactReduction / 100) * master : 0);

    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    return this.canvas;
  }
}

const webglEnhancer = new WebGL2QualityEnhancer();

// Real-time synchronous helper for composite frame playback & export
export function applyClipQualityEnhancerToCanvas(
  canvas: HTMLCanvasElement,
  settings: QualityEnhancerSettings | undefined,
  isVideo: boolean
): void {
  if (!settings || !settings.enabled || settings.intensity <= 0) return;

  // Prefer WebGL2 GPU shader pass (fastest & preserves full 2D quality)
  const gpuOut = webglEnhancer.processCanvas(canvas, settings, isVideo);
  if (gpuOut) {
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.save();
      ctx.globalCompositeOperation = 'copy';
      ctx.drawImage(gpuOut, 0, 0, canvas.width, canvas.height);
      ctx.restore();
      return;
    }
  }

  // Deterministic CPU Fallback (lightweight 3x3 unsharp + color/shadow lift on current buffer)
  applyEnhancerCpuTile(canvas, settings, isVideo, 0, 0, canvas.width, canvas.height);
}

function applyEnhancerCpuTile(
  canvas: HTMLCanvasElement,
  settings: QualityEnhancerSettings,
  isVideo: boolean,
  tileX: number,
  tileY: number,
  tileW: number,
  tileH: number
): void {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return;

  const w = canvas.width;
  const h = canvas.height;
  const pad = 2;
  const rx = Math.max(0, tileX - pad);
  const ry = Math.max(0, tileY - pad);
  const rx2 = Math.min(w, tileX + tileW + pad);
  const ry2 = Math.min(h, tileY + tileH + pad);
  const rw = rx2 - rx;
  const rh = ry2 - ry;
  if (rw <= 0 || rh <= 0) return;

  const imgData = ctx.getImageData(rx, ry, rw, rh);
  const src = new Uint8ClampedArray(imgData.data);
  const dst = imgData.data;

  const master = Math.max(0, Math.min(1, settings.intensity / 100));
  const sharpenAmt = (settings.sharpening / 100) * master * 1.15 + (settings.deblurring / 100) * master * 1.35;
  const detailAmt = (settings.detailRecovery / 100) * master + (isVideo ? 0 : (settings.textureEnhancement / 100) * master * 0.7);
  const denoiseAmt = (settings.noiseReduction / 100) * master;
  const lowLightAmt = isVideo ? (settings.lowLightEnhancement / 100) * master : 0;
  const colorAmt = ((isVideo ? settings.colorCorrection : settings.colorEnhancement) / 100) * master;
  const deblockAmt = isVideo ? (settings.compressionArtifactReduction / 100) * master : 0;
  const faceAmt = isVideo ? 0 : (settings.faceDetailEnhancement / 100) * master;

  const xStart = tileX - rx;
  const yStart = tileY - ry;
  const xEnd = xStart + tileW;
  const yEnd = yStart + tileH;

  for (let ly = yStart; ly < yEnd; ly++) {
    const gy = ry + ly;
    const rowOff = ly * rw;
    const prevRow = Math.max(0, ly - 1) * rw;
    const nextRow = Math.min(rh - 1, ly + 1) * rw;

    for (let lx = xStart; lx < xEnd; lx++) {
      const gx = rx + lx;
      const prevCol = Math.max(0, lx - 1);
      const nextCol = Math.min(rw - 1, lx + 1);

      const i = (rowOff + lx) * 4;
      const iN = (prevRow + lx) * 4;
      const iS = (nextRow + lx) * 4;
      const iW = (rowOff + prevCol) * 4;
      const iE = (rowOff + nextCol) * 4;

      let r = src[i];
      let g = src[i + 1];
      let b = src[i + 2];

      const nR = (src[iN] + src[iS] + src[iW] + src[iE]) * 0.25;
      const nG = (src[iN + 1] + src[iS + 1] + src[iW + 1] + src[iE + 1]) * 0.25;
      const nB = (src[iN + 2] + src[iS + 2] + src[iW + 2] + src[iE + 2]) * 0.25;

      // Deblock 8x8 boundaries
      if (deblockAmt > 0.01 && (gx % 8 === 0 || gx % 8 === 7 || gy % 8 === 0 || gy % 8 === 7)) {
        const d = Math.abs(r - nR) + Math.abs(g - nG) + Math.abs(b - nB);
        if (d < 45) {
          const wMix = deblockAmt * 0.5;
          r += (nR - r) * wMix;
          g += (nG - g) * wMix;
          b += (nB - b) * wMix;
        }
      }

      // Edge-preserving bilateral mix
      if (denoiseAmt > 0.01) {
        const diff = Math.abs(r - nR) + Math.abs(g - nG) + Math.abs(b - nB);
        const edgeW = Math.exp(-(diff * diff) / 1400) * denoiseAmt * 0.78;
        r += (nR - r) * edgeW;
        g += (nG - g) * edgeW;
        b += (nB - b) * edgeW;
      }

      // Low-light shadow gamma lift
      if (lowLightAmt > 0.01) {
        const yNorm = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
        if (yNorm < 0.65 && yNorm > 0.002) {
          const lifted = Math.pow(yNorm, 1 - lowLightAmt * 0.42);
          const gain = Math.min(2.3, lifted / yNorm);
          const shadowW = (1 - yNorm / 0.65) * lowLightAmt * 0.85;
          const mult = 1 + (gain - 1) * shadowW;
          r *= mult;
          g *= mult;
          b *= mult;
        }
      }

      // Face skin-tone smoothing + crisp non-skin edges
      if (faceAmt > 0.01) {
        const cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
        const cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
        if (cb >= 80 && cb <= 128 && cr >= 133 && cr <= 174) {
          const d = Math.abs(r - nR) + Math.abs(g - nG) + Math.abs(b - nB);
          if (d < 36) {
            const sm = faceAmt * 0.45;
            r += (nR - r) * sm;
            g += (nG - g) * sm;
            b += (nB - b) * sm;
          }
        }
      }

      // Sharpen + Detail recovery with anti-halo clamping
      if (sharpenAmt > 0.01 || detailAmt > 0.01) {
        const hpR = r - nR;
        const hpG = g - nG;
        const hpB = b - nB;
        const gain = sharpenAmt + detailAmt * 0.75;
        r = r + Math.max(-42, Math.min(42, hpR * gain));
        g = g + Math.max(-42, Math.min(42, hpG * gain));
        b = b + Math.max(-42, Math.min(42, hpB * gain));
      }

      // Color vibrance + gentle contrast
      if (colorAmt > 0.01) {
        const maxC = Math.max(r, g, b);
        const minC = Math.min(r, g, b);
        const sat = (maxC - minC) / 255;
        const avg = (r + g + b) / 3;
        const vib = (1 - sat * 0.65) * colorAmt * 0.5;
        r += (r - avg) * vib;
        g += (g - avg) * vib;
        b += (b - avg) * vib;
      }

      dst[i] = Math.max(0, Math.min(255, Math.round(r)));
      dst[i + 1] = Math.max(0, Math.min(255, Math.round(g)));
      dst[i + 2] = Math.max(0, Math.min(255, Math.round(b)));
    }
  }

  ctx.putImageData(imgData, rx, ry);
}

// Non-blocking Tiled High-Quality Processor (used for high-res still photos & Comparison Preview)
export async function processImageEnhancementTiled(
  source: CanvasImageSource,
  srcW: number,
  srcH: number,
  settings: QualityEnhancerSettings,
  isVideo: boolean,
  onProgress?: (pct: number, stage: string) => void,
  signal?: AbortSignal
): Promise<{ canvas: HTMLCanvasElement; width: number; height: number }> {
  const target = computeEnhancementTargetSize(
    srcW,
    srcH,
    settings.targetResolution,
    settings.processingQuality,
    settings.upscaling
  );

  const outCanvas = document.createElement('canvas');
  outCanvas.width = target.width;
  outCanvas.height = target.height;
  const outCtx = outCanvas.getContext('2d', { colorSpace: 'srgb', willReadFrequently: true })!;
  outCtx.imageSmoothingEnabled = true;
  outCtx.imageSmoothingQuality = 'high';

  onProgress?.(8, `Preparing ${target.width}×${target.height} workspace...`);

  // Step 1: Upscale or copy source
  if (
    settings.processingQuality === 'high' &&
    settings.upscaling &&
    (target.width > srcW || target.height > srcH)
  ) {
    // True separable Lanczos-3 resampling for High Quality upscaling
    const tmpSrc = document.createElement('canvas');
    tmpSrc.width = srcW;
    tmpSrc.height = srcH;
    const tmpCtx = tmpSrc.getContext('2d', { willReadFrequently: true })!;
    tmpCtx.drawImage(source, 0, 0, srcW, srcH);
    const raw = tmpCtx.getImageData(0, 0, srcW, srcH).data;
    onProgress?.(18, 'Running separable Lanczos-3 upscaling...');
    const upscaled = await resampleLanczos3Async(
      raw,
      srcW,
      srcH,
      target.width,
      target.height,
      (p) => onProgress?.(18 + Math.round(p * 0.45), 'Upscaling pixels (Lanczos-3)...'),
      signal
    );
    const outImg = outCtx.createImageData(target.width, target.height);
    outImg.data.set(upscaled);
    outCtx.putImageData(outImg, 0, 0);
  } else {
    outCtx.drawImage(source, 0, 0, target.width, target.height);
  }

  if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
  if (!settings.enabled || settings.intensity <= 0) {
    onProgress?.(100, 'Original quality preserved');
    return { canvas: outCanvas, width: target.width, height: target.height };
  }

  onProgress?.(68, 'Enhancing details, denoising & color...');

  // Step 2: Try WebGL2 GPU pass first when fast/balanced (or small enough for GPU max texture)
  if (settings.processingQuality !== 'high') {
    const gpuCanvas = webglEnhancer.processCanvas(outCanvas, settings, isVideo);
    if (gpuCanvas) {
      outCtx.save();
      outCtx.globalCompositeOperation = 'copy';
      outCtx.drawImage(gpuCanvas, 0, 0, target.width, target.height);
      outCtx.restore();
      onProgress?.(100, 'Enhanced on GPU');
      return { canvas: outCanvas, width: target.width, height: target.height };
    }
  }

  // Step 3: Tiled CPU pass (512x512 chunks so main UI stays silky smooth on low-end PCs)
  const tileSize = 512;
  const cols = Math.ceil(target.width / tileSize);
  const rows = Math.ceil(target.height / tileSize);
  const totalTiles = Math.max(1, cols * rows);
  let done = 0;

  for (let ty = 0; ty < target.height; ty += tileSize) {
    for (let tx = 0; tx < target.width; tx += tileSize) {
      if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
      const tw = Math.min(tileSize, target.width - tx);
      const th = Math.min(tileSize, target.height - ty);
      applyEnhancerCpuTile(outCanvas, settings, isVideo, tx, ty, tw, th);
      done++;
      onProgress?.(
        68 + Math.round((done / totalTiles) * 32),
        `Processing tile ${done}/${totalTiles}...`
      );
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  onProgress?.(100, 'Enhancement complete');
  return { canvas: outCanvas, width: target.width, height: target.height };
}

// Bounded LRU Cache for pre-processed still image enhancements (never overwrites original Asset URL)
interface EnhancedImageEntry {
  key: string;
  canvas: HTMLCanvasElement;
  width: number;
  height: number;
  lastUsed: number;
}

class EnhancedMediaCache {
  private entries = new Map<string, EnhancedImageEntry>();
  private maxEntries = 14;

  public get(assetId: string, settings: QualityEnhancerSettings): EnhancedImageEntry | null {
    const sig = `${assetId}:${serializeEnhancerSignature(settings)}`;
    const found = this.entries.get(sig);
    if (!found) return null;
    found.lastUsed = performance.now();
    return found;
  }

  public set(
    assetId: string,
    settings: QualityEnhancerSettings,
    canvas: HTMLCanvasElement,
    width: number,
    height: number
  ): void {
    const sig = `${assetId}:${serializeEnhancerSignature(settings)}`;
    if (this.entries.size >= this.maxEntries && !this.entries.has(sig)) {
      let oldestKey: string | null = null;
      let oldestTime = Infinity;
      for (const [k, v] of this.entries) {
        if (v.lastUsed < oldestTime) {
          oldestTime = v.lastUsed;
          oldestKey = k;
        }
      }
      if (oldestKey) {
        this.entries.delete(oldestKey);
      }
    }
    this.entries.set(sig, {
      key: sig,
      canvas,
      width,
      height,
      lastUsed: performance.now(),
    });
  }

  public clearAsset(assetId: string): void {
    for (const k of this.entries.keys()) {
      if (k.startsWith(`${assetId}:`)) {
        this.entries.delete(k);
      }
    }
  }

  public clearAll(): void {
    this.entries.clear();
  }
}

export const enhancedImageCache = new EnhancedMediaCache();
