import {
  AnimationEasing,
  EffectBlendMode,
  EffectInstance,
  TransitionSettings,
} from '../types/effects';
import { ColorGrade, Keyframe } from '../types/studio';
import {
  acquireReusableImageData,
  getActiveRenderPolicy,
  webgl2Runner,
} from './performanceEngine';

// Reusable scratch buffers to keep 30-60fps playback smooth without GC thrashing
const scratchA = typeof document !== 'undefined' ? document.createElement('canvas') : null;
const scratchB = typeof document !== 'undefined' ? document.createElement('canvas') : null;

const GL_FRAG_RGB_SPLIT = `#version 300 es
precision mediump float;
uniform sampler2D u_tex;
uniform vec2 u_res;
uniform vec2 u_delta;
uniform float u_flash;
in vec2 v_uv;
out vec4 outColor;
void main() {
  vec2 stepUv = u_delta / max(vec2(1.0), u_res);
  vec4 cR = texture(u_tex, clamp(v_uv + stepUv, 0.0, 1.0));
  vec4 cG = texture(u_tex, v_uv);
  vec4 cB = texture(u_tex, clamp(v_uv - stepUv, 0.0, 1.0));
  outColor = vec4(
    clamp(cR.r * u_flash, 0.0, 1.0),
    clamp(cG.g * (1.0 + (u_flash - 1.0) * 0.35), 0.0, 1.0),
    clamp(cB.b * u_flash, 0.0, 1.0),
    cG.a
  );
}`;

const GL_FRAG_WAVE_WARP = `#version 300 es
precision mediump float;
uniform sampler2D u_tex;
uniform vec2 u_res;
uniform float u_amp;
uniform float u_freq;
uniform float u_phase;
uniform float u_horizontal;
in vec2 v_uv;
out vec4 outColor;
void main() {
  vec2 uv = v_uv;
  if (u_horizontal > 0.5) {
    uv.x += (sin(uv.y * 6.283185 * u_freq + u_phase) * u_amp) / max(1.0, u_res.x);
  } else {
    uv.y += (sin(uv.x * 6.283185 * u_freq + u_phase) * u_amp) / max(1.0, u_res.y);
  }
  outColor = texture(u_tex, clamp(uv, 0.0, 1.0));
}`;

const GL_FRAG_LENS_DISTORT = `#version 300 es
precision mediump float;
uniform sampler2D u_tex;
uniform float u_curv;
uniform float u_scale;
in vec2 v_uv;
out vec4 outColor;
void main() {
  vec2 norm = v_uv * 2.0 - 1.0;
  float r2 = dot(norm, norm);
  float warp = (1.0 + u_curv * r2) / max(0.2, u_scale);
  vec2 uv = norm * warp * 0.5 + 0.5;
  outColor = texture(u_tex, clamp(uv, 0.0, 1.0));
}`;

const GL_FRAG_GLITCH = `#version 300 es
precision mediump float;
uniform sampler2D u_tex;
uniform vec2 u_res;
uniform float u_inten;
uniform float u_shift;
uniform float u_bandSize;
uniform float u_seed;
uniform float u_wobble;
uniform float u_trackPos;
uniform float u_time;
in vec2 v_uv;
out vec4 outColor;
float hash1(float n) { return fract(sin(n) * 43758.5453); }
void main() {
  float yPx = (1.0 - v_uv.y) * u_res.y;
  float band = floor(yPx / max(2.0, u_bandSize));
  float rnd = hash1(band * 91.7 + u_seed * 37.3);
  float offPx = 0.0;
  if (rnd > 1.0 - u_inten * 0.52) {
    offPx += (rnd - 0.5) * 45.0 * u_inten;
  }
  if (u_wobble > 0.001) {
    offPx += sin(yPx * 0.08 + u_time * 15.0) * 10.0 * u_wobble;
    if (abs(yPx - u_trackPos) < 22.0 * u_inten) {
      offPx += (rnd - 0.5) * 55.0 * u_inten;
    }
  }
  float baseX = clamp(v_uv.x + offPx / max(1.0, u_res.x), 0.0, 1.0);
  float sepUv = u_shift / max(1.0, u_res.x);
  float r = texture(u_tex, vec2(clamp(baseX + sepUv, 0.0, 1.0), v_uv.y)).r;
  vec4 gA = texture(u_tex, vec2(baseX, v_uv.y));
  float b = texture(u_tex, vec2(clamp(baseX - sepUv, 0.0, 1.0), v_uv.y)).b;
  outColor = vec4(r, gA.g, b, gA.a);
}`;

export interface ParsedLut {
  name: string;
  size: number;
  data: Float32Array;
}

const customLutRegistry = new Map<string, ParsedLut>();

export function registerCubeLut(name: string, cubeText: string): ParsedLut | null {
  const lines = cubeText.split(/\r?\n/);
  let size = 0;
  const values: number[] = [];
  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    if (line.startsWith('LUT_3D_SIZE')) {
      size = parseInt(line.split(/\s+/)[1] || '0', 10);
      continue;
    }
    if (line.startsWith('TITLE') || line.startsWith('DOMAIN_')) continue;
    const parts = line.split(/\s+/);
    if (parts.length === 3) {
      const r = parseFloat(parts[0]);
      const g = parseFloat(parts[1]);
      const b = parseFloat(parts[2]);
      if (Number.isFinite(r) && Number.isFinite(g) && Number.isFinite(b)) {
        values.push(r, g, b);
      }
    }
  }
  if (size <= 1 || values.length < size * size * size * 3) return null;
  const lut: ParsedLut = { name, size, data: new Float32Array(values) };
  customLutRegistry.set(name, lut);
  return lut;
}

export function getRegisteredLuts(): string[] {
  return Array.from(customLutRegistry.keys());
}

export function hexToRgbTuple(hex: string): [number, number, number] {
  const clean = (hex || '#FFFFFF').replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean.padEnd(6, '0');
  const n = parseInt(full, 16) || 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function blendModeToCanvasOp(mode: EffectBlendMode): GlobalCompositeOperation {
  switch (mode) {
    case 'screen':
      return 'screen';
    case 'multiply':
      return 'multiply';
    case 'overlay':
      return 'overlay';
    case 'add':
      return 'lighter';
    case 'soft-light':
      return 'soft-light';
    default:
      return 'source-over';
  }
}

export function evaluateCubicBezier(t: number, x1: number, y1: number, x2: number, y2: number): number {
  const clamped = Math.max(0, Math.min(1, t));
  // Newton-Raphson solve for t_x -> x(u) = clamped, then evaluate y(u)
  let u = clamped;
  for (let i = 0; i < 6; i++) {
    const cx = 3 * x1;
    const bx = 3 * (x2 - x1) - cx;
    const ax = 1 - cx - bx;
    const x = ((ax * u + bx) * u + cx) * u - clamped;
    const dx = (3 * ax * u + 2 * bx) * u + cx;
    if (Math.abs(x) < 1e-4) break;
    if (Math.abs(dx) > 1e-5) u -= x / dx;
    u = Math.max(0, Math.min(1, u));
  }
  const cy = 3 * y1;
  const by = 3 * (y2 - y1) - cy;
  const ay = 1 - cy - by;
  return ((ay * u + by) * u + cy) * u;
}

export interface CurvePresetDefinition {
  easing: AnimationEasing;
  label: string;
  category: 'Basic' | 'Smooth' | 'Physics' | 'Custom';
  bezier: [number, number, number, number];
  isFormulaCurve?: boolean;
}

export const ANIMATION_CURVE_PRESETS: CurvePresetDefinition[] = [
  { easing: 'linear', label: 'Linear', category: 'Basic', bezier: [0, 0, 1, 1] },
  { easing: 'easeIn', label: 'Ease In', category: 'Basic', bezier: [0.42, 0, 1, 1] },
  { easing: 'easeOut', label: 'Ease Out', category: 'Basic', bezier: [0, 0, 0.58, 1] },
  { easing: 'easeInOut', label: 'Ease In Out', category: 'Basic', bezier: [0.42, 0, 0.58, 1] },
  { easing: 'smooth', label: 'Smooth', category: 'Smooth', bezier: [0.25, 0.1, 0.25, 1] },
  { easing: 'smoothStart', label: 'Smooth Start', category: 'Smooth', bezier: [0.55, 0.05, 0.68, 0.53] },
  { easing: 'smoothEnd', label: 'Smooth End', category: 'Smooth', bezier: [0.22, 0.61, 0.36, 1] },
  { easing: 'bounce', label: 'Bounce', category: 'Physics', bezier: [0.34, 1.4, 0.64, 1], isFormulaCurve: true },
  { easing: 'elastic', label: 'Elastic', category: 'Physics', bezier: [0.5, 1.6, 0.3, 0.9], isFormulaCurve: true },
  { easing: 'back', label: 'Back', category: 'Physics', bezier: [0.68, -0.55, 0.27, 1.55] },
  { easing: 'overshoot', label: 'Overshoot', category: 'Physics', bezier: [0.22, 1.38, 0.44, 1] },
  { easing: 'anticipation', label: 'Anticipation', category: 'Physics', bezier: [0.64, -0.45, 0.42, 1] },
  { easing: 'bezier', label: 'Custom Bezier', category: 'Custom', bezier: [0.42, 0, 0.58, 1] },
];

export function getPresetBezier(easing: AnimationEasing): [number, number, number, number] {
  return ANIMATION_CURVE_PRESETS.find((p) => p.easing === easing)?.bezier ?? [0.42, 0, 0.58, 1];
}

function easeOutBounce(x: number): number {
  const n1 = 7.5625;
  const d1 = 2.75;
  if (x < 1 / d1) {
    return n1 * x * x;
  } else if (x < 2 / d1) {
    const t = x - 1.5 / d1;
    return n1 * t * t + 0.75;
  } else if (x < 2.5 / d1) {
    const t = x - 2.25 / d1;
    return n1 * t * t + 0.9375;
  } else {
    const t = x - 2.625 / d1;
    return n1 * t * t + 0.984375;
  }
}

function easeOutElastic(x: number): number {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const c4 = (2 * Math.PI) / 3;
  return Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * c4) + 1;
}

export function applyEasingCurve(
  t: number,
  easing: AnimationEasing,
  bezier?: [number, number, number, number]
): number {
  const c = Math.max(0, Math.min(1, t));
  switch (easing) {
    case 'linear':
      return c;
    case 'easeIn':
      return c * c * c;
    case 'easeOut':
      return 1 - Math.pow(1 - c, 3);
    case 'easeInOut':
      return c < 0.5 ? 4 * c * c * c : 1 - Math.pow(-2 * c + 2, 3) / 2;
    case 'smooth':
      return evaluateCubicBezier(c, 0.25, 0.1, 0.25, 1);
    case 'smoothStart':
      return evaluateCubicBezier(c, 0.55, 0.05, 0.68, 0.53);
    case 'smoothEnd':
      return evaluateCubicBezier(c, 0.22, 0.61, 0.36, 1);
    case 'bounce':
      return easeOutBounce(c);
    case 'elastic':
      return easeOutElastic(c);
    case 'back': {
      const c1 = 1.70158;
      const c2 = c1 * 1.525;
      return c < 0.5
        ? (Math.pow(2 * c, 2) * ((c2 + 1) * 2 * c - c2)) / 2
        : (Math.pow(2 * c - 2, 2) * ((c2 + 1) * (c * 2 - 2) + c2) + 2) / 2;
    }
    case 'overshoot': {
      const c1 = 1.70158;
      const c3 = c1 + 1;
      return 1 + c3 * Math.pow(c - 1, 3) + c1 * Math.pow(c - 1, 2);
    }
    case 'anticipation': {
      const c1 = 1.70158;
      const c3 = c1 + 1;
      return c3 * c * c * c - c1 * c * c;
    }
    case 'bezier':
      if (bezier) return evaluateCubicBezier(c, bezier[0], bezier[1], bezier[2], bezier[3]);
      return c < 0.5 ? 2 * c * c : 1 - Math.pow(-2 * c + 2, 2) / 2;
    default:
      return c;
  }
}

export function sampleCurvePreviewPoints(
  easing: AnimationEasing,
  bezier?: [number, number, number, number],
  steps = 28
): Array<{ t: number; v: number }> {
  const pts: Array<{ t: number; v: number }> = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    pts.push({ t, v: applyEasingCurve(t, easing, bezier) });
  }
  return pts;
}

function getNumParam(
  fx: EffectInstance,
  key: string,
  fallback: number,
  keyframes: Keyframe[],
  localTime: number
): number {
  const propKey = `effect:${fx.id}:${key}`;
  const matching = keyframes
    .filter((k) => k.property === propKey)
    .sort((a, b) => a.time - b.time);

  if (matching.length > 0) {
    if (localTime <= matching[0].time) return matching[0].value;
    if (localTime >= matching[matching.length - 1].time) return matching[matching.length - 1].value;
    for (let i = 0; i < matching.length - 1; i++) {
      const k1 = matching[i];
      const k2 = matching[i + 1];
      if (localTime >= k1.time && localTime <= k2.time) {
        const span = Math.max(0.0001, k2.time - k1.time);
        const t = applyEasingCurve((localTime - k1.time) / span, k2.easing, k2.bezier);
        return k1.value + (k2.value - k1.value) * t;
      }
    }
  }
  const v = fx.params[key];
  return typeof v === 'number' ? v : fallback;
}

function getStrParam(fx: EffectInstance, key: string, fallback: string): string {
  const v = fx.params[key];
  return typeof v === 'string' ? v : fallback;
}

function getBoolParam(fx: EffectInstance, key: string, fallback: boolean): boolean {
  const v = fx.params[key];
  return typeof v === 'boolean' ? v : fallback;
}

function copyCanvas(src: HTMLCanvasElement, dst: HTMLCanvasElement, w: number, h: number) {
  if (dst.width !== w || dst.height !== h) {
    dst.width = w;
    dst.height = h;
  }
  const ctx = dst.getContext('2d', { willReadFrequently: true })!;
  ctx.clearRect(0, 0, w, h);
  ctx.drawImage(src, 0, 0, w, h);
  return ctx;
}

function computeSobelEdges(d: Uint8ClampedArray, w: number, h: number): Float32Array {
  const mag = new Float32Array(w * h);
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const luma = (px: number, py: number) => {
        const idx = (py * w + px) * 4;
        return d[idx] * 0.299 + d[idx + 1] * 0.587 + d[idx + 2] * 0.114;
      };
      const gx =
        -luma(x - 1, y - 1) +
        luma(x + 1, y - 1) -
        2 * luma(x - 1, y) +
        2 * luma(x + 1, y) -
        luma(x - 1, y + 1) +
        luma(x + 1, y + 1);
      const gy =
        -luma(x - 1, y - 1) -
        2 * luma(x, y - 1) -
        luma(x + 1, y - 1) +
        luma(x - 1, y + 1) +
        2 * luma(x, y + 1) +
        luma(x + 1, y + 1);
      mag[y * w + x] = Math.min(255, Math.sqrt(gx * gx + gy * gy));
    }
  }
  return mag;
}

/**
 * Applies the entire non-destructive Effects Stack onto `workCanvas` in place.
 */
export function applyEffectsStackToCanvas(
  workCanvas: HTMLCanvasElement,
  effectsStack: EffectInstance[],
  localTime: number,
  keyframes: Keyframe[] = [],
  clipDuration = 5
): void {
  if (!effectsStack || effectsStack.length === 0 || !scratchA || !scratchB) return;
  const w = workCanvas.width;
  const h = workCanvas.height;
  if (w < 2 || h < 2) return;

  const ctx = workCanvas.getContext('2d', { willReadFrequently: true })!;
  const policy = getActiveRenderPolicy();

  for (const fx of effectsStack) {
    if (!fx.enabled) continue;
    if (
      policy.skipHeavyScrubEffects &&
      (fx.type === 'oil-painting' ||
        fx.type === 'watercolor' ||
        fx.type === 'halftone' ||
        fx.type === 'pixel-sorting')
    ) {
      continue;
    }

    const p = (k: string, fb: number) => getNumParam(fx, k, fb, keyframes, localTime);
    const s = (k: string, fb: string) => getStrParam(fx, k, fb);
    const b = (k: string, fb: boolean) => getBoolParam(fx, k, fb);

    switch (fx.type) {
      // ---------------- BLUR EFFECTS ----------------
      case 'gaussian-blur': {
        const amt = p('amount', 10);
        const hRatio = p('horizontal', 100) / 100;
        const vRatio = p('vertical', 100) / 100;
        if (amt <= 0.1) break;
        const bCtx = copyCanvas(workCanvas, scratchA, w, h);
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        const avgR = amt * ((hRatio + vRatio) * 0.5);
        ctx.filter = `blur(${avgR.toFixed(1)}px)`;
        // Asymmetric H/V multi-pass sampling if horizontal != vertical
        if (Math.abs(hRatio - vRatio) > 0.15) {
          const steps = 5;
          ctx.globalAlpha = 1 / steps;
          for (let i = 0; i < steps; i++) {
            const off = (i / (steps - 1) - 0.5) * amt * 1.4;
            ctx.drawImage(scratchA, off * hRatio, off * vRatio, w, h);
          }
        } else {
          ctx.drawImage(scratchA, 0, 0, w, h);
        }
        ctx.restore();
        void bCtx;
        break;
      }

      case 'box-blur': {
        const radius = p('radius', 6);
        const iter = Math.max(1, Math.min(4, Math.round(p('iterations', 2))));
        if (radius <= 0.2) break;
        for (let it = 0; it < iter; it++) {
          copyCanvas(workCanvas, scratchA, w, h);
          ctx.save();
          ctx.clearRect(0, 0, w, h);
          ctx.filter = `blur(${(radius * 0.65).toFixed(1)}px)`;
          ctx.drawImage(scratchA, 0, 0, w, h);
          ctx.restore();
        }
        break;
      }

      case 'motion-blur':
      case 'directional-blur': {
        const amt =
          fx.type === 'motion-blur'
            ? (p('amount', 18) * p('shutterAngle', 180)) / 180
            : p('length', 16);
        const angle = ((fx.type === 'motion-blur' ? p('direction', 0) : p('angle', 35)) * Math.PI) / 180;
        const samples = Math.max(
          2,
          Math.min(policy.motionBlurSampleCap, Math.round(p('samples', 8)))
        );
        if (amt <= 0.5) break;
        copyCanvas(workCanvas, scratchA, w, h);
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        ctx.globalAlpha = 1 / samples;
        const dx = Math.cos(angle) * amt;
        const dy = Math.sin(angle) * amt;
        for (let i = 0; i < samples; i++) {
          const frac = i / (samples - 1) - 0.5;
          ctx.drawImage(scratchA, frac * dx, frac * dy, w, h);
        }
        ctx.restore();
        break;
      }

      case 'radial-blur': {
        const amt = p('amount', 14);
        const cx = (p('centerX', 50) / 100) * w;
        const cy = (p('centerY', 50) / 100) * h;
        const samples = Math.max(
          2,
          Math.min(policy.motionBlurSampleCap, Math.round(p('samples', 8)))
        );
        if (amt <= 0.2) break;
        copyCanvas(workCanvas, scratchA, w, h);
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        ctx.globalAlpha = 1 / samples;
        const maxRad = (amt * Math.PI) / 180;
        for (let i = 0; i < samples; i++) {
          const ang = (i / (samples - 1) - 0.5) * maxRad;
          ctx.save();
          ctx.translate(cx, cy);
          ctx.rotate(ang);
          ctx.translate(-cx, -cy);
          ctx.drawImage(scratchA, 0, 0, w, h);
          ctx.restore();
        }
        ctx.restore();
        break;
      }

      case 'zoom-blur': {
        const strength = p('strength', 28) / 100;
        const cx = (p('centerX', 50) / 100) * w;
        const cy = (p('centerY', 50) / 100) * h;
        const samples = Math.max(
          2,
          Math.min(policy.motionBlurSampleCap, Math.round(p('samples', 8)))
        );
        if (strength <= 0.01) break;
        copyCanvas(workCanvas, scratchA, w, h);
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        ctx.globalAlpha = 1 / samples;
        for (let i = 0; i < samples; i++) {
          const sc = 1 + (i / (samples - 1)) * strength * 0.35;
          ctx.save();
          ctx.translate(cx, cy);
          ctx.scale(sc, sc);
          ctx.translate(-cx, -cy);
          ctx.drawImage(scratchA, 0, 0, w, h);
          ctx.restore();
        }
        ctx.restore();
        break;
      }

      case 'lens-blur':
      case 'bokeh-blur': {
        const radius = fx.type === 'lens-blur' ? p('radius', 10) : p('amount', 8);
        const gain = (fx.type === 'lens-blur' ? p('bladeCurvature', 40) : p('bokehGain', 55)) / 100;
        const thresh = p('threshold', 180);
        copyCanvas(workCanvas, scratchA, w, h);
        const sCtx = copyCanvas(workCanvas, scratchB, w, h);
        const img = sCtx.getImageData(0, 0, w, h);
        const d = img.data;
        for (let i = 0; i < d.length; i += 4) {
          const lum = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
          if (lum < thresh) {
            d[i + 3] = 0;
          } else {
            d[i] = Math.min(255, d[i] * 1.3);
            d[i + 1] = Math.min(255, d[i + 1] * 1.3);
            d[i + 2] = Math.min(255, d[i + 2] * 1.3);
          }
        }
        sCtx.putImageData(img, 0, 0);
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        ctx.filter = `blur(${radius.toFixed(1)}px)`;
        ctx.drawImage(scratchA, 0, 0, w, h);
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = Math.min(1, gain);
        ctx.filter = `blur(${(radius * 1.35).toFixed(1)}px)`;
        ctx.drawImage(scratchB, 0, 0, w, h);
        ctx.restore();
        break;
      }

      case 'edge-blur': {
        const amt = p('amount', 8);
        const thresh = p('threshold', 35);
        const origData = ctx.getImageData(0, 0, w, h);
        const edges = computeSobelEdges(origData.data, w, h);
        const bCtx = copyCanvas(workCanvas, scratchA, w, h);
        bCtx.save();
        bCtx.filter = `blur(${amt.toFixed(1)}px)`;
        bCtx.drawImage(workCanvas, 0, 0, w, h);
        bCtx.restore();
        const blurData = bCtx.getImageData(0, 0, w, h).data;
        const od = origData.data;
        for (let idx = 0; idx < w * h; idx++) {
          const mix = Math.min(1, Math.max(0, (edges[idx] - thresh) / 100));
          if (mix > 0.01) {
            const p4 = idx * 4;
            od[p4] = od[p4] + (blurData[p4] - od[p4]) * mix;
            od[p4 + 1] = od[p4 + 1] + (blurData[p4 + 1] - od[p4 + 1]) * mix;
            od[p4 + 2] = od[p4 + 2] + (blurData[p4 + 2] - od[p4 + 2]) * mix;
          }
        }
        ctx.putImageData(origData, 0, 0);
        break;
      }

      // ---------------- GLOW & LIGHT EFFECTS ----------------
      case 'glow':
      case 'outer-glow':
      case 'bloom':
      case 'neon-glow': {
        const intensity = p('intensity', 65) / 100;
        const radius = p('radius', p('spread', 20));
        const thresh = fx.type === 'neon-glow' ? 90 : p('threshold', 140);
        const colorHex = s('color', '#E50914');
        const [cr, cg, cb] = hexToRgbTuple(colorHex);
        const useTint = fx.type === 'glow' || fx.type === 'outer-glow' || fx.type === 'neon-glow';

        const bCtx = copyCanvas(workCanvas, scratchA, w, h);
        const img = bCtx.getImageData(0, 0, w, h);
        const d = img.data;
        const edges = fx.type === 'neon-glow' ? computeSobelEdges(d, w, h) : null;
        for (let i = 0; i < d.length; i += 4) {
          const lum = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
          const edgeVal = edges ? edges[i >> 2] : 0;
          const active = fx.type === 'neon-glow' ? edgeVal > 28 : lum > thresh;
          if (!active) {
            d[i + 3] = 0;
          } else if (useTint) {
            const m = fx.type === 'neon-glow' ? 0.8 : 0.45;
            d[i] = Math.round(d[i] * (1 - m) + cr * m);
            d[i + 1] = Math.round(d[i + 1] * (1 - m) + cg * m);
            d[i + 2] = Math.round(d[i + 2] * (1 - m) + cb * m);
          }
        }
        bCtx.putImageData(img, 0, 0);

        ctx.save();
        ctx.globalCompositeOperation = blendModeToCanvasOp(
          (s('blend', 'screen') as EffectBlendMode) || 'screen'
        );
        ctx.globalAlpha = Math.min(1, intensity);
        ctx.filter = `blur(${radius.toFixed(1)}px)`;
        ctx.drawImage(scratchA, 0, 0, w, h);
        ctx.restore();
        break;
      }

      case 'inner-glow': {
        const intensity = p('intensity', 55) / 100;
        const size = p('size', 45) / 100;
        const [r, g, bCol] = hexToRgbTuple(s('color', '#E50914'));
        const grad = ctx.createRadialGradient(
          w * 0.5,
          h * 0.5,
          Math.min(w, h) * (0.45 - size * 0.35),
          w * 0.5,
          h * 0.5,
          Math.max(w, h) * 0.65
        );
        grad.addColorStop(0, `rgba(${r},${g},${bCol},0)`);
        grad.addColorStop(1, `rgba(${r},${g},${bCol},${Math.min(0.95, intensity).toFixed(2)})`);
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
        break;
      }

      case 'light-rays':
      case 'god-rays': {
        const intensity = p('intensity', 65) / 100;
        const sx = (p('sourceX', 50) / 100) * w;
        const sy = (p('sourceY', 15) / 100) * h;
        const rayCount = Math.round(p('rayCount', 7));
        const [r, g, bCol] = hexToRgbTuple(s('color', '#FDE68A'));

        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        for (let i = 0; i < rayCount; i++) {
          const baseAng = (i / rayCount) * Math.PI * 0.9 + Math.PI * 0.05 + Math.sin(localTime * 0.6 + i) * 0.04;
          const spread = 0.08 + (i % 2) * 0.05;
          const len = Math.max(w, h) * 1.4;
          const grad = ctx.createLinearGradient(
            sx,
            sy,
            sx + Math.cos(baseAng) * len,
            sy + Math.sin(baseAng) * len
          );
          grad.addColorStop(0, `rgba(${r},${g},${bCol},${(intensity * 0.42).toFixed(2)})`);
          grad.addColorStop(1, `rgba(${r},${g},${bCol},0)`);
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.lineTo(sx + Math.cos(baseAng - spread) * len, sy + Math.sin(baseAng - spread) * len);
          ctx.lineTo(sx + Math.cos(baseAng + spread) * len, sy + Math.sin(baseAng + spread) * len);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'lens-flare': {
        const bright = p('brightness', 70) / 100;
        const lx = (p('sourceX', 28) / 100) * w;
        const ly = (p('sourceY', 24) / 100) * h;
        const anam = p('anamorphic', 75) / 100;
        const [r, g, bCol] = hexToRgbTuple(s('color', '#E50914'));

        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        const sunGrad = ctx.createRadialGradient(lx, ly, 0, lx, ly, w * 0.28);
        sunGrad.addColorStop(0, `rgba(255,255,255,${Math.min(0.95, bright).toFixed(2)})`);
        sunGrad.addColorStop(0.25, `rgba(${r},${g},${bCol},${(bright * 0.55).toFixed(2)})`);
        sunGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = sunGrad;
        ctx.fillRect(0, 0, w, h);

        if (anam > 0.05) {
          const streak = ctx.createLinearGradient(0, ly, w, ly);
          streak.addColorStop(0, 'rgba(0,0,0,0)');
          streak.addColorStop(lx / w, `rgba(${r},${g},${bCol},${(bright * anam * 0.75).toFixed(2)})`);
          streak.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = streak;
          ctx.fillRect(0, ly - h * 0.025, w, h * 0.05);
        }

        // Secondary ghost hexagons opposite center
        for (let k = 1; k <= 3; k++) {
          const gx = w * 0.5 + (w * 0.5 - lx) * (k * 0.42);
          const gy = h * 0.5 + (h * 0.5 - ly) * (k * 0.42);
          const rad = w * (0.025 + k * 0.015);
          ctx.fillStyle = `rgba(${r},${g},${bCol},${(bright * 0.14).toFixed(2)})`;
          ctx.beginPath();
          ctx.arc(gx, gy, rad, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'light-leak': {
        const intensity = p('intensity', 55) / 100;
        const angle = (p('angle', 35) * Math.PI) / 180;
        const [r1, g1, b1] = hexToRgbTuple(s('primaryColor', '#E50914'));
        const [r2, g2, b2] = hexToRgbTuple(s('secondaryColor', '#FF9F1C'));
        const dx = Math.cos(angle) * w * 0.5;
        const dy = Math.sin(angle) * h * 0.5;
        const grad = ctx.createLinearGradient(w * 0.5 - dx, h * 0.5 - dy, w * 0.5 + dx, h * 0.5 + dy);
        grad.addColorStop(0, `rgba(${r1},${g1},${b1},${(intensity * 0.75).toFixed(2)})`);
        grad.addColorStop(0.45, `rgba(${r2},${g2},${b2},${(intensity * 0.35).toFixed(2)})`);
        grad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
        break;
      }

      case 'light-streaks': {
        const intensity = p('intensity', 70) / 100;
        const len = p('length', 45);
        const angle = (p('angle', 0) * Math.PI) / 180;
        const [cr, cg, cb] = hexToRgbTuple(s('color', '#E50914'));
        const bCtx = copyCanvas(workCanvas, scratchA, w, h);
        const img = bCtx.getImageData(0, 0, w, h);
        const d = img.data;
        for (let i = 0; i < d.length; i += 4) {
          const lum = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
          if (lum < 185) d[i + 3] = 0;
          else {
            d[i] = Math.round((d[i] + cr) * 0.5);
            d[i + 1] = Math.round((d[i + 1] + cg) * 0.5);
            d[i + 2] = Math.round((d[i + 2] + cb) * 0.5);
          }
        }
        bCtx.putImageData(img, 0, 0);
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = (intensity * 0.35) / 3;
        for (let i = -3; i <= 3; i++) {
          if (i === 0) continue;
          const off = (i / 3) * len;
          ctx.drawImage(scratchA, Math.cos(angle) * off, Math.sin(angle) * off, w, h);
        }
        ctx.restore();
        break;
      }

      // ---------------- COLOR EFFECTS ----------------
      case 'brightness':
      case 'contrast':
      case 'exposure':
      case 'saturation':
      case 'hue': {
        copyCanvas(workCanvas, scratchA, w, h);
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        if (fx.type === 'brightness') {
          ctx.filter = `brightness(${Math.max(0.05, 1 + p('value', 15) / 100).toFixed(2)})`;
        } else if (fx.type === 'contrast') {
          ctx.filter = `contrast(${Math.max(0.05, 1 + p('value', 22) / 100).toFixed(2)})`;
        } else if (fx.type === 'exposure') {
          const mult = Math.pow(2, p('ev', 0.4));
          ctx.filter = `brightness(${mult.toFixed(2)}) contrast(${p('gamma', 1).toFixed(2)})`;
        } else if (fx.type === 'saturation') {
          ctx.filter = `saturate(${Math.max(0, 1 + p('value', 25) / 100).toFixed(2)})`;
        } else {
          ctx.filter = `hue-rotate(${p('angle', 24).toFixed(1)}deg)`;
        }
        ctx.drawImage(scratchA, 0, 0, w, h);
        ctx.restore();
        break;
      }

      case 'color-balance':
      case 'color-correction':
      case 'color-grading':
      case 'black-and-white':
      case 'negative':
      case 'gradient-map':
      case 'lut': {
        const img = ctx.getImageData(0, 0, w, h);
        const d = img.data;

        if (fx.type === 'color-balance') {
          const rb = p('red', 12) * 1.4;
          const gb = p('green', 0) * 1.4;
          const bb = p('blue', -8) * 1.4;
          for (let i = 0; i < d.length; i += 4) {
            d[i] = Math.min(255, Math.max(0, d[i] + rb));
            d[i + 1] = Math.min(255, Math.max(0, d[i + 1] + gb));
            d[i + 2] = Math.min(255, Math.max(0, d[i + 2] + bb));
          }
        } else if (fx.type === 'color-correction') {
          const lift = p('lift', -6);
          const gamma = 1 - p('gamma', 4) / 120;
          const gain = 1 + p('gain', 8) / 80;
          const sat = Math.max(0, 1 + p('saturation', 8) / 100);
          for (let i = 0; i < d.length; i += 4) {
            let r = Math.pow(Math.max(0, Math.min(1, (d[i] + lift) / 255)), Math.max(0.2, gamma)) * gain * 255;
            let g = Math.pow(Math.max(0, Math.min(1, (d[i + 1] + lift) / 255)), Math.max(0.2, gamma)) * gain * 255;
            let bCol = Math.pow(Math.max(0, Math.min(1, (d[i + 2] + lift) / 255)), Math.max(0.2, gamma)) * gain * 255;
            const lum = r * 0.299 + g * 0.587 + bCol * 0.114;
            d[i] = Math.min(255, Math.max(0, lum + (r - lum) * sat));
            d[i + 1] = Math.min(255, Math.max(0, lum + (g - lum) * sat));
            d[i + 2] = Math.min(255, Math.max(0, lum + (bCol - lum) * sat));
          }
        } else if (fx.type === 'color-grading') {
          const temp = p('temperature', 8) * 0.6;
          const tint = p('tint', 0) * 0.5;
          const exp = 1 + p('exposure', 6) / 100;
          const con = 1 + p('contrast', 18) / 100;
          const hi = p('highlights', 10) * 0.55;
          const sh = p('shadows', -10) * 0.55;
          const sat = Math.max(0, 1 + p('saturation', 15) / 100);
          for (let i = 0; i < d.length; i += 4) {
            let r = (d[i] * exp - 128) * con + 128 + temp - tint * 0.4;
            let g = (d[i + 1] * exp - 128) * con + 128 + tint * 0.6;
            let bCol = (d[i + 2] * exp - 128) * con + 128 - temp - tint * 0.4;
            const lum = (r * 0.299 + g * 0.587 + bCol * 0.114) / 255;
            const tonalShift = lum > 0.5 ? hi * (lum - 0.5) * 2 : sh * (0.5 - lum) * 2;
            r += tonalShift;
            g += tonalShift;
            bCol += tonalShift;
            const l2 = r * 0.299 + g * 0.587 + bCol * 0.114;
            d[i] = Math.min(255, Math.max(0, l2 + (r - l2) * sat));
            d[i + 1] = Math.min(255, Math.max(0, l2 + (g - l2) * sat));
            d[i + 2] = Math.min(255, Math.max(0, l2 + (bCol - l2) * sat));
          }
        } else if (fx.type === 'black-and-white') {
          const con = 1 + p('contrast', 22) / 100;
          const rw = p('redWeight', 35) / 100;
          const gw = (1 - rw) * 0.72;
          const bw = 1 - rw - gw;
          for (let i = 0; i < d.length; i += 4) {
            let lum = d[i] * rw + d[i + 1] * gw + d[i + 2] * bw;
            lum = Math.min(255, Math.max(0, (lum - 128) * con + 128));
            d[i] = d[i + 1] = d[i + 2] = lum;
          }
        } else if (fx.type === 'negative') {
          const mix = p('mix', 100) / 100;
          for (let i = 0; i < d.length; i += 4) {
            d[i] = d[i] + (255 - d[i] - d[i]) * mix;
            d[i + 1] = d[i + 1] + (255 - d[i + 1] - d[i + 1]) * mix;
            d[i + 2] = d[i + 2] + (255 - d[i + 2] - d[i + 2]) * mix;
          }
        } else if (fx.type === 'gradient-map') {
          const [sr, sg, sb] = hexToRgbTuple(s('shadowColor', '#0E0A14'));
          const [hr, hg, hb] = hexToRgbTuple(s('highlightColor', '#E50914'));
          const mix = p('mix', 70) / 100;
          for (let i = 0; i < d.length; i += 4) {
            const t = (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114) / 255;
            const mr = sr + (hr - sr) * t;
            const mg = sg + (hg - sg) * t;
            const mb = sb + (hb - sb) * t;
            d[i] = d[i] * (1 - mix) + mr * mix;
            d[i + 1] = d[i + 1] * (1 - mix) + mg * mix;
            d[i + 2] = d[i + 2] * (1 - mix) + mb * mix;
          }
        } else if (fx.type === 'lut') {
          const profile = s('preset', 'kodak-2383');
          const strength = p('strength', 80) / 100;
          const customLut = customLutRegistry.get(profile);
          if (customLut) {
            const sz = customLut.size;
            for (let i = 0; i < d.length; i += 4) {
              const ri = Math.min(sz - 1, Math.round((d[i] / 255) * (sz - 1)));
              const gi = Math.min(sz - 1, Math.round((d[i + 1] / 255) * (sz - 1)));
              const bi = Math.min(sz - 1, Math.round((d[i + 2] / 255) * (sz - 1)));
              const idx = (bi * sz * sz + gi * sz + ri) * 3;
              const lr = customLut.data[idx] * 255;
              const lg = customLut.data[idx + 1] * 255;
              const lb = customLut.data[idx + 2] * 255;
              d[i] = d[i] + (lr - d[i]) * strength;
              d[i + 1] = d[i + 1] + (lg - d[i + 1]) * strength;
              d[i + 2] = d[i + 2] + (lb - d[i + 2]) * strength;
            }
          } else {
            for (let i = 0; i < d.length; i += 4) {
              let r = d[i];
              let g = d[i + 1];
              let bCol = d[i + 2];
              const lum = (r * 0.299 + g * 0.587 + bCol * 0.114) / 255;
              if (profile === 'teal-orange') {
                r = lum > 0.45 ? r * 1.12 + 12 : r * 0.86;
                g = g * 1.02;
                bCol = lum < 0.5 ? bCol * 1.16 + 14 : bCol * 0.84;
              } else if (profile === 'crimson-cinema') {
                r = r * 1.18 + 8;
                g = g * 0.88;
                bCol = bCol * 0.92;
              } else if (profile === 'fuji-eterna') {
                r = (r - 128) * 0.92 + 132;
                g = (g - 128) * 0.95 + 130;
                bCol = (bCol - 128) * 0.92 + 134;
              } else if (profile === 'cyber-night') {
                r = r * 1.15;
                g = g * 0.84;
                bCol = bCol * 1.24 + 10;
              } else {
                // kodak-2383
                r = (r - 128) * 1.18 + 130;
                g = (g - 128) * 1.14 + 127;
                bCol = (bCol - 128) * 1.18 + 122;
              }
              d[i] = Math.min(255, Math.max(0, d[i] + (r - d[i]) * strength));
              d[i + 1] = Math.min(255, Math.max(0, d[i + 1] + (g - d[i + 1]) * strength));
              d[i + 2] = Math.min(255, Math.max(0, d[i + 2] + (bCol - d[i + 2]) * strength));
            }
          }
        }
        ctx.putImageData(img, 0, 0);
        break;
      }

      case 'tint': {
        const [r, g, bCol] = hexToRgbTuple(s('color', '#E50914'));
        const amt = p('amount', 40) / 100;
        ctx.save();
        ctx.globalCompositeOperation = 'color';
        ctx.fillStyle = `rgba(${r},${g},${bCol},${amt.toFixed(2)})`;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
        break;
      }

      case 'rgb-split':
      case 'chromatic-aberration': {
        const dist = fx.type === 'rgb-split' ? p('distance', 10) : p('amount', 12);
        const ang = fx.type === 'rgb-split' ? (p('angle', 0) * Math.PI) / 180 : 0;
        const dx = Math.round(Math.cos(ang) * dist);
        const dy = Math.round(Math.sin(ang) * dist);
        if (dx === 0 && dy === 0) break;
        const usedGpu = webgl2Runner.runShader(
          workCanvas,
          'rgb-split',
          GL_FRAG_RGB_SPLIT,
          (gl, prog) => {
            gl.uniform2f(gl.getUniformLocation(prog, 'u_delta'), dx, dy);
            gl.uniform1f(gl.getUniformLocation(prog, 'u_flash'), 1.0);
          }
        );
        if (usedGpu) break;
        const srcImg = ctx.getImageData(0, 0, w, h);
        const outImg = acquireReusableImageData(ctx, w, h);
        const sd = srcImg.data;
        const od = outImg.data;
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const idx = (y * w + x) * 4;
            const rx = Math.min(w - 1, Math.max(0, x + dx));
            const ry = Math.min(h - 1, Math.max(0, y + dy));
            const bx = Math.min(w - 1, Math.max(0, x - dx));
            const by = Math.min(h - 1, Math.max(0, y - dy));
            od[idx] = sd[(ry * w + rx) * 4];
            od[idx + 1] = sd[idx + 1];
            od[idx + 2] = sd[(by * w + bx) * 4 + 2];
            od[idx + 3] = sd[idx + 3];
          }
        }
        ctx.putImageData(outImg, 0, 0);
        break;
      }

      // ---------------- DISTORTION EFFECTS ----------------
      case 'wave-warp':
      case 'displacement-map':
      case 'ripple':
      case 'twirl':
      case 'pinch':
      case 'bulge':
      case 'turbulent-displace':
      case 'glitch-distortion':
      case 'lens-distortion':
      case 'perspective-distortion': {
        if (fx.type === 'wave-warp') {
          const amp = p('amplitude', 14);
          const freq = p('frequency', 3.5);
          const spd = p('speed', 2);
          const isHoriz = s('axis', 'horizontal') === 'horizontal' ? 1 : 0;
          if (
            webgl2Runner.runShader(workCanvas, 'wave-warp', GL_FRAG_WAVE_WARP, (gl, prog) => {
              gl.uniform1f(gl.getUniformLocation(prog, 'u_amp'), amp);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_freq'), freq);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_phase'), localTime * spd);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_horizontal'), isHoriz);
            })
          ) {
            break;
          }
        } else if (fx.type === 'lens-distortion') {
          const k = (p('curvature', -35) / 100) * 0.75;
          const sc = p('scale', 105) / 100;
          if (
            webgl2Runner.runShader(workCanvas, 'lens-distort', GL_FRAG_LENS_DISTORT, (gl, prog) => {
              gl.uniform1f(gl.getUniformLocation(prog, 'u_curv'), k);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_scale'), sc);
            })
          ) {
            break;
          }
        }
        const srcImg = ctx.getImageData(0, 0, w, h);
        const outImg = acquireReusableImageData(ctx, w, h);
        const sd = srcImg.data;
        const od = outImg.data;

        const cx = ((fx.type === 'ripple' || fx.type === 'twirl' ? p('centerX', 50) : 50) / 100) * w;
        const cy = ((fx.type === 'ripple' || fx.type === 'twirl' ? p('centerY', 50) : 50) / 100) * h;
        const minDim = Math.min(w, h);

        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            let sx = x;
            let sy = y;

            if (fx.type === 'wave-warp') {
              const amp = p('amplitude', 14);
              const freq = p('frequency', 3.5);
              const spd = p('speed', 2);
              const axis = s('axis', 'horizontal');
              if (axis === 'horizontal') {
                sx = x + Math.sin((y / h) * Math.PI * 2 * freq + localTime * spd) * amp;
              } else {
                sy = y + Math.sin((x / w) * Math.PI * 2 * freq + localTime * spd) * amp;
              }
            } else if (fx.type === 'displacement-map') {
              const scaleX = p('scaleX', 18);
              const scaleY = p('scaleY', 14);
              const detail = p('detail', 6);
              const nx = Math.sin((x / w) * detail * 3.1 + Math.cos((y / h) * detail * 2.3));
              const ny = Math.cos((y / h) * detail * 3.1 + Math.sin((x / w) * detail * 2.3));
              sx = x + nx * scaleX;
              sy = y + ny * scaleY;
            } else if (fx.type === 'ripple') {
              const amp = p('amplitude', 14);
              const freq = p('frequency', 14);
              const spd = p('speed', 3);
              const dx = x - cx;
              const dy = y - cy;
              const dist = Math.sqrt(dx * dx + dy * dy) || 1;
              const wave = Math.sin((dist / minDim) * freq * 2 - localTime * spd * 3) * amp;
              sx = x + (dx / dist) * wave;
              sy = y + (dy / dist) * wave;
            } else if (fx.type === 'twirl') {
              const maxAng = (p('angle', 110) * Math.PI) / 180;
              const rad = (p('radius', 48) / 100) * minDim * 0.5;
              const dx = x - cx;
              const dy = y - cy;
              const dist = Math.sqrt(dx * dx + dy * dy);
              if (dist < rad && rad > 1) {
                const factor = (rad - dist) / rad;
                const theta = factor * factor * maxAng;
                const cosT = Math.cos(theta);
                const sinT = Math.sin(theta);
                sx = cx + dx * cosT - dy * sinT;
                sy = cy + dx * sinT + dy * cosT;
              }
            } else if (fx.type === 'pinch' || fx.type === 'bulge') {
              const str = (p('strength', 45) / 100) * (fx.type === 'bulge' ? -0.65 : 0.75);
              const rad = (p('radius', 55) / 100) * minDim * 0.5;
              const dx = x - cx;
              const dy = y - cy;
              const dist = Math.sqrt(dx * dx + dy * dy);
              if (dist < rad && dist > 0.5) {
                const norm = dist / rad;
                const factor = Math.pow(norm, str);
                sx = cx + dx * factor;
                sy = cy + dy * factor;
              }
            } else if (fx.type === 'turbulent-displace') {
              const amt = p('amount', 24);
              const sz = p('size', 5);
              const ev = localTime * p('evolution', 1.5);
              sx = x + Math.sin(x * 0.02 * sz + ev) * Math.cos(y * 0.02 * sz - ev) * amt;
              sy = y + Math.cos(y * 0.02 * sz + ev) * Math.sin(x * 0.02 * sz + ev) * amt;
            } else if (fx.type === 'glitch-distortion') {
              const intensity = p('intensity', 55) / 100;
              const bSize = Math.max(4, p('blockSize', 18));
              const rate = p('speed', 8);
              const band = Math.floor(y / bSize);
              const hash = Math.sin(band * 12.9898 + Math.floor(localTime * rate) * 78.233) * 43758.5453;
              const rnd = hash - Math.floor(hash);
              if (rnd > 1 - intensity * 0.55) {
                sx = x + (rnd - 0.5) * intensity * w * 0.25;
              }
            } else if (fx.type === 'lens-distortion') {
              const k = (p('curvature', -35) / 100) * 0.75;
              const sc = p('scale', 105) / 100;
              const nx = (x - w * 0.5) / (w * 0.5);
              const ny = (y - h * 0.5) / (h * 0.5);
              const r2 = nx * nx + ny * ny;
              const warp = (1 + k * r2) / Math.max(0.2, sc);
              sx = w * 0.5 + nx * warp * (w * 0.5);
              sy = h * 0.5 + ny * warp * (h * 0.5);
            } else if (fx.type === 'perspective-distortion') {
              const tiltX = p('tiltX', 22) / 100;
              const tiltY = p('tiltY', 0) / 100;
              const nyNorm = y / h - 0.5;
              const nxNorm = x / w - 0.5;
              const scaleRow = 1 + nyNorm * tiltX;
              sx = w * 0.5 + (nxNorm / Math.max(0.25, scaleRow)) * w;
              sy = h * 0.5 + (nyNorm + nxNorm * tiltY) * h;
            }

            const ix = Math.min(w - 1, Math.max(0, sx | 0));
            const iy = Math.min(h - 1, Math.max(0, sy | 0));
            const sIdx = (iy * w + ix) * 4;
            const dIdx = (y * w + x) * 4;
            od[dIdx] = sd[sIdx];
            od[dIdx + 1] = sd[sIdx + 1];
            od[dIdx + 2] = sd[sIdx + 2];
            od[dIdx + 3] = sd[sIdx + 3];
          }
        }
        ctx.putImageData(outImg, 0, 0);
        break;
      }

      // ---------------- GLITCH EFFECTS ----------------
      case 'rgb-glitch':
      case 'digital-glitch':
      case 'vhs-glitch':
      case 'signal-interference':
      case 'datamosh': {
        const frameSeed = Math.floor(localTime * (fx.type === 'rgb-glitch' ? p('rate', 10) : 12));
        if (fx.type === 'rgb-glitch' || fx.type === 'vhs-glitch') {
          const inten = fx.type === 'rgb-glitch' ? p('intensity', 60) / 100 : p('tracking', 55) / 100;
          const shift = fx.type === 'rgb-glitch' ? p('shift', 14) * inten : p('chromaBleed', 10);
          const wobble = fx.type === 'vhs-glitch' ? p('wobble', 35) / 100 : 0;
          const trackPos = ((localTime * 0.35) % 1) * h;
          const bandSz = Math.max(4, p('bandSize', 16));
          if (
            webgl2Runner.runShader(workCanvas, 'glitch', GL_FRAG_GLITCH, (gl, prog) => {
              gl.uniform1f(gl.getUniformLocation(prog, 'u_inten'), inten);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_shift'), shift);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_bandSize'), bandSz);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_seed'), frameSeed);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_wobble'), wobble);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_trackPos'), trackPos);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_time'), localTime);
            })
          ) {
            break;
          }
        }
        const srcImg = ctx.getImageData(0, 0, w, h);
        const outImg = acquireReusableImageData(ctx, w, h);
        const sd = srcImg.data;
        const od = outImg.data;

        for (let y = 0; y < h; y++) {
          const band = Math.floor(y / Math.max(4, p('bandSize', 16)));
          const hVal = Math.sin(band * 91.7 + frameSeed * 37.3) * 43758.5453;
          const rnd = hVal - Math.floor(hVal);

          let rowOffset = 0;
          let rShift = 0;
          let bShift = 0;

          if (fx.type === 'rgb-glitch') {
            const inten = p('intensity', 60) / 100;
            const shift = p('shift', 14);
            if (rnd > 1 - inten * 0.5) rowOffset = Math.round((rnd - 0.5) * 40 * inten);
            rShift = Math.round(shift * inten);
            bShift = -rShift;
          } else if (fx.type === 'vhs-glitch') {
            const track = p('tracking', 55) / 100;
            const bleed = p('chromaBleed', 10);
            const wobble = p('wobble', 35) / 100;
            rowOffset = Math.round(Math.sin(y * 0.08 + localTime * 15) * 10 * wobble);
            const trackPos = ((localTime * 0.35) % 1) * h;
            if (Math.abs(y - trackPos) < 22 * track) {
              rowOffset += Math.round((rnd - 0.5) * 55 * track);
            }
            rShift = Math.round(bleed);
            bShift = -Math.round(bleed);
          } else if (fx.type === 'digital-glitch') {
            const inten = p('intensity', 50) / 100;
            const blocks = Math.max(3, p('blocks', 14));
            const bRow = Math.floor((y / h) * blocks);
            const bHash = Math.sin(bRow * 44.1 + frameSeed * 19.7) * 9817.1;
            const br = bHash - Math.floor(bHash);
            if (br > 1 - inten * 0.45) rowOffset = Math.round((br - 0.5) * w * 0.18 * inten);
          } else if (fx.type === 'signal-interference') {
            const inten = p('intensity', 55) / 100;
            if (rnd > 1 - inten * 0.45) rowOffset = Math.round((rnd - 0.5) * 60 * inten);
            rShift = Math.round(inten * 8);
          } else if (fx.type === 'datamosh') {
            const smear = p('smear', 36);
            rowOffset = Math.round(Math.sin(y * 0.04 + localTime * 4) * smear * 0.4);
          }

          for (let x = 0; x < w; x++) {
            const dIdx = (y * w + x) * 4;
            const baseX = Math.min(w - 1, Math.max(0, x + rowOffset));
            const rx = Math.min(w - 1, Math.max(0, baseX + rShift));
            const bx = Math.min(w - 1, Math.max(0, baseX + bShift));
            od[dIdx] = sd[(y * w + rx) * 4];
            od[dIdx + 1] = sd[(y * w + baseX) * 4 + 1];
            od[dIdx + 2] = sd[(y * w + bx) * 4 + 2];
            od[dIdx + 3] = sd[(y * w + baseX) * 4 + 3];
          }
        }
        ctx.putImageData(outImg, 0, 0);
        break;
      }

      case 'pixel-sorting': {
        const thresh = p('threshold', 110);
        const maxLen = Math.max(6, Math.round((p('strength', 65) / 100) * 64));
        const img = ctx.getImageData(0, 0, w, h);
        const d = img.data;
        for (let y = 0; y < h; y += 2) {
          let x = 0;
          while (x < w) {
            const idx = (y * w + x) * 4;
            const lum = d[idx] * 0.299 + d[idx + 1] * 0.587 + d[idx + 2] * 0.114;
            if (lum > thresh) {
              const spanEnd = Math.min(w, x + maxLen);
              const span: Array<[number, number, number, number, number]> = [];
              for (let k = x; k < spanEnd; k++) {
                const ki = (y * w + k) * 4;
                const l = d[ki] * 0.299 + d[ki + 1] * 0.587 + d[ki + 2] * 0.114;
                span.push([l, d[ki], d[ki + 1], d[ki + 2], d[ki + 3]]);
              }
              span.sort((a, b2) => a[0] - b2[0]);
              for (let k = 0; k < span.length; k++) {
                const ki = (y * w + (x + k)) * 4;
                d[ki] = span[k][1];
                d[ki + 1] = span[k][2];
                d[ki + 2] = span[k][3];
                d[ki + 3] = span[k][4];
              }
              x = spanEnd;
            } else {
              x++;
            }
          }
        }
        ctx.putImageData(img, 0, 0);
        break;
      }

      case 'scan-lines': {
        const spacing = Math.max(2, Math.round(p('density', 4)));
        const opacity = p('opacity', 45) / 100;
        ctx.save();
        ctx.fillStyle = `rgba(0,0,0,${opacity.toFixed(2)})`;
        for (let y = 0; y < h; y += spacing) {
          ctx.fillRect(0, y, w, Math.max(1, Math.floor(spacing * 0.45)));
        }
        ctx.restore();
        break;
      }

      case 'digital-noise':
      case 'film-grain':
      case 'noise': {
        const amt = p('amount', 30) * 1.1;
        const colored = fx.type === 'digital-noise' && b('colored', true);
        const img = ctx.getImageData(0, 0, w, h);
        const d = img.data;
        const seedBase = Math.floor(localTime * 30) * 17;
        for (let i = 0; i < d.length; i += 4) {
          const n = ((Math.sin((i + seedBase) * 12.9898) * 43758.5453) % 1) - 0.5;
          if (colored) {
            const n2 = ((Math.cos((i + seedBase) * 78.233) * 19341.123) % 1) - 0.5;
            d[i] = Math.min(255, Math.max(0, d[i] + n * amt * 1.4));
            d[i + 1] = Math.min(255, Math.max(0, d[i + 1] + n2 * amt * 1.4));
            d[i + 2] = Math.min(255, Math.max(0, d[i + 2] - n * amt * 1.4));
          } else {
            const delta = n * amt;
            d[i] = Math.min(255, Math.max(0, d[i] + delta));
            d[i + 1] = Math.min(255, Math.max(0, d[i + 1] + delta));
            d[i + 2] = Math.min(255, Math.max(0, d[i + 2] + delta));
          }
        }
        ctx.putImageData(img, 0, 0);
        break;
      }

      case 'horizontal-glitch':
      case 'vertical-glitch':
      case 'screen-tear':
      case 'data-corruption': {
        const inten = p('intensity', 65) / 100;
        const rate = p('rate', 14);
        const seed = Math.floor(localTime * rate);
        if (fx.type === 'horizontal-glitch') {
          const bandH = Math.max(2, Math.round(p('bandHeight', 12)));
          if (
            webgl2Runner.runShader(workCanvas, 'glitch', GL_FRAG_GLITCH, (gl, prog) => {
              gl.uniform1f(gl.getUniformLocation(prog, 'u_inten'), inten);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_shift'), Math.round(inten * 14));
              gl.uniform1f(gl.getUniformLocation(prog, 'u_bandSize'), bandH);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_seed'), seed);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_wobble'), 0);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_trackPos'), 0);
              gl.uniform1f(gl.getUniformLocation(prog, 'u_time'), localTime);
            })
          ) {
            break;
          }
        }
        const srcImg = ctx.getImageData(0, 0, w, h);
        const outImg = acquireReusableImageData(ctx, w, h);
        const sd = srcImg.data;
        const od = outImg.data;

        if (fx.type === 'vertical-glitch') {
          const colW = Math.max(2, Math.round(p('columnWidth', 16)));
          for (let y = 0; y < h; y++) {
            for (let x = 0; x < w; x++) {
              const col = Math.floor(x / colW);
              const hsh = Math.sin(col * 73.1 + seed * 31.7) * 43758.5453;
              const r = hsh - Math.floor(hsh);
              const slip = r > 1 - inten * 0.55 ? Math.round((r - 0.5) * h * 0.28 * inten) : 0;
              const sy = Math.min(h - 1, Math.max(0, y + slip));
              const sxR = Math.min(w - 1, Math.max(0, x + Math.round(inten * 8)));
              const di = (y * w + x) * 4;
              od[di] = sd[(sy * w + sxR) * 4];
              od[di + 1] = sd[(sy * w + x) * 4 + 1];
              od[di + 2] = sd[(sy * w + x) * 4 + 2];
              od[di + 3] = sd[(sy * w + x) * 4 + 3];
            }
          }
        } else if (fx.type === 'screen-tear') {
          const splits = Math.max(1, Math.round(p('splits', 4)));
          const bandH = Math.max(8, Math.floor(h / splits));
          for (let y = 0; y < h; y++) {
            const b = Math.floor(y / bandH);
            const hsh = Math.sin(b * 41.3 + seed * 17.9) * 19384.2;
            const r = hsh - Math.floor(hsh);
            const active = r > 0.35;
            const off = active ? Math.round((r - 0.5) * w * 0.24 * inten) : 0;
            const flash = active && r > 0.88 ? 45 * inten : 0;
            for (let x = 0; x < w; x++) {
              const sx = (x + off + w) % w;
              const si = (y * w + sx) * 4;
              const di = (y * w + x) * 4;
              od[di] = Math.min(255, sd[si] + flash);
              od[di + 1] = sd[si + 1];
              od[di + 2] = Math.min(255, sd[si + 2] + flash * 0.6);
              od[di + 3] = sd[si + 3];
            }
          }
        } else if (fx.type === 'data-corruption') {
          const bSize = Math.max(6, Math.round(p('blockSize', 24)));
          for (let y = 0; y < h; y++) {
            const by = Math.floor(y / bSize);
            for (let x = 0; x < w; x++) {
              const bx = Math.floor(x / bSize);
              const hsh = Math.sin((by * 37 + bx * 91) + seed * 19.3) * 43758.54;
              const r = hsh - Math.floor(hsh);
              const di = (y * w + x) * 4;
              if (r > 1 - inten * 0.32) {
                const shiftX = Math.min(w - 1, Math.max(0, x + Math.round((r - 0.5) * 60 * inten)));
                const si = (y * w + shiftX) * 4;
                od[di] = r > 0.85 ? 255 - sd[si] : sd[si];
                od[di + 1] = sd[si + 2];
                od[di + 2] = sd[si + 1];
                od[di + 3] = sd[si + 3];
              } else {
                od[di] = sd[di];
                od[di + 1] = sd[di + 1];
                od[di + 2] = sd[di + 2];
                od[di + 3] = sd[di + 3];
              }
            }
          }
        } else {
          // horizontal-glitch
          const bandH = Math.max(2, Math.round(p('bandHeight', 12)));
          for (let y = 0; y < h; y++) {
            const band = Math.floor(y / bandH);
            const hsh = Math.sin(band * 53.7 + seed * 29.1) * 43758.5453;
            const r = hsh - Math.floor(hsh);
            const off = r > 1 - inten * 0.52 ? Math.round((r - 0.5) * w * 0.22 * inten) : 0;
            const rgbSep = r > 0.55 ? Math.round(inten * 14) : 0;
            for (let x = 0; x < w; x++) {
              const bx = Math.min(w - 1, Math.max(0, x + off));
              const rx = Math.min(w - 1, Math.max(0, bx + rgbSep));
              const bpx = Math.min(w - 1, Math.max(0, bx - rgbSep));
              const di = (y * w + x) * 4;
              od[di] = sd[(y * w + rx) * 4];
              od[di + 1] = sd[(y * w + bx) * 4 + 1];
              od[di + 2] = sd[(y * w + bpx) * 4 + 2];
              od[di + 3] = sd[(y * w + bx) * 4 + 3];
            }
          }
        }
        ctx.putImageData(outImg, 0, 0);
        break;
      }

      case 'rgb-flash': {
        const inten = p('intensity', 70) / 100;
        const speed = p('speed', 12);
        const split = p('split', 16);
        const phase = Math.sin(localTime * speed * Math.PI);
        const pulse = Math.max(0, Math.abs(phase));
        const dx = Math.round(Math.cos(localTime * speed * 1.5) * split * inten * pulse);
        const dy = Math.round(Math.sin(localTime * speed * 1.5) * split * 0.5 * inten * pulse);
        const flashGain = 1 + pulse * inten * 0.45;
        if (
          webgl2Runner.runShader(workCanvas, 'rgb-split', GL_FRAG_RGB_SPLIT, (gl, prog) => {
            gl.uniform2f(gl.getUniformLocation(prog, 'u_delta'), dx, dy);
            gl.uniform1f(gl.getUniformLocation(prog, 'u_flash'), flashGain);
          })
        ) {
          break;
        }
        const srcImg = ctx.getImageData(0, 0, w, h);
        const outImg = acquireReusableImageData(ctx, w, h);
        const sd = srcImg.data;
        const od = outImg.data;
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const di = (y * w + x) * 4;
            const rx = Math.min(w - 1, Math.max(0, x + dx));
            const ry = Math.min(h - 1, Math.max(0, y + dy));
            const bx = Math.min(w - 1, Math.max(0, x - dx));
            const by = Math.min(h - 1, Math.max(0, y - dy));
            od[di] = Math.min(255, sd[(ry * w + rx) * 4] * flashGain);
            od[di + 1] = Math.min(255, sd[di + 1] * (1 + pulse * inten * 0.15));
            od[di + 2] = Math.min(255, sd[(by * w + bx) * 4 + 2] * flashGain);
            od[di + 3] = sd[di + 3];
          }
        }
        ctx.putImageData(outImg, 0, 0);
        break;
      }

      // ---------------- SHAKE EFFECTS ----------------
      case 'camera-shake': {
        const intensity = p('intensity', 55) / 100;
        const speed = p('speed', 1.4);
        const freq = p('frequency', 8);
        const rotDeg = p('rotation', 4);
        const posXPct = p('posX', 45) / 100;
        const posYPct = p('posY', 40) / 100;
        const zoomStrength = p('zoomStrength', 12) / 100;
        const motionBlurPct = p('motionBlur', 35) / 100;
        const fxDur = Math.max(0.15, Math.min(clipDuration, p('duration', clipDuration)));
        const smoothness = p('smoothness', 50) / 100;
        const startStr = p('startStrength', 100) / 100;
        const endStr = p('endStrength', 25) / 100;
        const waveProfile = s('waveProfile', 'smooth');

        const normT = Math.min(1, Math.max(0, localTime / fxDur));
        const envelope = startStr + (endStr - startStr) * normT;
        const tailAtten = localTime > fxDur ? Math.max(0, 1 - (localTime - fxDur) / 0.25) : 1;
        const masterAmp = intensity * envelope * tailAtten;
        if (masterAmp <= 0.004) break;

        const phaseT = localTime * speed * freq;
        const computeSample = (tPhase: number) => {
          let nx = 0;
          let ny = 0;
          let nr = 0;
          let nz = 0;
          if (waveProfile === 'impact') {
            const decay = Math.exp(-normT * 3.8);
            nx = (Math.sin(tPhase * 5.2) * 0.7 + Math.sin(tPhase * 13.7) * 0.3) * decay;
            ny = (Math.cos(tPhase * 4.9) * 0.7 + Math.cos(tPhase * 15.1) * 0.3) * decay;
            nr = Math.sin(tPhase * 6.3) * decay;
            nz = Math.abs(Math.sin(tPhase * 3.1)) * decay;
          } else if (waveProfile === 'beat') {
            const beatCycle = (tPhase * 0.35) % 1;
            const pulse = Math.pow(Math.max(0, 1 - beatCycle), 2.5);
            nx = Math.sin(tPhase * 4.4) * pulse;
            ny = Math.cos(tPhase * 3.8) * pulse;
            nr = Math.sin(tPhase * 3.1) * pulse;
            nz = pulse;
          } else if (waveProfile === 'whip') {
            const snap = Math.sin(tPhase * 2.6);
            nx = Math.tanh(snap * 2.2);
            ny = Math.cos(tPhase * 1.9) * 0.45;
            nr = Math.tanh(Math.sin(tPhase * 2.2) * 1.8);
            nz = Math.abs(Math.sin(tPhase * 2.6)) * 0.8;
          } else if (waveProfile === 'hard') {
            nx = Math.sin(tPhase * 6.1) * 0.65 + Math.cos(tPhase * 14.3) * 0.35;
            ny = Math.cos(tPhase * 5.7) * 0.65 + Math.sin(tPhase * 16.9) * 0.35;
            nr = Math.sin(tPhase * 7.2);
            nz = Math.sin(tPhase * 5.1) * 0.5 + 0.5;
          } else {
            // smooth drift blended by smoothness
            const sharp = 1 - smoothness * 0.65;
            nx = Math.sin(tPhase * 1.7) * 0.75 + Math.sin(tPhase * 4.3) * 0.25 * sharp;
            ny = Math.cos(tPhase * 1.45) * 0.75 + Math.cos(tPhase * 3.9) * 0.25 * sharp;
            nr = Math.sin(tPhase * 1.3);
            nz = 0.5 + Math.sin(tPhase * 1.8) * 0.5;
          }
          const maxShiftX = w * 0.065 * posXPct * masterAmp;
          const maxShiftY = h * 0.065 * posYPct * masterAmp;
          const rotRad = (nr * rotDeg * masterAmp * Math.PI) / 180;
          const overfill = 1 + Math.min(0.45, (posXPct + posYPct) * 0.08 * masterAmp + (rotDeg / 90) * 0.14 * masterAmp);
          const zoom = overfill + nz * zoomStrength * masterAmp;
          return { dx: nx * maxShiftX, dy: ny * maxShiftY, rotRad, zoom };
        };

        copyCanvas(workCanvas, scratchA, w, h);
        const samples =
          policy.shakeBlurEnabled && motionBlurPct > 0.05
            ? Math.max(2, Math.min(policy.motionBlurSampleCap, Math.round(2 + motionBlurPct * 5)))
            : 1;
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        const shutterSpan = motionBlurPct * 0.32 * speed;
        ctx.globalAlpha = 1 / samples;
        for (let si = 0; si < samples; si++) {
          const offsetPhase = samples > 1 ? (si / (samples - 1) - 0.5) * shutterSpan : 0;
          const st = computeSample(phaseT + offsetPhase);
          ctx.save();
          ctx.translate(w * 0.5 + st.dx, h * 0.5 + st.dy);
          ctx.rotate(st.rotRad);
          ctx.scale(st.zoom, st.zoom);
          ctx.translate(-w * 0.5, -h * 0.5);
          ctx.drawImage(scratchA, 0, 0, w, h);
          ctx.restore();
        }
        ctx.restore();
        break;
      }

      // ---------------- SHADOW EFFECTS ----------------
      case 'drop-shadow':
      case 'soft-shadow': {
        const dist = fx.type === 'drop-shadow' ? p('distance', 16) : p('offsetY', 14);
        const angle = fx.type === 'drop-shadow' ? (p('angle', 135) * Math.PI) / 180 : Math.PI * 0.5;
        const blur = fx.type === 'drop-shadow' ? p('blur', 18) : p('spread', 32);
        const op = p('opacity', 70) / 100;
        const [r, g, bCol] = hexToRgbTuple(s('color', '#000000'));
        copyCanvas(workCanvas, scratchA, w, h);
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        ctx.shadowColor = `rgba(${r},${g},${bCol},${op.toFixed(2)})`;
        ctx.shadowBlur = blur;
        ctx.shadowOffsetX = Math.cos(angle) * dist;
        ctx.shadowOffsetY = Math.sin(angle) * dist;
        ctx.drawImage(scratchA, 0, 0, w, h);
        ctx.restore();
        break;
      }

      case 'inner-shadow': {
        const depth = p('depth', 22);
        const op = p('opacity', 65) / 100;
        const [r, g, bCol] = hexToRgbTuple(s('color', '#000000'));
        const grad = ctx.createRadialGradient(
          w * 0.5,
          h * 0.5,
          Math.max(10, Math.min(w, h) * 0.5 - depth * 2),
          w * 0.5,
          h * 0.5,
          Math.max(w, h) * 0.72
        );
        grad.addColorStop(0, `rgba(${r},${g},${bCol},0)`);
        grad.addColorStop(1, `rgba(${r},${g},${bCol},${op.toFixed(2)})`);
        ctx.save();
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
        break;
      }

      case 'long-shadow':
      case '3d-shadow': {
        const len = p('length', p('offsetY', 32));
        const angle = (p('angle', 45) * Math.PI) / 180;
        const op = p('opacity', 60) / 100;
        const [r, g, bCol] = hexToRgbTuple(s('color', '#4C0519'));
        copyCanvas(workCanvas, scratchA, w, h);
        const sCtx = copyCanvas(workCanvas, scratchB, w, h);
        sCtx.save();
        sCtx.globalCompositeOperation = 'source-in';
        sCtx.fillStyle = `rgba(${r},${g},${bCol},${(op / 8).toFixed(2)})`;
        sCtx.fillRect(0, 0, w, h);
        sCtx.restore();
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        for (let step = 8; step >= 1; step--) {
          const frac = step / 8;
          ctx.drawImage(
            scratchB,
            Math.cos(angle) * len * frac,
            Math.sin(angle) * len * frac,
            w,
            h
          );
        }
        ctx.drawImage(scratchA, 0, 0, w, h);
        ctx.restore();
        break;
      }

      // ---------------- TEXTURE & CONVOLUTION ----------------
      case 'dust': {
        const count = Math.round((p('density', 40) / 100) * 90);
        const op = p('opacity', 55) / 100;
        ctx.save();
        ctx.fillStyle = `rgba(245,245,245,${(op * 0.65).toFixed(2)})`;
        const tIdx = Math.floor(localTime * 12);
        for (let i = 0; i < count; i++) {
          const px = ((Math.sin(i * 19.3 + tIdx * 3.1) * 0.5 + 0.5) * w) | 0;
          const py = ((Math.cos(i * 41.7 + tIdx * 5.7) * 0.5 + 0.5) * h) | 0;
          ctx.fillRect(px, py, (i % 3) + 1, (i % 2) + 1);
        }
        ctx.restore();
        break;
      }

      case 'scratches': {
        const count = Math.max(1, Math.round((p('count', 45) / 100) * 14));
        const op = p('opacity', 45) / 100;
        ctx.save();
        ctx.strokeStyle = `rgba(255,255,255,${(op * 0.45).toFixed(2)})`;
        ctx.lineWidth = 1;
        const tIdx = Math.floor(localTime * 16);
        for (let i = 0; i < count; i++) {
          const sx = (Math.sin(i * 23.1 + tIdx * 7.7) * 0.5 + 0.5) * w;
          ctx.beginPath();
          ctx.moveTo(sx, 0);
          ctx.lineTo(sx + Math.sin(tIdx + i) * 6, h);
          ctx.stroke();
        }
        ctx.restore();
        break;
      }

      case 'paper-texture': {
        const str = p('strength', 40) / 100;
        const warmth = p('warmth', 20) / 100;
        const img = ctx.getImageData(0, 0, w, h);
        const d = img.data;
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const idx = (y * w + x) * 4;
            const fiber =
              (Math.sin(x * 0.45) * Math.cos(y * 0.45) +
                Math.sin((x + y) * 0.25) * 0.5) *
              22 *
              str;
            d[idx] = Math.min(255, Math.max(0, d[idx] + fiber + warmth * 14));
            d[idx + 1] = Math.min(255, Math.max(0, d[idx + 1] + fiber + warmth * 6));
            d[idx + 2] = Math.min(255, Math.max(0, d[idx + 2] + fiber - warmth * 12));
          }
        }
        ctx.putImageData(img, 0, 0);
        break;
      }

      case 'vignette': {
        const amt = p('amount', 55) / 100;
        const mid = p('midpoint', 48) / 100;
        const [r, g, bCol] = hexToRgbTuple(s('color', '#000000'));
        const grad = ctx.createRadialGradient(
          w * 0.5,
          h * 0.5,
          Math.min(w, h) * mid * 0.5,
          w * 0.5,
          h * 0.5,
          Math.max(w, h) * 0.72
        );
        grad.addColorStop(0, `rgba(${r},${g},${bCol},0)`);
        grad.addColorStop(1, `rgba(${r},${g},${bCol},${Math.min(0.95, amt).toFixed(2)})`);
        ctx.save();
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
        break;
      }

      case 'sharpen':
      case 'emboss': {
        const src = ctx.getImageData(0, 0, w, h);
        const out = acquireReusableImageData(ctx, w, h);
        const sd = src.data;
        const od = out.data;
        if (fx.type === 'sharpen') {
          const k = p('amount', 55) / 50; // 0..2
          for (let y = 1; y < h - 1; y++) {
            for (let x = 1; x < w - 1; x++) {
              const i = (y * w + x) * 4;
              for (let c = 0; c < 3; c++) {
                const center = sd[i + c];
                const neighbors =
                  (sd[((y - 1) * w + x) * 4 + c] +
                    sd[((y + 1) * w + x) * 4 + c] +
                    sd[(y * w + x - 1) * 4 + c] +
                    sd[(y * w + x + 1) * 4 + c]) *
                  0.25;
                od[i + c] = Math.min(255, Math.max(0, center + (center - neighbors) * k));
              }
              od[i + 3] = sd[i + 3];
            }
          }
        } else {
          const str = p('strength', 70) / 50;
          const mix = p('mix', 65) / 100;
          for (let y = 1; y < h - 1; y++) {
            for (let x = 1; x < w - 1; x++) {
              const i = (y * w + x) * 4;
              const tl = ((y - 1) * w + (x - 1)) * 4;
              const br = ((y + 1) * w + (x + 1)) * 4;
              for (let c = 0; c < 3; c++) {
                const val = 128 + (sd[tl + c] - sd[br + c]) * str;
                od[i + c] = Math.min(255, Math.max(0, sd[i + c] * (1 - mix) + val * mix));
              }
              od[i + 3] = sd[i + 3];
            }
          }
        }
        ctx.putImageData(out, 0, 0);
        break;
      }

      case 'mosaic':
      case 'pixelate': {
        const size = Math.max(2, Math.round(fx.type === 'mosaic' ? p('tileSize', 14) : p('pixelSize', 10)));
        const mw = Math.max(2, Math.round(w / size));
        const mh = Math.max(2, Math.round(h / size));
        scratchA.width = mw;
        scratchA.height = mh;
        const sCtx = scratchA.getContext('2d')!;
        sCtx.imageSmoothingEnabled = false;
        sCtx.drawImage(workCanvas, 0, 0, mw, mh);
        ctx.save();
        ctx.imageSmoothingEnabled = false;
        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(scratchA, 0, 0, w, h);
        ctx.restore();
        break;
      }

      // ---------------- STYLIZE EFFECTS ----------------
      case 'cartoon':
      case 'posterize':
      case 'sketch':
      case 'edge-detection':
      case 'outline':
      case 'glow-edges': {
        const img = ctx.getImageData(0, 0, w, h);
        const d = img.data;
        const needEdges = fx.type !== 'posterize';
        const edges = needEdges ? computeSobelEdges(d, w, h) : null;

        if (fx.type === 'posterize') {
          const levels = Math.max(2, Math.round(p('levels', 5)));
          const step = 255 / (levels - 1);
          for (let i = 0; i < d.length; i += 4) {
            d[i] = Math.round(d[i] / step) * step;
            d[i + 1] = Math.round(d[i + 1] / step) * step;
            d[i + 2] = Math.round(d[i + 2] / step) * step;
          }
        } else if (fx.type === 'cartoon' && edges) {
          const levels = Math.max(2, Math.round(p('levels', 5)));
          const step = 255 / (levels - 1);
          const edgeWeight = p('edgeStrength', 65) / 100;
          for (let idx = 0; idx < w * h; idx++) {
            const i = idx * 4;
            const e = edges[idx] > 42 ? Math.min(1, ((edges[idx] - 42) / 90) * edgeWeight) : 0;
            d[i] = (Math.round(d[i] / step) * step) * (1 - e);
            d[i + 1] = (Math.round(d[i + 1] / step) * step) * (1 - e);
            d[i + 2] = (Math.round(d[i + 2] / step) * step) * (1 - e);
          }
        } else if (fx.type === 'sketch' && edges) {
          const thresh = p('threshold', 45);
          const dark = b('invertPaper', false);
          for (let idx = 0; idx < w * h; idx++) {
            const i = idx * 4;
            const e = Math.min(255, Math.max(0, (edges[idx] - thresh * 0.4) * 2.2));
            const v = dark ? e : 255 - e;
            d[i] = d[i + 1] = d[i + 2] = v;
          }
        } else if (fx.type === 'edge-detection' && edges) {
          const gain = p('gain', 140) / 100;
          const mix = p('mix', 100) / 100;
          for (let idx = 0; idx < w * h; idx++) {
            const i = idx * 4;
            const e = Math.min(255, edges[idx] * gain);
            d[i] = d[i] * (1 - mix) + e * mix;
            d[i + 1] = d[i + 1] * (1 - mix) + e * mix;
            d[i + 2] = d[i + 2] * (1 - mix) + e * mix;
          }
        } else if ((fx.type === 'outline' || fx.type === 'glow-edges') && edges) {
          const [cr, cg, cb] = hexToRgbTuple(s('color', '#E50914'));
          const thresh = p('threshold', 35);
          const power =
            fx.type === 'glow-edges' ? p('intensity', 85) / 100 : p('mix', 85) / 100;
          for (let idx = 0; idx < w * h; idx++) {
            const i = idx * 4;
            const e = edges[idx] > thresh ? Math.min(1, ((edges[idx] - thresh) / 95) * power) : 0;
            if (fx.type === 'glow-edges') {
              d[i] = Math.min(255, d[i] + cr * e);
              d[i + 1] = Math.min(255, d[i + 1] + cg * e);
              d[i + 2] = Math.min(255, d[i + 2] + cb * e);
            } else {
              d[i] = d[i] * (1 - e) + cr * e;
              d[i + 1] = d[i + 1] * (1 - e) + cg * e;
              d[i + 2] = d[i + 2] * (1 - e) + cb * e;
            }
          }
        }
        ctx.putImageData(img, 0, 0);
        break;
      }

      case 'oil-painting': {
        const radius = Math.max(1, Math.min(4, Math.round(p('brushSize', 3))));
        const levels = Math.max(4, Math.round(p('levels', 12)));
        const src = ctx.getImageData(0, 0, w, h);
        const out = acquireReusableImageData(ctx, w, h);
        const sd = src.data;
        const od = out.data;
        const stride = 2; // 2x2 brush cluster optimization for real-time speed
        for (let y = 0; y < h; y += stride) {
          for (let x = 0; x < w; x += stride) {
            const bins = new Int32Array(levels);
            const sumR = new Int32Array(levels);
            const sumG = new Int32Array(levels);
            const sumB = new Int32Array(levels);
            for (let ky = -radius; ky <= radius; ky += 2) {
              const py = Math.min(h - 1, Math.max(0, y + ky));
              for (let kx = -radius; kx <= radius; kx += 2) {
                const px = Math.min(w - 1, Math.max(0, x + kx));
                const idx = (py * w + px) * 4;
                const intensity = Math.min(
                  levels - 1,
                  Math.floor(((sd[idx] + sd[idx + 1] + sd[idx + 2]) / 768) * levels)
                );
                bins[intensity]++;
                sumR[intensity] += sd[idx];
                sumG[intensity] += sd[idx + 1];
                sumB[intensity] += sd[idx + 2];
              }
            }
            let maxBin = 0;
            for (let k = 1; k < levels; k++) {
              if (bins[k] > bins[maxBin]) maxBin = k;
            }
            const cnt = Math.max(1, bins[maxBin]);
            const r = sumR[maxBin] / cnt;
            const g = sumG[maxBin] / cnt;
            const bCol = sumB[maxBin] / cnt;
            for (let sy = 0; sy < stride && y + sy < h; sy++) {
              for (let sx = 0; sx < stride && x + sx < w; sx++) {
                const oi = ((y + sy) * w + (x + sx)) * 4;
                od[oi] = r;
                od[oi + 1] = g;
                od[oi + 2] = bCol;
                od[oi + 3] = sd[oi + 3];
              }
            }
          }
        }
        ctx.putImageData(out, 0, 0);
        break;
      }

      case 'watercolor': {
        const soft = p('softness', 55) / 10;
        const pigment = p('edgePigment', 50) / 100;
        const orig = ctx.getImageData(0, 0, w, h);
        const edges = computeSobelEdges(orig.data, w, h);
        copyCanvas(workCanvas, scratchA, w, h);
        ctx.save();
        ctx.clearRect(0, 0, w, h);
        ctx.filter = `blur(${soft.toFixed(1)}px) saturate(1.25)`;
        ctx.drawImage(scratchA, 0, 0, w, h);
        ctx.restore();
        const washed = ctx.getImageData(0, 0, w, h);
        const wd = washed.data;
        for (let idx = 0; idx < w * h; idx++) {
          const e = Math.min(0.65, (edges[idx] / 255) * pigment);
          const i = idx * 4;
          wd[i] *= 1 - e;
          wd[i + 1] *= 1 - e;
          wd[i + 2] *= 1 - e;
        }
        ctx.putImageData(washed, 0, 0);
        break;
      }

      case 'halftone': {
        const cell = Math.max(4, Math.round(p('dotSize', 8)));
        const colored = b('colored', false);
        const img = ctx.getImageData(0, 0, w, h);
        const d = img.data;
        ctx.save();
        ctx.fillStyle = '#111111';
        ctx.fillRect(0, 0, w, h);
        for (let y = cell * 0.5; y < h; y += cell) {
          for (let x = cell * 0.5; x < w; x += cell) {
            const idx = (Math.floor(y) * w + Math.floor(x)) * 4;
            const r = d[idx];
            const g = d[idx + 1];
            const bCol = d[idx + 2];
            const lum = (r * 0.299 + g * 0.587 + bCol * 0.114) / 255;
            const rad = Math.max(0.5, lum * cell * 0.48);
            ctx.fillStyle = colored ? `rgb(${r},${g},${bCol})` : '#FFFFFF';
            ctx.beginPath();
            ctx.arc(x, y, rad, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        ctx.restore();
        break;
      }
    }
  }
}

export interface ComputedTransitionTransform {
  opacityMult: number;
  offsetX: number;
  offsetY: number;
  scaleMultX: number;
  scaleMultY: number;
  rotationDeg: number;
  blurAdd: number;
  flashAlpha: number;
  flashColor: string;
  lightLeakAlpha: number;
  clipMode: 'none' | 'circle' | 'rect-wipe' | 'radial-wipe' | 'diamond';
  clipProgress: number;
  clipDirection: TransitionSettings['direction'];
  rgbSplitPx: number;
  shakeX: number;
  shakeY: number;
  particleBurstProgress: number;
}

export function computeTransitionState(
  settings: TransitionSettings,
  rawProgress: number, // 0 = edge of cut, 1 = fully visible
  isOut: boolean,
  targetW: number,
  targetH: number,
  playheadTime: number
): ComputedTransitionTransform {
  const out: ComputedTransitionTransform = {
    opacityMult: 1,
    offsetX: 0,
    offsetY: 0,
    scaleMultX: 1,
    scaleMultY: 1,
    rotationDeg: 0,
    blurAdd: 0,
    flashAlpha: 0,
    flashColor: '#FFFFFF',
    lightLeakAlpha: 0,
    clipMode: 'none',
    clipProgress: 1,
    clipDirection: settings.direction,
    rgbSplitPx: 0,
    shakeX: 0,
    shakeY: 0,
    particleBurstProgress: 0,
  };

  if (settings.type === 'none') return out;

  const sped = Math.min(1, Math.max(0, rawProgress * Math.max(0.25, settings.speed || 1)));
  const p = applyEasingCurve(sped, settings.easing || 'easeInOut');
  const inv = 1 - p;
  const inten = (settings.intensity ?? 75) / 100;
  const sign = isOut ? -1 : 1;
  const dir = settings.direction || 'left';

  switch (settings.type) {
    case 'cut':
      out.opacityMult = p > 0.5 ? 1 : 0;
      break;
    case 'fade-in':
    case 'fade-out':
    case 'cross-dissolve':
      out.opacityMult = p;
      break;
    case 'dip-to-black':
      out.opacityMult = p;
      out.flashColor = '#000000';
      out.flashAlpha = inv * 0.9;
      break;
    case 'dip-to-white':
      out.opacityMult = p;
      out.flashColor = '#FFFFFF';
      out.flashAlpha = inv * 0.95;
      break;
    case 'zoom-in':
    case 'lens-zoom':
      out.scaleMultX = out.scaleMultY = isOut ? 1 + inv * 0.85 * inten : 0.45 + p * 0.55;
      out.opacityMult = Math.min(1, p * 1.4);
      if (settings.type === 'lens-zoom') out.blurAdd = inv * 12 * inten;
      break;
    case 'zoom-out':
      out.scaleMultX = out.scaleMultY = isOut ? 1 - inv * 0.55 * inten : 1 + inv * 0.95 * inten;
      out.opacityMult = Math.min(1, p * 1.4);
      break;
    case 'push':
    case 'slide-left':
    case 'slide-right':
    case 'slide-up':
    case 'slide-down': {
      const effectiveDir =
        settings.type === 'slide-left'
          ? 'left'
          : settings.type === 'slide-right'
          ? 'right'
          : settings.type === 'slide-up'
          ? 'up'
          : settings.type === 'slide-down'
          ? 'down'
          : dir;
      if (effectiveDir === 'left') out.offsetX = inv * targetW * sign;
      else if (effectiveDir === 'right') out.offsetX = -inv * targetW * sign;
      else if (effectiveDir === 'up') out.offsetY = inv * targetH * sign;
      else out.offsetY = -inv * targetH * sign;
      break;
    }
    case 'rotation-transition':
      out.rotationDeg = inv * 45 * sign * inten;
      out.scaleMultX = out.scaleMultY = 0.75 + p * 0.25;
      out.opacityMult = p;
      break;
    case 'spin-transition':
      out.rotationDeg = inv * 360 * sign * inten;
      out.scaleMultX = out.scaleMultY = 0.55 + p * 0.45;
      out.blurAdd = inv * 10 * inten;
      out.opacityMult = Math.min(1, p * 1.5);
      break;
    case 'whip-pan':
    case 'motion-blur-transition':
      out.offsetX = inv * targetW * 0.72 * sign;
      out.rotationDeg = inv * -7 * sign;
      out.blurAdd = inv * 16 * inten;
      break;
    case 'camera-shake':
      out.shakeX = Math.sin(playheadTime * 95) * inv * 32 * inten;
      out.shakeY = Math.cos(playheadTime * 112) * inv * 24 * inten;
      out.scaleMultX = out.scaleMultY = 1 + inv * 0.14 * inten;
      out.opacityMult = Math.min(1, p * 1.6);
      break;
    case 'flash-transition':
      out.flashColor = '#FFFFFF';
      out.flashAlpha = inv * inten;
      out.opacityMult = Math.min(1, p * 1.3);
      break;
    case 'light-leak-transition':
    case 'film-burn':
      out.lightLeakAlpha = inv * inten;
      out.opacityMult = Math.min(1, p * 1.25);
      break;
    case 'glitch-cut':
    case 'rgb-split-transition':
      out.shakeX = Math.sin(playheadTime * 120) * inv * 24 * inten;
      out.rgbSplitPx = Math.round(inv * 24 * inten);
      out.opacityMult = Math.min(1, p * 1.4);
      break;
    case 'cinematic-blur':
      out.blurAdd = inv * 26 * inten;
      out.opacityMult = p;
      break;
    case 'circle-reveal':
    case 'iris-reveal':
      out.clipMode = 'circle';
      out.clipProgress = Math.max(0.01, p);
      break;
    case 'linear-wipe':
    case 'mask-expansion':
      out.clipMode = 'rect-wipe';
      out.clipProgress = Math.max(0.01, p);
      break;
    case 'radial-wipe':
      out.clipMode = 'radial-wipe';
      out.clipProgress = Math.max(0.01, p);
      break;
    case 'shape-reveal':
      out.clipMode = 'diamond';
      out.clipProgress = Math.max(0.01, p);
      break;
    case 'luma-matte':
      out.opacityMult = Math.pow(p, 1.35);
      out.blurAdd = inv * 6;
      break;
    case 'liquid-transition':
      out.scaleMultX = 1 + Math.sin(inv * Math.PI * 2) * 0.18 * inten;
      out.scaleMultY = 1 - Math.sin(inv * Math.PI * 2) * 0.18 * inten;
      out.blurAdd = inv * 8 * inten;
      out.opacityMult = p;
      break;
    case 'warp-transition':
    case 'distortion-transition':
      out.scaleMultX = out.scaleMultY = 1 + inv * 0.75 * inten;
      out.rotationDeg = inv * 18 * sign * inten;
      out.rgbSplitPx = Math.round(inv * 14 * inten);
      out.opacityMult = Math.min(1, p * 1.3);
      break;
    case 'morph-transition':
      out.scaleMultX = 0.7 + p * 0.3;
      out.scaleMultY = 1.25 - p * 0.25;
      out.opacityMult = p;
      break;
    case 'particle-transition':
      out.particleBurstProgress = inv * inten;
      out.opacityMult = Math.min(1, p * 1.35);
      break;
    case '3d-cube-transition':
      out.scaleMultX = Math.max(0.08, p);
      out.offsetX = inv * targetW * 0.5 * sign;
      out.opacityMult = Math.min(1, p * 1.25);
      break;
  }

  return out;
}

export function hasAdvancedColorGrade(grade?: ColorGrade): boolean {
  if (!grade) return false;
  if (grade.preset !== 'none') return true;
  if (
    grade.exposure !== 0 ||
    grade.contrast !== 0 ||
    grade.saturation !== 0 ||
    grade.temperature !== 0 ||
    grade.tint !== 0 ||
    grade.vignette !== 0 ||
    grade.highlights !== 0 ||
    grade.shadows !== 0 ||
    (grade.whites ?? 0) !== 0 ||
    (grade.blacks ?? 0) !== 0 ||
    (grade.vibrance ?? 0) !== 0
  ) {
    return true;
  }
  if (grade.rgbCurves) {
    const { master, red, green, blue } = grade.rgbCurves;
    if (master !== 0 || red !== 0 || green !== 0 || blue !== 0) return true;
  }
  if (grade.colorBalance) {
    const cb = grade.colorBalance;
    if (
      cb.shadowsRed !== 0 ||
      cb.shadowsGreen !== 0 ||
      cb.shadowsBlue !== 0 ||
      cb.highlightsRed !== 0 ||
      cb.highlightsGreen !== 0 ||
      cb.highlightsBlue !== 0
    ) {
      return true;
    }
  }
  if (grade.lutName && customLutRegistry.has(grade.lutName)) return true;
  return false;
}

export function applyFullColorGradeToCanvas(workCanvas: HTMLCanvasElement, grade: ColorGrade): void {
  if (!hasAdvancedColorGrade(grade)) return;
  const ctx = workCanvas.getContext('2d');
  if (!ctx) return;
  const w = workCanvas.width;
  const h = workCanvas.height;
  if (w <= 0 || h <= 0) return;

  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;

  const lutMix = Math.max(0, Math.min(1, (grade.lutIntensity ?? grade.lutStrength ?? 100) / 100));
  const expGain = Math.pow(2, (grade.exposure || 0) / 55);
  const contrastFactor = 1 + (grade.contrast || 0) / 100;
  const satMult = Math.max(0, 1 + (grade.saturation || 0) / 100);
  const vibranceAmt = (grade.vibrance || 0) / 100;
  const tempShift = ((grade.temperature || 0) / 100) * 32;
  const tintShift = ((grade.tint || 0) / 100) * 26;
  const hlAdj = ((grade.highlights || 0) / 100) * 58;
  const shAdj = ((grade.shadows || 0) / 100) * 58;
  const whitesAdj = ((grade.whites || 0) / 100) * 42;
  const blacksAdj = ((grade.blacks || 0) / 100) * 42;

  const curves = grade.rgbCurves || { master: 0, red: 0, green: 0, blue: 0 };
  const bal = grade.colorBalance || {
    shadowsRed: 0,
    shadowsGreen: 0,
    shadowsBlue: 0,
    highlightsRed: 0,
    highlightsGreen: 0,
    highlightsBlue: 0,
  };

  const preset = grade.preset;
  const customLut = grade.lutName ? customLutRegistry.get(grade.lutName) : undefined;

  // Precompute 256-entry RGB Curve LUTs to eliminate per-pixel Math.pow calls
  const hasCurves =
    curves.master !== 0 || curves.red !== 0 || curves.green !== 0 || curves.blue !== 0;
  let rLut: Uint8Array | null = null;
  let gLut: Uint8Array | null = null;
  let bLut: Uint8Array | null = null;
  if (hasCurves) {
    rLut = new Uint8Array(256);
    gLut = new Uint8Array(256);
    bLut = new Uint8Array(256);
    const mPow = curves.master !== 0 ? Math.pow(2, -curves.master / 120) : 1;
    const rPow = curves.red !== 0 ? Math.pow(2, -curves.red / 120) : 1;
    const gPow = curves.green !== 0 ? Math.pow(2, -curves.green / 120) : 1;
    const bPow = curves.blue !== 0 ? Math.pow(2, -curves.blue / 120) : 1;
    for (let v = 0; v < 256; v++) {
      const n = v / 255;
      const base = mPow !== 1 ? Math.pow(n, mPow) : n;
      rLut[v] = Math.round((rPow !== 1 ? Math.pow(base, rPow) : base) * 255);
      gLut[v] = Math.round((gPow !== 1 ? Math.pow(base, gPow) : base) * 255);
      bLut[v] = Math.round((bPow !== 1 ? Math.pow(base, bPow) : base) * 255);
    }
  }

  for (let i = 0; i < d.length; i += 4) {
    let r = d[i];
    let g = d[i + 1];
    let b = d[i + 2];

    // 1. Exposure + Blacks/Whites + Contrast
    r = r * expGain + blacksAdj * 0.65;
    g = g * expGain + blacksAdj * 0.65;
    b = b * expGain + blacksAdj * 0.65;

    const lum0 = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    const hlMask = Math.max(0, Math.min(1, (lum0 - 0.52) / 0.48));
    const shMask = Math.max(0, Math.min(1, (0.48 - lum0) / 0.48));
    const wMask = Math.max(0, Math.min(1, (lum0 - 0.75) / 0.25));

    const toneDelta = hlMask * hlAdj + shMask * shAdj + wMask * whitesAdj;
    r += toneDelta;
    g += toneDelta;
    b += toneDelta;

    r = (r - 127.5) * contrastFactor + 127.5;
    g = (g - 127.5) * contrastFactor + 127.5;
    b = (b - 127.5) * contrastFactor + 127.5;

    // 2. Temperature & Tint
    r += tempShift;
    b -= tempShift;
    g += tintShift * 0.6;
    r -= tintShift * 0.25;
    b -= tintShift * 0.25;

    // 3. Color Balance (Shadows vs Highlights)
    r += shMask * bal.shadowsRed * 0.55 + hlMask * bal.highlightsRed * 0.55;
    g += shMask * bal.shadowsGreen * 0.55 + hlMask * bal.highlightsGreen * 0.55;
    b += shMask * bal.shadowsBlue * 0.55 + hlMask * bal.highlightsBlue * 0.55;

    // 4. RGB Curves midtone bend via precomputed 256-entry 1D LUTs
    if (rLut && gLut && bLut) {
      r = rLut[r < 0 ? 0 : r > 255 ? 255 : r | 0];
      g = gLut[g < 0 ? 0 : g > 255 ? 255 : g | 0];
      b = bLut[b < 0 ? 0 : b > 255 ? 255 : b | 0];
    }

    // 5. Saturation + Vibrance
    const lum1 = 0.299 * r + 0.587 * g + 0.114 * b;
    const maxC = Math.max(r, g, b);
    const minC = Math.min(r, g, b);
    const chroma = (maxC - minC) / 255;
    const vibBoost = 1 + vibranceAmt * (1 - chroma);
    const totalSat = satMult * Math.max(0.05, vibBoost);
    r = lum1 + (r - lum1) * totalSat;
    g = lum1 + (g - lum1) * totalSat;
    b = lum1 + (b - lum1) * totalSat;

    // 6. Named CC Presets / Film Looks blended by lutMix
    if (preset !== 'none' && lutMix > 0) {
      let pr = r;
      let pg = g;
      let pb = b;
      const l = Math.max(0, Math.min(1, (0.299 * r + 0.587 * g + 0.114 * b) / 255));
      const pSh = Math.max(0, 1 - l * 1.8);
      const pHl = Math.max(0, (l - 0.45) * 1.8);

      switch (preset) {
        case 'cinematic-teal-orange':
          pr = r + pHl * 26 - pSh * 14;
          pg = g + pSh * 8 + pHl * 6;
          pb = b + pSh * 28 - pHl * 22;
          break;
        case 'cinematic-cc':
          pr = (r - 127) * 1.14 + 127 + pHl * 14 - pSh * 8;
          pg = (g - 127) * 1.12 + 127 + pSh * 4;
          pb = (b - 127) * 1.14 + 127 + pSh * 16 - pHl * 8;
          break;
        case 'dark-cc':
          pr = r * 0.82 - 8;
          pg = g * 0.81 - 8;
          pb = b * 0.86 - 5;
          break;
        case 'moody-cc':
          pr = lum1 * 0.22 + r * 0.78 - pSh * 8;
          pg = lum1 * 0.22 + g * 0.78 + pSh * 4;
          pb = lum1 * 0.18 + b * 0.82 + pSh * 14;
          break;
        case 'blue-cinematic':
          pr = r * 0.84 - pSh * 10;
          pg = g * 0.96 + pSh * 4;
          pb = b * 1.12 + 16;
          break;
        case 'warm-film':
          pr = r * 1.09 + 12;
          pg = g * 1.03 + 5;
          pb = b * 0.86 - 8;
          break;
        case 'cold-film':
          pr = r * 0.86 - 6;
          pg = g * 0.98 + 4;
          pb = b * 1.12 + 14;
          break;
        case 'vintage-35mm':
          pr = r * 0.96 + 18;
          pg = g * 0.92 + 14;
          pb = b * 0.82 + 22;
          break;
        case 'anime-cc': {
          const boost = 1.24;
          pr = lum1 + (r - lum1) * boost + 8;
          pg = lum1 + (g - lum1) * boost + 5;
          pb = lum1 + (b - lum1) * boost + 12;
          break;
        }
        case 'hdr-look':
          pr = (r - 127.5) * 1.28 + 127.5 + pSh * 22 - pHl * 14;
          pg = (g - 127.5) * 1.28 + 127.5 + pSh * 22 - pHl * 14;
          pb = (b - 127.5) * 1.28 + 127.5 + pSh * 22 - pHl * 14;
          break;
        case 'high-contrast':
          pr = (r - 127.5) * 1.42 + 127.5;
          pg = (g - 127.5) * 1.42 + 127.5;
          pb = (b - 127.5) * 1.42 + 127.5;
          break;
        case 'dark-fantasy':
          pr = r * 0.92 + pHl * 18 - pSh * 6;
          pg = g * 0.78 - pSh * 4;
          pb = b * 1.04 + pSh * 22;
          break;
        case 'film-pro':
          // Film S-curve + slight warm highlights + rich blacks
          pr = (Math.pow(l, 0.95) * 255 * 0.12 + r * 0.88) + pHl * 10;
          pg = (Math.pow(l, 0.96) * 255 * 0.12 + g * 0.88) + pHl * 4;
          pb = (Math.pow(l, 0.98) * 255 * 0.12 + b * 0.88) + pSh * 10;
          break;
        case 'crimson-noir':
          pr = lum1 * 0.45 + r * 0.55 + (r > g && r > b ? 28 : 4);
          pg = lum1 * 0.65 + g * 0.35 - 10;
          pb = lum1 * 0.65 + b * 0.35 - 10;
          break;
        case 'golden-hour':
          pr = r * 1.12 + 16;
          pg = g * 1.04 + 6;
          pb = b * 0.78 - 10;
          break;
        case 'monochrome': {
          const mono = lum1 * 1.08 - 6;
          pr = mono;
          pg = mono;
          pb = mono;
          break;
        }
      }
      r = r * (1 - lutMix) + pr * lutMix;
      g = g * (1 - lutMix) + pg * lutMix;
      b = b * (1 - lutMix) + pb * lutMix;
    }

    // 7. Custom uploaded .cube 3D LUT if registered
    if (customLut && lutMix > 0) {
      const sz = customLut.size;
      const ri = Math.min(sz - 1, Math.max(0, Math.round((Math.max(0, Math.min(255, r)) / 255) * (sz - 1))));
      const gi = Math.min(sz - 1, Math.max(0, Math.round((Math.max(0, Math.min(255, g)) / 255) * (sz - 1))));
      const bi = Math.min(sz - 1, Math.max(0, Math.round((Math.max(0, Math.min(255, b)) / 255) * (sz - 1))));
      const idx3 = (bi * sz * sz + gi * sz + ri) * 3;
      const lr = customLut.data[idx3] * 255;
      const lg = customLut.data[idx3 + 1] * 255;
      const lb = customLut.data[idx3 + 2] * 255;
      r = r * (1 - lutMix) + lr * lutMix;
      g = g * (1 - lutMix) + lg * lutMix;
      b = b * (1 - lutMix) + lb * lutMix;
    }

    d[i] = Math.max(0, Math.min(255, r));
    d[i + 1] = Math.max(0, Math.min(255, g));
    d[i + 2] = Math.max(0, Math.min(255, b));
  }

  ctx.putImageData(img, 0, 0);

  // 8. Vignette overlay
  if ((grade.vignette || 0) > 0) {
    const vig = Math.max(0, Math.min(1, grade.vignette / 100));
    const cx = w / 2;
    const cy = h / 2;
    const maxR = Math.hypot(cx, cy);
    const grad = ctx.createRadialGradient(cx, cy, maxR * 0.35, cx, cy, maxR);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, `rgba(0,0,0,${(vig * 0.85).toFixed(3)})`);
    ctx.save();
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }
}

