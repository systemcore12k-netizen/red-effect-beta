export type EffectCategoryId =
  | 'blur'
  | 'glow'
  | 'color'
  | 'distortion'
  | 'glitch'
  | 'shadow'
  | 'texture'
  | 'stylize'
  | 'shake';

export type ReadyMadeCategoryId =
  | 'text'
  | 'shake'
  | 'glitch'
  | 'cc'
  | 'blur'
  | 'rgb'
  | 'distortion'
  | 'cinematic'
  | 'transition';

export type EffectBlendMode = 'normal' | 'screen' | 'multiply' | 'overlay' | 'add' | 'soft-light';

export type EffectParamType = 'slider' | 'color' | 'select' | 'boolean';

export interface EffectParamSchema {
  key: string;
  label: string;
  type: EffectParamType;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  options?: Array<{ value: string; label: string }>;
  defaultValue: number | string | boolean;
}

export interface EffectDefinition {
  type: string;
  name: string;
  category: EffectCategoryId;
  description: string;
  params: EffectParamSchema[];
}

export interface EffectInstance {
  id: string;
  type: string;
  name: string;
  category: EffectCategoryId;
  enabled: boolean;
  blendMode: EffectBlendMode;
  params: Record<string, number | string | boolean>;
}

export type TransitionCategoryId = 'basic' | 'motion' | 'cinematic' | 'mask' | 'advanced';

export type AdvancedTransitionType =
  | 'none'
  // Basic
  | 'fade-in'
  | 'fade-out'
  | 'cross-dissolve'
  | 'cut'
  | 'dip-to-black'
  | 'dip-to-white'
  // Motion
  | 'zoom-in'
  | 'zoom-out'
  | 'push'
  | 'slide-left'
  | 'slide-right'
  | 'slide-up'
  | 'slide-down'
  | 'rotation-transition'
  | 'spin-transition'
  | 'whip-pan'
  // Cinematic
  | 'camera-shake'
  | 'motion-blur-transition'
  | 'flash-transition'
  | 'light-leak-transition'
  | 'glitch-cut'
  | 'rgb-split-transition'
  | 'film-burn'
  | 'lens-zoom'
  | 'cinematic-blur'
  // Mask
  | 'circle-reveal'
  | 'linear-wipe'
  | 'radial-wipe'
  | 'shape-reveal'
  | 'luma-matte'
  | 'mask-expansion'
  // Advanced
  | 'liquid-transition'
  | 'warp-transition'
  | 'morph-transition'
  | 'distortion-transition'
  | 'particle-transition'
  | '3d-cube-transition'
  // Legacy alias support
  | 'iris-reveal';

export type TransitionDirection = 'left' | 'right' | 'up' | 'down' | 'center';
export type AnimationEasing =
  | 'linear'
  | 'easeIn'
  | 'easeOut'
  | 'easeInOut'
  | 'smooth'
  | 'smoothStart'
  | 'smoothEnd'
  | 'bounce'
  | 'elastic'
  | 'back'
  | 'overshoot'
  | 'anticipation'
  | 'bezier';

export interface CustomCurvePreset {
  id: string;
  name: string;
  easing: AnimationEasing;
  bezier: [number, number, number, number];
  createdAt: number;
}

export interface TransitionSettings {
  type: AdvancedTransitionType;
  duration: number; // seconds
  speed: number; // 0.25 to 3
  direction: TransitionDirection;
  intensity: number; // 0 to 100
  smoothness: number; // 0 to 100
  easing: AnimationEasing;
}

export interface TransitionDefinition {
  type: AdvancedTransitionType;
  name: string;
  category: TransitionCategoryId;
  description: string;
  defaultSettings: TransitionSettings;
}

export type TextAnimationEffect =
  | 'none'
  | 'typewriter'
  | 'fade-in'
  | 'fade-out'
  | 'fade-up'
  | 'letter-reveal'
  | 'word-reveal'
  | 'character-reveal'
  | 'tracking-animation'
  | 'text-shake'
  | 'text-bounce'
  | 'text-wave'
  | 'text-rotation'
  | 'text-zoom'
  | 'text-flip'
  | 'text-glitch'
  | 'rgb-text'
  | 'neon-text'
  | 'fire-text'
  | 'smoke-text'
  | 'liquid-text'
  | '3d-extrude'
  | 'metallic-text'
  | 'cinematic-title'
  | 'kinetic-typography'
  | 'pop-up'
  | 'velocity-text'
  | 'distortion-text';

export type TextGranularity = 'all' | 'character' | 'word' | 'line';
export type TextPathMode = 'none' | 'arc' | 'wave' | 'circle';

export type ShapeKind =
  | 'rectangle'
  | 'circle'
  | 'ellipse'
  | 'polygon'
  | 'star'
  | 'custom-path';

export interface BezierPoint {
  x: number; // normalized -0.5 to 0.5 around center
  y: number; // normalized -0.5 to 0.5 around center
  inX: number; // handle offset
  inY: number;
  outX: number;
  outY: number;
}

export interface ShapeProperties {
  shape: ShapeKind;
  fillColor: string;
  fillOpacity: number; // 0 to 1
  strokeColor: string;
  strokeWidth: number;
  cornerRadius: number; // px
  points: number; // polygon sides or star points
  innerRadius: number; // 0.1 to 0.95 for star
  widthPct: number; // 5 to 100
  heightPct: number; // 5 to 100
  pathPoints: BezierPoint[];
  closed: boolean;
}

export type MaskMode = 'add' | 'subtract' | 'intersect';

export interface AnimatedMaskKeyframe {
  time: number;
  points: BezierPoint[];
}

export type PresetCategory =
  | 'Trending'
  | 'Cinematic'
  | 'Velocity'
  | 'Anime'
  | 'Typography'
  | 'Glitch'
  | '3D'
  | 'Social Media';

export type PresetKind =
  | 'effects-stack'
  | 'transition'
  | 'text-style'
  | 'animation';

export interface StudioPreset {
  id: string;
  name: string;
  category: PresetCategory;
  kind: PresetKind;
  description: string;
  isBuiltIn?: boolean;
  createdAt: number;
  effectsStack?: EffectInstance[];
  transitionIn?: TransitionSettings;
  transitionOut?: TransitionSettings;
  textStyle?: Record<string, unknown>;
  keyframes?: Array<{
    timeRatio: number; // 0 to 1 of clip duration
    property: string;
    value: number;
    easing: AnimationEasing;
    bezier?: [number, number, number, number];
  }>;
}

export interface ReadyMadeTextStyleConfig {
  animation: TextAnimationEffect;
  effectSpeed: number;
  effectIntensity: number;
  effectDuration: number;
  effectDirection: TransitionDirection;
  animationStrength: number;
  fontWeight?: number;
  color?: string;
  strokeColor?: string;
  strokeWidth?: number;
  shadowBlur?: number;
  shadowColor?: string;
  extrude3D?: boolean;
  extrudeDepth?: number;
  letterSpacing?: number;
  gradientEnabled?: boolean;
  gradientStart?: string;
  gradientEnd?: string;
}

export interface ReadyMadeEffectPreset {
  id: string;
  name: string;
  category: ReadyMadeCategoryId;
  description: string;
  accentColor: string;
  defaultDuration?: number;
  isCustom?: boolean;
  createdAt?: number;
  effectsStack?: EffectInstance[];
  colorGrade?: Record<string, unknown>;
  textPreset?: ReadyMadeTextStyleConfig;
  transitionConfig?: TransitionSettings;
}

export type AnimationPlaybackMode = 'none' | 'loop' | 'pingpong' | 'reverse';
