import type * as THREE from 'three';
import type { Model3DBlueprint } from './studio';

export type LightingPreset4D =
  | 'realistic-studio'
  | 'crimson-cinema'
  | 'sunset-golden'
  | 'moonlight-noir'
  | 'neon-cyber';

export type CharacterMotionPreset =
  | 'none'
  | 'idle'
  | 'walk'
  | 'run'
  | 'jump'
  | 'dance'
  | 'wave';

export type ObjectAnimPreset =
  | 'none'
  | 'rotate-y'
  | 'orbit'
  | 'bounce'
  | 'pulse-scale'
  | 'hover';

export type ParticlePreset4D =
  | 'none'
  | 'crimson-sparks'
  | 'volumetric-smoke'
  | 'fire-embers'
  | 'cyber-rain'
  | 'stardust';

export type CameraAnimMode4D =
  | 'free'
  | 'cinematic-orbit'
  | 'dolly-zoom'
  | 'crane-sweep'
  | 'handheld-chase';

export type KeyframeProperty4D =
  | 'position.x'
  | 'position.y'
  | 'position.z'
  | 'rotation.x'
  | 'rotation.y'
  | 'rotation.z'
  | 'scale.x'
  | 'scale.y'
  | 'scale.z'
  | 'material.metalness'
  | 'material.roughness'
  | 'material.emissiveIntensity'
  | 'hyper4d.xw';

export interface Keyframe4D {
  id: string;
  objectUuid: string;
  objectName: string;
  property: KeyframeProperty4D;
  time: number;
  value: number;
  interpolation: 'linear' | 'smooth' | 'step';
}

export interface AnimationClipEntry4D {
  name: string;
  duration: number;
  weight: number;
  speed: number;
  playing: boolean;
  loop: boolean;
}

export interface PhysicsConfig4D {
  enabled: boolean;
  gravity: number;
  restitution: number;
  drag: number;
  windX: number;
  floorY: number;
}

export interface ParticleConfig4D {
  enabled: boolean;
  preset: ParticlePreset4D;
  count: number;
  speed: number;
  size: number;
  color: string;
  turbulence: number;
}

export interface FacialRigState {
  smile: number; // 0 to 1
  blink: number; // 0 to 1
  browRaise: number; // 0 to 1
  jawOpen: number; // 0 to 1
  surprise: number; // 0 to 1
}

export interface Hyper4DConfig {
  enabled: boolean;
  shape: 'tesseract' | '16-cell';
  wAngleXW: number;
  wAngleYW: number;
  wAngleZW: number;
  wSlice: number;
  spin4DSpeed: number;
  color: string;
}

export interface LightingConfig4D {
  preset: LightingPreset4D;
  keyIntensity: number;
  keyColor: string;
  fillIntensity: number;
  fillColor: string;
  rimIntensity: number;
  rimColor: string;
  ambientIntensity: number;
  envIntensity: number;
  shadowsEnabled: boolean;
  fogDensity: number;
}

export interface CameraConfig4D {
  mode: CameraAnimMode4D;
  fov: number;
  speed: number;
  autoAnimate: boolean;
  distance: number;
  elevation: number;
}

export interface SceneNodeInfo {
  uuid: string;
  name: string;
  type: string;
  depth: number;
  visible: boolean;
  hasGeometry: boolean;
  hasMaterial: boolean;
  isBone: boolean;
  isSkinnedMesh: boolean;
  isLight: boolean;
  isCamera: boolean;
  morphCount: number;
}

export interface Studio4DTransferPayload {
  id: string;
  name: string;
  sourceKind: 'blueprint' | 'imported-file' | 'procedural';
  format: 'glb' | 'gltf' | 'fbx' | 'obj' | 'procedural';
  blueprint?: Model3DBlueprint;
  object3D?: THREE.Object3D;
  animations?: THREE.AnimationClip[];
  cameras?: THREE.Camera[];
  lightingMode?: LightingPreset4D;
  cameraPose?: {
    position: [number, number, number];
    target: [number, number, number];
    fov: number;
  };
}
