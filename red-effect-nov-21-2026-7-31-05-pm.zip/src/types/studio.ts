import type {
  AdvancedTransitionType,
  AnimatedMaskKeyframe,
  AnimationEasing,
  AnimationPlaybackMode,
  BezierPoint,
  EffectInstance,
  MaskMode,
  ShapeProperties,
  TextAnimationEffect,
  TextGranularity,
  TextPathMode,
  TransitionSettings,
} from './effects';

export type MediaType = 'video' | 'image' | 'audio' | 'model3d';

export type WorkspaceMode = 'editing' | 'motion' | '3d' | '4d' | 'audio';

export type PanelId =
  | 'project'
  | 'media'
  | 'monitor'
  | 'timeline'
  | 'effects'
  | 'transitions'
  | 'textStudio'
  | 'shapes'
  | 'presets'
  | 'properties'
  | 'colorControls'
  | 'mixer'
  | 'layers'
  | 'keyframes'
  | 'nullHierarchy'
  | 'templates';

export type BlendMode = 'normal' | 'screen' | 'multiply' | 'overlay' | 'add';

export type TransitionType = AdvancedTransitionType;

export type ParticlePreset = 'none' | 'red-smoke' | 'fire-embers' | 'neon-sparks' | 'rain' | 'snow';

export type MaskShape =
  | 'none'
  | 'circle'
  | 'rectangle'
  | 'ellipse'
  | 'polygon'
  | 'star'
  | 'custom-path'
  | 'radial-vignette';

export type ProxyQuality = 'full' | 'half' | 'quarter' | 'eighth';

export type PreviewQuality = 'ultra' | 'high' | 'medium' | 'low' | 'performance';

export type EnhancementProcessingQuality = 'fast' | 'balanced' | 'high';
export type UpscaleResolutionTarget = 'original' | '720p' | '1080p' | '2k' | '4k';
export type SmoothVideoFpsTarget = 'original' | 30 | 50 | 60 | 120 | 240;

export interface QualityEnhancerSettings {
  enabled: boolean;
  processingQuality: EnhancementProcessingQuality;
  intensity: number; // 0 to 100
  targetResolution: UpscaleResolutionTarget;
  // Shared / Image + Video enhancement controls (0 to 100 each when enabled)
  upscaling: boolean;
  sharpening: number; // 0 to 100
  detailRecovery: number; // 0 to 100
  noiseReduction: number; // 0 to 100
  deblurring: number; // 0 to 100
  // Image-specific
  textureEnhancement: number; // 0 to 100
  faceDetailEnhancement: number; // 0 to 100
  colorEnhancement: number; // 0 to 100
  // Video-specific
  colorCorrection: number; // 0 to 100
  lowLightEnhancement: number; // 0 to 100
  compressionArtifactReduction: number; // 0 to 100
}

export interface SmoothVideoSettings {
  enabled: boolean;
  targetFps: SmoothVideoFpsTarget;
  processingQuality: EnhancementProcessingQuality;
  slowMotionSpeed: 1 | 0.75 | 0.5 | 0.25 | 0.1; // 1 = preserve duration
  motionBlurReduction: number; // 0 to 100
  artifactSuppression: number; // 0 to 100 (occlusion/residual check strictness)
  preRenderedCount?: number;
}

export interface MediaAsset {
  id: string;
  name: string;
  type: MediaType;
  mimeType: string;
  url: string;
  originalUrl?: string;
  duration: number; // seconds (default 5 for images/3D)
  width?: number;
  height?: number;
  sourceFps?: number;
  sizeBytes?: number;
  folder: string;
  createdAt: number;
  thumbnailUrl?: string;
  modelBlueprint?: Model3DBlueprint;
  rawModelText?: string; // OBJ/GLB text or data URL if imported/exported
  waveformPeaks?: number[];
  hasAudio?: boolean;
  isStarter?: boolean;
}

export type KeyframeProperty =
  | 'x'
  | 'y'
  | 'z'
  | 'scale'
  | 'scaleX'
  | 'scaleY'
  | 'scaleZ'
  | 'rotation'
  | 'rotX'
  | 'rotY'
  | 'rotZ'
  | 'opacity'
  | 'anchorX'
  | 'anchorY'
  | 'blur'
  | 'glow'
  | 'glowRadius'
  | 'effectIntensity'
  | 'distortion'
  | 'shadow'
  | 'colorTemp'
  | 'fontSize'
  | 'textTracking'
  | 'maskRadius'
  | 'maskFeather'
  | 'maskExpansion'
  | 'maskOpacity'
  | 'cameraZoom'
  | `effect:${string}`;

export interface Keyframe {
  id: string;
  time: number; // seconds relative to clip start
  property: KeyframeProperty;
  value: number;
  easing: AnimationEasing;
  bezier?: [number, number, number, number]; // [x1, y1, x2, y2]
}

export interface ClipTransform {
  x: number; // -100 to 100 (% of canvas)
  y: number; // -100 to 100 (% of canvas)
  scale: number; // 0.1 to 4.0
  scaleX?: number; // 0.1 to 4.0 multiplier
  scaleY?: number; // 0.1 to 4.0 multiplier
  scaleZ?: number; // 0.1 to 4.0 multiplier
  rotation: number; // degrees (Z)
  opacity: number; // 0 to 1
  anchorX: number; // 0 to 1
  anchorY: number; // 0 to 1
  zDepth: number; // for 3D layers
  rotX: number;
  rotY: number;
}

export interface ColorGrade {
  preset:
    | 'none'
    | 'cinematic-teal-orange'
    | 'crimson-noir'
    | 'golden-hour'
    | 'vintage-35mm'
    | 'monochrome'
    | 'cinematic-cc'
    | 'dark-cc'
    | 'moody-cc'
    | 'blue-cinematic'
    | 'warm-film'
    | 'cold-film'
    | 'anime-cc'
    | 'hdr-look'
    | 'high-contrast'
    | 'dark-fantasy'
    | 'film-pro';
  exposure: number; // -100 to 100
  contrast: number; // -100 to 100
  saturation: number; // -100 to 100
  temperature: number; // -100 to 100
  tint: number; // -100 to 100
  vignette: number; // 0 to 100
  highlights: number; // -100 to 100
  shadows: number; // -100 to 100
  whites?: number; // -100 to 100
  blacks?: number; // -100 to 100
  vibrance?: number; // -100 to 100
  rgbCurves?: {
    master: number;
    red: number;
    green: number;
    blue: number;
  };
  colorBalance?: {
    shadowsRed: number;
    shadowsGreen: number;
    shadowsBlue: number;
    highlightsRed: number;
    highlightsGreen: number;
    highlightsBlue: number;
  };
  lutName?: string;
  lutStrength?: number; // 0 to 100
  lutIntensity?: number; // 0 to 100
}

export interface ChromaKeySettings {
  enabled: boolean;
  color: string; // hex e.g. #00ff00
  tolerance: number; // 0 to 100
  softness: number; // 0 to 100
  spillSuppression: number; // 0 to 100
}

export interface MaskSettings {
  shape: MaskShape;
  mode?: MaskMode;
  centerX: number; // 0 to 1
  centerY: number; // 0 to 1
  radiusX: number; // 0.05 to 1
  radiusY: number; // 0.05 to 1
  feather: number; // 0 to 100
  expansion?: number; // -50 to 50
  opacity?: number; // 0 to 100
  points?: number; // sides/points for polygon/star
  inverted: boolean;
  pathPoints?: BezierPoint[];
  animatedPaths?: AnimatedMaskKeyframe[];
}

export interface TextProperties {
  text: string;
  fontFamily: string;
  fontSize: number;
  fontWeight?: number; // 400..900
  letterSpacing?: number; // -10..40 px
  lineHeight?: number; // 0.8..2.5 multiplier
  color: string;
  strokeColor: string;
  strokeWidth: number;
  outlineColor?: string;
  outlineWidth?: number;
  shadowColor?: string;
  shadowBlur?: number;
  shadowOffsetX?: number;
  shadowOffsetY?: number;
  gradientEnabled?: boolean;
  gradientStart?: string;
  gradientEnd?: string;
  gradientAngle?: number;
  animatedGradient?: boolean;
  extrude3D?: boolean;
  extrudeDepth?: number;
  granularity?: TextGranularity;
  pathMode?: TextPathMode;
  pathCurvature?: number; // -100 to 100
  revealProgress?: number; // 0 to 100
  backgroundColor: string;
  animation: TextAnimationEffect;
  effectSpeed?: number; // 0.2 to 3.0
  effectIntensity?: number; // 0 to 200
  effectDuration?: number; // 0.2 to 5.0 seconds
  effectDirection?: 'left' | 'right' | 'up' | 'down' | 'center';
  animationStrength?: number; // 0 to 200
  isSubtitle: boolean;
  align: 'left' | 'center' | 'right';
}

export interface ClipEffects {
  blur: number; // 0 to 40
  glow: number; // 0 to 100
  glowColor: string;
  stabilization: number; // 0 to 100
  filmGrain: number; // 0 to 100
  chromaticAberration: number; // 0 to 50
  particles: ParticlePreset;
  particleIntensity: number; // 0 to 100
}

export interface MotionTrackData {
  enabled: boolean;
  targetX: number; // 0 to 1
  targetY: number; // 0 to 1
  amplitudeX: number;
  amplitudeY: number;
  frequency: number;
}

export interface TimelineClip {
  id: string;
  assetId: string;
  trackId: string;
  name: string;
  type: MediaType | 'text' | 'fx' | 'null' | 'shape';
  startTime: number; // seconds on timeline
  duration: number; // seconds on timeline
  sourceOffset: number; // trim start inside source media
  speed: number; // 0.25 to 4
  reverse: boolean;
  volume: number; // 0 to 2 (1 = 0dB)
  fadeIn: number; // seconds
  fadeOut: number; // seconds
  muted: boolean;
  visible: boolean;
  locked: boolean;
  blendMode: BlendMode;
  is3DLayer: boolean;
  parentClipId?: string;
  labelColor?: MarkerColor;
  disabled?: boolean;
  fxMeta?: {
    presetId: string;
    presetName: string;
    category: 'text' | 'shake' | 'glitch' | 'cc' | 'blur' | 'rgb' | 'distortion' | 'cinematic' | 'transition';
    targetClipId?: string;
  };
  transitionIn: TransitionType;
  transitionInDuration: number;
  transitionInConfig?: TransitionSettings;
  transitionOut: TransitionType;
  transitionOutDuration: number;
  transitionOutConfig?: TransitionSettings;
  transform: ClipTransform;
  keyframes: Keyframe[];
  animationLoopMode?: AnimationPlaybackMode;
  animationSpeed?: number;
  colorGrade: ColorGrade;
  chromaKey: ChromaKeySettings;
  mask: MaskSettings;
  effects: ClipEffects;
  effectsStack?: EffectInstance[];
  textProps?: TextProperties;
  shapeProps?: ShapeProperties;
  motionTrack: MotionTrackData;
  modelBlueprint?: Model3DBlueprint;
  groupId?: string;
  qualityEnhancer?: QualityEnhancerSettings;
  smoothVideo?: SmoothVideoSettings;
}

export type PreviewCanvasTool = 'select' | 'hand' | 'text' | 'shape' | 'pen' | 'zoom';

export interface ClipGroup {
  id: string;
  name: string;
  clipIds: string[];
}

export interface TimelineTrack {
  id: string;
  name: string;
  kind: 'video' | 'image' | 'text' | 'shape' | 'null' | 'fx' | 'audio';
  muted: boolean;
  solo: boolean;
  locked: boolean;
  visible: boolean;
  volume: number; // 0 to 1.5
  pan: number; // -1 to 1
  color?: MarkerColor;
  collapsed?: boolean;
}

export interface Camera3DSettings {
  fov: number; // 20 to 100
  orbitX: number; // degrees
  orbitY: number; // degrees
  zoom: number; // 0.5 to 3
  dofBlur: number; // 0 to 20
}

export interface Model3DPart {
  name: string;
  geometry:
    | 'box'
    | 'sphere'
    | 'cylinder'
    | 'cone'
    | 'torus'
    | 'icosahedron'
    | 'capsule'
    | 'extrude_bevel'
    | 'lathe'
    | 'tube';
  position: [number, number, number];
  rotation: [number, number, number]; // radians
  scale: [number, number, number];
  dimensions?: number[]; // e.g. [width, height, depth] or [radius, height, radialSegments]
  profilePoints?: [number, number][]; // for lathe / extrude / tube
  color: string;
  roughness: number; // 0 to 1
  metalness: number; // 0 to 1
  emissive?: string;
  emissiveIntensity?: number;
  clearcoat?: number;
  texturePattern?: 'none' | 'brushed-metal' | 'carbon-weave' | 'scales' | 'stone' | 'wood' | 'grid';
}

export interface Model3DBlueprint {
  title: string;
  category: string;
  description: string;
  environmentLighting: 'studio' | 'crimson-rim' | 'sunset' | 'moonlight';
  autoRotateSpeed: number;
  parts: Model3DPart[];
}

export type MarkerColor = 'rose' | 'amber' | 'emerald' | 'sky' | 'violet';

export interface TimelineMarker {
  id: string;
  time: number; // seconds (synced to timestampMs / 1000)
  timestampMs?: number; // exact integer milliseconds on timeline
  trackId?: string; // per-audio-track isolation (supports multiple audio tracks)
  clipId?: string; // originating audio clip ID
  kind?: 'beat' | 'cue';
  source?: 'manual' | 'auto';
  strength?: number; // 0..1 detected transient energy
  label: string;
  notes?: string;
  color: MarkerColor;
}

export type AspectRatioPreset = '16:9' | '9:16' | '1:1' | '4:5' | '21:9' | 'custom';
export type VideoFormatPreset = 'mp4' | 'mov' | 'webm';
export type AudioSampleRatePreset = 44100 | 48000 | 96000;

export interface NewProjectConfig {
  name: string;
  location: string;
  width: number;
  height: number;
  fps: 24 | 25 | 30 | 50 | 60 | 120;
  aspectRatio: AspectRatioPreset;
  videoFormat: VideoFormatPreset;
  audioSampleRate: AudioSampleRatePreset;
  backgroundColor: string;
  videoTrackCount: number;
  audioTrackCount: number;
  snapEnabled: boolean;
  defaultClipDuration: number;
}

export interface StudioProject {
  id: string;
  name: string;
  location?: string;
  width: number;
  height: number;
  fps: number;
  aspectRatio?: AspectRatioPreset;
  videoFormat?: VideoFormatPreset;
  audioSampleRate?: AudioSampleRatePreset;
  backgroundColor?: string;
  defaultClipDuration?: number;
  createdAt: number;
  updatedAt: number;
  tracks: TimelineTrack[];
  clips: TimelineClip[];
  groups?: ClipGroup[];
  markers: TimelineMarker[];
  assets: MediaAsset[];
  folders: string[];
  camera3D: Camera3DSettings;
  snapEnabled: boolean;
  proxyQuality: ProxyQuality;
  previewQuality?: PreviewQuality;
}

export interface ShortcutMap {
  newProject: string;
  openProject: string;
  saveProject: string;
  saveAs: string;
  importMedia: string;
  undo: string;
  redo: string;
  playPause: string;
  cutTool: string;
  selectTool: string;
  textTool: string;
  keyPosition: string;
  keyScale: string;
  keyRotation: string;
  keyAnchor: string;
  keyOpacity: string;
  showAnimated: string;
  easyEase: string;
  duplicateClip: string;
  deleteClip: string;
  renameClip: string;
  exportVideo: string;
  copyClip: string;
  pasteClip: string;
  selectAll: string;
  addMarker: string;
}

export interface SlotConfig {
  leftTop: PanelId;
  leftBottom: PanelId;
  center: PanelId;
  right: PanelId;
  bottom: PanelId;
}

export interface FloatingPanelWindow {
  panelId: PanelId;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
}

export type WorkspaceLayoutPresetId =
  | 'default'
  | 'editing-workspace'
  | 'effects-workspace'
  | 'motion-workspace'
  | 'color-workspace'
  | 'audio-workspace'
  | 'beginner-workspace'
  | 'video-editing'
  | 'motion-graphics'
  | 'animation'
  | 'audio-editing'
  | '3d-editing'
  | string;

export interface WorkspaceLayoutSnapshot {
  presetId: WorkspaceLayoutPresetId;
  workspaceMode: WorkspaceMode;
  slots: SlotConfig;
  leftWidth: number;
  rightWidth: number;
  bottomHeight: number;
  leftCollapsed: boolean;
  rightCollapsed: boolean;
  bottomCollapsed: boolean;
  closedPanels: PanelId[];
  collapsedPanels: PanelId[];
  floatingPanels: FloatingPanelWindow[];
}

export interface SavedWorkspacePreset extends WorkspaceLayoutSnapshot {
  id: string;
  name: string;
  isBuiltIn?: boolean;
}

export type UiSurfaceMode = 'gray' | 'white' | 'dark' | 'slate' | 'midnight' | 'warm';

export type UiAccentPresetId =
  | 'gray'
  | 'white'
  | 'red'
  | 'crimson'
  | 'rose'
  | 'pink'
  | 'purple'
  | 'violet'
  | 'indigo'
  | 'blue'
  | 'sky'
  | 'cyan'
  | 'teal'
  | 'emerald'
  | 'green'
  | 'lime'
  | 'yellow'
  | 'amber'
  | 'orange'
  | 'custom';

export interface UiThemeSettings {
  surface: UiSurfaceMode;
  accentPreset: UiAccentPresetId;
  customAccentHex: string;
  uiScale?: 'compact' | 'normal' | 'comfortable';
  borderRadius?: 'sharp' | 'rounded' | 'pill';
}

export interface StudioSettings {
  autoSaveIntervalSec: number;
  proxyQuality: ProxyQuality;
  previewQuality?: PreviewQuality;
  performanceMode?: boolean;
  autoDownscalePreview?: boolean;
  hoverPreviewEnabled?: boolean;
  hardwareAcceleration: boolean;
  defaultFps: 24 | 25 | 30 | 50 | 60 | 120;
  defaultResolution: '720p' | '1080p' | '2k' | '1440p' | '4k';
  audioOutputDeviceId: string;
  shortcuts: ShortcutMap;
  uiTheme?: UiThemeSettings;
}

export interface ExportSettings {
  format: 'mp4' | 'mov' | 'webm' | 'png' | 'jpg' | 'wav' | 'mp3' | 'glb' | 'obj';
  codec?: 'auto' | 'h264' | 'h265' | 'vp9';
  resolution: 'project' | '720p' | '1080p' | '2k' | '1440p' | '4k' | '8k';
  fps: 24 | 25 | 30 | 50 | 60 | 120 | 240;
  bitrateMbps: number;
  fileName: string;
  audioEnabled: boolean;
  audioQuality: '128' | '192' | '256' | '320';
}
