import React, { useMemo, useRef, useState } from 'react';
import { Sparkles, Save, Download, Upload, Trash2, CheckCircle2 } from 'lucide-react';
import { PresetCategory, StudioPreset } from '../types/effects';
import { TimelineClip } from '../types/studio';
import { BUILT_IN_PRESETS } from '../services/effectsCatalog';

interface PresetLibraryPanelProps {
  selectedClip: TimelineClip | null;
  selectedClipIds: string[];
  customPresets: StudioPreset[];
  onSaveCustomPreset: (preset: StudioPreset) => void;
  onDeleteCustomPreset: (id: string) => void;
  onApplyPresetToClips: (preset: StudioPreset, clipIds: string[]) => void;
}

const CATEGORIES: Array<PresetCategory | 'All'> = [
  'All',
  'Trending',
  'Cinematic',
  'Velocity',
  'Anime',
  'Typography',
  'Glitch',
  '3D',
  'Social Media',
];

export const PresetLibraryPanel: React.FC<PresetLibraryPanelProps> = ({
  selectedClip,
  selectedClipIds,
  customPresets,
  onSaveCustomPreset,
  onDeleteCustomPreset,
  onApplyPresetToClips,
}) => {
  const [activeCat, setActiveCat] = useState<PresetCategory | 'All'>('All');
  const [newName, setNewName] = useState('');
  const [newCat, setNewCat] = useState<PresetCategory>('Cinematic');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const allPresets = useMemo(
    () => [...customPresets, ...BUILT_IN_PRESETS],
    [customPresets]
  );

  const visible = useMemo(
    () =>
      allPresets.filter((p) => (activeCat === 'All' ? true : p.category === activeCat)),
    [allPresets, activeCat]
  );

  const targetIds = selectedClipIds.length > 0 ? selectedClipIds : selectedClip ? [selectedClip.id] : [];

  const handleSaveFromClip = () => {
    if (!selectedClip) return;
    const name = newName.trim() || `${selectedClip.name} Preset`;
    const preset: StudioPreset = {
      id: `preset-${Date.now()}`,
      name,
      category: newCat,
      kind: selectedClip.type === 'text' ? 'text-style' : 'effects-stack',
      description: `Custom stack (${selectedClip.effectsStack?.length || 0} FX, ${selectedClip.keyframes.length} keyframes)`,
      createdAt: Date.now(),
      effectsStack: selectedClip.effectsStack ? structuredClone(selectedClip.effectsStack) : [],
      transitionIn: selectedClip.transitionInConfig
        ? structuredClone(selectedClip.transitionInConfig)
        : undefined,
      transitionOut: selectedClip.transitionOutConfig
        ? structuredClone(selectedClip.transitionOutConfig)
        : undefined,
      textStyle: selectedClip.textProps ? { ...selectedClip.textProps } : undefined,
      keyframes:
        selectedClip.keyframes.length > 0
          ? selectedClip.keyframes.map((k) => ({
              timeRatio: k.time / Math.max(0.1, selectedClip.duration),
              property: k.property,
              value: k.value,
              easing: k.easing,
              bezier: k.bezier,
            }))
          : undefined,
    };
    onSaveCustomPreset(preset);
    setNewName('');
  };

  const handleExportPresets = () => {
    const blob = new Blob([JSON.stringify(customPresets, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'RED_EFFECT_Presets.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportPresets = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const list: StudioPreset[] = Array.isArray(parsed) ? parsed : [parsed];
      list.forEach((p) => {
        if (p && p.name) {
          onSaveCustomPreset({
            ...p,
            id: `preset-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            isBuiltIn: false,
            createdAt: Date.now(),
          });
        }
      });
    } catch {
      // ignore invalid preset file
    }
    e.target.value = '';
  };

  return (
    <div className="p-3 flex flex-col gap-2.5 h-full text-xs bg-[#222225] text-[#F4F4F5]">
      {/* Save Custom Preset Bar */}
      <div className="p-2 bg-[#18181A] border border-[#3E3E44] rounded space-y-1.5">
        <div className="flex items-center justify-between text-[10px] text-[#A1A1AA]">
          <span>Save Selected Clip as Preset</span>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Import Presets JSON"
              className="p-1 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <Upload className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={handleExportPresets}
              disabled={customPresets.length === 0}
              title="Export Custom Presets JSON"
              className="p-1 bg-[#2C2C30] hover:bg-[#2E323E] disabled:opacity-40 border border-[#3E3E44] rounded text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <Download className="w-3 h-3" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleImportPresets}
              className="hidden"
            />
          </div>
        </div>
        <div className="flex gap-1">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Preset name..."
            className="flex-1 px-2 py-1 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#F4F4F5] placeholder:text-[#A1A1AA] text-[11px] focus:outline-none focus:border-[#A1A1AA]"
          />
          <select
            value={newCat}
            onChange={(e) => setNewCat(e.target.value as PresetCategory)}
            className="px-1.5 py-1 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#F4F4F5] text-[10px] focus:outline-none focus:border-[#A1A1AA]"
          >
            {CATEGORIES.filter((c) => c !== 'All').map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <button
            type="button"
            disabled={!selectedClip}
            onClick={handleSaveFromClip}
            className="px-2 py-1 bg-[#52525B] hover:bg-[#6B7280] disabled:opacity-40 text-white rounded flex items-center gap-1 text-[10px] font-medium shrink-0"
          >
            <Save className="w-3 h-3" />
            Save
          </button>
        </div>
      </div>

      {/* Category Chips */}
      <div className="flex flex-wrap gap-1">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setActiveCat(cat)}
            className={`px-2 py-1 rounded text-[10px] font-medium ${
              activeCat === cat
                ? 'bg-[#52525B] text-white'
                : 'bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5] border border-[#3E3E44]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Preset List */}
      <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5">
        {visible.map((preset) => (
          <div
            key={preset.id}
            className="p-2 bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded space-y-1.5"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[#F4F4F5] font-medium truncate flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-[#D4D4D8] shrink-0" />
                  {preset.name}
                </div>
                <div className="text-[10px] text-[#A1A1AA] truncate">{preset.description}</div>
              </div>
              <span className="text-[9px] px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#A1A1AA] shrink-0">
                {preset.category}
              </span>
            </div>

            <div className="flex items-center justify-between gap-1.5">
              <button
                type="button"
                disabled={targetIds.length === 0}
                onClick={() => onApplyPresetToClips(preset, targetIds)}
                className="flex-1 py-1 bg-[#52525B] hover:bg-[#6B7280] disabled:opacity-40 text-white rounded text-[10px] font-medium flex items-center justify-center gap-1"
              >
                <CheckCircle2 className="w-3 h-3" />
                {targetIds.length > 1
                  ? `Apply to ${targetIds.length} Layers`
                  : targetIds.length === 1
                  ? 'Apply to Layer'
                  : 'Select Layer'}
              </button>
              {!preset.isBuiltIn && (
                <button
                  type="button"
                  onClick={() => onDeleteCustomPreset(preset.id)}
                  className="p-1 bg-[#18181A] border border-[#3E3E44] hover:border-rose-500 rounded text-[#A1A1AA] hover:text-rose-400"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
