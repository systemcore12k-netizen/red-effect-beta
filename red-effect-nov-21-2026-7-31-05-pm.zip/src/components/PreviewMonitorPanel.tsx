import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  ChevronLeft,
  ChevronRight,
  Repeat,
  Crosshair,
  Grid,
  Camera,
  Volume2,
  VolumeX,
  PenTool,
  MousePointer2,
  Hand,
  Type as TypeIcon,
  Square,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Magnet,
  Diamond,
  Group,
  Ungroup,
  AlignLeft,
  AlignCenterHorizontal,
  AlignRight,
  AlignStartVertical,
  AlignCenterVertical,
  AlignEndVertical,
  Lock,
  Maximize,
  Minimize,
  SplitSquareHorizontal,
  Scissors,
  Trash2,
  Copy,
  ClipboardPaste,
  Gauge,
  Sliders,
  Sparkles,
  Eye,
  EyeOff,
  Loader2,
} from 'lucide-react';
import { BezierPoint, ReadyMadeEffectPreset, ShapeKind } from '../types/effects';
import {
  Keyframe,
  KeyframeProperty,
  PreviewCanvasTool,
  PreviewQuality,
  ProxyQuality,
  StudioProject,
  TimelineClip,
  WorkspaceMode,
} from '../types/studio';
import {
  ClipCanvasBounds,
  computeVisibleClipBounds,
  createMediaCache,
  evaluateKeyframeProperty,
  getClipAnimationEvalTime,
  hitTestClipBounds,
  invertMatrix2D,
  renderCompositeFrame,
  resolveHoverTargetClip,
} from '../services/videoCompositor';
import { resolveRenderPolicy } from '../services/performanceEngine';
import { hoverPreviewCache, isHoverPresetAnimated } from '../services/hoverPreviewCache';

function clipBoundsEqual(a: ClipCanvasBounds[], b: ClipCanvasBounds[]): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    const ba = a[i];
    const bb = b[i];
    if (
      ba.clip.id !== bb.clip.id ||
      Math.abs(ba.pivotX - bb.pivotX) > 0.05 ||
      Math.abs(ba.pivotY - bb.pivotY) > 0.05 ||
      ba.corners.length !== bb.corners.length
    ) {
      return false;
    }
    for (let j = 0; j < ba.corners.length; j++) {
      if (
        Math.abs(ba.corners[j].x - bb.corners[j].x) > 0.05 ||
        Math.abs(ba.corners[j].y - bb.corners[j].y) > 0.05
      ) {
        return false;
      }
    }
  }
  return true;
}

interface PreviewMonitorPanelProps {
  project: StudioProject;
  playheadTime: number;
  totalDuration: number;
  isPlaying: boolean;
  loopEnabled: boolean;
  masterVolume: number;
  masterMuted: boolean;
  workspaceMode: WorkspaceMode;
  selectedClip: TimelineClip | null;
  selectedClipIds?: string[];
  hoverPreviewPreset?: ReadyMadeEffectPreset | null;
  hoverPreviewPending?: boolean;
  penToolActive?: boolean;
  autoKeyframeEnabled?: boolean;
  onToggleAutoKeyframe?: () => void;
  onTogglePenTool?: () => void;
  onSelectClip?: (clipId: string | null, additive?: boolean) => void;
  onUpdateClip?: (
    clipId: string,
    updater: (c: TimelineClip) => TimelineClip,
    commitHistory?: boolean
  ) => void;
  onBatchUpdateClips?: (
    updates: Record<string, (c: TimelineClip) => TimelineClip>,
    commitHistory?: boolean
  ) => void;
  onBeginDragHistory?: () => void;
  onEndDragHistory?: () => void;
  onAddTextAtPosition?: (xPct: number, yPct: number) => void;
  onAddShapeClip?: (shape: ShapeKind) => void;
  onGroupSelected?: () => void;
  onUngroupSelected?: () => void;
  onToggleSnap?: () => void;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onToggleLoop: () => void;
  onToggleMasterMute: () => void;
  onSetMasterVolume: (vol: number) => void;
  onChangeProxy: (q: ProxyQuality) => void;
  previewQuality?: PreviewQuality;
  performanceMode?: boolean;
  autoDownscalePreview?: boolean;
  onChangePreviewQuality?: (q: PreviewQuality) => void;
  onUpdateMotionTrackTarget: (clipId: string, x: number, y: number) => void;
  onCaptureFramePNG: () => void;
  hasCopiedAttributes?: boolean;
  onSplitClip?: (clipId: string) => void;
  onDeleteClip?: (clipId: string) => void;
  onDuplicateClip?: (clipId: string) => void;
  onOpenSpeedDuration?: (clipId: string) => void;
  onFocusInspectorTab?: (
    clipId: string,
    tab: 'effects' | 'transform' | 'video' | 'color' | 'audio' | 'text'
  ) => void;
  onAddKeyframeAtPlayhead?: (clipId: string) => void;
  onCopyAttributes?: (clipId: string) => void;
  onPasteAttributes?: (clipId: string) => void;
}

export function formatTimecode(seconds: number, fps: number): string {
  const safe = Math.max(0, seconds);
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = Math.floor(safe % 60);
  const frames = Math.floor((safe % 1) * fps);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(hrs)}:${pad(mins)}:${pad(secs)}:${pad(frames)}`;
}

type DragOperation =
  | {
      kind: 'pan';
      startClientX: number;
      startClientY: number;
      startPanX: number;
      startPanY: number;
    }
  | {
      kind: 'move';
      startPxX: number;
      startPxY: number;
      primaryId: string;
      initialPositions: Record<string, { x: number; y: number }>;
      primaryInitialBounds: ClipCanvasBounds;
    }
  | {
      kind: 'resize';
      handle: 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w';
      clipId: string;
      startPxX: number;
      startPxY: number;
      initialBounds: ClipCanvasBounds;
      initialTransform: TimelineClip['transform'];
    }
  | {
      kind: 'rotate';
      clipId: string;
      pivotX: number;
      pivotY: number;
      startAngleRad: number;
      initialRotation: number;
    }
  | {
      kind: 'anchor';
      clipId: string;
      initialAnchorX: number;
      initialAnchorY: number;
      startPxX: number;
      startPxY: number;
    };

function upsertKeyframesForProps(
  clip: TimelineClip,
  playheadTime: number,
  entries: Array<{ property: KeyframeProperty; value: number }>
): Keyframe[] {
  const localTime = Math.max(0, Math.min(clip.duration, Math.round((playheadTime - clip.startTime) * 100) / 100));
  let next = [...clip.keyframes];
  for (const { property, value } of entries) {
    const idx = next.findIndex(
      (k) => k.property === property && Math.abs(k.time - localTime) < 0.08
    );
    const rounded = Math.round(value * 1000) / 1000;
    if (idx >= 0) {
      next[idx] = { ...next[idx], value: rounded };
    } else {
      next.push({
        id: `kf-${Date.now()}-${property}-${Math.random().toString(36).slice(2, 6)}`,
        time: localTime,
        property,
        value: rounded,
        easing: 'easeInOut',
        bezier: [0.42, 0, 0.58, 1],
      });
    }
  }
  return next.sort((a, b) => a.time - b.time);
}

export const PreviewMonitorPanel: React.FC<PreviewMonitorPanelProps> = ({
  project,
  playheadTime,
  totalDuration,
  isPlaying,
  loopEnabled,
  masterVolume,
  masterMuted,
  workspaceMode,
  selectedClip,
  selectedClipIds = [],
  hoverPreviewPreset = null,
  hoverPreviewPending = false,
  penToolActive = false,
  autoKeyframeEnabled = false,
  onToggleAutoKeyframe,
  onTogglePenTool,
  onSelectClip,
  onUpdateClip,
  onBatchUpdateClips,
  onBeginDragHistory,
  onEndDragHistory,
  onAddTextAtPosition,
  onAddShapeClip,
  onGroupSelected,
  onUngroupSelected,
  onToggleSnap,
  onTogglePlay,
  onSeek,
  onToggleLoop,
  onToggleMasterMute,
  onSetMasterVolume,
  onChangeProxy,
  previewQuality = 'high',
  performanceMode = false,
  autoDownscalePreview = true,
  onChangePreviewQuality,
  onUpdateMotionTrackTarget,
  onCaptureFramePNG,
  hasCopiedAttributes = false,
  onSplitClip,
  onDeleteClip,
  onDuplicateClip,
  onOpenSpeedDuration,
  onFocusInspectorTab,
  onAddKeyframeAtPlayhead,
  onCopyAttributes,
  onPasteAttributes,
}) => {
  const monitorRootRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rawCanvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const cacheRef = useRef(createMediaCache());

  const [showSafeMargins, setShowSafeMargins] = useState(false);
  const [beforeAfterEnabled, setBeforeAfterEnabled] = useState(false);
  const [compareSplitPct, setCompareSplitPct] = useState(50);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [draggingVertexIdx, setDraggingVertexIdx] = useState<number | null>(null);

  // Canvas Direct Manipulation Tool & Viewport State
  const [canvasTool, setCanvasTool] = useState<PreviewCanvasTool>('select');
  const [canvasZoom, setCanvasZoom] = useState(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [shapeMenuOpen, setShapeMenuOpen] = useState(false);
  const [snapGuides, setSnapGuides] = useState<Array<{ axis: 'x' | 'y'; canvasPos: number }>>([]);
  const [rotationReadout, setRotationReadout] = useState<{
    x: number;
    y: number;
    deg: number;
  } | null>(null);
  const [visibleBounds, setVisibleBounds] = useState<ClipCanvasBounds[]>([]);
  const [inlineTextEdit, setInlineTextEdit] = useState<{
    clipId: string;
    value: string;
    leftPct: number;
    topPct: number;
  } | null>(null);

  const dragOpRef = useRef<DragOperation | null>(null);
  const didMutateDuringDragRef = useRef(false);
  const [isInteracting, setIsInteracting] = useState(false);
  const scrubIdleTimerRef = useRef<number | null>(null);
  const [fpsDropFactor, setFpsDropFactor] = useState(0);
  const [measuredFps, setMeasuredFps] = useState<number | null>(null);
  const fpsAccumRef = useRef({ frames: 0, totalMs: 0, lastReport: 0 });

  const markInteractingPulse = () => {
    setIsInteracting(true);
    if (scrubIdleTimerRef.current !== null) {
      window.clearTimeout(scrubIdleTimerRef.current);
    }
    scrubIdleTimerRef.current = window.setTimeout(() => {
      setIsInteracting(false);
      scrubIdleTimerRef.current = null;
    }, 140);
  };

  useEffect(() => {
    return () => {
      if (scrubIdleTimerRef.current !== null) {
        window.clearTimeout(scrubIdleTimerRef.current);
      }
    };
  }, []);

  const [hoverBypassOriginal, setHoverBypassOriginal] = useState(false);
  const [isHoverRendering, setIsHoverRendering] = useState(false);
  const hoverJobIdRef = useRef(0);
  const hoverClockRef = useRef(0);

  // Reset Preview Original bypass when user leaves the hovered effect
  useEffect(() => {
    if (!hoverPreviewPreset) {
      setHoverBypassOriginal(false);
      setIsHoverRendering(false);
    }
  }, [hoverPreviewPreset]);

  const effectiveTool: PreviewCanvasTool = penToolActive ? 'pen' : canvasTool;
  const effectivePreviewQuality: PreviewQuality = performanceMode
    ? 'performance'
    : project.previewQuality || previewQuality || 'high';

  const isHoverActive = Boolean(hoverPreviewPreset) && !isPlaying;

  const activePolicy = useMemo(
    () =>
      resolveRenderPolicy({
        isExport: false,
        previewQuality: effectivePreviewQuality,
        proxyQuality: project.proxyQuality,
        isInteracting,
        isHoverPreview: isHoverActive && !hoverBypassOriginal,
        fpsDropFactor: autoDownscalePreview ? fpsDropFactor : 0,
      }),
    [
      effectivePreviewQuality,
      project.proxyQuality,
      isInteracting,
      isHoverActive,
      hoverBypassOriginal,
      autoDownscalePreview,
      fpsDropFactor,
    ]
  );

  const renderW = Math.max(240, Math.round(project.width * activePolicy.resolutionScale));
  const renderH = Math.max(135, Math.round(project.height * activePolicy.resolutionScale));

  const hoverTargetInfo = useMemo(
    () =>
      resolveHoverTargetClip(project, playheadTime, selectedClip?.id, hoverPreviewPreset),
    [project, playheadTime, selectedClip?.id, hoverPreviewPreset]
  );

  const [hoverTick, setHoverTick] = useState(0);

  useEffect(() => {
    if (!hoverPreviewPreset || isPlaying || hoverBypassOriginal) return;
    if (!isHoverPresetAnimated(hoverPreviewPreset)) return;
    const frameIntervalMs =
      effectivePreviewQuality === 'performance' || effectivePreviewQuality === 'low' ? 56 : 38;
    let raf = 0;
    let last = 0;
    const startClock = performance.now();
    const loop = (now: number) => {
      if (now - last >= frameIntervalMs) {
        last = now;
        hoverClockRef.current = (now - startClock) / 1000;
        setHoverTick((t) => (t + 1) % 10000);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [hoverPreviewPreset, isPlaying, hoverBypassOriginal, effectivePreviewQuality]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (canvas.width !== renderW || canvas.height !== renderH) {
      canvas.width = renderW;
      canvas.height = renderH;
    }
    const ctx = canvas.getContext('2d', { colorSpace: 'srgb' }) || canvas.getContext('2d');
    if (!ctx) return;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    const jobId = ++hoverJobIdRef.current;
    const useStaticHoverCache =
      Boolean(hoverPreviewPreset) &&
      !hoverBypassOriginal &&
      !isPlaying &&
      !beforeAfterEnabled &&
      !isHoverPresetAnimated(hoverPreviewPreset);

    const cacheKey = useStaticHoverCache
      ? `${hoverPreviewPreset!.id}|${hoverTargetInfo.targetClip?.id || 'stage'}|${Math.round(playheadTime * 20)}|${renderW}x${renderH}|${project.clips.length}`
      : '';

    const t0 = performance.now();
    let frameMs = 0;

    if (useStaticHoverCache) {
      const cachedCanvas = hoverPreviewCache.get(cacheKey);
      if (cachedCanvas) {
        ctx.clearRect(0, 0, renderW, renderH);
        ctx.drawImage(cachedCanvas, 0, 0, renderW, renderH);
      } else {
        renderCompositeFrame(ctx, project, playheadTime, cacheRef.current, renderW, renderH, {
          isPlaying,
          selectedClipId: selectedClip?.id,
          hoverPreviewPreset,
          hoverPreviewBypass: hoverBypassOriginal,
          hoverPreviewClockSec: hoverClockRef.current,
          isHoverPreview: isHoverActive && !hoverBypassOriginal,
          previewQuality: effectivePreviewQuality,
          proxyQuality: project.proxyQuality,
          isInteracting,
          fpsDropFactor: autoDownscalePreview ? fpsDropFactor : 0,
        });
        if (jobId === hoverJobIdRef.current) {
          hoverPreviewCache.set(cacheKey, canvas);
        }
      }
      frameMs = performance.now() - t0;
    } else {
      renderCompositeFrame(ctx, project, playheadTime, cacheRef.current, renderW, renderH, {
        isPlaying,
        selectedClipId: selectedClip?.id,
        hoverPreviewPreset,
        hoverPreviewBypass: hoverBypassOriginal,
        hoverPreviewClockSec: hoverClockRef.current,
        isHoverPreview: isHoverActive && !hoverBypassOriginal,
        previewQuality: effectivePreviewQuality,
        proxyQuality: project.proxyQuality,
        isInteracting,
        fpsDropFactor: autoDownscalePreview ? fpsDropFactor : 0,
      });
      frameMs = performance.now() - t0;
    }
    setIsHoverRendering((prev) => (prev ? false : prev));

    if (beforeAfterEnabled && rawCanvasRef.current) {
      const rawCanvas = rawCanvasRef.current;
      if (rawCanvas.width !== renderW || rawCanvas.height !== renderH) {
        rawCanvas.width = renderW;
        rawCanvas.height = renderH;
      }
      const rawCtx = rawCanvas.getContext('2d', { colorSpace: 'srgb' }) || rawCanvas.getContext('2d');
      if (rawCtx) {
        rawCtx.imageSmoothingEnabled = true;
        rawCtx.imageSmoothingQuality = 'high';
        if (hoverPreviewPreset) {
          // When hovering an effect, Before = untouched current timeline (without hover effect)
          renderCompositeFrame(rawCtx, project, playheadTime, cacheRef.current, renderW, renderH, {
            isPlaying,
            selectedClipId: selectedClip?.id,
            hoverPreviewPreset: null,
            isHoverPreview: true,
            previewQuality: effectivePreviewQuality,
            proxyQuality: project.proxyQuality,
            isInteracting,
            fpsDropFactor: 0,
          });
        } else {
          const rawProject: StudioProject = {
            ...project,
            clips: project.clips
              .filter((c) => c.type !== 'fx')
              .map((c) => ({
                ...c,
                effectsStack: [],
                colorGrade: {
                  ...(c.colorGrade || {}),
                  preset: 'none',
                  exposure: 0,
                  contrast: 0,
                  saturation: 0,
                  temperature: 0,
                  tint: 0,
                  vignette: 0,
                  highlights: 0,
                  shadows: 0,
                  whites: 0,
                  blacks: 0,
                  vibrance: 0,
                  rgbCurves: undefined,
                  colorBalance: undefined,
                },
                effects: {
                  ...(c.effects || {}),
                  blur: 0,
                  glow: 0,
                  particles: 'none',
                  filmGrain: 0,
                  sharpness: 0,
                  upscaleBoost: 0,
                  denoise: 0,
                  deblur: 0,
                  detailRecovery: 0,
                  textureEnhance: 0,
                  faceDetail: 0,
                  colorEnhance: 0,
                  chromaAberration: 0,
                  glitchIntensity: 0,
                  vignetteIntensity: 0,
                },
              })),
          };
          renderCompositeFrame(rawCtx, rawProject, playheadTime, cacheRef.current, renderW, renderH, {
            isPlaying,
            selectedClipId: undefined,
            hoverPreviewPreset: null,
            previewQuality: effectivePreviewQuality,
            proxyQuality: project.proxyQuality,
            isInteracting,
            fpsDropFactor: 0,
          });
        }
      }
    }

    if (isPlaying) {
      const acc = fpsAccumRef.current;
      acc.frames += 1;
      acc.totalMs += frameMs;
      const now = performance.now();
      if (now - acc.lastReport >= 600) {
        const avgMs = acc.totalMs / Math.max(1, acc.frames);
        const estFps = Math.min(project.fps, Math.max(1, Math.round(1000 / Math.max(16.6, avgMs))));
        setMeasuredFps(estFps);
        const budgetMs = 1000 / Math.max(15, project.fps);
        const nextDrop = avgMs > budgetMs * 1.3 ? Math.min(0.85, (avgMs - budgetMs) / (budgetMs * 2)) : 0;
        setFpsDropFactor((prev) => (Math.abs(prev - nextDrop) > 0.12 ? nextDrop : prev));
        acc.frames = 0;
        acc.totalMs = 0;
        acc.lastReport = now;
      }
    } else {
      setMeasuredFps((prev) => (prev === null ? prev : null));
      if (fpsDropFactor !== 0) setFpsDropFactor(0);
      const bounds = computeVisibleClipBounds(
        ctx,
        project,
        playheadTime,
        cacheRef.current,
        renderW,
        renderH
      );
      setVisibleBounds((prev) => (clipBoundsEqual(prev, bounds) ? prev : bounds));
    }
  }, [
    project,
    playheadTime,
    isPlaying,
    renderW,
    renderH,
    selectedClip?.id,
    hoverPreviewPreset,
    hoverBypassOriginal,
    hoverTargetInfo.targetClip?.id,
    isHoverActive,
    hoverTick,
    effectivePreviewQuality,
    isInteracting,
    autoDownscalePreview,
    fpsDropFactor,
    beforeAfterEnabled,
  ]);

  useEffect(() => {
    const onFs = () => setIsFullscreen(document.fullscreenElement === monitorRootRef.current);
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  const toggleFullscreen = () => {
    const el = monitorRootRef.current;
    if (!el) return;
    if (document.fullscreenElement === el) {
      void document.exitFullscreen().catch(() => {});
    } else {
      void el.requestFullscreen().catch(() => {});
    }
  };

  // Keyboard shortcuts local to Preview canvas tools (V, H, \ for Preview Original toggle)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT')) {
        return;
      }
      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        if (e.key.toLowerCase() === 'h') {
          setCanvasTool('hand');
          if (penToolActive && onTogglePenTool) onTogglePenTool();
        } else if (e.key.toLowerCase() === 'v') {
          setCanvasTool('select');
          if (penToolActive && onTogglePenTool) onTogglePenTool();
        } else if (e.key === '\\') {
          setHoverBypassOriginal((v) => !v);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [penToolActive, onTogglePenTool]);

  const activeBezierPoints: BezierPoint[] | null =
    effectiveTool === 'pen' && selectedClip
      ? selectedClip.type === 'shape' && selectedClip.shapeProps?.shape === 'custom-path'
        ? selectedClip.shapeProps.pathPoints
        : selectedClip.mask.pathPoints || []
      : null;

  const commitPoints = (nextPts: BezierPoint[]) => {
    if (!selectedClip || !onUpdateClip) return;
    if (selectedClip.type === 'shape' && selectedClip.shapeProps?.shape === 'custom-path') {
      onUpdateClip(selectedClip.id, (c) => ({
        ...c,
        shapeProps: { ...c.shapeProps!, pathPoints: nextPts },
      }));
    } else {
      onUpdateClip(selectedClip.id, (c) => ({
        ...c,
        mask: { ...c.mask, shape: 'custom-path', pathPoints: nextPts },
      }));
    }
  };

  const clientToCanvasPx = (clientX: number, clientY: number): { px: number; py: number } => {
    const canvas = canvasRef.current;
    if (!canvas) return { px: 0, py: 0 };
    const rect = canvas.getBoundingClientRect();
    const px = ((clientX - rect.left) / Math.max(1, rect.width)) * renderW;
    const py = ((clientY - rect.top) / Math.max(1, rect.height)) * renderH;
    return { px, py };
  };

  const selectedBoundsList = useMemo(
    () =>
      visibleBounds.filter(
        (b) => b.clip.id === selectedClip?.id || selectedClipIds.includes(b.clip.id)
      ),
    [visibleBounds, selectedClip?.id, selectedClipIds]
  );

  const primaryBounds = useMemo(
    () =>
      visibleBounds.find((b) => b.clip.id === selectedClip?.id) ||
      selectedBoundsList[0] ||
      null,
    [visibleBounds, selectedClip?.id, selectedBoundsList]
  );

  const unit = Math.max(1, renderW / 800);

  const getOverlayGeometry = (b: ClipCanvasBounds) => {
    const [tl, tr, br, bl] = b.corners;
    const topMid = { x: (tl.x + tr.x) * 0.5, y: (tl.y + tr.y) * 0.5 };
    const rightMid = { x: (tr.x + br.x) * 0.5, y: (tr.y + br.y) * 0.5 };
    const bottomMid = { x: (bl.x + br.x) * 0.5, y: (bl.y + br.y) * 0.5 };
    const leftMid = { x: (tl.x + bl.x) * 0.5, y: (tl.y + bl.y) * 0.5 };

    // Normal outward along top edge
    const edgeDx = tr.x - tl.x;
    const edgeDy = tr.y - tl.y;
    const len = Math.hypot(edgeDx, edgeDy) || 1;
    const nx = edgeDy / len;
    const ny = -edgeDx / len;
    const rotStemDist = 26 * unit;
    const rotateHandle = {
      x: topMid.x + nx * rotStemDist,
      y: topMid.y + ny * rotStemDist,
    };
    return {
      tl,
      tr,
      br,
      bl,
      topMid,
      rightMid,
      bottomMid,
      leftMid,
      rotateHandle,
    };
  };

  const handleStagePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (inlineTextEdit) return;
    if (effectiveTool === 'pen') return;

    if (effectiveTool === 'hand' || e.button === 1) {
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      dragOpRef.current = {
        kind: 'pan',
        startClientX: e.clientX,
        startClientY: e.clientY,
        startPanX: pan.x,
        startPanY: pan.y,
      };
      return;
    }

    if (effectiveTool === 'zoom') {
      const nextZoom = e.altKey
        ? Math.max(0.4, canvasZoom - 0.25)
        : Math.min(3, canvasZoom + 0.25);
      setCanvasZoom(Number(nextZoom.toFixed(2)));
      return;
    }

    const { px, py } = clientToCanvasPx(e.clientX, e.clientY);

    if (effectiveTool === 'text') {
      const xPct = Math.round(((px / renderW - 0.5) * 100) * 10) / 10;
      const yPct = Math.round(((py / renderH - 0.5) * 100) * 10) / 10;
      onAddTextAtPosition?.(xPct, yPct);
      setCanvasTool('select');
      return;
    }

    if (workspaceMode === 'motion' && selectedClip?.motionTrack.enabled && e.altKey) {
      const nx = Math.max(0, Math.min(1, px / renderW));
      const ny = Math.max(0, Math.min(1, py / renderH));
      onUpdateMotionTrackTarget(selectedClip.id, nx, ny);
      return;
    }

    // 1. Check Handles on Primary Selected Bounds First
    const isTrackLocked = (clip: TimelineClip) =>
      Boolean(clip.locked || project.tracks.find((t) => t.id === clip.trackId)?.locked);

    if (primaryBounds && !isTrackLocked(primaryBounds.clip)) {
      const geom = getOverlayGeometry(primaryBounds);
      const hitRadius = 11 * unit;
      const dist = (a: { x: number; y: number }) => Math.hypot(a.x - px, a.y - py);

      if (dist(geom.rotateHandle) <= hitRadius * 1.2) {
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        onBeginDragHistory?.();
        didMutateDuringDragRef.current = false;
        const evalT = getClipAnimationEvalTime(
          primaryBounds.clip,
          Math.max(0, playheadTime - primaryBounds.clip.startTime)
        );
        const curRot = evaluateKeyframeProperty(
          primaryBounds.clip.keyframes,
          'rotation',
          evalT,
          primaryBounds.clip.transform.rotation
        );
        dragOpRef.current = {
          kind: 'rotate',
          clipId: primaryBounds.clip.id,
          pivotX: primaryBounds.pivotX,
          pivotY: primaryBounds.pivotY,
          startAngleRad: Math.atan2(py - primaryBounds.pivotY, px - primaryBounds.pivotX),
          initialRotation: curRot,
        };
        return;
      }

      if (dist({ x: primaryBounds.pivotX, y: primaryBounds.pivotY }) <= hitRadius && e.altKey) {
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        onBeginDragHistory?.();
        didMutateDuringDragRef.current = false;
        const evalT = getClipAnimationEvalTime(
          primaryBounds.clip,
          Math.max(0, playheadTime - primaryBounds.clip.startTime)
        );
        dragOpRef.current = {
          kind: 'anchor',
          clipId: primaryBounds.clip.id,
          initialAnchorX: evaluateKeyframeProperty(
            primaryBounds.clip.keyframes,
            'anchorX',
            evalT,
            primaryBounds.clip.transform.anchorX
          ),
          initialAnchorY: evaluateKeyframeProperty(
            primaryBounds.clip.keyframes,
            'anchorY',
            evalT,
            primaryBounds.clip.transform.anchorY
          ),
          startPxX: px,
          startPxY: py,
        };
        return;
      }

      const handleMap: Array<{
        key: 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w';
        pt: { x: number; y: number };
      }> = [
        { key: 'nw', pt: geom.tl },
        { key: 'n', pt: geom.topMid },
        { key: 'ne', pt: geom.tr },
        { key: 'e', pt: geom.rightMid },
        { key: 'se', pt: geom.br },
        { key: 's', pt: geom.bottomMid },
        { key: 'sw', pt: geom.bl },
        { key: 'w', pt: geom.leftMid },
      ];

      for (const h of handleMap) {
        if (dist(h.pt) <= hitRadius) {
          e.preventDefault();
          e.currentTarget.setPointerCapture(e.pointerId);
          onBeginDragHistory?.();
          didMutateDuringDragRef.current = false;
          dragOpRef.current = {
            kind: 'resize',
            handle: h.key,
            clipId: primaryBounds.clip.id,
            startPxX: px,
            startPxY: py,
            initialBounds: primaryBounds,
            initialTransform: structuredClone(primaryBounds.clip.transform),
          };
          return;
        }
      }
    }

    // 2. Hit test visible objects (topmost first)
    const hit = hitTestClipBounds(visibleBounds, px, py, 6 * unit);
    if (!hit) {
      onSelectClip?.(null);
      return;
    }

    const additive = e.ctrlKey || e.metaKey || e.shiftKey;
    let activeIds: string[] = [];
    if (additive) {
      onSelectClip?.(hit.clip.id, true);
      activeIds = selectedClipIds.includes(hit.clip.id)
        ? selectedClipIds
        : [...selectedClipIds, hit.clip.id];
    } else if (selectedClipIds.includes(hit.clip.id) && selectedClipIds.length > 1) {
      onSelectClip?.(hit.clip.id, true); // keep group active
      activeIds = selectedClipIds;
    } else if (hit.clip.groupId) {
      const members = project.clips
        .filter((c) => c.groupId === hit.clip.groupId)
        .map((c) => c.id);
      onSelectClip?.(hit.clip.id, false);
      activeIds = members;
    } else {
      onSelectClip?.(hit.clip.id, false);
      activeIds = [hit.clip.id];
    }

    // Locked check
    if (isTrackLocked(hit.clip)) {
      return;
    }

    const initialPositions: Record<string, { x: number; y: number }> = {};
    for (const id of activeIds) {
      const c = project.clips.find((x) => x.id === id);
      if (c && !isTrackLocked(c)) {
        const evalT = getClipAnimationEvalTime(c, Math.max(0, playheadTime - c.startTime));
        initialPositions[id] = {
          x: evaluateKeyframeProperty(c.keyframes, 'x', evalT, c.transform.x),
          y: evaluateKeyframeProperty(c.keyframes, 'y', evalT, c.transform.y),
        };
      }
    }

    if (Object.keys(initialPositions).length > 0) {
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      onBeginDragHistory?.();
      didMutateDuringDragRef.current = false;
      dragOpRef.current = {
        kind: 'move',
        startPxX: px,
        startPxY: py,
        primaryId: hit.clip.id,
        initialPositions,
        primaryInitialBounds: hit,
      };
    }
  };

  const handleStagePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const op = dragOpRef.current;
    if (!op) return;

    if (op.kind === 'pan') {
      setPan({
        x: op.startPanX + (e.clientX - op.startClientX),
        y: op.startPanY + (e.clientY - op.startClientY),
      });
      return;
    }

    markInteractingPulse();
    const { px, py } = clientToCanvasPx(e.clientX, e.clientY);

    if (op.kind === 'move') {
      const screenDx = px - op.startPxX;
      const screenDy = py - op.startPxY;
      const invParent = invertMatrix2D(op.primaryInitialBounds.parentWorldMatrix);
      const localDxPx = invParent[0] * screenDx + invParent[2] * screenDy;
      const localDyPx = invParent[1] * screenDx + invParent[3] * screenDy;
      let dxPct = (localDxPx / renderW) * 100;
      let dyPct = (localDyPx / renderH) * 100;
      const basePos = op.initialPositions[op.primaryId];
      if (!basePos) return;

      let candidateX = basePos.x + dxPct;
      let candidateY = basePos.y + dyPct;
      const guides: Array<{ axis: 'x' | 'y'; canvasPos: number }> = [];

      const hasParent = Boolean(op.primaryInitialBounds.clip.parentClipId);
      if (project.snapEnabled && !e.altKey && !hasParent) {
        const snapThresholdPct = 1.6;
        const xTargets: Array<{ val: number; canvasPx: number }> = [
          { val: 0, canvasPx: renderW * 0.5 },
          { val: -25, canvasPx: renderW * 0.25 },
          { val: 25, canvasPx: renderW * 0.75 },
        ];
        const yTargets: Array<{ val: number; canvasPx: number }> = [
          { val: 0, canvasPx: renderH * 0.5 },
          { val: -25, canvasPx: renderH * 0.25 },
          { val: 25, canvasPx: renderH * 0.75 },
        ];

        // Snap to other visible unselected layers' centers
        for (const other of visibleBounds) {
          if (op.initialPositions[other.clip.id]) continue;
          xTargets.push({
            val: other.clip.transform.x,
            canvasPx: other.centerX,
          });
          yTargets.push({
            val: other.clip.transform.y,
            canvasPx: other.centerY,
          });
        }

        // Also snap bounding edges to canvas edges (0 and 100%)
        const halfWPct = ((op.primaryInitialBounds.maxX - op.primaryInitialBounds.minX) * 0.5 / renderW) * 100;
        const halfHPct = ((op.primaryInitialBounds.maxY - op.primaryInitialBounds.minY) * 0.5 / renderH) * 100;
        xTargets.push({ val: -50 + halfWPct, canvasPx: 0 });
        xTargets.push({ val: 50 - halfWPct, canvasPx: renderW });
        yTargets.push({ val: -50 + halfHPct, canvasPx: 0 });
        yTargets.push({ val: 50 - halfHPct, canvasPx: renderH });

        let bestXDist = snapThresholdPct;
        let snappedXTarget: { val: number; canvasPx: number } | null = null;
        for (const t of xTargets) {
          const d = Math.abs(candidateX - t.val);
          if (d < bestXDist) {
            bestXDist = d;
            snappedXTarget = t;
          }
        }
        if (snappedXTarget) {
          dxPct += snappedXTarget.val - candidateX;
          candidateX = snappedXTarget.val;
          guides.push({ axis: 'x', canvasPos: snappedXTarget.canvasPx });
        }

        let bestYDist = snapThresholdPct;
        let snappedYTarget: { val: number; canvasPx: number } | null = null;
        for (const t of yTargets) {
          const d = Math.abs(candidateY - t.val);
          if (d < bestYDist) {
            bestYDist = d;
            snappedYTarget = t;
          }
        }
        if (snappedYTarget) {
          dyPct += snappedYTarget.val - candidateY;
          candidateY = snappedYTarget.val;
          guides.push({ axis: 'y', canvasPos: snappedYTarget.canvasPx });
        }
      }

      setSnapGuides(guides);
      didMutateDuringDragRef.current = true;

      const updates: Record<string, (c: TimelineClip) => TimelineClip> = {};
      for (const [cid, init] of Object.entries(op.initialPositions)) {
        const nx = Math.round((init.x + dxPct) * 100) / 100;
        const ny = Math.round((init.y + dyPct) * 100) / 100;
        updates[cid] = (c) => {
          const kfUpdates: Array<{ property: KeyframeProperty; value: number }> = [];
          if (c.keyframes.some((k) => k.property === 'x')) kfUpdates.push({ property: 'x', value: nx });
          if (c.keyframes.some((k) => k.property === 'y')) kfUpdates.push({ property: 'y', value: ny });
          return {
            ...c,
            keyframes: kfUpdates.length > 0 ? upsertKeyframesForProps(c, playheadTime, kfUpdates) : c.keyframes,
            transform: { ...c.transform, x: nx, y: ny },
          };
        };
      }
      if (onBatchUpdateClips) {
        onBatchUpdateClips(updates, false);
      } else if (onUpdateClip) {
        Object.entries(updates).forEach(([id, fn]) => onUpdateClip(id, fn, false));
      }
      return;
    }

    if (op.kind === 'resize' && onUpdateClip) {
      const b = op.initialBounds;
      const rad = (b.rotationDeg * Math.PI) / 180;
      const cos = Math.cos(rad);
      const sin = Math.sin(rad);
      const dx = px - op.startPxX;
      const dy = py - op.startPxY;
      // Project pointer delta into clip's rotated local space
      const localDx = dx * cos + dy * sin;
      const localDy = -dx * sin + dy * cos;

      const symMult = e.altKey ? 2 : 1;
      const curW = Math.max(12, b.scaledWidth);
      const curH = Math.max(12, b.scaledHeight);

      let ratioX = 1;
      let ratioY = 1;

      if (op.handle.includes('e')) {
        ratioX = Math.max(0.08, (curW + localDx * symMult) / curW);
      } else if (op.handle.includes('w')) {
        ratioX = Math.max(0.08, (curW - localDx * symMult) / curW);
      }
      if (op.handle.includes('s')) {
        ratioY = Math.max(0.08, (curH + localDy * symMult) / curH);
      } else if (op.handle.includes('n')) {
        ratioY = Math.max(0.08, (curH - localDy * symMult) / curH);
      }

      if (e.shiftKey && op.handle.length === 2) {
        const avg = Math.max(ratioX, ratioY);
        ratioX = avg;
        ratioY = avg;
      }

      const initSX = op.initialTransform.scaleX ?? 1;
      const initSY = op.initialTransform.scaleY ?? 1;
      const nextScaleX = Math.max(0.08, Math.min(5, Math.round(initSX * ratioX * 1000) / 1000));
      const nextScaleY = Math.max(0.08, Math.min(5, Math.round(initSY * ratioY * 1000) / 1000));

      didMutateDuringDragRef.current = true;
      onUpdateClip(
        op.clipId,
        (c) => {
          const kfUpdates: Array<{ property: KeyframeProperty; value: number }> = [];
          if (c.keyframes.some((k) => k.property === 'scaleX')) kfUpdates.push({ property: 'scaleX', value: nextScaleX });
          if (c.keyframes.some((k) => k.property === 'scaleY')) kfUpdates.push({ property: 'scaleY', value: nextScaleY });
          return {
            ...c,
            keyframes: kfUpdates.length > 0 ? upsertKeyframesForProps(c, playheadTime, kfUpdates) : c.keyframes,
            transform: {
              ...c.transform,
              scaleX: nextScaleX,
              scaleY: nextScaleY,
            },
          };
        },
        false
      );
      return;
    }

    if (op.kind === 'rotate' && onUpdateClip) {
      const angle = Math.atan2(py - op.pivotY, px - op.pivotX);
      const deltaDeg = ((angle - op.startAngleRad) * 180) / Math.PI;
      let nextRot = op.initialRotation + deltaDeg;
      if (e.shiftKey) {
        nextRot = Math.round(nextRot / 15) * 15;
      } else {
        nextRot = Math.round(nextRot * 10) / 10;
      }
      didMutateDuringDragRef.current = true;
      setRotationReadout({ x: px, y: py, deg: Math.round(nextRot) });
      onUpdateClip(
        op.clipId,
        (c) => ({
          ...c,
          keyframes: c.keyframes.some((k) => k.property === 'rotation')
            ? upsertKeyframesForProps(c, playheadTime, [{ property: 'rotation', value: nextRot }])
            : c.keyframes,
          transform: { ...c.transform, rotation: nextRot },
        }),
        false
      );
      return;
    }

    if (op.kind === 'anchor' && onUpdateClip) {
      const dxNorm = (px - op.startPxX) / renderW;
      const dyNorm = (py - op.startPxY) / renderH;
      const nextAx = Math.max(0, Math.min(1, Math.round((op.initialAnchorX + dxNorm) * 1000) / 1000));
      const nextAy = Math.max(0, Math.min(1, Math.round((op.initialAnchorY + dyNorm) * 1000) / 1000));
      didMutateDuringDragRef.current = true;
      onUpdateClip(
        op.clipId,
        (c) => {
          const kfUpdates: Array<{ property: KeyframeProperty; value: number }> = [];
          if (c.keyframes.some((k) => k.property === 'anchorX')) kfUpdates.push({ property: 'anchorX', value: nextAx });
          if (c.keyframes.some((k) => k.property === 'anchorY')) kfUpdates.push({ property: 'anchorY', value: nextAy });
          return {
            ...c,
            keyframes: kfUpdates.length > 0 ? upsertKeyframesForProps(c, playheadTime, kfUpdates) : c.keyframes,
            transform: { ...c.transform, anchorX: nextAx, anchorY: nextAy },
          };
        },
        false
      );
    }
  };

  const handleStagePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const op = dragOpRef.current;
    if (!op) return;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    dragOpRef.current = null;
    setSnapGuides([]);
    setRotationReadout(null);

    if (op.kind !== 'pan' && didMutateDuringDragRef.current) {
      // Auto Keyframe insertion if enabled
      if (autoKeyframeEnabled) {
        if (op.kind === 'move') {
          const updates: Record<string, (c: TimelineClip) => TimelineClip> = {};
          for (const cid of Object.keys(op.initialPositions)) {
            updates[cid] = (c) => ({
              ...c,
              keyframes: upsertKeyframesForProps(c, playheadTime, [
                { property: 'x', value: c.transform.x },
                { property: 'y', value: c.transform.y },
              ]),
            });
          }
          onBatchUpdateClips?.(updates, false);
        } else if (op.kind === 'resize' && onUpdateClip) {
          onUpdateClip(
            op.clipId,
            (c) => ({
              ...c,
              keyframes: upsertKeyframesForProps(c, playheadTime, [
                { property: 'scaleX', value: c.transform.scaleX ?? 1 },
                { property: 'scaleY', value: c.transform.scaleY ?? 1 },
              ]),
            }),
            false
          );
        } else if (op.kind === 'rotate' && onUpdateClip) {
          onUpdateClip(
            op.clipId,
            (c) => ({
              ...c,
              keyframes: upsertKeyframesForProps(c, playheadTime, [
                { property: 'rotation', value: c.transform.rotation },
              ]),
            }),
            false
          );
        } else if (op.kind === 'anchor' && onUpdateClip) {
          onUpdateClip(
            op.clipId,
            (c) => ({
              ...c,
              keyframes: upsertKeyframesForProps(c, playheadTime, [
                { property: 'anchorX', value: c.transform.anchorX },
                { property: 'anchorY', value: c.transform.anchorY },
              ]),
            }),
            false
          );
        }
      }
      onEndDragHistory?.();
    }
    didMutateDuringDragRef.current = false;
  };

  const handleStageDoubleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (effectiveTool !== 'select') return;
    const { px, py } = clientToCanvasPx(e.clientX, e.clientY);
    const hit = hitTestClipBounds(visibleBounds, px, py, 8 * unit);
    if (hit && hit.clip.type === 'text' && hit.clip.textProps) {
      setInlineTextEdit({
        clipId: hit.clip.id,
        value: hit.clip.textProps.text,
        leftPct: (hit.centerX / renderW) * 100,
        topPct: (hit.centerY / renderH) * 100,
      });
    }
  };

  // Align & Distribute Actions for Multi-Selection (or single against canvas)
  const alignSelectedBounds = (mode: 'left' | 'center-h' | 'right' | 'top' | 'center-v' | 'bottom') => {
    if (!onBatchUpdateClips || selectedBoundsList.length === 0) return;
    const minLeft =
      selectedBoundsList.length === 1
        ? 0
        : Math.min(...selectedBoundsList.map((b) => b.minX));
    const maxRight =
      selectedBoundsList.length === 1
        ? renderW
        : Math.max(...selectedBoundsList.map((b) => b.maxX));
    const minTop =
      selectedBoundsList.length === 1
        ? 0
        : Math.min(...selectedBoundsList.map((b) => b.minY));
    const maxBottom =
      selectedBoundsList.length === 1
        ? renderH
        : Math.max(...selectedBoundsList.map((b) => b.maxY));
    const midX = (minLeft + maxRight) * 0.5;
    const midY = (minTop + maxBottom) * 0.5;

    const updates: Record<string, (c: TimelineClip) => TimelineClip> = {};
    for (const b of selectedBoundsList) {
      let targetDxPx = 0;
      let targetDyPx = 0;
      if (mode === 'left') targetDxPx = minLeft - b.minX;
      if (mode === 'right') targetDxPx = maxRight - b.maxX;
      if (mode === 'center-h') targetDxPx = midX - (b.minX + b.maxX) * 0.5;
      if (mode === 'top') targetDyPx = minTop - b.minY;
      if (mode === 'bottom') targetDyPx = maxBottom - b.maxY;
      if (mode === 'center-v') targetDyPx = midY - (b.minY + b.maxY) * 0.5;

      const dxPct = (targetDxPx / renderW) * 100;
      const dyPct = (targetDyPx / renderH) * 100;
      updates[b.clip.id] = (c) => ({
        ...c,
        transform: {
          ...c.transform,
          x: Math.round((c.transform.x + dxPct) * 100) / 100,
          y: Math.round((c.transform.y + dyPct) * 100) / 100,
        },
      });
    }
    onBatchUpdateClips(updates, true);
  };

  const handleSvgPointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (draggingVertexIdx === null || !activeBezierPoints) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = Math.max(-0.5, Math.min(0.5, (e.clientX - rect.left) / rect.width - 0.5));
    const ny = Math.max(-0.5, Math.min(0.5, (e.clientY - rect.top) / rect.height - 0.5));
    const next = activeBezierPoints.map((pt, idx) =>
      idx === draggingVertexIdx ? { ...pt, x: nx, y: ny } : pt
    );
    commitPoints(next);
  };

  const anySelectedGrouped = selectedBoundsList.some((b) => Boolean(b.clip.groupId));

  return (
    <div
      ref={monitorRootRef}
      data-tutorial-target="preview-monitor"
      className="flex flex-col h-full bg-[#18181A]"
    >
      {/* Top Preview Canvas Direct Manipulation Toolbar */}
      <div
        data-tutorial-target="canvas-tools"
        className="px-2.5 py-1.5 bg-[#222225] border-b border-[#3E3E44] flex items-center justify-between gap-2 flex-wrap shrink-0 select-none text-[11px]"
      >
        {/* Creation & Manipulation Tools */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => {
              setCanvasTool('select');
              if (penToolActive && onTogglePenTool) onTogglePenTool();
            }}
            title="Selection Tool (V)"
            className={`p-1.5 rounded-[5px] border transition-colors ${
              effectiveTool === 'select'
                ? 'border-[#A1A1AA] bg-[#52525B] text-[#F4F4F5]'
                : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <MousePointer2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => {
              setCanvasTool('hand');
              if (penToolActive && onTogglePenTool) onTogglePenTool();
            }}
            title="Hand Pan Tool (H)"
            className={`p-1.5 rounded-[5px] border transition-colors ${
              effectiveTool === 'hand'
                ? 'border-[#A1A1AA] bg-[#52525B] text-[#F4F4F5]'
                : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <Hand className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => {
              setCanvasTool('text');
              if (penToolActive && onTogglePenTool) onTogglePenTool();
            }}
            title="Text Tool (Click anywhere on preview canvas to add text)"
            className={`p-1.5 rounded-[5px] border transition-colors ${
              effectiveTool === 'text'
                ? 'border-[#A1A1AA] bg-[#52525B] text-[#F4F4F5]'
                : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <TypeIcon className="w-3.5 h-3.5" />
          </button>

          <div className="relative">
            <button
              type="button"
              onClick={() => setShapeMenuOpen((v) => !v)}
              title="Add Vector Shape Layer"
              className={`p-1.5 rounded-[5px] border transition-colors ${
                shapeMenuOpen
                  ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#F4F4F5]'
                  : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
              }`}
            >
              <Square className="w-3.5 h-3.5" />
            </button>
            {shapeMenuOpen && onAddShapeClip && (
              <div className="absolute left-0 top-full mt-1 w-32 bg-[#222225] border border-[#3E3E44] rounded-[6px] shadow-xl py-1 z-50">
                {(['rectangle', 'circle', 'ellipse', 'polygon', 'star'] as ShapeKind[]).map(
                  (sk) => (
                    <button
                      key={sk}
                      type="button"
                      onClick={() => {
                        onAddShapeClip(sk);
                        setShapeMenuOpen(false);
                        setCanvasTool('select');
                      }}
                      className="w-full px-3 py-1 text-left capitalize text-[#F4F4F5] hover:bg-[#71717A]/20 transition-colors"
                    >
                      {sk}
                    </button>
                  )
                )}
              </div>
            )}
          </div>

          {onTogglePenTool && (
            <button
              type="button"
              onClick={onTogglePenTool}
              title="Pen Tool (Bezier mask / custom shape)"
              className={`p-1.5 rounded-[5px] border transition-colors ${
                effectiveTool === 'pen'
                  ? 'border-[#A1A1AA] bg-[#52525B] text-[#F4F4F5]'
                  : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
              }`}
            >
              <PenTool className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Multi-Selection Align & Group Controls */}
        {selectedBoundsList.length > 0 && (
          <div className="hidden lg:flex items-center gap-0.5 px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded-[5px]">
            <button
              type="button"
              onClick={() => alignSelectedBounds('left')}
              title="Align Left"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <AlignLeft className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => alignSelectedBounds('center-h')}
              title="Align Horizontal Center"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <AlignCenterHorizontal className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => alignSelectedBounds('right')}
              title="Align Right"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <AlignRight className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => alignSelectedBounds('top')}
              title="Align Top"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <AlignStartVertical className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => alignSelectedBounds('center-v')}
              title="Align Vertical Center"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <AlignCenterVertical className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => alignSelectedBounds('bottom')}
              title="Align Bottom"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <AlignEndVertical className="w-3 h-3" />
            </button>

            {selectedClipIds.length >= 2 && onGroupSelected && (
              <button
                type="button"
                onClick={onGroupSelected}
                title="Group Selected Layers (Ctrl+G)"
                className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] border-l border-[#3E3E44] ml-0.5 pl-1.5"
              >
                <Group className="w-3 h-3" />
              </button>
            )}
            {anySelectedGrouped && onUngroupSelected && (
              <button
                type="button"
                onClick={onUngroupSelected}
                title="Ungroup Layers (Ctrl+Shift+G)"
                className="p-1 text-[#D4D4D8] hover:text-[#F4F4F5]"
              >
                <Ungroup className="w-3 h-3" />
              </button>
            )}
          </div>
        )}

        {/* Zoom, Snap & Auto-Keyframe Controls */}
        <div className="flex items-center gap-1">
          {onToggleSnap && (
            <button
              type="button"
              onClick={onToggleSnap}
              title={`Snap to Guides & Center (${project.snapEnabled ? 'ON' : 'OFF'})`}
              className={`px-2 py-1 rounded-[5px] border flex items-center gap-1 text-[10px] font-medium transition-colors ${
                project.snapEnabled
                  ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#F4F4F5]'
                  : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
              }`}
            >
              <Magnet className="w-3 h-3" />
              Snap
            </button>
          )}
          {onToggleAutoKeyframe && (
            <button
              type="button"
              onClick={onToggleAutoKeyframe}
              title="Auto Keyframe ON/OFF (Automatically records keyframes when dragging/resizing/rotating)"
              className={`px-2 py-1 rounded-[5px] border flex items-center gap-1 text-[10px] font-medium transition-colors ${
                autoKeyframeEnabled
                  ? 'border-[#A1A1AA] bg-[#52525B] text-[#F4F4F5]'
                  : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
              }`}
            >
              <Diamond className="w-3 h-3 fill-current" />
              Auto KF
            </button>
          )}

          <div className="flex items-center bg-[#18181A] border border-[#3E3E44] rounded-[5px] ml-0.5">
            <button
              type="button"
              onClick={() => setCanvasZoom((z) => Math.max(0.4, Number((z - 0.15).toFixed(2))))}
              title="Zoom Out"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <select
              value={String(canvasZoom)}
              onChange={(e) => {
                setCanvasZoom(Number(e.target.value));
                if (Number(e.target.value) === 1) setPan({ x: 0, y: 0 });
              }}
              className="bg-transparent text-[#F4F4F5] font-mono-tabular text-[10px] px-1 py-0.5 focus:outline-none"
            >
              <option value="0.5" className="bg-[#222225]">50%</option>
              <option value="0.75" className="bg-[#222225]">75%</option>
              <option value="1" className="bg-[#222225]">Fit (100%)</option>
              <option value="1.25" className="bg-[#222225]">125%</option>
              <option value="1.5" className="bg-[#222225]">150%</option>
              <option value="2" className="bg-[#222225]">200%</option>
            </select>
            <button
              type="button"
              onClick={() => setCanvasZoom((z) => Math.min(3, Number((z + 0.15).toFixed(2))))}
              title="Zoom In"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => {
                setCanvasZoom(1);
                setPan({ x: 0, y: 0 });
              }}
              title="Fit to Screen"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] border-l border-[#3E3E44]"
            >
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>

          {hoverPreviewPreset && (
            <div className="hidden md:flex items-center bg-[#18181A] border border-[#3E3E44] rounded-[5px] overflow-hidden">
              <button
                type="button"
                onClick={() => setHoverBypassOriginal(true)}
                title="Preview Original Clip without hovered effect (Shortcut: \\)"
                className={`px-1.5 py-0.5 text-[10px] font-medium flex items-center gap-1 transition-colors ${
                  hoverBypassOriginal
                    ? 'bg-[#2C2C30] text-[#F4F4F5]'
                    : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                <EyeOff className="w-2.5 h-2.5" />
                Original
              </button>
              <button
                type="button"
                onClick={() => setHoverBypassOriginal(false)}
                title="Preview Hovered Effect in real time"
                className={`px-1.5 py-0.5 text-[10px] font-medium flex items-center gap-1 transition-colors ${
                  !hoverBypassOriginal
                    ? 'bg-[#52525B] text-[#F4F4F5]'
                    : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                <Eye className="w-2.5 h-2.5" />
                Effect
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={() => setBeforeAfterEnabled((v) => !v)}
            title="Compare Before / After Split"
            className={`px-2 py-1 rounded-[5px] border flex items-center gap-1 text-[10px] font-medium transition-colors whitespace-nowrap ${
              beforeAfterEnabled
                ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#F4F4F5]'
                : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <SplitSquareHorizontal className="w-3 h-3" />
            <span className="hidden xl:inline">Compare</span>
          </button>

          <button
            type="button"
            onClick={toggleFullscreen}
            title={isFullscreen ? 'Exit Fullscreen (Esc)' : 'Fullscreen Preview'}
            className="p-1.5 rounded-[5px] border border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5] transition-colors"
          >
            {isFullscreen ? <Minimize className="w-3 h-3" /> : <Maximize className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* Viewport Canvas Stage (Pure Black Canvas on Dark Slate Matte) */}
      <div
        ref={stageRef}
        onWheel={(e) => {
          if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            setCanvasZoom((z) =>
              Math.max(0.4, Math.min(3, Number((z - e.deltaY * 0.001).toFixed(2))))
            );
          }
        }}
        className={`flex-1 min-h-0 flex items-center justify-center p-3 relative overflow-hidden touch-none select-none bg-[#18181A] ${
          effectiveTool === 'hand'
            ? 'cursor-grab active:cursor-grabbing'
            : effectiveTool === 'text'
            ? 'cursor-text'
            : effectiveTool === 'zoom'
            ? 'cursor-zoom-in'
            : ''
        }`}
      >
        <div
          style={{
            aspectRatio: `${project.width} / ${project.height}`,
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${canvasZoom})`,
          }}
          onPointerDown={handleStagePointerDown}
          onPointerMove={handleStagePointerMove}
          onPointerUp={handleStagePointerUp}
          onDoubleClick={handleStageDoubleClick}
          className="re-stage-keep-dark relative max-w-full max-h-full h-full bg-[#000000] border border-[#3E3E44] shadow-2xl flex items-center justify-center transition-transform duration-75"
        >
          <canvas
            ref={canvasRef}
            className="w-full h-full object-contain pointer-events-none"
          />

          {beforeAfterEnabled && (
            <>
              <canvas
                ref={rawCanvasRef}
                style={{ clipPath: `inset(0 ${100 - compareSplitPct}% 0 0)` }}
                className="w-full h-full object-contain pointer-events-none absolute inset-0"
              />
              <div
                style={{ left: `${compareSplitPct}%` }}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  const stageBox = e.currentTarget.parentElement?.getBoundingClientRect();
                  if (!stageBox) return;
                  const onMove = (ev: PointerEvent) => {
                    const pct = ((ev.clientX - stageBox.left) / Math.max(1, stageBox.width)) * 100;
                    setCompareSplitPct(Math.max(5, Math.min(95, Math.round(pct))));
                  };
                  const onUp = () => {
                    window.removeEventListener('pointermove', onMove);
                    window.removeEventListener('pointerup', onUp);
                  };
                  window.addEventListener('pointermove', onMove);
                  window.addEventListener('pointerup', onUp);
                }}
                className="absolute top-0 bottom-0 w-0.5 bg-[#52525B] cursor-ew-resize z-20 flex items-center justify-center"
              >
                <div className="px-1 py-1 rounded bg-[#52525B] text-[#F4F4F5] text-[9px] font-mono-tabular shadow">
                  ↔
                </div>
              </div>
              <div className="pointer-events-none absolute top-2 left-2 px-1.5 py-0.5 bg-black/85 border border-[#3E3E44] rounded text-[9px] font-mono-tabular text-[#A1A1AA] z-20">
                {hoverPreviewPreset ? 'ORIGINAL' : 'BEFORE (RAW)'}
              </div>
              <div className="pointer-events-none absolute top-2 right-2 px-1.5 py-0.5 bg-[#71717A]/90 border border-white/20 rounded text-[9px] font-mono-tabular text-[#F4F4F5] z-20">
                {hoverPreviewPreset
                  ? `PREVIEW: ${hoverPreviewPreset.name.toUpperCase()}`
                  : 'AFTER (FX)'}
              </div>
            </>
          )}

          {/* Interactive Pen Tool / Bezier Mask Overlay */}
          {effectiveTool === 'pen' && selectedClip && (
            <svg
              viewBox="-0.5 -0.5 1 1"
              preserveAspectRatio="none"
              onPointerMove={handleSvgPointerMove}
              onPointerUp={() => setDraggingVertexIdx(null)}
              onPointerLeave={() => setDraggingVertexIdx(null)}
              onClick={(e) => {
                if (e.target === e.currentTarget) {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const nx = (e.clientX - rect.left) / rect.width - 0.5;
                  const ny = (e.clientY - rect.top) / rect.height - 0.5;
                  commitPoints([
                    ...(activeBezierPoints || []),
                    { x: nx, y: ny, inX: -0.04, inY: 0, outX: 0.04, outY: 0 },
                  ]);
                }
              }}
              className="absolute inset-0 w-full h-full cursor-crosshair"
            >
              {activeBezierPoints && activeBezierPoints.length > 1 && (
                <polygon
                  points={activeBezierPoints.map((p) => `${p.x},${p.y}`).join(' ')}
                  fill="rgba(139,112,232,0.12)"
                  stroke="#A1A1AA"
                  strokeWidth="0.004"
                  strokeDasharray="0.01 0.01"
                />
              )}
              {activeBezierPoints?.map((pt, i) => (
                <circle
                  key={i}
                  cx={pt.x}
                  cy={pt.y}
                  r="0.016"
                  fill="#A1A1AA"
                  stroke="#F4F4F5"
                  strokeWidth="0.004"
                  className="cursor-grab active:cursor-grabbing"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setDraggingVertexIdx(i);
                  }}
                />
              ))}
            </svg>
          )}

          {/* Direct Manipulation Selection Boxes, Handles & Alignment Snap Guides (Never Exported) */}
          {effectiveTool !== 'pen' && !isPlaying && (
            <svg
              viewBox={`0 0 ${renderW} ${renderH}`}
              preserveAspectRatio="none"
              className="pointer-events-none absolute inset-0 w-full h-full overflow-visible"
            >
              {/* Snap Alignment Guide Hairlines */}
              {snapGuides.map((g, idx) =>
                g.axis === 'x' ? (
                  <line
                    key={idx}
                    x1={g.canvasPos}
                    y1={0}
                    x2={g.canvasPos}
                    y2={renderH}
                    stroke="#A1A1AA"
                    strokeWidth={1.2 * unit}
                    strokeDasharray={`${4 * unit} ${3 * unit}`}
                  />
                ) : (
                  <line
                    key={idx}
                    x1={0}
                    y1={g.canvasPos}
                    x2={renderW}
                    y2={g.canvasPos}
                    stroke="#A1A1AA"
                    strokeWidth={1.2 * unit}
                    strokeDasharray={`${4 * unit} ${3 * unit}`}
                  />
                )
              )}

              {/* Bounding Box Outlines for Selected Layers */}
              {selectedBoundsList.map((b) => {
                const isPrimary = primaryBounds?.clip.id === b.clip.id;
                const locked =
                  b.clip.locked || project.tracks.find((t) => t.id === b.clip.trackId)?.locked;
                const geom = getOverlayGeometry(b);
                const ptsStr = `${geom.tl.x},${geom.tl.y} ${geom.tr.x},${geom.tr.y} ${geom.br.x},${geom.br.y} ${geom.bl.x},${geom.bl.y}`;
                const hs = 6.5 * unit;

                return (
                  <g key={b.clip.id}>
                    <polygon
                      points={ptsStr}
                      fill="none"
                      stroke={locked ? '#A1A1AA' : '#A1A1AA'}
                      strokeWidth={(isPrimary ? 1.8 : 1.1) * unit}
                      strokeDasharray={locked ? `${4 * unit} ${3 * unit}` : undefined}
                    />

                    {isPrimary && !locked && (
                      <>
                        {/* Rotation Stem & Handle */}
                        <line
                          x1={geom.topMid.x}
                          y1={geom.topMid.y}
                          x2={geom.rotateHandle.x}
                          y2={geom.rotateHandle.y}
                          stroke="#A1A1AA"
                          strokeWidth={1.4 * unit}
                        />
                        <circle
                          cx={geom.rotateHandle.x}
                          cy={geom.rotateHandle.y}
                          r={4.5 * unit}
                          fill="#F4F4F5"
                          stroke="#A1A1AA"
                          strokeWidth={1.6 * unit}
                        />

                        {/* Anchor Point Crosshair */}
                        <circle
                          cx={b.pivotX}
                          cy={b.pivotY}
                          r={4.2 * unit}
                          fill="rgba(23,25,31,0.85)"
                          stroke="#F4F4F5"
                          strokeWidth={1.4 * unit}
                        />
                        <circle cx={b.pivotX} cy={b.pivotY} r={1.6 * unit} fill="#A1A1AA" />

                        {/* 8 Corner + Edge Resize Handles */}
                        {[
                          geom.tl,
                          geom.topMid,
                          geom.tr,
                          geom.rightMid,
                          geom.br,
                          geom.bottomMid,
                          geom.bl,
                          geom.leftMid,
                        ].map((pt, hi) => (
                          <rect
                            key={hi}
                            x={pt.x - hs * 0.5}
                            y={pt.y - hs * 0.5}
                            width={hs}
                            height={hs}
                            rx={1 * unit}
                            fill="#F4F4F5"
                            stroke="#A1A1AA"
                            strokeWidth={1.4 * unit}
                          />
                        ))}
                      </>
                    )}
                  </g>
                );
              })}

              {/* Rotation Degree Tooltip */}
              {rotationReadout && (
                <g transform={`translate(${rotationReadout.x + 14 * unit}, ${rotationReadout.y - 12 * unit})`}>
                  <rect
                    x={0}
                    y={-12 * unit}
                    width={42 * unit}
                    height={16 * unit}
                    rx={3 * unit}
                    fill="#18181A"
                    stroke="#A1A1AA"
                    strokeWidth={1 * unit}
                  />
                  <text
                    x={21 * unit}
                    y={-1 * unit}
                    textAnchor="middle"
                    fill="#F4F4F5"
                    fontSize={9.5 * unit}
                    fontFamily="JetBrains Mono, monospace"
                  >
                    {rotationReadout.deg}°
                  </text>
                </g>
              )}
            </svg>
          )}

          {/* Lock Indicator Chip if Selected Clip is Locked */}
          {selectedClip &&
            (selectedClip.locked ||
              project.tracks.find((t) => t.id === selectedClip.trackId)?.locked) && (
              <div className="pointer-events-none absolute top-2 left-2 px-2 py-0.5 rounded bg-[#18181A]/90 border border-[#3E3E44] text-[10px] text-[#A1A1AA] flex items-center gap-1">
                <Lock className="w-3 h-3 text-[#D4D4D8]" />
                Layer Locked
              </div>
            )}

          {/* Inline Text Layer Double-Click Editor */}
          {inlineTextEdit && (
            <div
              style={{
                left: `${inlineTextEdit.leftPct}%`,
                top: `${inlineTextEdit.topPct}%`,
              }}
              onPointerDown={(e) => e.stopPropagation()}
              className="absolute -translate-x-1/2 -translate-y-1/2 z-30 min-w-[200px]"
            >
              <textarea
                autoFocus
                rows={2}
                value={inlineTextEdit.value}
                onChange={(e) => setInlineTextEdit({ ...inlineTextEdit, value: e.target.value })}
                onBlur={() => {
                  onUpdateClip?.(
                    inlineTextEdit.clipId,
                    (c) =>
                      c.textProps
                        ? { ...c, textProps: { ...c.textProps, text: inlineTextEdit.value } }
                        : c,
                    true
                  );
                  setInlineTextEdit(null);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    onUpdateClip?.(
                      inlineTextEdit.clipId,
                      (c) =>
                        c.textProps
                          ? { ...c, textProps: { ...c.textProps, text: inlineTextEdit.value } }
                          : c,
                      true
                    );
                    setInlineTextEdit(null);
                  } else if (e.key === 'Escape') {
                    setInlineTextEdit(null);
                  }
                }}
                className="w-full px-2.5 py-1.5 bg-[#18181A]/95 border-2 border-[#A1A1AA] rounded text-center text-[#F4F4F5] text-sm font-semibold shadow-2xl focus:outline-none"
              />
              <div className="text-[9px] text-center text-[#A1A1AA] mt-0.5 bg-[#18181A]/90 px-1.5 py-0.5 rounded">
                Enter to apply · Esc to cancel
              </div>
            </div>
          )}

          {/* Broadcast Safe Margins Overlay */}
          {showSafeMargins && (
            <div className="pointer-events-none absolute inset-0">
              <div className="absolute inset-[5%] border border-dashed border-white/25" />
              <div className="absolute inset-[10%] border border-dashed border-[#A1A1AA]/60" />
              <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/15" />
              <div className="absolute top-1/2 left-0 right-0 h-px bg-white/15" />
            </div>
          )}

          {/* Motion Tracker Reticle */}
          {workspaceMode === 'motion' && selectedClip?.motionTrack.enabled && (
            <div
              style={{
                left: `${selectedClip.motionTrack.targetX * 100}%`,
                top: `${selectedClip.motionTrack.targetY * 100}%`,
              }}
              className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8 border-2 border-[#A1A1AA] flex items-center justify-center"
            >
              <Crosshair className="w-4 h-4 text-[#D4D4D8]" />
            </div>
          )}
        </div>

        {/* Non-Intrusive Live Effect Hover Preview Floating HUD */}
        {(hoverPreviewPreset || hoverPreviewPending) && (
          <div
            onPointerDown={(e) => e.stopPropagation()}
            className="absolute bottom-2.5 left-1/2 -translate-x-1/2 z-30 max-w-[96%] bg-[#222225]/95 backdrop-blur-sm border border-[#3E3E44] rounded-[6px] shadow-2xl px-2.5 py-1 flex items-center gap-2 flex-wrap text-[10px]"
          >
            <div className="flex items-center gap-1.5 min-w-0">
              {hoverPreviewPending || isHoverRendering ? (
                <Loader2 className="w-3 h-3 text-[#D4D4D8] animate-spin shrink-0" />
              ) : (
                <span
                  className="w-2 h-2 rounded-xs shrink-0"
                  style={{ backgroundColor: hoverPreviewPreset?.accentColor || '#A1A1AA' }}
                />
              )}
              <span className="font-mono-tabular uppercase text-[9px] text-[#A1A1AA]">
                {hoverBypassOriginal ? 'ORIGINAL' : 'LIVE PREVIEW'}
              </span>
              {hoverPreviewPreset && (
                <span className="font-semibold text-[#F4F4F5] truncate max-w-[160px]">
                  {hoverPreviewPreset.name}
                </span>
              )}
              {hoverTargetInfo.targetClip && (
                <span className="text-[9px] text-[#A1A1AA] truncate max-w-[110px] hidden sm:inline">
                  on {hoverTargetInfo.targetClip.name}
                </span>
              )}
            </div>

            <div className="h-3 w-px bg-[#3E3E44] hidden sm:block" />

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setHoverBypassOriginal(true)}
                className={`px-1.5 py-0.5 rounded border text-[9px] font-medium transition-colors ${
                  hoverBypassOriginal
                    ? 'border-[#A1A1AA]/60 bg-[#2C2C30] text-[#F4F4F5]'
                    : 'border-[#3E3E44] bg-[#18181A] text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                Preview Original
              </button>
              <button
                type="button"
                onClick={() => setHoverBypassOriginal(false)}
                className={`px-1.5 py-0.5 rounded border text-[9px] font-medium transition-colors ${
                  !hoverBypassOriginal
                    ? 'border-[#A1A1AA] bg-[#52525B] text-[#F4F4F5]'
                    : 'border-[#3E3E44] bg-[#18181A] text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                Preview Effect
              </button>
              <button
                type="button"
                onClick={() => setBeforeAfterEnabled((v) => !v)}
                className={`px-1.5 py-0.5 rounded border text-[9px] font-medium transition-colors ${
                  beforeAfterEnabled
                    ? 'border-[#A1A1AA] bg-[#71717A]/25 text-[#F4F4F5]'
                    : 'border-[#3E3E44] bg-[#18181A] text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                Compare Before / After
              </button>
              {onChangePreviewQuality && (
                <select
                  value={effectivePreviewQuality}
                  disabled={performanceMode}
                  onChange={(e) => onChangePreviewQuality(e.target.value as PreviewQuality)}
                  title="Preview Quality"
                  className="px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[9px] text-[#F4F4F5] disabled:opacity-50"
                >
                  <option value="ultra">Ultra</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                  <option value="performance">Perf</option>
                </select>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Contextual Selected Clip Quick Action Strip */}
      {selectedClip && (
        <div className="px-2.5 py-1 bg-[#2C2C30] border-t border-[#3E3E44] flex items-center justify-between gap-2 overflow-x-auto shrink-0 text-[10px]">
          <div className="flex items-center gap-1.5 min-w-0 shrink-0">
            <span className="w-1.5 h-1.5 rounded-xs bg-[#52525B] shrink-0" />
            <span className="font-medium text-[#F4F4F5] truncate max-w-[130px]">
              {selectedClip.name}
            </span>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {onSplitClip && (
              <button
                type="button"
                onClick={() => onSplitClip(selectedClip.id)}
                title="Split Clip at Playhead"
                className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap transition-colors"
              >
                <Scissors className="w-2.5 h-2.5 text-[#D4D4D8]" />
                Split
              </button>
            )}
            {onDuplicateClip && (
              <button
                type="button"
                onClick={() => onDuplicateClip(selectedClip.id)}
                title="Duplicate Clip (Ctrl+D)"
                className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap transition-colors"
              >
                <Copy className="w-2.5 h-2.5 text-[#A1A1AA]" />
                Dup
              </button>
            )}
            {onOpenSpeedDuration && (
              <button
                type="button"
                onClick={() => onOpenSpeedDuration(selectedClip.id)}
                title="Adjust Speed / Duration"
                className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap transition-colors"
              >
                <Gauge className="w-2.5 h-2.5 text-[#A1A1AA]" />
                Speed
              </button>
            )}
            {onFocusInspectorTab && (
              <>
                <button
                  type="button"
                  onClick={() => onFocusInspectorTab(selectedClip.id, 'transform')}
                  title="Inspect Transform"
                  className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap transition-colors"
                >
                  <Sliders className="w-2.5 h-2.5 text-[#A1A1AA]" />
                  Transform
                </button>
                <button
                  type="button"
                  onClick={() => onFocusInspectorTab(selectedClip.id, 'effects')}
                  title="Add Effect"
                  className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap transition-colors"
                >
                  <Sparkles className="w-2.5 h-2.5 text-[#D4D4D8]" />
                  Add Effect
                </button>
              </>
            )}
            {onAddKeyframeAtPlayhead && (
              <button
                type="button"
                onClick={() => onAddKeyframeAtPlayhead(selectedClip.id)}
                title="Add Keyframe at Playhead"
                className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#52525B] border border-[#3E3E44] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap transition-colors"
              >
                <Diamond className="w-2.5 h-2.5 fill-current text-amber-400" />
                +KF
              </button>
            )}
            {onCopyAttributes && (
              <button
                type="button"
                onClick={() => onCopyAttributes(selectedClip.id)}
                title="Copy Transform & FX Attributes"
                className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap transition-colors"
              >
                <Copy className="w-2.5 h-2.5 text-[#A1A1AA]" />
                Copy Attr
              </button>
            )}
            {onPasteAttributes && (
              <button
                type="button"
                disabled={!hasCopiedAttributes}
                onClick={() => onPasteAttributes(selectedClip.id)}
                title="Paste Copied Attributes"
                className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#2F3340] disabled:opacity-35 border border-[#3E3E44] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap transition-colors"
              >
                <ClipboardPaste className="w-2.5 h-2.5 text-[#A1A1AA]" />
                Paste
              </button>
            )}
            {onDeleteClip && (
              <button
                type="button"
                onClick={() => onDeleteClip(selectedClip.id)}
                title="Delete Selected Clip (Del)"
                className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-red-500/20 border border-[#3E3E44] text-[#A1A1AA] hover:text-red-300 flex items-center gap-1 whitespace-nowrap transition-colors"
              >
                <Trash2 className="w-2.5 h-2.5" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Transport & Scrubber Control Strip */}
      <div
        data-tutorial-target="playback-controls"
        className="px-3 py-2 bg-[#222225] border-t border-[#3E3E44] shrink-0 space-y-2"
      >
        <input
          type="range"
          min={0}
          max={Math.max(1, totalDuration)}
          step={1 / project.fps}
          value={playheadTime}
          onChange={(e) => {
            markInteractingPulse();
            onSeek(Number(e.target.value));
          }}
          className="w-full h-1.5 accent-[#A1A1AA] cursor-pointer"
        />

        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="font-mono-tabular text-sm font-semibold text-[#D4D4D8]">
              {formatTimecode(playheadTime, project.fps)}
            </span>
            <span className="font-mono-tabular text-[11px] text-[#A1A1AA]">
              / {formatTimecode(totalDuration, project.fps)}
            </span>
            {measuredFps !== null && (
              <span className="font-mono-tabular text-[10px] text-emerald-400">
                {measuredFps} FPS
              </span>
            )}
            {hoverPreviewPreset && (
              <span className="px-1.5 py-0.5 rounded bg-[#71717A]/15 border border-[#A1A1AA]/40 text-[10px] text-[#F4F4F5] flex items-center gap-1 max-w-[200px] truncate">
                {(hoverPreviewPending || isHoverRendering) && (
                  <Loader2 className="w-2.5 h-2.5 text-[#D4D4D8] animate-spin shrink-0" />
                )}
                <span className="truncate">
                  {hoverBypassOriginal ? 'Original' : `Hover: ${hoverPreviewPreset.name}`}
                </span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => onSeek(0)}
              title="Jump to Start"
              className="p-1.5 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] rounded transition-colors"
            >
              <SkipBack className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onSeek(Math.max(0, playheadTime - 1 / project.fps))}
              title="Previous Frame"
              className="p-1.5 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] rounded transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onTogglePlay}
              title="Play / Pause (Space)"
              className="px-3.5 py-1.5 bg-[#52525B] hover:bg-[#6B7280] text-[#F4F4F5] rounded-[5px] flex items-center gap-1.5 text-xs font-medium transition-colors"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              {isPlaying ? 'Pause' : 'Play'}
            </button>
            <button
              type="button"
              onClick={() => onSeek(Math.min(totalDuration, playheadTime + 1 / project.fps))}
              title="Next Frame"
              className="p-1.5 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] rounded transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onSeek(totalDuration)}
              title="Jump to End"
              className="p-1.5 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] rounded transition-colors"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-[11px]">
            <button
              type="button"
              onClick={onToggleMasterMute}
              title={masterMuted ? 'Unmute Audio' : 'Mute Audio'}
              className={`p-1.5 rounded-[5px] border transition-colors ${
                masterMuted
                  ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#F4F4F5]'
                  : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
              }`}
            >
              {masterMuted || masterVolume === 0 ? (
                <VolumeX className="w-3.5 h-3.5" />
              ) : (
                <Volume2 className="w-3.5 h-3.5" />
              )}
            </button>
            <input
              type="range"
              min={0}
              max={1.5}
              step={0.05}
              value={masterMuted ? 0 : masterVolume}
              onChange={(e) => onSetMasterVolume(Number(e.target.value))}
              title="Monitor Audio Volume"
              className="w-14 h-1 accent-[#A1A1AA] cursor-pointer hidden md:block"
            />
            <button
              type="button"
              onClick={onToggleLoop}
              title="Toggle Loop Playback"
              className={`p-1.5 rounded-[5px] border transition-colors ${
                loopEnabled
                  ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#F4F4F5]'
                  : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
              }`}
            >
              <Repeat className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setShowSafeMargins((s) => !s)}
              title="Toggle Safe Margins"
              className={`p-1.5 rounded-[5px] border transition-colors ${
                showSafeMargins
                  ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#F4F4F5]'
                  : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={onCaptureFramePNG}
              title="Export Snapshot Frame (PNG)"
              className="p-1.5 rounded-[5px] border border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5] transition-colors"
            >
              <Camera className="w-3.5 h-3.5" />
            </button>
            {onChangePreviewQuality && (
              <select
                value={effectivePreviewQuality}
                disabled={performanceMode}
                onChange={(e) => onChangePreviewQuality(e.target.value as PreviewQuality)}
                title={
                  performanceMode
                    ? 'Locked to Performance Mode (Exports remain full quality)'
                    : 'Preview Quality Preset (Final Export always renders full quality)'
                }
                className="px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded-[5px] text-[#F4F4F5] text-[11px] disabled:opacity-60 focus:outline-none focus:border-[#A1A1AA]"
              >
                <option value="ultra" className="bg-[#222225]">Ultra</option>
                <option value="high" className="bg-[#222225]">High</option>
                <option value="medium" className="bg-[#222225]">Medium</option>
                <option value="low" className="bg-[#222225]">Low</option>
                <option value="performance" className="bg-[#222225]">Perf</option>
              </select>
            )}
            <select
              value={project.proxyQuality}
              onChange={(e) => onChangeProxy(e.target.value as ProxyQuality)}
              title="Preview Resolution Scale (Final Export always uses 100%)"
              className="px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded-[5px] text-[#F4F4F5] font-mono-tabular text-[11px] focus:outline-none focus:border-[#A1A1AA]"
            >
              <option value="full" className="bg-[#222225]">Full Res</option>
              <option value="half" className="bg-[#222225]">1/2 Res</option>
              <option value="quarter" className="bg-[#222225]">1/4 Res</option>
              <option value="eighth" className="bg-[#222225]">1/8 Res</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};
