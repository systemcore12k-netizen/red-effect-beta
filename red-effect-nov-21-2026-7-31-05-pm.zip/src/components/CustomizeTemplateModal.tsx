import React, { useRef, useState } from 'react';
import { X, Sliders, Type, Music, Upload, Save, Play, RotateCcw } from 'lucide-react';
import {
  createDefaultRedRebellionCustomization,
  SavedCustomTemplate,
  TrailerTemplateCustomization,
} from '../services/trailerTemplate';
import { MediaAsset } from '../types/studio';
import { generateAudioWaveform } from '../services/audioEngine';

interface CustomizeTemplateModalProps {
  initialCustomization?: TrailerTemplateCustomization;
  onClose: () => void;
  onApplyAndOpen: (customization: TrailerTemplateCustomization) => void;
  onSaveAsCustomTemplate: (tpl: SavedCustomTemplate) => void;
}

const FONT_OPTIONS = ['Outfit', 'Impact', 'Arial Black', 'Plus Jakarta Sans', 'JetBrains Mono'];

export const CustomizeTemplateModal: React.FC<CustomizeTemplateModalProps> = ({
  initialCustomization,
  onClose,
  onApplyAndOpen,
  onSaveAsCustomTemplate,
}) => {
  const [cfg, setCfg] = useState<TrailerTemplateCustomization>(() =>
    initialCustomization
      ? structuredClone(initialCustomization)
      : createDefaultRedRebellionCustomization()
  );
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const musicInputRef = useRef<HTMLInputElement | null>(null);

  const handleMusicUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    let duration = 20;
    try {
      const audio = document.createElement('audio');
      audio.src = url;
      await new Promise<void>((resolve) => {
        audio.onloadedmetadata = () => {
          if (Number.isFinite(audio.duration) && audio.duration > 0) {
            duration = Math.min(20, audio.duration);
          }
          resolve();
        };
        audio.onerror = () => resolve();
      });
    } catch {
      // Fallback 20s
    }
    const customAsset: MediaAsset = {
      id: `asset-custom-music-${Date.now()}`,
      name: file.name,
      type: 'audio',
      mimeType: file.type || 'audio/mpeg',
      url,
      duration,
      folder: 'Media/Audio',
      createdAt: Date.now(),
      hasAudio: true,
      waveformPeaks: [],
    };
    const wf = await generateAudioWaveform(customAsset).catch(() => ({
      peaks: [] as number[],
      hasAudio: true,
    }));
    customAsset.waveformPeaks = wf.peaks;
    customAsset.hasAudio = wf.hasAudio;
    setCfg((prev) => ({ ...prev, customMusicAsset: customAsset }));
    e.target.value = '';
  };

  const handleSaveCustom = () => {
    const entry: SavedCustomTemplate = {
      id: `tpl-custom-${Date.now().toString(36)}`,
      name: cfg.templateName.trim() || 'Custom Red Trailer',
      category: '2D Typography',
      duration: 20,
      aspectRatio: '16:9',
      width: 1920,
      height: 1080,
      fps: 60,
      createdAt: Date.now(),
      customization: structuredClone(cfg),
    };
    onSaveAsCustomTemplate(entry);
    setSavedNotice(`Saved "${entry.name}" to Templates Library`);
    setTimeout(() => setSavedNotice(null), 2600);
  };

  return (
    <div className="fixed inset-0 z-[140] bg-black/75 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl max-h-[88vh] bg-[#222225] border border-[#3E3E44] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs text-[#F4F4F5]">
        {/* Header */}
        <div className="px-4 py-3 bg-[#2C2C30] border-b border-[#3E3E44] flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <Sliders className="w-4 h-4 text-[#D4D4D8] shrink-0" />
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-[#F4F4F5] truncate">
                Customize Template — {cfg.templateName}
              </h2>
              <p className="text-[11px] text-[#A1A1AA]">
                2D Typography · 20.0s · 1920×1080 · 60 FPS · 12 Editable Layers
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setCfg(createDefaultRedRebellionCustomization())}
              className="px-2.5 py-1 rounded bg-[#222225] hover:bg-[#2E323E] border border-[#3E3E44] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap"
            >
              <RotateCcw className="w-3 h-3" />
              Reset Defaults
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2E323E] rounded"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 min-h-0 overflow-y-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left Column: 7 Beat Headlines */}
          <div className="lg:col-span-7 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#A1A1AA] flex items-center gap-1.5">
                <Type className="w-3.5 h-3.5 text-[#D4D4D8]" />
                7-Section Narrative Headlines
              </span>
              <span className="text-[10px] font-mono-tabular text-[#A1A1AA]">00:00 → 00:20</span>
            </div>

            <div className="space-y-2">
              {cfg.sections.map((sec, idx) => (
                <div
                  key={sec.id}
                  className="p-2.5 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-1.5"
                >
                  <div className="flex items-center justify-between text-[10px] font-mono-tabular">
                    <span className="text-[#F4F4F5] font-semibold">
                      0{idx + 1} · {sec.label}
                    </span>
                    <span className="text-[#E4E4E7]">{sec.timeRange}</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] text-[#A1A1AA] mb-0.5">Main Title</label>
                      <input
                        type="text"
                        value={sec.mainText}
                        onChange={(e) =>
                          setCfg((prev) => ({
                            ...prev,
                            sections: prev.sections.map((s, i) =>
                              i === idx ? { ...s, mainText: e.target.value } : s
                            ),
                          }))
                        }
                        className="w-full px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] font-medium focus:outline-none focus:border-[#A1A1AA]"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-[#A1A1AA] mb-0.5">
                        Secondary Caption
                      </label>
                      <input
                        type="text"
                        value={sec.subText}
                        onChange={(e) =>
                          setCfg((prev) => ({
                            ...prev,
                            sections: prev.sections.map((s, i) =>
                              i === idx ? { ...s, subText: e.target.value } : s
                            ),
                          }))
                        }
                        className="w-full px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Typography, Colors, FX Strength & Audio */}
          <div className="lg:col-span-5 space-y-3">
            <div className="p-3 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-3">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
                Style &amp; Identity
              </div>

              <div>
                <label className="block text-[10px] text-[#A1A1AA] mb-1">Template Name</label>
                <input
                  type="text"
                  value={cfg.templateName}
                  onChange={(e) => setCfg((p) => ({ ...p, templateName: e.target.value }))}
                  className="w-full px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                />
              </div>

              <div>
                <label className="block text-[10px] text-[#A1A1AA] mb-1">Typography Font</label>
                <select
                  value={cfg.fontFamily}
                  onChange={(e) => setCfg((p) => ({ ...p, fontFamily: e.target.value }))}
                  className="w-full px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                >
                  {FONT_OPTIONS.map((f) => (
                    <option key={f} value={f}>
                      {f}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[10px] text-[#A1A1AA] mb-1">Text Fill Color</label>
                  <div className="flex items-center gap-2 bg-[#18181A] border border-[#3E3E44] rounded px-2 py-1">
                    <input
                      type="color"
                      value={cfg.primaryColor}
                      onChange={(e) => setCfg((p) => ({ ...p, primaryColor: e.target.value }))}
                      className="w-5 h-5 bg-transparent border-0 cursor-pointer"
                    />
                    <span className="font-mono-tabular text-[11px] text-zinc-300">
                      {cfg.primaryColor.toUpperCase()}
                    </span>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] text-[#A1A1AA] mb-1">
                    Crimson / Light Accent
                  </label>
                  <div className="flex items-center gap-2 bg-[#18181A] border border-[#3E3E44] rounded px-2 py-1">
                    <input
                      type="color"
                      value={cfg.accentColor}
                      onChange={(e) => setCfg((p) => ({ ...p, accentColor: e.target.value }))}
                      className="w-5 h-5 bg-transparent border-0 cursor-pointer"
                    />
                    <span className="font-mono-tabular text-[11px] text-[#F4F4F5]">
                      {cfg.accentColor.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Dynamics & Intensity */}
            <div className="p-3 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-2.5">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
                FX &amp; Motion Dynamics
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-[#F4F4F5]">Camera Shake Strength</span>
                  <span className="font-mono-tabular text-[#A1A1AA]">
                    {Math.round(cfg.shakeStrength * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0.2}
                  max={2}
                  step={0.05}
                  value={cfg.shakeStrength}
                  onChange={(e) =>
                    setCfg((p) => ({ ...p, shakeStrength: Number(e.target.value) }))
                  }
                  className="w-full h-1 cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-[#F4F4F5]">Glitch, Glow &amp; Smoke Intensity</span>
                  <span className="font-mono-tabular text-[#A1A1AA]">
                    {Math.round(cfg.effectIntensity * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0.2}
                  max={2}
                  step={0.05}
                  value={cfg.effectIntensity}
                  onChange={(e) =>
                    setCfg((p) => ({ ...p, effectIntensity: Number(e.target.value) }))
                  }
                  className="w-full h-1 cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-[#F4F4F5]">Text Animation Speed</span>
                  <span className="font-mono-tabular text-[#A1A1AA]">
                    {cfg.animationSpeed.toFixed(2)}×
                  </span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={2}
                  step={0.05}
                  value={cfg.animationSpeed}
                  onChange={(e) =>
                    setCfg((p) => ({ ...p, animationSpeed: Number(e.target.value) }))
                  }
                  className="w-full h-1 cursor-pointer"
                />
              </div>
            </div>

            {/* Soundtrack Replacement */}
            <div className="p-3 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-2">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-[#A1A1AA] flex items-center gap-1.5">
                <Music className="w-3.5 h-3.5 text-emerald-400" />
                Trailer Music Track
              </div>
              <div className="text-[11px] text-[#F4F4F5] bg-[#18181A] border border-[#3E3E44] rounded px-2.5 py-2 flex items-center justify-between gap-2">
                <span className="truncate">
                  {cfg.customMusicAsset
                    ? cfg.customMusicAsset.name
                    : 'Built-in Dark Pulse 120 BPM (Royalty-Free WAV)'}
                </span>
                {cfg.customMusicAsset && (
                  <button
                    type="button"
                    onClick={() => setCfg((p) => ({ ...p, customMusicAsset: null }))}
                    className="text-[10px] text-rose-400 hover:underline shrink-0"
                  >
                    Use Default
                  </button>
                )}
              </div>
              <input
                ref={musicInputRef}
                type="file"
                accept="audio/*,.mp3,.wav,.aac,.m4a,.ogg"
                onChange={handleMusicUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => musicInputRef.current?.click()}
                className="w-full py-1.5 px-3 bg-[#222225] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5] flex items-center justify-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5 text-emerald-400" />
                Replace Music Audio File...
              </button>
            </div>

            {savedNotice && (
              <div className="px-3 py-2 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-[11px]">
                {savedNotice}
              </div>
            )}
          </div>
        </div>

        {/* Footer CTA */}
        <div className="px-4 py-3 bg-[#2C2C30] border-t border-[#3E3E44] flex items-center justify-between gap-3 shrink-0">
          <span className="text-[11px] text-[#A1A1AA] hidden sm:inline">
            Opens all 12 layers onto the timeline for full manual keyframe &amp; FX editing.
          </span>
          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={handleSaveCustom}
              className="px-3 py-1.5 rounded bg-[#222225] hover:bg-[#2E323E] border border-[#3E3E44] text-[#F4F4F5] font-medium flex items-center gap-1.5 whitespace-nowrap"
            >
              <Save className="w-3.5 h-3.5 text-amber-400" />
              Save Custom Template
            </button>
            <button
              type="button"
              onClick={() => onApplyAndOpen(cfg)}
              className="px-4 py-1.5 rounded bg-[#52525B] hover:bg-[#6B7280] text-white font-semibold flex items-center gap-1.5 whitespace-nowrap"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              Apply &amp; Open in Timeline
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
