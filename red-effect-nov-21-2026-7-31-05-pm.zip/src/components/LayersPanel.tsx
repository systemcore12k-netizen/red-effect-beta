import React from 'react';
import {
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Box,
  Crosshair,
  Diamond,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import { BlendMode, StudioProject, TimelineClip } from '../types/studio';

interface LayersPanelProps {
  project: StudioProject;
  selectedClipId: string | null;
  playheadTime: number;
  onSelectClip: (clipId: string) => void;
  onUpdateClip: (clipId: string, updater: (c: TimelineClip) => TimelineClip) => void;
  onSeek: (time: number) => void;
}

export const LayersPanel: React.FC<LayersPanelProps> = ({
  project,
  selectedClipId,
  playheadTime,
  onSelectClip,
  onUpdateClip,
  onSeek,
}) => {
  const visualClips = project.clips
    .filter((c) => c.type !== 'audio')
    .sort((a, b) => {
      const idxA = project.tracks.findIndex((t) => t.id === a.trackId);
      const idxB = project.tracks.findIndex((t) => t.id === b.trackId);
      if (idxA !== idxB) return idxA - idxB;
      return a.startTime - b.startTime;
    });

  const moveClipTrack = (clip: TimelineClip, dir: -1 | 1) => {
    const visualTracks = project.tracks.filter((t) => t.kind !== 'audio');
    const curIdx = visualTracks.findIndex((t) => t.id === clip.trackId);
    const nextTrack = visualTracks[curIdx + dir];
    if (!nextTrack) return;
    onUpdateClip(clip.id, (c) => ({ ...c, trackId: nextTrack.id }));
  };

  return (
    <div className="p-2.5 space-y-2 text-xs bg-[#222225] text-[#F4F4F5] h-full overflow-y-auto">
      <div className="flex items-center justify-between text-[11px] text-[#A1A1AA] border-b border-[#3E3E44] pb-1.5">
        <span>Composition Layer Stack</span>
        <span className="font-mono-tabular text-[#A1A1AA]">{visualClips.length} layers</span>
      </div>

      {visualClips.length === 0 ? (
        <div className="text-center py-6 text-[#A1A1AA] text-[11px]">
          No visual or motion layers in sequence.
        </div>
      ) : (
        <div className="space-y-1.5">
          {visualClips.map((clip) => {
            const isSelected = clip.id === selectedClipId;
            const isActiveAtPlayhead =
              playheadTime >= clip.startTime && playheadTime <= clip.startTime + clip.duration;
            const parentObj = clip.parentClipId
              ? project.clips.find((p) => p.id === clip.parentClipId)
              : null;

            return (
              <div
                key={clip.id}
                onClick={() => onSelectClip(clip.id)}
                className={`p-2 rounded border transition-colors cursor-pointer space-y-1.5 ${
                  isSelected
                    ? 'bg-[#71717A]/15 border-[#A1A1AA]'
                    : 'bg-[#2C2C30] border-[#3E3E44] hover:border-[#A1A1AA]/50'
                }`}
              >
                <div className="flex items-center justify-between gap-1.5">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateClip(clip.id, (c) => ({ ...c, visible: !c.visible }));
                      }}
                      title="Toggle Visibility"
                      className={clip.visible ? 'text-[#F4F4F5]' : 'text-[#6E7280]'}
                    >
                      {clip.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateClip(clip.id, (c) => ({ ...c, locked: !c.locked }));
                      }}
                      title="Lock Layer"
                      className={clip.locked ? 'text-amber-400' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'}
                    >
                      {clip.locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                    </button>
                    <span
                      className={`font-medium truncate ${
                        isActiveAtPlayhead ? 'text-[#F4F4F5]' : 'text-[#A1A1AA]'
                      }`}
                    >
                      {clip.type === 'null' ? `[NULL] ${clip.name}` : clip.name}
                    </span>
                    {parentObj && (
                      <span className="text-[9px] px-1 py-0.5 rounded bg-[#18181A] border border-[#3E3E44] text-[#D4D4D8] shrink-0">
                        ↳ {parentObj.name}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        moveClipTrack(clip, -1);
                      }}
                      title="Move Layer Up"
                      className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5]"
                    >
                      <ArrowUp className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        moveClipTrack(clip, 1);
                      }}
                      title="Move Layer Down"
                      className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5]"
                    >
                      <ArrowDown className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Blend Mode, 3D Layer, Motion Tracking */}
                <div className="flex items-center justify-between gap-1.5 text-[10px]">
                  <select
                    value={clip.blendMode}
                    onClick={(e) => e.stopPropagation()}
                    onChange={(e) =>
                      onUpdateClip(clip.id, (c) => ({
                        ...c,
                        blendMode: e.target.value as BlendMode,
                      }))
                    }
                    className="px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  >
                    <option value="normal">Normal</option>
                    <option value="screen">Screen</option>
                    <option value="multiply">Multiply</option>
                    <option value="overlay">Overlay</option>
                    <option value="add">Add</option>
                  </select>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateClip(clip.id, (c) => ({ ...c, is3DLayer: !c.is3DLayer }));
                      }}
                      title="Toggle 3D Camera Parallax Layer"
                      className={`px-1.5 py-0.5 rounded border flex items-center gap-1 ${
                        clip.is3DLayer
                          ? 'border-[#A1A1AA]/60 bg-[#71717A]/20 text-[#E4E4E7]'
                          : 'border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                      }`}
                    >
                      <Box className="w-2.5 h-2.5" />
                      3D
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateClip(clip.id, (c) => ({
                          ...c,
                          motionTrack: { ...c.motionTrack, enabled: !c.motionTrack.enabled },
                        }));
                      }}
                      title="Toggle Motion Tracking Anchor"
                      className={`px-1.5 py-0.5 rounded border flex items-center gap-1 ${
                        clip.motionTrack.enabled
                          ? 'border-amber-500/50 bg-amber-500/20 text-amber-300'
                          : 'border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                      }`}
                    >
                      <Crosshair className="w-2.5 h-2.5" />
                      Track
                    </button>
                  </div>
                </div>

                {/* Keyframe Dope-Sheet Strip */}
                {clip.keyframes.length > 0 && (
                  <div className="pt-1 border-t border-[#3E3E44]/60 flex items-center gap-1 flex-wrap">
                    <span className="text-[10px] text-[#A1A1AA]">Keys:</span>
                    {clip.keyframes.map((kf) => (
                      <button
                        key={kf.id}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSeek(clip.startTime + kf.time);
                        }}
                        title={`Jump to ${kf.property} keyframe at ${kf.time.toFixed(2)}s`}
                        className="px-1 py-0.5 bg-[#71717A]/15 hover:bg-[#71717A]/30 text-[#E4E4E7] rounded text-[9px] font-mono-tabular flex items-center gap-0.5"
                      >
                        <Diamond className="w-2 h-2 fill-current" />
                        {kf.property}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
