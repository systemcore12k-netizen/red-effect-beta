import React from 'react';
import {
  ChevronDown,
  ChevronUp,
  ExternalLink,
  GripVertical,
  Maximize2,
  Minimize2,
  PanelBottom,
  X,
} from 'lucide-react';
import { PanelId } from '../types/studio';

interface PanelShellProps {
  panelId: PanelId;
  title: string;
  subtitle?: string;
  headerRight?: React.ReactNode;
  isMaximized?: boolean;
  isCollapsed?: boolean;
  isFloating?: boolean;
  canClose?: boolean;
  canFloat?: boolean;
  onToggleMaximize?: () => void;
  onToggleCollapse?: () => void;
  onToggleFloat?: () => void;
  onClosePanel?: () => void;
  onSwapPanels?: (sourceId: PanelId, targetId: PanelId) => void;
  onDragHeaderMouseDown?: (e: React.MouseEvent<HTMLDivElement>) => void;
  children: React.ReactNode;
  className?: string;
}

export const PanelShell: React.FC<PanelShellProps> = ({
  panelId,
  title,
  subtitle,
  headerRight,
  isMaximized,
  isCollapsed = false,
  isFloating = false,
  canClose = false,
  canFloat = true,
  onToggleMaximize,
  onToggleCollapse,
  onToggleFloat,
  onClosePanel,
  onSwapPanels,
  onDragHeaderMouseDown,
  children,
  className = '',
}) => {
  const [dragOver, setDragOver] = React.useState(false);

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    if (isFloating) return;
    e.dataTransfer.setData('application/x-redeffect-panel', panelId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    if (isFloating) return;
    if (e.dataTransfer.types.includes('application/x-redeffect-panel')) {
      e.preventDefault();
      setDragOver(true);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    if (isFloating) return;
    setDragOver(false);
    const sourceId = e.dataTransfer.getData('application/x-redeffect-panel') as PanelId;
    if (sourceId && sourceId !== panelId && onSwapPanels) {
      onSwapPanels(sourceId, panelId);
    }
  };

  return (
    <section
      onDragOver={handleDragOver}
      onDragLeave={() => setDragOver(false)}
      onDrop={handleDrop}
      className={`flex flex-col bg-[#222225] border transition-colors min-h-0 min-w-0 overflow-hidden ${
        dragOver ? 'border-[#A1A1AA] ring-1 ring-[#A1A1AA]/40' : 'border-[#3E3E44]'
      } ${className}`}
    >
      <div
        draggable={Boolean(onSwapPanels) && !isFloating}
        onDragStart={handleDragStart}
        onMouseDown={onDragHeaderMouseDown}
        title={
          isFloating
            ? 'Drag title bar to move floating window'
            : 'Drag panel header onto another panel to dock or swap'
        }
        className={`h-8 px-2.5 flex items-center justify-between gap-2 bg-[#2C2C30] border-b border-[#3E3E44] shrink-0 ${
          isFloating ? 'cursor-move' : 'cursor-grab active:cursor-grabbing'
        }`}
      >
        <div className="flex items-center gap-1.5 min-w-0">
          <GripVertical className="w-3.5 h-3.5 text-[#A1A1AA]/70 shrink-0" />
          <h2 className="font-display text-[11px] font-semibold uppercase tracking-wider text-[#F4F4F5] truncate">
            {title}
          </h2>
          {subtitle && (
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular truncate hidden sm:inline">
              · {subtitle}
            </span>
          )}
        </div>
        <div
          className="flex items-center gap-0.5 shrink-0"
          onMouseDown={(e) => e.stopPropagation()}
        >
          {headerRight}
          {onToggleCollapse && !isFloating && (
            <button
              type="button"
              onClick={onToggleCollapse}
              title={isCollapsed ? 'Expand panel' : 'Collapse panel'}
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-white/[0.06] rounded transition-colors"
            >
              {isCollapsed ? (
                <ChevronDown className="w-3.5 h-3.5" />
              ) : (
                <ChevronUp className="w-3.5 h-3.5" />
              )}
            </button>
          )}
          {onToggleFloat && canFloat && (
            <button
              type="button"
              onClick={onToggleFloat}
              title={isFloating ? 'Dock back into workspace' : 'Undock / Float panel'}
              className={`p-1 rounded transition-colors ${
                isFloating
                  ? 'text-[#D4D4D8] hover:text-[#F4F4F5] hover:bg-white/[0.06]'
                  : 'text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-white/[0.06]'
              }`}
            >
              {isFloating ? (
                <PanelBottom className="w-3.5 h-3.5" />
              ) : (
                <ExternalLink className="w-3.5 h-3.5" />
              )}
            </button>
          )}
          {onToggleMaximize && !isFloating && (
            <button
              type="button"
              onClick={onToggleMaximize}
              title={isMaximized ? 'Restore panel' : 'Expand / Maximize panel'}
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-white/[0.06] rounded transition-colors"
            >
              {isMaximized ? (
                <Minimize2 className="w-3.5 h-3.5 text-[#D4D4D8]" />
              ) : (
                <Maximize2 className="w-3.5 h-3.5" />
              )}
            </button>
          )}
          {onClosePanel && canClose && (
            <button
              type="button"
              onClick={onClosePanel}
              title="Close panel (reopen from View menu)"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-white/[0.06] rounded transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
      {!isCollapsed && (
        <div className="flex-1 min-h-0 overflow-auto bg-[#222225]">{children}</div>
      )}
    </section>
  );
};
