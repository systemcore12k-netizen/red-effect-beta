import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  GraduationCap,
  LocateFixed,
  RotateCcw,
  Sparkles,
  X,
} from 'lucide-react';
import {
  PanelId,
  StudioProject,
  TimelineClip,
  WorkspaceMode,
} from '../types/studio';
import {
  TUTORIAL_CHAPTERS,
  TUTORIAL_STEPS,
  TutorialCompletionContext,
  TutorialStep,
} from '../services/tutorialData';

interface SpotlightRect {
  left: number;
  top: number;
  width: number;
  height: number;
}

interface InteractiveTutorialOverlayProps {
  isOpen: boolean;
  project: StudioProject;
  selectedClip: TimelineClip | null;
  workspaceMode: WorkspaceMode;
  slots: {
    leftTop: PanelId;
    leftBottom: PanelId;
    center: PanelId;
    right: PanelId;
    bottom: PanelId;
  };
  playheadTime: number;
  isPlaying: boolean;
  autoKeyframeEnabled: boolean;
  exportModalOpen: boolean;
  activeStepIndex: number;
  completedStepIds: string[];
  onChangeStepIndex: (nextIndex: number) => void;
  onMarkStepCompleted: (stepId: string) => void;
  onAutoFocusStepPanel: (step: TutorialStep) => void;
  onRestartTutorial: () => void;
  onCloseTutorial: () => void;
}

export const InteractiveTutorialOverlay: React.FC<InteractiveTutorialOverlayProps> = ({
  isOpen,
  project,
  selectedClip,
  workspaceMode,
  slots,
  playheadTime,
  isPlaying,
  autoKeyframeEnabled,
  exportModalOpen,
  activeStepIndex,
  completedStepIds,
  onChangeStepIndex,
  onMarkStepCompleted,
  onAutoFocusStepPanel,
  onRestartTutorial,
  onCloseTutorial,
}) => {
  const [targetRect, setTargetRect] = useState<SpotlightRect | null>(null);
  const [chapterMenuOpen, setChapterMenuOpen] = useState(false);
  const onMarkStepCompletedRef = useRef(onMarkStepCompleted);
  onMarkStepCompletedRef.current = onMarkStepCompleted;

  const safeIndex = Math.max(0, Math.min(TUTORIAL_STEPS.length - 1, activeStepIndex));
  const currentStep = TUTORIAL_STEPS[safeIndex];
  const isFirstStep = safeIndex === 0;
  const isLastStep = safeIndex === TUTORIAL_STEPS.length - 1;

  const completionCtx: TutorialCompletionContext = useMemo(
    () => ({
      project,
      selectedClip,
      workspaceMode,
      slots,
      playheadTime,
      isPlaying,
      autoKeyframeEnabled,
      exportModalOpen,
    }),
    [
      project,
      selectedClip,
      workspaceMode,
      slots,
      playheadTime,
      isPlaying,
      autoKeyframeEnabled,
      exportModalOpen,
    ]
  );

  // Auto-mark live action completion if step defines a predicate
  useEffect(() => {
    if (!isOpen || !currentStep.checkCompleted) return;
    if (completedStepIds.includes(currentStep.id)) return;
    if (currentStep.checkCompleted(completionCtx)) {
      onMarkStepCompletedRef.current(currentStep.id);
    }
  }, [isOpen, currentStep, completionCtx, completedStepIds]);

  // Dynamically track spotlight target bounds
  useLayoutEffect(() => {
    if (!isOpen) return;

    const measure = () => {
      const el = document.querySelector(currentStep.targetSelector) as HTMLElement | null;
      if (!el) {
        setTargetRect((prev) => (prev === null ? prev : null));
        return;
      }
      const r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) {
        setTargetRect((prev) => (prev === null ? prev : null));
        return;
      }
      const pad = 6;
      const nextRect: SpotlightRect = {
        left: Math.round(Math.max(4, r.left - pad)),
        top: Math.round(Math.max(4, r.top - pad)),
        width: Math.round(Math.min(window.innerWidth - 8, r.width + pad * 2)),
        height: Math.round(Math.min(window.innerHeight - 8, r.height + pad * 2)),
      };
      setTargetRect((prev) =>
        prev &&
        prev.left === nextRect.left &&
        prev.top === nextRect.top &&
        prev.width === nextRect.width &&
        prev.height === nextRect.height
          ? prev
          : nextRect
      );
    };

    measure();
    const timer = window.setInterval(measure, 180);
    window.addEventListener('resize', measure);
    window.addEventListener('scroll', measure, true);

    return () => {
      window.clearInterval(timer);
      window.removeEventListener('resize', measure);
      window.removeEventListener('scroll', measure, true);
    };
  }, [isOpen, currentStep.targetSelector, workspaceMode, slots]);

  if (!isOpen) return null;

  const vw = typeof window !== 'undefined' ? window.innerWidth : 1280;
  const vh = typeof window !== 'undefined' ? window.innerHeight : 720;
  const cardWidth = Math.min(410, vw - 24);
  const cardHeightEst = 290;

  // Smart non-overlapping floating card position near target
  let cardLeft = Math.round((vw - cardWidth) / 2);
  let cardTop = Math.round((vh - cardHeightEst) / 2);
  let arrowDir: 'up' | 'down' | 'left' | 'right' | null = null;

  if (targetRect) {
    const spaceBelow = vh - (targetRect.top + targetRect.height);
    const spaceAbove = targetRect.top;
    const spaceRight = vw - (targetRect.left + targetRect.width);
    const spaceLeft = targetRect.left;

    if (spaceBelow >= cardHeightEst + 20) {
      cardTop = targetRect.top + targetRect.height + 16;
      cardLeft = Math.max(12, Math.min(vw - cardWidth - 12, targetRect.left + targetRect.width / 2 - cardWidth / 2));
      arrowDir = 'up';
    } else if (spaceAbove >= cardHeightEst + 20) {
      cardTop = Math.max(12, targetRect.top - cardHeightEst - 16);
      cardLeft = Math.max(12, Math.min(vw - cardWidth - 12, targetRect.left + targetRect.width / 2 - cardWidth / 2));
      arrowDir = 'down';
    } else if (spaceRight >= cardWidth + 24) {
      cardLeft = targetRect.left + targetRect.width + 16;
      cardTop = Math.max(12, Math.min(vh - cardHeightEst - 12, targetRect.top + targetRect.height / 2 - cardHeightEst / 2));
      arrowDir = 'left';
    } else if (spaceLeft >= cardWidth + 24) {
      cardLeft = Math.max(12, targetRect.left - cardWidth - 16);
      cardTop = Math.max(12, Math.min(vh - cardHeightEst - 12, targetRect.top + targetRect.height / 2 - cardHeightEst / 2));
      arrowDir = 'right';
    } else {
      cardLeft = vw - cardWidth - 18;
      cardTop = 58;
    }
  }

  const isStepDone =
    completedStepIds.includes(currentStep.id) ||
    Boolean(currentStep.checkCompleted?.(completionCtx));

  const progressPct = Math.round(((safeIndex + 1) / TUTORIAL_STEPS.length) * 100);

  const goToStep = (idx: number) => {
    const clamped = Math.max(0, Math.min(TUTORIAL_STEPS.length - 1, idx));
    const step = TUTORIAL_STEPS[clamped];
    onMarkStepCompleted(currentStep.id);
    onAutoFocusStepPanel(step);
    onChangeStepIndex(clamped);
    setChapterMenuOpen(false);
  };

  return (
    <div className="fixed inset-0 z-[70] pointer-events-none select-none">
      {/* Dark Cutout Backdrop SVG */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none">
        <defs>
          <mask id="tutorial-spotlight-mask">
            <rect x="0" y="0" width="100%" height="100%" fill="white" />
            {targetRect && (
              <rect
                x={targetRect.left}
                y={targetRect.top}
                width={targetRect.width}
                height={targetRect.height}
                rx="6"
                fill="black"
              />
            )}
          </mask>
        </defs>
        <rect
          x="0"
          y="0"
          width="100%"
          height="100%"
          fill="rgba(5, 5, 8, 0.58)"
          mask="url(#tutorial-spotlight-mask)"
        />
      </svg>

      {/* Highlight Pulsing Border */}
      {targetRect && (
        <div
          style={{
            left: targetRect.left,
            top: targetRect.top,
            width: targetRect.width,
            height: targetRect.height,
          }}
          className="fixed rounded-md border-2 border-[#A1A1AA] shadow-[0_0_0_3px_rgba(139,112,232,0.22),0_0_24px_rgba(139,112,232,0.45)] transition-all duration-200 pointer-events-none"
        >
          <span className="absolute -top-2.5 left-2 px-1.5 py-0.5 rounded bg-[#52525B] text-white text-[9px] font-bold tracking-wider uppercase shadow">
            Active Focus
          </span>
        </div>
      )}

      {/* Floating Guide Card (Interactive) */}
      <div
        style={{ left: cardLeft, top: cardTop, width: cardWidth }}
        className="fixed pointer-events-auto bg-[#222225] border border-[#A1A1AA]/60 rounded-lg shadow-[0_18px_50px_rgba(0,0,0,0.85)] text-xs text-[#F4F4F5] transition-all duration-200"
      >
        {/* Optional Arrow Pointer */}
        {arrowDir === 'up' && (
          <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3.5 h-3.5 rotate-45 bg-[#222225] border-l border-t border-[#A1A1AA]/60" />
        )}
        {arrowDir === 'down' && (
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-3.5 h-3.5 rotate-45 bg-[#222225] border-r border-b border-[#A1A1AA]/60" />
        )}
        {arrowDir === 'left' && (
          <div className="absolute top-1/2 -left-2 -translate-y-1/2 w-3.5 h-3.5 rotate-45 bg-[#222225] border-l border-b border-[#A1A1AA]/60" />
        )}
        {arrowDir === 'right' && (
          <div className="absolute top-1/2 -right-2 -translate-y-1/2 w-3.5 h-3.5 rotate-45 bg-[#222225] border-r border-t border-[#A1A1AA]/60" />
        )}

        {/* Header Strip */}
        <div className="px-3.5 py-2.5 bg-[#2C2C30] border-b border-[#3E3E44] rounded-t-lg flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-6 h-6 rounded bg-[#71717A]/20 border border-[#A1A1AA]/50 flex items-center justify-center shrink-0">
              <GraduationCap className="w-3.5 h-3.5 text-[#E4E4E7]" />
            </div>
            <div className="min-w-0">
              <div className="text-[10px] font-bold uppercase tracking-wider text-[#E4E4E7] truncate">
                {currentStep.chapterTitle}
              </div>
              <div className="text-[10px] text-[#A1A1AA] font-mono-tabular">
                Step {safeIndex + 1} of {TUTORIAL_STEPS.length} · Section {currentStep.stepNumberLabel}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            {/* Chapter Jump Menu */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setChapterMenuOpen((v) => !v)}
                className="px-2 py-1 rounded bg-[#18181A] border border-[#3E3E44] hover:border-[#A1A1AA]/60 text-[10px] text-[#F4F4F5] flex items-center gap-1"
                title="Jump to Tutorial Chapter"
              >
                Chapters
                <ChevronDown className="w-3 h-3" />
              </button>
              {chapterMenuOpen && (
                <div className="absolute right-0 mt-1 w-64 max-h-72 overflow-y-auto bg-[#222225] border border-[#3E3E44] rounded-md shadow-2xl py-1 z-30">
                  {TUTORIAL_CHAPTERS.map((ch) => {
                    const firstIdx = TUTORIAL_STEPS.findIndex((s) => s.chapterId === ch.id);
                    const isCurrCh = currentStep.chapterId === ch.id;
                    return (
                      <button
                        key={ch.id}
                        type="button"
                        onClick={() => {
                          if (firstIdx >= 0) goToStep(firstIdx);
                        }}
                        className={`w-full px-3 py-1.5 text-left hover:bg-[#2E323E] flex items-start gap-2 ${
                          isCurrCh ? 'bg-[#71717A]/20 text-white' : 'text-[#F4F4F5]'
                        }`}
                      >
                        <span className="text-[10px] font-mono-tabular text-[#E4E4E7] font-bold mt-0.5 shrink-0">
                          {ch.id}.
                        </span>
                        <span className="min-w-0">
                          <div className="text-[11px] font-semibold truncate">{ch.title}</div>
                          <div className="text-[10px] text-[#A1A1AA] truncate">{ch.summary}</div>
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={onCloseTutorial}
              title="Close RED EFFECT Tutorial"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] rounded hover:bg-[#2E323E]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1 bg-[#18181A]">
          <div
            style={{ width: `${progressPct}%` }}
            className="h-full bg-[#52525B] transition-[width] duration-200"
          />
        </div>

        {/* Body Content */}
        <div className="p-3.5 space-y-2.5">
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-sm font-bold text-[#F4F4F5] leading-snug">{currentStep.title}</h3>
            {isStepDone && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-[10px] font-semibold shrink-0">
                <CheckCircle2 className="w-3 h-3" />
                Done
              </span>
            )}
          </div>

          <p className="text-[11.5px] text-[#A1A1AA] leading-relaxed">
            {currentStep.description}
          </p>

          <div className="px-2.5 py-2 rounded bg-[#2C2C30] border border-[#3E3E44] flex items-start gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0 mt-0.5" />
            <div className="text-[11px] text-[#F4F4F5] leading-snug flex-1">
              <span className="font-semibold text-[#E4E4E7]">Try it: </span>
              {currentStep.actionHint}
            </div>
            {!targetRect && (
              <button
                type="button"
                onClick={() => onAutoFocusStepPanel(currentStep)}
                className="px-1.5 py-0.5 rounded bg-[#71717A]/20 border border-[#A1A1AA]/40 text-[10px] text-[#E4E4E7] hover:bg-[#71717A]/40 flex items-center gap-1 shrink-0"
              >
                <LocateFixed className="w-3 h-3" />
                Focus Panel
              </button>
            )}
          </div>
        </div>

        {/* Footer Action Bar */}
        <div className="px-3.5 py-2.5 bg-[#18181A] border-t border-[#3E3E44] rounded-b-lg flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onRestartTutorial}
              title="Restart Tutorial from Chapter 1"
              className="px-2 py-1 rounded text-[11px] text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              Restart
            </button>
            <button
              type="button"
              onClick={onCloseTutorial}
              className="px-2 py-1 rounded text-[11px] text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]"
            >
              Skip
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              disabled={isFirstStep}
              onClick={() => goToStep(safeIndex - 1)}
              className="px-2.5 py-1.5 rounded bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] disabled:opacity-40 text-[#F4F4F5] text-[11px] font-medium flex items-center gap-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              Previous
            </button>
            {isLastStep ? (
              <button
                type="button"
                onClick={() => {
                  onMarkStepCompleted(currentStep.id);
                  onCloseTutorial();
                }}
                className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold flex items-center gap-1"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Finish Tutorial
              </button>
            ) : (
              <button
                type="button"
                onClick={() => goToStep(safeIndex + 1)}
                className="px-3 py-1.5 rounded bg-[#52525B] hover:bg-[#6B7280] text-white text-[11px] font-semibold flex items-center gap-1"
              >
                Next Step
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
