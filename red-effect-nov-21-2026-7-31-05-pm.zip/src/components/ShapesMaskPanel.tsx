import React from 'react';
import {
  Square,
  Circle,
  Star,
  Hexagon,
  PenTool,
  Layers,
  Diamond,
  Trash2,
} from 'lucide-react';
import { BezierPoint, MaskMode, ShapeKind, ShapeProperties } from '../types/effects';
import { KeyframeProperty, MaskShape, TimelineClip } from '../types/studio';

interface ShapesMaskPanelProps {
  selectedClip: TimelineClip | null;
  playheadTime: number;
  penToolActive: boolean;
  onTogglePenTool: () => void;
  onAddShapeClip: (shape: ShapeKind) => void;
  onUpdateClip: (clipId: string, updater: (c: TimelineClip) => TimelineClip) => void;
}

const DEFAULT_PATH_POINTS: BezierPoint[] = [
  { x: -0.18, y: -0.16, inX: -0.05, inY: 0, outX: 0.05, outY: 0 },
  { x: 0.18, y: -0.14, inX: -0.05, inY: 0, outX: 0.05, outY: 0 },
  { x: 0.22, y: 0.16, inX: 0, inY: -0.05, outX: 0, outY: 0.05 },
  { x: -0.2, y: 0.14, inX: 0, inY: 0.05, outX: 0, outY: -0.05 },
];

export const ShapesMaskPanel: React.FC<ShapesMaskPanelProps> = ({
  selectedClip,
  playheadTime,
  penToolActive,
  onTogglePenTool,
  onAddShapeClip,
  onUpdateClip,
}) => {
  const sp = selectedClip?.type === 'shape' ? selectedClip.shapeProps : null;

  const updateSp = (patch: Partial<ShapeProperties>) => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      shapeProps: { ...(c.shapeProps as ShapeProperties), ...patch },
    }));
  };

  const localTime = selectedClip
    ? Math.max(0, Math.min(selectedClip.duration, playheadTime - selectedClip.startTime))
    : 0;

  const addAnimatedMaskKeyframe = () => {
    if (!selectedClip) return;
    const pts = selectedClip.mask.pathPoints?.length
      ? selectedClip.mask.pathPoints
      : DEFAULT_PATH_POINTS;
    onUpdateClip(selectedClip.id, (c) => {
      const existing = c.mask.animatedPaths || [];
      const filtered = existing.filter((k) => Math.abs(k.time - localTime) > 0.08);
      return {
        ...c,
        mask: {
          ...c.mask,
          shape: 'custom-path',
          pathPoints: pts,
          animatedPaths: [...filtered, { time: Math.round(localTime * 100) / 100, points: pts }].sort(
            (a, b) => a.time - b.time
          ),
        },
      };
    });
  };

  const hasKfAtPlayhead = (prop: KeyframeProperty) =>
    Boolean(
      selectedClip?.keyframes.some(
        (k) => k.property === prop && Math.abs(k.time - localTime) < 0.12
      )
    );

  const toggleMaskKf = (prop: KeyframeProperty, val: number) => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, (c) => {
      const idx = c.keyframes.findIndex(
        (k) => k.property === prop && Math.abs(k.time - localTime) < 0.12
      );
      if (idx >= 0) {
        return { ...c, keyframes: c.keyframes.filter((_, i) => i !== idx) };
      }
      return {
        ...c,
        keyframes: [
          ...c.keyframes,
          {
            id: `kf-${Date.now()}-${prop}-${Math.random().toString(36).slice(2, 5)}`,
            time: Math.round(localTime * 100) / 100,
            property: prop,
            value: val,
            easing: 'easeInOut',
          },
        ],
      };
    });
  };

  return (
    <div
      data-tutorial-target="shapes-mask-panel"
      className="p-3 flex flex-col gap-3 h-full text-xs bg-[#222225] text-[#F4F4F5] overflow-y-auto"
    >
      {/* Vector Shape Layer Creation */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-semibold text-[#A1A1AA] uppercase tracking-wider">
            Create Shape Layer
          </span>
          <button
            type="button"
            onClick={onTogglePenTool}
            className={`px-2 py-0.5 rounded text-[10px] font-medium flex items-center gap-1 border ${
              penToolActive
                ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <PenTool className="w-3 h-3" />
            {penToolActive ? 'Pen Tool Active' : 'Pen Tool'}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-1.5">
          {(
            [
              { id: 'rectangle', label: 'Rectangle', icon: <Square className="w-3.5 h-3.5" /> },
              { id: 'circle', label: 'Circle', icon: <Circle className="w-3.5 h-3.5" /> },
              { id: 'ellipse', label: 'Ellipse', icon: <Circle className="w-3.5 h-3.5 scale-x-125" /> },
              { id: 'polygon', label: 'Polygon', icon: <Hexagon className="w-3.5 h-3.5" /> },
              { id: 'star', label: 'Star', icon: <Star className="w-3.5 h-3.5" /> },
              { id: 'custom-path', label: 'Bezier Path', icon: <PenTool className="w-3.5 h-3.5" /> },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onAddShapeClip(item.id)}
              className="py-2 px-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] hover:border-[#A1A1AA] rounded flex flex-col items-center gap-1 text-[10px] text-[#F4F4F5] transition-colors"
            >
              <span className="text-[#D4D4D8]">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Shape Styling */}
      {sp && selectedClip && (
        <div className="space-y-2 border-t border-[#3E3E44] pt-2.5">
          <div className="text-[11px] font-semibold text-[#F4F4F5] flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-[#D4D4D8]" />
            Shape Vector Properties
          </div>
          <div className="grid grid-cols-2 gap-2">
            <label className="flex items-center justify-between bg-[#18181A] border border-[#3E3E44] rounded px-2 py-1">
              <span className="text-[10px] text-[#A1A1AA]">Fill</span>
              <input
                type="color"
                value={sp.fillColor}
                onChange={(e) => updateSp({ fillColor: e.target.value })}
                className="w-5 h-5 bg-transparent cursor-pointer"
              />
            </label>
            <label className="flex items-center justify-between bg-[#18181A] border border-[#3E3E44] rounded px-2 py-1">
              <span className="text-[10px] text-[#A1A1AA]">Stroke</span>
              <input
                type="color"
                value={sp.strokeColor}
                onChange={(e) => updateSp({ strokeColor: e.target.value })}
                className="w-5 h-5 bg-transparent cursor-pointer"
              />
            </label>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <RangeSlider
              label="Width"
              value={sp.widthPct}
              min={5}
              max={100}
              step={1}
              unit="%"
              onChange={(v) => updateSp({ widthPct: v })}
            />
            <RangeSlider
              label="Height"
              value={sp.heightPct}
              min={5}
              max={100}
              step={1}
              unit="%"
              onChange={(v) => updateSp({ heightPct: v })}
            />
            <RangeSlider
              label="Fill Opacity"
              value={Math.round(sp.fillOpacity * 100)}
              min={0}
              max={100}
              step={1}
              unit="%"
              onChange={(v) => updateSp({ fillOpacity: v / 100 })}
            />
            <RangeSlider
              label="Stroke Width"
              value={sp.strokeWidth}
              min={0}
              max={30}
              step={1}
              unit="px"
              onChange={(v) => updateSp({ strokeWidth: v })}
            />
          </div>
          {sp.shape === 'rectangle' && (
            <RangeSlider
              label="Corner Radius"
              value={sp.cornerRadius}
              min={0}
              max={160}
              step={2}
              unit="px"
              onChange={(v) => updateSp({ cornerRadius: v })}
            />
          )}
          {(sp.shape === 'polygon' || sp.shape === 'star') && (
            <RangeSlider
              label="Sides / Points"
              value={sp.points}
              min={3}
              max={16}
              step={1}
              onChange={(v) => updateSp({ points: v })}
            />
          )}
          {sp.shape === 'star' && (
            <RangeSlider
              label="Inner Radius"
              value={Math.round(sp.innerRadius * 100)}
              min={15}
              max={90}
              step={1}
              unit="%"
              onChange={(v) => updateSp({ innerRadius: v / 100 })}
            />
          )}
        </div>
      )}

      {/* Mask System for Any Selected Visual Clip */}
      {selectedClip && selectedClip.type !== 'audio' && selectedClip.type !== 'null' ? (
        <div className="space-y-2.5 border-t border-[#3E3E44] pt-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-[#F4F4F5]">Layer Masking System</span>
            <button
              type="button"
              onClick={onTogglePenTool}
              className={`px-2 py-0.5 rounded text-[10px] border flex items-center gap-1 ${
                penToolActive
                  ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                  : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
              }`}
            >
              <PenTool className="w-2.5 h-2.5" />
              Edit on Monitor
            </button>
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            <div>
              <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Mask Shape</label>
              <select
                value={selectedClip.mask.shape}
                onChange={(e) => {
                  const shape = e.target.value as MaskShape;
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    mask: {
                      ...c.mask,
                      shape,
                      pathPoints:
                        shape === 'custom-path' && (!c.mask.pathPoints || c.mask.pathPoints.length === 0)
                          ? DEFAULT_PATH_POINTS
                          : c.mask.pathPoints,
                    },
                  }));
                }}
                className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
              >
                <option value="none">None</option>
                <option value="rectangle">Rectangle</option>
                <option value="circle">Circle</option>
                <option value="ellipse">Ellipse</option>
                <option value="polygon">Polygon</option>
                <option value="star">Star</option>
                <option value="custom-path">Custom Bezier Path</option>
                <option value="radial-vignette">Radial Vignette</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Mask Mode</label>
              <select
                value={selectedClip.mask.mode || 'add'}
                onChange={(e) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    mask: { ...c.mask, mode: e.target.value as MaskMode },
                  }))
                }
                className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
              >
                <option value="add">Add (Inside)</option>
                <option value="subtract">Subtract (Cutout)</option>
                <option value="intersect">Intersect</option>
              </select>
            </div>
          </div>

          {selectedClip.mask.shape !== 'none' && (
            <>
              <div className="grid grid-cols-2 gap-2">
                <RangeSlider
                  label="Width / Radius X"
                  value={Math.round(selectedClip.mask.radiusX * 100)}
                  min={5}
                  max={100}
                  step={1}
                  unit="%"
                  keyframeActive={hasKfAtPlayhead('maskRadius')}
                  onToggleKeyframe={() => toggleMaskKf('maskRadius', selectedClip.mask.radiusX)}
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      mask: { ...c.mask, radiusX: v / 100 },
                    }))
                  }
                />
                <RangeSlider
                  label="Height / Radius Y"
                  value={Math.round(selectedClip.mask.radiusY * 100)}
                  min={5}
                  max={100}
                  step={1}
                  unit="%"
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      mask: { ...c.mask, radiusY: v / 100 },
                    }))
                  }
                />
                <RangeSlider
                  label="Mask Feather"
                  value={selectedClip.mask.feather}
                  min={0}
                  max={100}
                  step={1}
                  unit="px"
                  keyframeActive={hasKfAtPlayhead('maskFeather')}
                  onToggleKeyframe={() => toggleMaskKf('maskFeather', selectedClip.mask.feather)}
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      mask: { ...c.mask, feather: v },
                    }))
                  }
                />
                <RangeSlider
                  label="Mask Expansion"
                  value={selectedClip.mask.expansion ?? 0}
                  min={-40}
                  max={40}
                  step={1}
                  unit="%"
                  keyframeActive={hasKfAtPlayhead('maskExpansion')}
                  onToggleKeyframe={() =>
                    toggleMaskKf('maskExpansion', selectedClip.mask.expansion ?? 0)
                  }
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      mask: { ...c.mask, expansion: v },
                    }))
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-1.5 text-[11px] text-[#A1A1AA] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedClip.mask.inverted}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        mask: { ...c.mask, inverted: e.target.checked },
                      }))
                    }
                    className="accent-[#A1A1AA]"
                  />
                  Invert Mask
                </label>

                <button
                  type="button"
                  onClick={addAnimatedMaskKeyframe}
                  className="px-2 py-1 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] hover:border-[#A1A1AA] rounded text-[10px] text-[#F4F4F5] flex items-center gap-1"
                >
                  <Diamond className="w-2.5 h-2.5 text-[#D4D4D8] fill-current" />
                  Keyframe Mask Path
                </button>
              </div>

              {(selectedClip.mask.animatedPaths?.length ?? 0) > 0 && (
                <div className="p-1.5 bg-[#18181A] border border-[#3E3E44] rounded flex items-center justify-between text-[10px]">
                  <span className="text-[#A1A1AA]">
                    {selectedClip.mask.animatedPaths!.length} animated path keyframes
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        mask: { ...c.mask, animatedPaths: [] },
                      }))
                    }
                    className="text-rose-400 hover:underline flex items-center gap-0.5"
                  >
                    <Trash2 className="w-2.5 h-2.5" />
                    Clear
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      ) : (
        <div className="p-2.5 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#A1A1AA]">
          Select any video, image, text, or shape clip to configure Layer Masking &amp; Pen Bezier Paths.
        </div>
      )}
    </div>
  );
};

const RangeSlider: React.FC<{
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit?: string;
  keyframeActive?: boolean;
  onToggleKeyframe?: () => void;
  onChange: (v: number) => void;
}> = ({ label, value, min, max, step, unit = '', keyframeActive, onToggleKeyframe, onChange }) => (
  <div className="space-y-0.5">
    <div className="flex justify-between items-center text-[10px] gap-1">
      <div className="flex items-center gap-1 text-[#A1A1AA] min-w-0">
        {onToggleKeyframe && (
          <button
            type="button"
            onClick={onToggleKeyframe}
            title="Toggle Keyframe at Playhead"
            className={`p-0.5 rounded ${
              keyframeActive ? 'text-[#D4D4D8]' : 'text-[#6E7280] hover:text-[#F4F4F5]'
            }`}
          >
            <Diamond className="w-2.5 h-2.5 fill-current" />
          </button>
        )}
        <span className="truncate">{label}</span>
      </div>
      <span className="font-mono-tabular text-[#F4F4F5] shrink-0">
        {value}
        {unit}
      </span>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="w-full h-1 cursor-pointer"
    />
  </div>
);
