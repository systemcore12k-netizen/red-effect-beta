import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX, Headphones, RefreshCw } from 'lucide-react';
import { StudioProject, TimelineClip, TimelineTrack } from '../types/studio';
import { AudioOutputDeviceInfo, listAudioOutputDevices } from '../services/audioEngine';

interface AudioMixerPanelProps {
  project: StudioProject;
  isPlaying: boolean;
  masterVolume: number;
  masterMuted: boolean;
  audioOutputDeviceId: string;
  selectedClip: TimelineClip | null;
  getPeakLevels: () => { left: number; right: number };
  onSetMasterVolume: (vol: number) => void;
  onToggleMasterMute: () => void;
  onSelectAudioDevice: (deviceId: string) => Promise<void>;
  onUpdateTrack: (trackId: string, updater: (t: TimelineTrack) => TimelineTrack) => void;
  onUpdateClip: (clipId: string, updater: (c: TimelineClip) => TimelineClip) => void;
}

export const AudioMixerPanel: React.FC<AudioMixerPanelProps> = ({
  project,
  isPlaying,
  masterVolume,
  masterMuted,
  audioOutputDeviceId,
  selectedClip,
  getPeakLevels,
  onSetMasterVolume,
  onToggleMasterMute,
  onSelectAudioDevice,
  onUpdateTrack,
  onUpdateClip,
}) => {
  const [peaks, setPeaks] = useState({ left: 0, right: 0 });
  const getPeakLevelsRef = useRef(getPeakLevels);
  getPeakLevelsRef.current = getPeakLevels;
  const [devices, setDevices] = useState<AudioOutputDeviceInfo[]>([
    { deviceId: 'default', label: 'System Default Output' },
  ]);

  const refreshDevices = async () => {
    const list = await listAudioOutputDevices();
    setDevices(list);
  };

  useEffect(() => {
    void refreshDevices();
  }, []);

  useEffect(() => {
    if (!isPlaying) {
      setPeaks((prev) => (prev.left === 0 && prev.right === 0 ? prev : { left: 0, right: 0 }));
      return;
    }
    let raf = 0;
    const poll = () => {
      const next = getPeakLevelsRef.current();
      setPeaks((prev) =>
        Math.abs(prev.left - next.left) < 0.002 && Math.abs(prev.right - next.right) < 0.002
          ? prev
          : next
      );
      raf = requestAnimationFrame(poll);
    };
    raf = requestAnimationFrame(poll);
    return () => cancelAnimationFrame(raf);
  }, [isPlaying]);

  // Show all dedicated audio tracks PLUS any video track containing video clips with audio
  const mixerTracks = project.tracks.filter(
    (t) =>
      t.kind === 'audio' ||
      (t.kind === 'video' &&
        project.clips.some((c) => c.trackId === t.id && c.type === 'video'))
  );

  const toDb = (gain: number) => {
    if (gain <= 0.01) return '-∞ dB';
    const db = 20 * Math.log10(gain);
    return `${db >= 0 ? '+' : ''}${db.toFixed(1)} dB`;
  };

  return (
    <div className="p-3 h-full flex flex-col gap-2.5 overflow-hidden text-xs bg-[#222225] text-[#F4F4F5]">
      {/* Top Output Device Selector Strip */}
      <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#3E3E44] shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <Headphones className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0" />
          <span className="text-[11px] text-[#A1A1AA] whitespace-nowrap">Output Device:</span>
          <select
            value={audioOutputDeviceId || 'default'}
            onChange={(e) => void onSelectAudioDevice(e.target.value)}
            className="max-w-xs px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] truncate focus:outline-none focus:border-[#A1A1AA]"
          >
            {devices.map((d) => (
              <option key={d.deviceId} value={d.deviceId}>
                {d.label}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={refreshDevices}
            title="Refresh Speakers / Headphones"
            className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] rounded"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="text-[11px] text-[#A1A1AA] font-mono-tabular hidden sm:block">
          {(project.audioSampleRate || 48000).toLocaleString()} Hz · Stereo
        </div>
      </div>

      {/* Channel Strips Row */}
      <div className="flex-1 min-h-0 flex gap-3 overflow-x-auto">
        {mixerTracks.map((track) => {
          const meterLevel =
            track.muted || masterMuted
              ? 0
              : Math.min(1, ((peaks.left + peaks.right) * 0.5 || (isPlaying ? 0.12 : 0)) * track.volume);

          return (
            <div
              key={track.id}
              className="w-32 shrink-0 bg-[#2C2C30] border border-[#3E3E44] rounded p-2.5 flex flex-col justify-between gap-2"
            >
              <div>
                <div className="font-medium text-[#F4F4F5] truncate">{track.name}</div>
                <div className="text-[10px] font-mono-tabular text-[#A1A1AA]">
                  {toDb(track.volume)}
                </div>
              </div>

              <div className="flex items-center justify-center gap-3 py-1">
                {/* VU Meter Bar */}
                <div className="w-2.5 h-20 bg-[#18181A] rounded overflow-hidden flex flex-col justify-end border border-[#3E3E44]">
                  <div
                    style={{ height: `${Math.round(meterLevel * 100)}%` }}
                    className="w-full bg-gradient-to-t from-emerald-500 via-amber-400 to-rose-500 transition-[height] duration-75"
                  />
                </div>

                {/* Vertical Gain Slider */}
                <input
                  type="range"
                  min={0}
                  max={1.5}
                  step={0.02}
                  value={track.volume}
                  onChange={(e) =>
                    onUpdateTrack(track.id, (t) => ({ ...t, volume: Number(e.target.value) }))
                  }
                  className="w-16 -rotate-90 cursor-pointer"
                />
              </div>

              {/* Pan & Mute/Solo */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[10px] text-[#A1A1AA] font-mono-tabular">
                  <span>L</span>
                  <span>Pan {Math.round(track.pan * 100)}</span>
                  <span>R</span>
                </div>
                <input
                  type="range"
                  min={-1}
                  max={1}
                  step={0.05}
                  value={track.pan}
                  onChange={(e) =>
                    onUpdateTrack(track.id, (t) => ({ ...t, pan: Number(e.target.value) }))
                  }
                  className="w-full h-1 cursor-pointer"
                />
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => onUpdateTrack(track.id, (t) => ({ ...t, muted: !t.muted }))}
                    className={`flex-1 py-1 rounded text-[10px] font-medium ${
                      track.muted
                        ? 'bg-rose-600 text-white'
                        : 'bg-[#18181A] border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                    }`}
                  >
                    M
                  </button>
                  <button
                    type="button"
                    onClick={() => onUpdateTrack(track.id, (t) => ({ ...t, solo: !t.solo }))}
                    className={`flex-1 py-1 rounded text-[10px] font-medium ${
                      track.solo
                        ? 'bg-amber-500 text-black'
                        : 'bg-[#18181A] border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                    }`}
                  >
                    S
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {/* Master Bus */}
        <div className="w-36 shrink-0 bg-[#2C2C30] border border-[#A1A1AA]/50 rounded p-2.5 flex flex-col justify-between gap-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold text-[#E4E4E7]">MASTER BUS</div>
              <div className="text-[10px] font-mono-tabular text-[#A1A1AA]">
                {masterMuted ? 'MUTED' : toDb(masterVolume)}
              </div>
            </div>
            <button
              type="button"
              onClick={onToggleMasterMute}
              title={masterMuted ? 'Unmute Master Audio' : 'Mute Master Audio'}
              className={`p-1 rounded transition-colors ${
                masterMuted
                  ? 'bg-rose-600 text-white'
                  : 'text-[#D4D4D8] hover:bg-[#3E3E44]/50'
              }`}
            >
              {masterMuted || masterVolume === 0 ? (
                <VolumeX className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
          </div>

          <div className="flex items-center justify-center gap-2 py-1">
            <div className="flex gap-1">
              <div className="w-2 h-20 bg-[#18181A] rounded overflow-hidden flex flex-col justify-end border border-[#3E3E44]">
                <div
                  style={{ height: `${Math.round(peaks.left * 100)}%` }}
                  className="w-full bg-gradient-to-t from-emerald-500 via-amber-400 to-rose-500"
                />
              </div>
              <div className="w-2 h-20 bg-[#18181A] rounded overflow-hidden flex flex-col justify-end border border-[#3E3E44]">
                <div
                  style={{ height: `${Math.round(peaks.right * 100)}%` }}
                  className="w-full bg-gradient-to-t from-emerald-500 via-amber-400 to-rose-500"
                />
              </div>
            </div>

            <input
              type="range"
              min={0}
              max={1.5}
              step={0.02}
              value={masterMuted ? 0 : masterVolume}
              onChange={(e) => onSetMasterVolume(Number(e.target.value))}
              className="w-16 -rotate-90 cursor-pointer"
            />
          </div>

          <button
            type="button"
            onClick={() => onSetMasterVolume(1)}
            className="w-full py-1 bg-[#18181A] hover:bg-[#3E3E44]/60 border border-[#3E3E44] text-[#F4F4F5] rounded text-[10px]"
          >
            Reset 0.0 dB
          </button>
        </div>

        {/* Selected Clip Quick Audio & Fade Controls */}
        {selectedClip && (
          <div className="min-w-48 flex-1 bg-[#2C2C30] border border-[#3E3E44] rounded p-2.5 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="font-medium text-[#F4F4F5] truncate">
                Clip Audio · {selectedClip.name}
              </div>
              <button
                type="button"
                onClick={() =>
                  onUpdateClip(selectedClip.id, (c) => ({ ...c, muted: !c.muted }))
                }
                className={`px-2 py-0.5 rounded text-[10px] font-medium shrink-0 ${
                  selectedClip.muted
                    ? 'bg-rose-600 text-white'
                    : 'bg-[#18181A] border border-[#3E3E44] text-[#F4F4F5] hover:border-[#A1A1AA]'
                }`}
              >
                {selectedClip.muted ? 'Muted' : 'Active'}
              </button>
            </div>
            <div className="space-y-1.5 text-[11px]">
              <div className="flex justify-between text-[#A1A1AA]">
                <span>Clip Gain</span>
                <span className="font-mono-tabular text-[#F4F4F5]">
                  {Math.round(selectedClip.volume * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={2}
                step={0.05}
                value={selectedClip.volume}
                onChange={(e) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    volume: Number(e.target.value),
                  }))
                }
                className="w-full h-1 cursor-pointer"
              />
              <div className="flex justify-between text-[#A1A1AA]">
                <span>Fade In</span>
                <span className="font-mono-tabular text-[#F4F4F5]">
                  {selectedClip.fadeIn.toFixed(1)}s
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={4}
                step={0.1}
                value={selectedClip.fadeIn}
                onChange={(e) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    fadeIn: Number(e.target.value),
                  }))
                }
                className="w-full h-1 cursor-pointer"
              />
              <div className="flex justify-between text-[#A1A1AA]">
                <span>Fade Out</span>
                <span className="font-mono-tabular text-[#F4F4F5]">
                  {selectedClip.fadeOut.toFixed(1)}s
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={4}
                step={0.1}
                value={selectedClip.fadeOut}
                onChange={(e) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    fadeOut: Number(e.target.value),
                  }))
                }
                className="w-full h-1 cursor-pointer"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
