import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import {
  Box,
  Download,
  Plus,
  RotateCw,
  Upload,
  Eye,
  EyeOff,
  AlertCircle,
  Boxes,
} from 'lucide-react';
import { Model3DBlueprint } from '../types/studio';
import { Studio4DTransferPayload } from '../types/studio4d';
import {
  buildComposite3DGroup,
  createDefaultShowcase3DBlueprint,
  createStudioEnvironment,
  exportGroupToGLB,
  exportGroupToOBJ,
} from '../services/threeModelBuilder';
import { cloneTransferableObject } from '../services/studio4DEngine';
import { saveBlobWithWindowsDialog } from '../services/projectStorage';

interface Studio3DPanelProps {
  activeBlueprint: Model3DBlueprint | null;
  onBlueprintChange: (bp: Model3DBlueprint) => void;
  onImport3DToProject: (blueprint: Model3DBlueprint, thumbnailDataUrl: string) => void;
  onOpenIn4DStudio: (payload: Studio4DTransferPayload) => void;
}

interface BuiltInModelPreset {
  id: string;
  label: string;
  build: () => Model3DBlueprint;
}

const BUILTIN_3D_PRESETS: BuiltInModelPreset[] = [
  {
    id: 'drone',
    label: 'Crimson Cinema Drone',
    build: () => createDefaultShowcase3DBlueprint(),
  },
  {
    id: 'mech-core',
    label: 'Procedural Mech Core',
    build: () => ({
      title: 'Procedural Mech Core',
      category: 'Robotics',
      description: 'Articulated armor torso with glowing reactor ring and shoulder pauldrons.',
      environmentLighting: 'crimson-rim',
      autoRotateSpeed: 0.7,
      parts: [
        { name: 'Torso_Frame', geometry: 'extrude_bevel', position: [0, 1.15, 0], rotation: [0, 0, 0], scale: [1.1, 1.3, 0.8], color: '#27272A', roughness: 0.35, metalness: 0.85, clearcoat: 0.5, texturePattern: 'carbon-weave' },
        { name: 'Reactor_Core', geometry: 'torus', position: [0, 1.25, 0.42], rotation: [0, 0, 0], scale: [0.35, 0.35, 0.35], color: '#E11D48', roughness: 0.12, metalness: 0.9, emissive: '#E50914', emissiveIntensity: 1.6, texturePattern: 'none' },
        { name: 'Pauldron_L', geometry: 'capsule', position: [-0.85, 1.55, 0], rotation: [0, 0, 0.45], scale: [0.55, 0.5, 0.65], color: '#991B1B', roughness: 0.25, metalness: 0.88, clearcoat: 0.8, texturePattern: 'brushed-metal' },
        { name: 'Pauldron_R', geometry: 'capsule', position: [0.85, 1.55, 0], rotation: [0, 0, -0.45], scale: [0.55, 0.5, 0.65], color: '#991B1B', roughness: 0.25, metalness: 0.88, clearcoat: 0.8, texturePattern: 'brushed-metal' },
        { name: 'Sensor_Head', geometry: 'icosahedron', position: [0, 1.98, 0.05], rotation: [0, 0.4, 0], scale: [0.46, 0.42, 0.48], color: '#18181B', roughness: 0.22, metalness: 0.9, texturePattern: 'grid' },
        { name: 'Base_Pedestal', geometry: 'cylinder', position: [0, 0.2, 0], rotation: [0, 0, 0], scale: [1.5, 0.35, 1.5], color: '#111114', roughness: 0.6, metalness: 0.4, texturePattern: 'brushed-metal' },
      ],
    }),
  },
  {
    id: 'prism',
    label: 'Geometric Prism Monument',
    build: () => ({
      title: 'Geometric Prism Monument',
      category: 'Architectural',
      description: 'Sculptural crystalline monolith with orbital gimbal rings.',
      environmentLighting: 'studio',
      autoRotateSpeed: 0.9,
      parts: [
        { name: 'Monolith_Spire', geometry: 'cone', position: [0, 1.25, 0], rotation: [0, 0.3, 0], scale: [0.95, 2.2, 0.95], color: '#1F2937', roughness: 0.18, metalness: 0.92, clearcoat: 0.85, texturePattern: 'grid' },
        { name: 'Halo_Ring_Outer', geometry: 'torus', position: [0, 1.35, 0], rotation: [1.1, 0.4, 0], scale: [1.45, 1.45, 0.5], color: '#E11D48', roughness: 0.2, metalness: 0.9, emissive: '#E11D48', emissiveIntensity: 0.8, texturePattern: 'none' },
        { name: 'Halo_Ring_Inner', geometry: 'torus', position: [0, 1.35, 0], rotation: [-0.8, 0.6, 0.4], scale: [1.0, 1.0, 0.45], color: '#F4F4F5', roughness: 0.15, metalness: 0.95, texturePattern: 'brushed-metal' },
        { name: 'Floating_Crystal', geometry: 'icosahedron', position: [0, 2.6, 0], rotation: [0.2, 0.5, 0.1], scale: [0.48, 0.48, 0.48], color: '#FB7185', roughness: 0.1, metalness: 0.7, emissive: '#E11D48', emissiveIntensity: 1.2, texturePattern: 'none' },
        { name: 'Plinth', geometry: 'cylinder', position: [0, 0.15, 0], rotation: [0, 0, 0], scale: [1.9, 0.3, 1.9], color: '#09090B', roughness: 0.55, metalness: 0.3, texturePattern: 'stone' },
      ],
    }),
  },
  {
    id: 'turntable',
    label: 'Studio Lathe Goblet & Stage',
    build: () => ({
      title: 'Studio Lathe Goblet & Stage',
      category: 'Product Viz',
      description: 'Revolved lathe metalwork vessel mounted on a reflective studio turntable.',
      environmentLighting: 'sunset',
      autoRotateSpeed: 0.65,
      parts: [
        { name: 'Turned_Vessel', geometry: 'lathe', position: [0, 1.05, 0], rotation: [0, 0, 0], scale: [1.3, 1.5, 1.3], color: '#E11D48', roughness: 0.16, metalness: 0.85, clearcoat: 0.95, texturePattern: 'brushed-metal' },
        { name: 'Accent_Collar', geometry: 'torus', position: [0, 0.88, 0], rotation: [Math.PI / 2, 0, 0], scale: [0.55, 0.55, 0.35], color: '#F59E0B', roughness: 0.2, metalness: 0.95, texturePattern: 'none' },
        { name: 'Turntable_Platter', geometry: 'cylinder', position: [0, 0.15, 0], rotation: [0, 0, 0], scale: [2.2, 0.28, 2.2], color: '#18181B', roughness: 0.25, metalness: 0.75, clearcoat: 0.8, texturePattern: 'carbon-weave' },
      ],
    }),
  },
];

export const Studio3DPanel: React.FC<Studio3DPanelProps> = ({
  activeBlueprint,
  onBlueprintChange,
  onImport3DToProject,
  onOpenIn4DStudio,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [wireframe, setWireframe] = useState(false);
  const [autoRotate, setAutoRotate] = useState(true);
  const [explodeFactor, setExplodeFactor] = useState(0);
  const [lightingMode, setLightingMode] = useState<'studio' | 'crimson-rim' | 'sunset'>('crimson-rim');
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [webglLost, setWebglLost] = useState(false);
  const [exportStatus, setExportStatus] = useState<string | null>(null);

  const blueprint = activeBlueprint ?? createDefaultShowcase3DBlueprint();

  // Store mutable refs for Three.js objects
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const lightsRef = useRef<{
    key: THREE.DirectionalLight;
    fill: THREE.DirectionalLight;
    rim: THREE.DirectionalLight;
  } | null>(null);
  const loadedAnimationsRef = useRef<THREE.AnimationClip[]>([]);
  const loadedCamerasRef = useRef<THREE.Camera[]>([]);
  const loadedSourceRef = useRef<{
    sourceKind: 'blueprint' | 'imported-file';
    format: 'glb' | 'gltf' | 'fbx' | 'obj' | 'procedural';
    name: string;
  }>({ sourceKind: 'blueprint', format: 'procedural', name: blueprint.title });

  const explodeRef = useRef(explodeFactor);
  const autoRotateRef = useRef(autoRotate);
  explodeRef.current = explodeFactor;
  autoRotateRef.current = autoRotate;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = Math.max(300, container.clientWidth);
    const height = Math.max(240, container.clientHeight);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#09090B');
    scene.fog = new THREE.FogExp2('#09090B', 0.045);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(3.2, 2.2, 4.2);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    renderer.domElement.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      setWebglLost(true);
    });
    renderer.domElement.addEventListener('webglcontextrestored', () => {
      setWebglLost(false);
    });

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const envTex = createStudioEnvironment(renderer);
    scene.environment = envTex;

    // Warm/cool 3-point studio lighting + hemisphere fill
    const hemi = new THREE.HemisphereLight(0xdbeafe, 0x18181b, 0.7);
    scene.add(hemi);

    const key = new THREE.DirectionalLight(0xfff1e0, 2.2);
    key.position.set(4, 6, 4);
    key.castShadow = !isSoftwareGl;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0005;
    key.shadow.normalBias = 0.02;
    scene.add(key);

    const fill = new THREE.DirectionalLight(0x93c5fd, 0.85);
    fill.position.set(-5, 3, 2);
    scene.add(fill);

    const rim = new THREE.DirectionalLight(0xe11d48, 1.8);
    rim.position.set(0, 4, -5);
    scene.add(rim);

    lightsRef.current = { key, fill, rim };

    // Ground grid & subtle shadow plane
    const grid = new THREE.GridHelper(14, 24, 0x3f3f46, 0x18181b);
    grid.position.y = 0;
    scene.add(grid);

    const floorGeo = new THREE.CircleGeometry(6, 48);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x0b0b0e,
      roughness: 0.85,
      metalness: 0.15,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.01;
    floor.receiveShadow = true;
    scene.add(floor);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 0.9, 0);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.minDistance = 1.5;
    controls.maxDistance = 14;
    controlsRef.current = controls;

    let frameId = 0;
    const clock = new THREE.Clock();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      const dt = Math.min(0.1, clock.getDelta());
      if (modelGroupRef.current) {
        if (autoRotateRef.current) {
          modelGroupRef.current.rotation.y += dt * 0.45;
        }
        // Smooth exploded-view separation
        const exp = explodeRef.current;
        modelGroupRef.current.children.forEach((child) => {
          const base = child.userData.basePosition as [number, number, number] | undefined;
          if (base) {
            const targetX = base[0] * (1 + exp * 1.1);
            const targetY = base[1] + exp * 0.45 * Math.max(0.1, base[1]);
            const targetZ = base[2] * (1 + exp * 1.1);
            child.position.x = THREE.MathUtils.damp(child.position.x, targetX, 8, dt);
            child.position.y = THREE.MathUtils.damp(child.position.y, targetY, 8, dt);
            child.position.z = THREE.MathUtils.damp(child.position.z, targetZ, 8, dt);
          }
        });
      }
      controls.update();
      renderer.render(scene, camera);
      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    };
    tick();

    const resizeObserver = new ResizeObserver(() => {
      if (!container) return;
      const w = Math.max(300, container.clientWidth);
      const h = Math.max(240, container.clientHeight);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
    resizeObserver.observe(container);

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      controls.dispose();
      envTex.dispose();
      renderer.dispose();
    };
  }, []);

  // Rebuild composite model when blueprint or wireframe changes
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (modelGroupRef.current) {
      scene.remove(modelGroupRef.current);
      modelGroupRef.current.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose();
          if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
          else obj.material.dispose();
        }
      });
    }

    const group = buildComposite3DGroup(blueprint, wireframe);
    modelGroupRef.current = group;
    loadedAnimationsRef.current = [];
    loadedCamerasRef.current = [];
    loadedSourceRef.current = {
      sourceKind: 'blueprint',
      format: 'procedural',
      name: blueprint.title,
    };
    scene.add(group);
  }, [blueprint, wireframe]);

  // Lighting preset updates
  useEffect(() => {
    const l = lightsRef.current;
    if (!l) return;
    if (lightingMode === 'studio') {
      l.key.color.setHex(0xffffff);
      l.rim.color.setHex(0x93c5fd);
      l.rim.intensity = 1.2;
    } else if (lightingMode === 'sunset') {
      l.key.color.setHex(0xfdba74);
      l.rim.color.setHex(0xf97316);
      l.rim.intensity = 2.0;
    } else {
      l.key.color.setHex(0xfff1e0);
      l.rim.color.setHex(0xe11d48);
      l.rim.intensity = 2.1;
    }
  }, [lightingMode]);

  const handleLoadPreset = (preset: BuiltInModelPreset) => {
    setErrorMsg(null);
    const bp = preset.build();
    onBlueprintChange(bp);
    setExportStatus(`Loaded procedural 3D preset: ${bp.title}`);
  };

  const handleImportModelFile = async (file: File) => {
    const scene = sceneRef.current;
    if (!scene) return;
    setErrorMsg(null);
    const ext = file.name.split('.').pop()?.toLowerCase();

    try {
      let loadedObj: THREE.Object3D | null = null;
      let animations: THREE.AnimationClip[] = [];
      let cameras: THREE.Camera[] = [];
      let fmt: 'glb' | 'gltf' | 'fbx' | 'obj' = 'glb';

      if (ext === 'obj') {
        const text = await file.text();
        loadedObj = new OBJLoader().parse(text);
        fmt = 'obj';
      } else if (ext === 'glb' || ext === 'gltf') {
        const buf = await file.arrayBuffer();
        const gltf = await new GLTFLoader().parseAsync(buf, '');
        loadedObj = gltf.scene;
        animations = gltf.animations || [];
        cameras = gltf.cameras || [];
        fmt = ext === 'gltf' ? 'gltf' : 'glb';
      } else if (ext === 'fbx') {
        const buf = await file.arrayBuffer();
        const fbx = new FBXLoader().parse(buf, '');
        loadedObj = fbx;
        animations = fbx.animations || [];
        fmt = 'fbx';
      } else {
        throw new Error(`Unsupported 3D format .${ext}. Use OBJ, GLB, GLTF, or FBX.`);
      }

      if (loadedObj) {
        if (modelGroupRef.current) scene.remove(modelGroupRef.current);
        const wrapper = new THREE.Group();
        wrapper.name = file.name.replace(/\.[^.]+$/, '');
        const box = new THREE.Box3().setFromObject(loadedObj);
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(0.001, size.x, size.y, size.z);
        const normScale = 2.2 / maxDim;
        loadedObj.scale.multiplyScalar(normScale);

        const scaledBox = new THREE.Box3().setFromObject(loadedObj);
        const center = scaledBox.getCenter(new THREE.Vector3());
        loadedObj.position.x -= center.x;
        loadedObj.position.z -= center.z;
        loadedObj.position.y -= scaledBox.min.y;
        loadedObj.traverse((node) => {
          if (node instanceof THREE.Mesh) {
            node.castShadow = true;
            node.receiveShadow = true;
          }
        });
        wrapper.add(loadedObj);
        modelGroupRef.current = wrapper;
        loadedAnimationsRef.current = animations;
        loadedCamerasRef.current = cameras;
        loadedSourceRef.current = {
          sourceKind: 'imported-file',
          format: fmt,
          name: wrapper.name,
        };
        scene.add(wrapper);
        setExportStatus(
          `Loaded ${file.name}${animations.length ? ` (${animations.length} animations preserved)` : ''}`
        );
      }
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to import 3D file.');
    }
  };

  const handleExport3D = async (fmt: 'glb' | 'obj') => {
    if (!modelGroupRef.current) return;
    setExportStatus(`Exporting .${fmt.toUpperCase()}...`);
    try {
      const safeName = blueprint.title.replace(/[^a-zA-Z0-9_-]/g, '_');
      if (fmt === 'obj') {
        const blob = exportGroupToOBJ(modelGroupRef.current);
        const res = await saveBlobWithWindowsDialog(
          blob,
          `${safeName}.obj`,
          { 'text/plain': ['.obj'] },
          'Wavefront OBJ 3D Model'
        );
        if (!res.cancelled) setExportStatus(`Saved ${res.fileName}`);
        else setExportStatus(null);
      } else {
        const blob = await exportGroupToGLB(modelGroupRef.current);
        const res = await saveBlobWithWindowsDialog(
          blob,
          `${safeName}.glb`,
          { 'model/gltf-binary': ['.glb'] },
          'Binary glTF 3D Model'
        );
        if (!res.cancelled) setExportStatus(`Saved ${res.fileName}`);
        else setExportStatus(null);
      }
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : '3D export failed.');
      setExportStatus(null);
    }
  };

  const handleSendToProject = () => {
    const renderer = rendererRef.current;
    const scene = sceneRef.current;
    const camera = cameraRef.current;
    let thumb = '';
    if (renderer && scene && camera) {
      renderer.render(scene, camera);
      thumb = renderer.domElement.toDataURL('image/png');
    }
    onImport3DToProject(blueprint, thumb);
    setExportStatus(`Imported "${blueprint.title}" into Project Media & Timeline`);
  };

  const handleTransferTo4D = () => {
    const group = modelGroupRef.current;
    const cam = cameraRef.current;
    const ctrl = controlsRef.current;
    const src = loadedSourceRef.current;

    const clonedObj = group ? cloneTransferableObject(group) : undefined;
    const clonedClips = loadedAnimationsRef.current.map((clip) => clip.clone());

    const mappedLight =
      lightingMode === 'studio'
        ? 'realistic-studio'
        : lightingMode === 'sunset'
        ? 'sunset-golden'
        : 'crimson-cinema';

    onOpenIn4DStudio({
      id: `transfer-4d-${Date.now()}`,
      name: src.name || blueprint.title,
      sourceKind: src.sourceKind,
      format: src.format,
      blueprint: src.sourceKind === 'blueprint' ? blueprint : undefined,
      object3D: clonedObj,
      animations: clonedClips,
      cameras: loadedCamerasRef.current,
      lightingMode: mappedLight,
      cameraPose:
        cam && ctrl
          ? {
              position: [cam.position.x, cam.position.y, cam.position.z],
              target: [ctrl.target.x, ctrl.target.y, ctrl.target.z],
              fov: cam.fov,
            }
          : undefined,
    });
  };

  return (
    <div className="flex flex-col h-full bg-[#18181A] text-[#F4F4F5] text-xs">
      {/* Top 3D Modeling Toolbar */}
      <div className="p-2.5 bg-[#222225] border-b border-[#3E3E44] flex flex-wrap items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1.5 text-[#F4F4F5] font-medium shrink-0 pr-2 border-r border-[#3E3E44]">
            <Box className="w-4 h-4 text-[#D4D4D8]" />
            <span>3D Studio Workspace</span>
          </div>
          <span className="text-[11px] text-[#A1A1AA]">
            Select a procedural rig preset or import OBJ / GLB / FBX meshes
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="px-2.5 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] text-[#F4F4F5] rounded border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap"
          >
            <Upload className="w-3.5 h-3.5" />
            Import OBJ/GLB/FBX
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".obj,.glb,.gltf,.fbx"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleImportModelFile(f);
              e.target.value = '';
            }}
            className="hidden"
          />
          <button
            type="button"
            onClick={handleTransferTo4D}
            className="px-3 py-1.5 bg-[#52525B] hover:bg-[#6B7280] text-white font-semibold rounded flex items-center gap-1.5 whitespace-nowrap shadow-sm"
          >
            <Boxes className="w-3.5 h-3.5" />
            OPEN IN 4D STUDIO
          </button>
          <button
            type="button"
            onClick={handleSendToProject}
            className="px-2.5 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] text-[#E4E4E7] rounded border border-[#A1A1AA]/40 flex items-center gap-1 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            Add to Project
          </button>
          <button
            type="button"
            onClick={() => handleExport3D('glb')}
            className="px-2.5 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] text-[#F4F4F5] rounded border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            GLB
          </button>
          <button
            type="button"
            onClick={() => handleExport3D('obj')}
            className="px-2.5 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] text-[#F4F4F5] rounded border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            OBJ
          </button>
        </div>
      </div>

      {/* Built-in Procedural 3D Models Bar & Status */}
      <div className="px-3 py-1.5 bg-[#18181A] border-b border-[#3E3E44] flex items-center justify-between gap-2 overflow-x-auto shrink-0">
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] uppercase tracking-wider text-[#A1A1AA] mr-1">
            3D Presets:
          </span>
          {BUILTIN_3D_PRESETS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => handleLoadPreset(preset)}
              className={`px-2.5 py-1 border rounded text-[11px] whitespace-nowrap transition-colors ${
                blueprint.title === preset.label
                  ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#E4E4E7]'
                  : 'bg-[#2C2C30] hover:bg-[#2E323E] border-[#3E3E44] text-[#F4F4F5]'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>
        {exportStatus && (
          <span className="text-[11px] font-mono-tabular text-emerald-400 whitespace-nowrap">
            {exportStatus}
          </span>
        )}
      </div>

      {errorMsg && (
        <div className="px-3 py-2 bg-rose-950/60 border-b border-rose-500/40 text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Full Unobstructed 3D Viewport + Collapsible Bottom Dock */}
      <div className="flex-1 min-h-0 relative overflow-hidden">
        <div ref={mountRef} className="w-full h-full" />

        {webglLost && (
          <div className="absolute inset-0 bg-black/80 flex items-center justify-center text-[#A1A1AA]">
            WebGL context paused — restoring GPU viewport...
          </div>
        )}

        {/* Top-left Clean Model Metadata */}
        <div className="pointer-events-none absolute top-3 left-3 bg-[#222225]/90 border border-[#3E3E44] px-3 py-1.5 rounded">
          <div className="font-display font-semibold text-[#F4F4F5]">{blueprint.title}</div>
          <div className="text-[11px] text-[#A1A1AA] font-mono-tabular">
            {blueprint.category} · {blueprint.parts.length} meshes · Drag to orbit, Scroll to zoom
          </div>
        </div>

        {/* Unified Collapsible Bottom Control Dock */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center max-w-[94%]">
          <button
            type="button"
            onClick={() => setDockCollapsed((c) => !c)}
            className="px-3 py-1 bg-[#2C2C30] border border-b-0 border-[#3E3E44] rounded-t text-[11px] text-[#A1A1AA] hover:text-[#F4F4F5] flex items-center gap-1"
          >
            {dockCollapsed ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            {dockCollapsed ? 'Show Controls' : 'Hide Controls'}
          </button>
          {!dockCollapsed && (
            <div className="bg-[#222225]/95 border border-[#3E3E44] rounded-md px-4 py-2 flex flex-wrap items-center gap-4 shadow-2xl">
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-[#A1A1AA]">Explode</span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.02}
                  value={explodeFactor}
                  onChange={(e) => setExplodeFactor(Number(e.target.value))}
                  className="w-24 cursor-pointer"
                />
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-[#A1A1AA]">Light</span>
                {(['crimson-rim', 'studio', 'sunset'] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setLightingMode(m)}
                    className={`px-2 py-1 rounded text-[11px] capitalize ${
                      lightingMode === m
                        ? 'bg-[#52525B] text-white'
                        : 'bg-[#2C2C30] border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                    }`}
                  >
                    {m.replace('-', ' ')}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setWireframe((w) => !w)}
                className={`px-2.5 py-1 rounded text-[11px] border ${
                  wireframe
                    ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#E4E4E7]'
                    : 'border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
                }`}
              >
                Wireframe
              </button>

              <button
                type="button"
                onClick={() => setAutoRotate((a) => !a)}
                className={`px-2.5 py-1 rounded text-[11px] border flex items-center gap-1 ${
                  autoRotate
                    ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#E4E4E7]'
                    : 'border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
                }`}
              >
                <RotateCw className="w-3 h-3" />
                Spin
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
