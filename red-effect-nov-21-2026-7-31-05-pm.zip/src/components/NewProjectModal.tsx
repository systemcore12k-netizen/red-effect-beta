import React, { useEffect, useRef, useState } from 'react';
import {
  X,
  Film,
  Image as ImageIcon,
  FolderPlus,
  Check,
  Trash2,
  ChevronDown,
  ChevronUp,
  Video,
  Music,
} from 'lucide-react';
import {
  AspectRatioPreset,
  AudioSampleRatePreset,
  NewProjectConfig,
  VideoFormatPreset,
} from '../types/studio';
import { pickWindowsDirectoryLabel } from '../services/projectStorage';

interface NewProjectModalProps {
  mode?: 'create' | 'edit';
  initialConfig?: Partial<NewProjectConfig>;
  initialMediaPick?: 'video' | 'image' | 'all' | null;
  onConfirm: (config: NewProjectConfig, mediaFiles?: File[]) => void;
  onCancel: () => void;
}

interface QueuedMediaItem {
  id: string;
  file: File;
  kind: 'video' | 'image' | 'audio';
  previewUrl: string;
}

const RESOLUTION_PRESETS = [
  { id: '720p', label: '720p HD', sub: '1280 × 720', width: 1280, height: 720 },
  { id: '1080p', label: '1080p Full HD', sub: '1920 × 1080', width: 1920, height: 1080 },
  { id: '1440p', label: '2K QHD', sub: '2560 × 1440', width: 2560, height: 1440 },
  { id: '4k', label: '4K UHD', sub: '3840 × 2160', width: 3840, height: 2160 },
  { id: 'custom', label: 'Custom', sub: 'Manual W × H', width: 0, height: 0 },
] as const;

const ASPECT_RATIOS: Array<{
  id: AspectRatioPreset;
  label: string;
  boxW: number;
  boxH: number;
  ratio?: number;
}> = [
  { id: '16:9', label: '16:9', boxW: 26, boxH: 15, ratio: 16 / 9 },
  { id: '9:16', label: '9:16', boxW: 15, boxH: 26, ratio: 9 / 16 },
  { id: '1:1', label: '1:1', boxW: 20, boxH: 20, ratio: 1 },
  { id: '4:5', label: '4:5', boxW: 17, boxH: 21, ratio: 4 / 5 },
  { id: '21:9', label: '21:9', boxW: 28, boxH: 12, ratio: 21 / 9 },
  { id: 'custom', label: 'Custom', boxW: 22, boxH: 16 },
];

const FPS_OPTIONS: Array<24 | 25 | 30 | 50 | 60 | 120> = [24, 25, 30, 50, 60, 120];
const BG_SWATCHES = ['#101010', '#000000', '#050507', '#191919', '#FFFFFF'];

function detectPreset(w: number, h: number): string {
  const maxDim = Math.max(w, h);
  const minDim = Math.min(w, h);
  if (maxDim === 1280 && minDim === 720) return '720p';
  if (maxDim === 1920 && minDim === 1080) return '1080p';
  if (maxDim === 2560 && minDim === 1440) return '1440p';
  if (maxDim === 3840 && minDim === 2160) return '4k';
  return 'custom';
}

function classifyMediaFile(file: File): 'video' | 'image' | 'audio' {
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  if (file.type.startsWith('video/') || ['mp4', 'mov', 'avi', 'mkv', 'webm', 'm4v'].includes(ext)) {
    return 'video';
  }
  if (file.type.startsWith('audio/') || ['mp3', 'wav', 'ogg', 'aac', 'm4a', 'flac'].includes(ext)) {
    return 'audio';
  }
  return 'image';
}

export const NewProjectModal: React.FC<NewProjectModalProps> = ({
  mode = 'create',
  initialConfig,
  initialMediaPick = null,
  onConfirm,
  onCancel,
}) => {
  const [name, setName] = useState(
    initialConfig?.name || (mode === 'create' ? 'Red_Effect_Project_01' : 'Project')
  );
  const [location, setLocation] = useState(
    initialConfig?.location || 'RED EFFECT APPS / Projects'
  );
  const [width, setWidth] = useState(initialConfig?.width || 1920);
  const [height, setHeight] = useState(initialConfig?.height || 1080);
  const [aspectRatio, setAspectRatio] = useState<AspectRatioPreset>(
    initialConfig?.aspectRatio || '16:9'
  );
  const [resPreset, setResPreset] = useState(() =>
    detectPreset(initialConfig?.width || 1920, initialConfig?.height || 1080)
  );
  const [fps, setFps] = useState<24 | 25 | 30 | 50 | 60 | 120>(
    initialConfig?.fps || 60
  );
  const [videoFormat, setVideoFormat] = useState<VideoFormatPreset>(
    initialConfig?.videoFormat || 'mp4'
  );
  const [audioSampleRate, setAudioSampleRate] = useState<AudioSampleRatePreset>(
    initialConfig?.audioSampleRate || 48000
  );
  const [backgroundColor, setBackgroundColor] = useState(
    initialConfig?.backgroundColor || '#101010'
  );
  const [videoTrackCount, setVideoTrackCount] = useState(
    initialConfig?.videoTrackCount || 2
  );
  const [audioTrackCount, setAudioTrackCount] = useState(
    initialConfig?.audioTrackCount || 2
  );
  const [snapEnabled, setSnapEnabled] = useState(
    initialConfig?.snapEnabled ?? true
  );
  const [defaultClipDuration, setDefaultClipDuration] = useState(
    initialConfig?.defaultClipDuration || 5
  );
  const [showAdvanced, setShowAdvanced] = useState(mode === 'edit');
  const [queuedMedia, setQueuedMedia] = useState<QueuedMediaItem[]>([]);

  const videoInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const multiInputRef = useRef<HTMLInputElement>(null);
  const queuedRef = useRef<QueuedMediaItem[]>([]);
  queuedRef.current = queuedMedia;

  useEffect(() => {
    return () => {
      for (const item of queuedRef.current) {
        URL.revokeObjectURL(item.previewUrl);
      }
    };
  }, []);

  useEffect(() => {
    if (mode !== 'create' || !initialMediaPick) return;
    const t = window.setTimeout(() => {
      if (initialMediaPick === 'video') videoInputRef.current?.click();
      else if (initialMediaPick === 'image') imageInputRef.current?.click();
      else if (initialMediaPick === 'all') multiInputRef.current?.click();
    }, 80);
    return () => window.clearTimeout(t);
  }, [mode, initialMediaPick]);

  const appendFiles = (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const additions: QueuedMediaItem[] = Array.from(fileList).map((file) => ({
      id: `q-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      file,
      kind: classifyMediaFile(file),
      previewUrl: URL.createObjectURL(file),
    }));
    setQueuedMedia((prev) => [...prev, ...additions]);
  };

  const removeQueuedFile = (id: string) => {
    setQueuedMedia((prev) => {
      const target = prev.find((item) => item.id === id);
      if (target) URL.revokeObjectURL(target.previewUrl);
      return prev.filter((item) => item.id !== id);
    });
  };

  const handlePresetChange = (presetId: string) => {
    setResPreset(presetId);
    const found = RESOLUTION_PRESETS.find((p) => p.id === presetId);
    if (found && found.width > 0) {
      const arEntry = ASPECT_RATIOS.find((a) => a.id === aspectRatio);
      if (arEntry?.ratio && (aspectRatio === '9:16' || aspectRatio === '4:5')) {
        const calcW = Math.round((found.width * arEntry.ratio) / 2) * 2;
        setWidth(calcW);
        setHeight(found.width);
      } else if (arEntry?.ratio) {
        const calcH = Math.round(found.width / arEntry.ratio / 2) * 2;
        setWidth(found.width);
        setHeight(calcH);
      } else {
        setWidth(found.width);
        setHeight(found.height);
      }
    }
  };

  const handleAspectChange = (nextAr: AspectRatioPreset) => {
    setAspectRatio(nextAr);
    const entry = ASPECT_RATIOS.find((a) => a.id === nextAr);
    if (entry?.ratio) {
      const basePreset = RESOLUTION_PRESETS.find((p) => p.id === resPreset);
      const longSide =
        basePreset && basePreset.width > 0
          ? basePreset.width
          : Math.max(width, height, 1920);
      if (nextAr === '9:16' || nextAr === '4:5') {
        const calcW = Math.round((longSide * entry.ratio) / 2) * 2;
        setWidth(calcW);
        setHeight(longSide);
      } else {
        const calcH = Math.round(longSide / entry.ratio / 2) * 2;
        setWidth(longSide);
        setHeight(calcH);
      }
    }
  };

  const handleBrowseLocation = async () => {
    const picked = await pickWindowsDirectoryLabel();
    if (picked) {
      setLocation(picked);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm(
      {
        name: name.trim() || 'Untitled_Project',
        location: location.trim() || 'RED EFFECT APPS / Projects',
        width: Math.max(256, Math.min(7680, Number(width) || 1920)),
        height: Math.max(256, Math.min(4320, Number(height) || 1080)),
        fps,
        aspectRatio,
        videoFormat,
        audioSampleRate,
        backgroundColor,
        videoTrackCount,
        audioTrackCount,
        snapEnabled,
        defaultClipDuration,
      },
      queuedMedia.map((q) => q.file)
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-4 text-xs"
      role="dialog"
      aria-modal="true"
      aria-label={mode === 'edit' ? 'Project Settings' : 'Create New Project'}
    >
      <div className="w-full sm:max-w-2xl bg-[#222225] border border-[#3E3E44] rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-[#222225] border-b border-[#3E3E44] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#71717A]/15 border border-[#A1A1AA]/40 flex items-center justify-center">
              <Film className="w-4 h-4 text-[#D4D4D8]" />
            </div>
            <div>
              <h2 className="font-display text-base font-bold text-white leading-tight">
                {mode === 'edit' ? 'Project Settings' : 'New Project'}
              </h2>
              <p className="text-[11px] text-[#A1A1AA]">
                {mode === 'edit'
                  ? 'Update sequence dimensions, frame rate, and timeline defaults'
                  : 'Choose canvas format, frame rate, and media clips to start editing'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="Close modal"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#A1A1AA] hover:text-white rounded-xl hover:bg-[#2C2C30] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-6">
          {/* Project Name */}
          <div>
            <label className="text-xs font-medium text-[#A1A1AA] block mb-1.5">
              Project Name
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter project name"
              className="w-full px-3.5 py-2.5 bg-[#18181A] border border-[#3E3E44] rounded-xl text-sm text-white placeholder-[#666666] focus:outline-none focus:border-[#A1A1AA] transition-colors"
            />
          </div>

          {/* Media Import Section (Create Mode) */}
          {mode === 'create' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">
                  Import Media (Optional)
                </span>
                <span className="text-[11px] text-[#A1A1AA] font-mono-tabular">
                  {queuedMedia.length} selected
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <button
                  type="button"
                  onClick={() => videoInputRef.current?.click()}
                  className="min-h-[48px] px-3.5 py-2.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-xl flex items-center gap-2.5 text-left transition-colors active:scale-[0.98]"
                >
                  <Video className="w-4 h-4 text-[#D4D4D8] shrink-0" />
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-white">Select Videos</div>
                    <div className="text-[10px] text-[#A1A1AA] truncate">MP4, MOV, WebM</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => imageInputRef.current?.click()}
                  className="min-h-[48px] px-3.5 py-2.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-xl flex items-center gap-2.5 text-left transition-colors active:scale-[0.98]"
                >
                  <ImageIcon className="w-4 h-4 text-[#D4D4D8] shrink-0" />
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-white">Select Images</div>
                    <div className="text-[10px] text-[#A1A1AA] truncate">PNG, JPG, WebP</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => multiInputRef.current?.click()}
                  className="min-h-[48px] px-3.5 py-2.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-xl flex items-center gap-2.5 text-left transition-colors active:scale-[0.98]"
                >
                  <FolderPlus className="w-4 h-4 text-white shrink-0" />
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-white">Multiple Media</div>
                    <div className="text-[10px] text-[#A1A1AA] truncate">Video, Photo, Audio</div>
                  </div>
                </button>
              </div>

              <input
                ref={videoInputRef}
                type="file"
                multiple
                accept="video/*,.mp4,.mov,.avi,.mkv,.webm,.m4v"
                onChange={(e) => {
                  appendFiles(e.target.files);
                  e.target.value = '';
                }}
                className="hidden"
              />
              <input
                ref={imageInputRef}
                type="file"
                multiple
                accept="image/*,.png,.jpg,.jpeg,.webp"
                onChange={(e) => {
                  appendFiles(e.target.files);
                  e.target.value = '';
                }}
                className="hidden"
              />
              <input
                ref={multiInputRef}
                type="file"
                multiple
                accept="video/*,image/*,audio/*,.mp4,.mov,.avi,.mkv,.webm,.mp3,.wav,.aac,.m4a,.png,.jpg,.jpeg,.webp"
                onChange={(e) => {
                  appendFiles(e.target.files);
                  e.target.value = '';
                }}
                className="hidden"
              />

              {queuedMedia.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 max-h-40 overflow-y-auto">
                  {queuedMedia.map((item) => (
                    <div
                      key={item.id}
                      className="relative bg-[#18181A] border border-[#3E3E44] rounded-xl overflow-hidden group"
                    >
                      <div className="aspect-video bg-[#222225] flex items-center justify-center overflow-hidden">
                        {item.kind === 'image' ? (
                          <img
                            src={item.previewUrl}
                            alt={item.file.name}
                            className="w-full h-full object-cover"
                          />
                        ) : item.kind === 'video' ? (
                          <video
                            src={item.previewUrl}
                            muted
                            playsInline
                            preload="metadata"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Music className="w-5 h-5 text-[#D4D4D8]" />
                        )}
                      </div>
                      <div className="px-2 py-1.5 flex items-center justify-between gap-1">
                        <span className="text-[10px] text-white truncate">
                          {item.file.name}
                        </span>
                        <button
                          type="button"
                          onClick={() => removeQueuedFile(item.id)}
                          aria-label={`Remove ${item.file.name}`}
                          className="p-1 text-[#A1A1AA] hover:text-white shrink-0"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Aspect Ratio Cards */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-white">Aspect Ratio</span>
              <span className="text-[11px] text-[#A1A1AA] font-mono-tabular">
                {width} × {height}
              </span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {ASPECT_RATIOS.map((ar) => {
                const active = aspectRatio === ar.id;
                return (
                  <button
                    key={ar.id}
                    type="button"
                    onClick={() => handleAspectChange(ar.id)}
                    className={`min-h-[68px] p-2 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all ${
                      active
                        ? 'bg-[#71717A]/15 border-[#A1A1AA] text-white'
                        : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-white hover:border-[#444444]'
                    }`}
                  >
                    <div
                      className={`rounded-[3px] border-2 ${
                        active ? 'border-[#A1A1AA] bg-[#71717A]/20' : 'border-current opacity-70'
                      }`}
                      style={{ width: ar.boxW, height: ar.boxH }}
                    />
                    <span className="text-[11px] font-semibold whitespace-nowrap">
                      {ar.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Resolution & Frame Rate */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-white block">Resolution</label>
              <div className="grid grid-cols-2 gap-2">
                {RESOLUTION_PRESETS.map((preset) => {
                  const active = resPreset === preset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handlePresetChange(preset.id)}
                      className={`min-h-[44px] px-3 py-2 rounded-xl border text-left transition-colors ${
                        active
                          ? 'bg-[#71717A]/15 border-[#A1A1AA] text-white'
                          : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-white'
                      }`}
                    >
                      <div className="text-xs font-semibold">{preset.label}</div>
                      <div className="text-[10px] opacity-80 font-mono-tabular">
                        {preset.sub}
                      </div>
                    </button>
                  );
                })}
              </div>
              {resPreset === 'custom' && (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <label className="text-[11px] text-[#A1A1AA] block mb-1">Width (px)</label>
                    <input
                      type="number"
                      min={256}
                      max={7680}
                      step={2}
                      value={width}
                      onChange={(e) => {
                        const v = Number(e.target.value) || 1920;
                        setWidth(v);
                        setAspectRatio('custom');
                      }}
                      className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded-lg text-white font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#A1A1AA] block mb-1">Height (px)</label>
                    <input
                      type="number"
                      min={256}
                      max={4320}
                      step={2}
                      value={height}
                      onChange={(e) => {
                        const v = Number(e.target.value) || 1080;
                        setHeight(v);
                        setAspectRatio('custom');
                      }}
                      className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded-lg text-white font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <div className="space-y-2">
                <label className="text-xs font-semibold text-white block">
                  Frame Rate (FPS)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {FPS_OPTIONS.map((f) => {
                    const active = fps === f;
                    return (
                      <button
                        key={f}
                        type="button"
                        onClick={() => setFps(f)}
                        className={`min-h-[44px] rounded-xl border font-mono-tabular text-xs font-semibold transition-colors ${
                          active
                            ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                            : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-white'
                        }`}
                      >
                        {f} fps
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-white block">
                  Background
                </label>
                <div className="flex items-center gap-2 p-2.5 bg-[#2C2C30] border border-[#3E3E44] rounded-xl">
                  <input
                    type="color"
                    value={backgroundColor}
                    onChange={(e) => setBackgroundColor(e.target.value)}
                    className="w-7 h-7 bg-transparent border border-[#3E3E44] rounded-lg cursor-pointer"
                  />
                  <div className="flex items-center gap-1.5">
                    {BG_SWATCHES.map((hex) => (
                      <button
                        key={hex}
                        type="button"
                        onClick={() => setBackgroundColor(hex)}
                        title={hex}
                        style={{ backgroundColor: hex }}
                        className={`w-6 h-6 rounded-lg border ${
                          backgroundColor.toLowerCase() === hex.toLowerCase()
                            ? 'border-[#A1A1AA] ring-2 ring-[#A1A1AA]/40'
                            : 'border-[#3E3E44]'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="font-mono-tabular text-[11px] text-[#A1A1AA] ml-auto">
                    {backgroundColor.toUpperCase()}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Collapsible Advanced Options */}
          <div className="border border-[#3E3E44] rounded-xl bg-[#2C2C30]/60 overflow-hidden">
            <button
              type="button"
              onClick={() => setShowAdvanced((v) => !v)}
              className="w-full min-h-[44px] px-4 py-2.5 flex items-center justify-between text-xs font-medium text-white hover:bg-[#2C2C30] transition-colors"
            >
              <span>Advanced Format &amp; Track Defaults</span>
              {showAdvanced ? (
                <ChevronUp className="w-4 h-4 text-[#A1A1AA]" />
              ) : (
                <ChevronDown className="w-4 h-4 text-[#A1A1AA]" />
              )}
            </button>
            {showAdvanced && (
              <div className="p-4 pt-2 border-t border-[#3E3E44] space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] text-[#A1A1AA] block mb-1">
                      Video Format
                    </label>
                    <select
                      value={videoFormat}
                      onChange={(e) => setVideoFormat(e.target.value as VideoFormatPreset)}
                      className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded-lg text-white focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value="mp4">MP4 (H.264)</option>
                      <option value="mov">MOV (QuickTime)</option>
                      <option value="webm">WebM (VP9)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-[#A1A1AA] block mb-1">
                      Audio Sample Rate
                    </label>
                    <select
                      value={audioSampleRate}
                      onChange={(e) =>
                        setAudioSampleRate(Number(e.target.value) as AudioSampleRatePreset)
                      }
                      className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded-lg text-white font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value={44100}>44,100 Hz</option>
                      <option value={48000}>48,000 Hz</option>
                      <option value={96000}>96,000 Hz</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-[#A1A1AA] block mb-1">
                      Default Clip Duration
                    </label>
                    <select
                      value={defaultClipDuration}
                      onChange={(e) => setDefaultClipDuration(Number(e.target.value))}
                      className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded-lg text-white font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value={3}>3 sec</option>
                      <option value={5}>5 sec</option>
                      <option value={8}>8 sec</option>
                      <option value={10}>10 sec</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                  <div className="sm:col-span-2">
                    <label className="text-[11px] text-[#A1A1AA] block mb-1">
                      Workspace Folder
                    </label>
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        className="flex-1 min-w-0 px-3 py-2 bg-[#18181A] border border-[#3E3E44] rounded-lg text-white font-mono-tabular text-[11px] focus:outline-none focus:border-[#A1A1AA]"
                      />
                      <button
                        type="button"
                        onClick={handleBrowseLocation}
                        className="px-3 py-2 bg-[#18181A] hover:bg-[#343439] text-white rounded-lg border border-[#3E3E44] whitespace-nowrap"
                      >
                        Browse
                      </button>
                    </div>
                  </div>
                  {mode === 'create' && (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[11px] text-[#A1A1AA] block mb-1">
                          Video Tracks
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={8}
                          value={videoTrackCount}
                          onChange={(e) => setVideoTrackCount(Number(e.target.value) || 2)}
                          className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded-lg text-white font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-[#A1A1AA] block mb-1">
                          Audio Tracks
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={8}
                          value={audioTrackCount}
                          onChange={(e) => setAudioTrackCount(Number(e.target.value) || 2)}
                          className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded-lg text-white font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <label className="flex items-center gap-2 text-white cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={snapEnabled}
                    onChange={(e) => setSnapEnabled(e.target.checked)}
                    className="accent-[#A1A1AA] w-4 h-4"
                  />
                  <span>Enable magnetic timeline snapping</span>
                </label>
              </div>
            )}
          </div>

          {/* Submit Footer */}
          <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#3E3E44]">
            <div className="text-[11px] font-mono-tabular text-[#A1A1AA]">
              {width} × {height} · {fps} fps
              {queuedMedia.length > 0 ? ` · ${queuedMedia.length} media` : ''}
            </div>
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onCancel}
                className="min-h-[44px] px-4 py-2 text-[#A1A1AA] hover:text-white hover:bg-[#2C2C30] rounded-xl transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="min-h-[44px] px-6 py-2 bg-[#52525B] hover:bg-[#6B7280] text-white font-semibold rounded-xl flex items-center gap-2 transition-colors active:scale-[0.98]"
              >
                <Check className="w-4 h-4" />
                {mode === 'edit'
                  ? 'Save Settings'
                  : queuedMedia.length > 0
                  ? `Create & Import (${queuedMedia.length})`
                  : 'Create Project'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
