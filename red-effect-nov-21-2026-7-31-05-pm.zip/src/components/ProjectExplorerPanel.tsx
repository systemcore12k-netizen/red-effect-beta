import React, { useState } from 'react';
import {
  FolderPlus,
  FilePlus2,
  FolderOpen,
  Save,
  Trash2,
  Clock,
  Film,
  HardDriveDownload,
} from 'lucide-react';
import { StudioProject } from '../types/studio';

interface ProjectExplorerPanelProps {
  project: StudioProject;
  recentProjects: StudioProject[];
  lastSavedAt: number | null;
  onOpenNewProjectModal: () => void;
  onOpenProjectSettingsModal: () => void;
  onLoadProject: (proj: StudioProject) => void;
  onDeleteProject: (id: string) => void;
  onSaveToDB: () => void;
  onSaveFileToPC: () => void;
  onOpenFileFromPC: () => void;
  onCreateFolder: (folderName: string) => void;
  activeFolder: string;
  onSelectFolder: (folder: string) => void;
}

export const ProjectExplorerPanel: React.FC<ProjectExplorerPanelProps> = ({
  project,
  recentProjects,
  lastSavedAt,
  onOpenNewProjectModal,
  onOpenProjectSettingsModal,
  onLoadProject,
  onDeleteProject,
  onSaveToDB,
  onSaveFileToPC,
  onOpenFileFromPC,
  onCreateFolder,
  activeFolder,
  onSelectFolder,
}) => {
  const [newFolderInput, setNewFolderInput] = useState('');

  const handleAddFolder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderInput.trim()) return;
    onCreateFolder(newFolderInput.trim());
    setNewFolderInput('');
  };

  return (
    <div className="p-3 space-y-4 text-xs bg-[#222225] text-[#F4F4F5] h-full overflow-y-auto">
      {/* Quick Project Actions */}
      <div className="grid grid-cols-2 gap-1.5">
        <button
          type="button"
          onClick={onOpenNewProjectModal}
          className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-[#52525B] hover:bg-[#6B7280] text-white font-medium rounded transition-colors whitespace-nowrap"
        >
          <FilePlus2 className="w-3.5 h-3.5" />
          New Project
        </button>
        <button
          type="button"
          onClick={onOpenFileFromPC}
          className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] rounded border border-[#3E3E44] transition-colors whitespace-nowrap"
        >
          <FolderOpen className="w-3.5 h-3.5" />
          Open PC File
        </button>
        <button
          type="button"
          onClick={onSaveToDB}
          className="flex items-center justify-center gap-1.5 py-1.5 px-2.5 bg-[#18181A] hover:bg-[#2C2C30] text-[#F4F4F5] rounded border border-[#3E3E44] transition-colors whitespace-nowrap"
        >
          <Save className="w-3.5 h-3.5 text-[#D4D4D8]" />
          Quick Save
        </button>
        <button
          type="button"
          onClick={onSaveFileToPC}
          className="flex items-center justify-center gap-1.5 py-1.5 px-2.5 bg-[#18181A] hover:bg-[#2C2C30] text-[#F4F4F5] rounded border border-[#3E3E44] transition-colors whitespace-nowrap"
        >
          <HardDriveDownload className="w-3.5 h-3.5 text-[#A1A1AA]" />
          Save to Disk
        </button>
      </div>

      {/* Active Sequence Info */}
      <div className="border-t border-[#3E3E44] pt-3 space-y-1.5">
        <div className="flex items-center justify-between gap-2 text-[#A1A1AA]">
          <span className="font-medium text-[#F4F4F5] flex items-center gap-1.5 min-w-0 truncate">
            <Film className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0" />
            <span className="truncate">{project.name}</span>
          </span>
          <button
            type="button"
            onClick={onOpenProjectSettingsModal}
            className="text-[10px] text-[#D4D4D8] hover:text-[#E4E4E7] shrink-0"
          >
            Settings
          </button>
        </div>
        <div className="text-[11px] text-[#A1A1AA] font-mono-tabular">
          {project.width}×{project.height} · {project.fps} FPS · {project.clips.length} clips
        </div>
        {lastSavedAt && (
          <div className="text-[11px] text-[#A1A1AA] font-mono-tabular">
            Auto-saved {new Date(lastSavedAt).toLocaleTimeString()}
          </div>
        )}
      </div>

      {/* Structured Project Organization Tree */}
      <div className="border-t border-[#3E3E44] pt-3 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-[#A1A1AA]">Project Organization Tree</span>
        </div>
        <div className="space-y-0.5">
          <button
            type="button"
            onClick={() => onSelectFolder('ALL')}
            className={`w-full text-left px-2 py-1.5 rounded flex items-center justify-between transition-colors ${
              activeFolder === 'ALL'
                ? 'bg-[#71717A]/20 text-[#F4F4F5] border-l-2 border-[#A1A1AA]'
                : 'text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
            }`}
          >
            <span>Project Root (All)</span>
            <span className="font-mono-tabular text-[#A1A1AA]">{project.assets.length}</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectFolder('Media')}
            className={`w-full text-left px-2 py-1.5 rounded flex items-center justify-between transition-colors ${
              activeFolder === 'Media'
                ? 'bg-[#71717A]/20 text-[#F4F4F5] border-l-2 border-[#A1A1AA]'
                : 'text-[#F4F4F5] hover:bg-[#2C2C30]'
            }`}
          >
            <span>Media</span>
            <span className="font-mono-tabular text-[#A1A1AA]">
              {project.assets.filter((a) => a.folder.startsWith('Media')).length}
            </span>
          </button>
          {project.folders.map((folder) => {
            const isSub = folder.includes('/');
            const display = isSub ? folder.split('/').slice(1).join('/') : folder;
            const count =
              folder === 'Text'
                ? project.clips.filter((c) => c.type === 'text').length
                : folder === 'Graphics'
                ? project.clips.filter((c) => c.type === 'shape' || c.type === 'null').length
                : folder === 'Effects'
                ? project.clips.reduce((acc, c) => acc + (c.effectsStack?.length || 0), 0)
                : folder === 'Transitions'
                ? project.clips.filter((c) => c.transitionIn !== 'none' || c.transitionOut !== 'none').length
                : folder === 'Animations'
                ? project.clips.filter((c) => c.keyframes.length > 0).length
                : project.assets.filter((a) => a.folder === folder).length;
            return (
              <button
                key={folder}
                type="button"
                onClick={() => onSelectFolder(folder)}
                style={{ paddingLeft: isSub ? '20px' : '8px' }}
                className={`w-full text-left pr-2 py-1.5 rounded flex items-center justify-between transition-colors ${
                  activeFolder === folder
                    ? 'bg-[#71717A]/20 text-[#F4F4F5] border-l-2 border-[#A1A1AA]'
                    : 'text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
                }`}
              >
                <span className="truncate">{isSub ? `↳ ${display}` : display}</span>
                <span className="font-mono-tabular text-[#A1A1AA]">{count}</span>
              </button>
            );
          })}
        </div>

        <form onSubmit={handleAddFolder} className="flex gap-1 pt-1">
          <input
            type="text"
            value={newFolderInput}
            onChange={(e) => setNewFolderInput(e.target.value)}
            placeholder="New bin name..."
            className="flex-1 min-w-0 px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] text-[11px] focus:outline-none focus:border-[#A1A1AA]"
          />
          <button
            type="submit"
            title="Create Folder Bin"
            className="p-1.5 bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] rounded border border-[#3E3E44]"
          >
            <FolderPlus className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

      {/* Recent Projects */}
      <div className="border-t border-[#3E3E44] pt-3 space-y-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#A1A1AA]">
          <Clock className="w-3.5 h-3.5" />
          Recent Projects
        </div>
        {recentProjects.length === 0 ? (
          <div className="text-[11px] text-[#A1A1AA]">No saved projects yet.</div>
        ) : (
          <div className="space-y-1">
            {recentProjects.map((rp) => (
              <div
                key={rp.id}
                className={`flex items-center justify-between px-2 py-1.5 rounded border transition-colors ${
                  rp.id === project.id
                    ? 'bg-[#2C2C30] border-[#A1A1AA]'
                    : 'bg-[#18181A] border-[#3E3E44] hover:border-[#A1A1AA]/50'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onLoadProject(rp)}
                  className="flex-1 text-left min-w-0"
                >
                  <div className="text-[#F4F4F5] font-medium truncate">{rp.name}</div>
                  <div className="text-[10px] text-[#A1A1AA] font-mono-tabular">
                    {rp.width}×{rp.height} · {rp.fps}fps ·{' '}
                    {new Date(rp.updatedAt).toLocaleDateString()}
                  </div>
                </button>
                {rp.id !== project.id && (
                  <button
                    type="button"
                    onClick={() => onDeleteProject(rp.id)}
                    title="Delete saved project"
                    className="p-1 text-[#A1A1AA] hover:text-rose-400"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
