import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Diamond,
  RotateCcw,
  Camera,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  Copy,
  ClipboardPaste,
  Trash2,
  Plus,
  Save,
  Upload,
  Sliders,
  Sparkles,
  Palette,
  Volume2,
  Link2,
  Unlink,
  Lock,
  Unlock,
  Pencil,
  Crosshair,
  Group,
  Ungroup,
  AlignLeft,
  AlignCenterHorizontal,
  AlignRight,
  AlignStartVertical,
  AlignCenterVertical,
  AlignEndVertical,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  AlignCenter,
  Film,
  Type as TypeIcon,
} from 'lucide-react';
import {
  AnimationEasing,
  EffectBlendMode,
  EffectInstance,
  ReadyMadeCategoryId,
  ReadyMadeEffectPreset,
  StudioPreset,
  TextAnimationEffect,
  TransitionDirection,
  TransitionSettings,
} from '../types/effects';
import {
  BlendMode,
  Camera3DSettings,
  ColorGrade,
  Keyframe,
  MarkerColor,
  StudioProject,
  TextProperties,
  TimelineClip,
  TransitionType,
} from '../types/studio';
import {
  EFFECTS_CATALOG,
  TRANSITIONS_CATALOG,
  createEffectInstance,
  getDefaultTransitionSettings,
  getEffectDefinition,
} from '../services/effectsCatalog';
import { getRegisteredLuts, registerCubeLut } from '../services/effectsProcessor';
import {
  evaluateKeyframeProperty,
  getClipAnimationEvalTime,
  wouldCreateParentCycle,
} from '../services/videoCompositor';
import {
  createDefaultChromaKey,
  createDefaultColorGrade,
  createDefaultEffects,
  createDefaultTransform,
} from '../services/projectStorage';

export type InspectorTab = 'effects' | 'transform' | 'video' | 'color' | 'audio' | 'text';

const NULL_LABEL_HEX: Record<MarkerColor, string> = {
  rose: '#E11D48',
  amber: '#F59E0B',
  emerald: '#10B981',
  sky: '#0EA5E9',
  violet: '#8B5CF6',
};

interface PropertiesPanelProps {
  project: StudioProject;
  selectedClip: TimelineClip | null;
  selectedClipIds?: string[];
  playheadTime: number;
  camera3D: Camera3DSettings;
  copiedEffectsStack: EffectInstance[];
  hasCopiedAttributes?: boolean;
  onUpdateClip: (clipId: string, updater: (c: TimelineClip) => TimelineClip) => void;
  onBatchUpdateClips?: (
    updates: Record<string, (c: TimelineClip) => TimelineClip>,
    commitHistory?: boolean
  ) => void;
  onSetClipParent?: (clipId: string, parentId: string | undefined) => void;
  onDuplicateClip?: (clipId: string) => void;
  onDeleteClip?: (clipId: string) => void;
  onRequestRenameClip?: (clipId: string) => void;
  onSelectClip?: (clipId: string) => void;
  forceTabSignal?: { clipId: string; tab: InspectorTab; seq: number } | null;
  onGroupSelected?: () => void;
  onUngroupSelected?: () => void;
  onUpdateCamera3D: (cam: Camera3DSettings) => void;
  onCopyEffectsStack: (stack: EffectInstance[]) => void;
  onCopyAttributes?: (clipId: string) => void;
  onPasteAttributes?: (clipId: string) => void;
  onSaveStackAsPreset: (preset: StudioPreset) => void;
  onSaveReadyMadePreset?: (preset: ReadyMadeEffectPreset) => void;
  initialTab?: InspectorTab;
  autoKeyframeEnabled?: boolean;
  onToggleAutoKeyframe?: () => void;
  onSeek?: (time: number) => void;
}

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  project,
  selectedClip,
  selectedClipIds = [],
  playheadTime,
  camera3D,
  copiedEffectsStack,
  hasCopiedAttributes = false,
  onUpdateClip,
  onBatchUpdateClips,
  onSetClipParent,
  onDuplicateClip,
  onDeleteClip,
  onRequestRenameClip,
  onSelectClip,
  forceTabSignal,
  onGroupSelected,
  onUngroupSelected,
  onUpdateCamera3D,
  onCopyEffectsStack,
  onCopyAttributes,
  onPasteAttributes,
  onSaveStackAsPreset,
  onSaveReadyMadePreset,
  initialTab = 'effects',
  autoKeyframeEnabled = false,
  onToggleAutoKeyframe,
  onSeek,
}) => {
  const [tab, setTab] = useState<InspectorTab>(initialTab);
  const [addEffectType, setAddEffectType] = useState<string>(EFFECTS_CATALOG[0].type);
  const [copiedKeyframes, setCopiedKeyframes] = useState<Keyframe[]>([]);
  const [, setLutRefresh] = useState(0);
  const lutInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!selectedClip) return;
    if (forceTabSignal && forceTabSignal.clipId === selectedClip.id) {
      setTab(forceTabSignal.tab);
      return;
    }
    if (selectedClip.type === 'text') {
      setTab('text');
    } else if (selectedClip.type === 'null') {
      setTab('transform');
    } else if (selectedClip.type === 'fx') {
      setTab(selectedClip.fxMeta?.category === 'cc' ? 'color' : 'effects');
    } else if (selectedClip.type === 'audio') {
      setTab('audio');
    } else if (tab === 'text' || tab === 'audio') {
      setTab('transform');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedClip?.id, selectedClip?.type, selectedClip?.fxMeta?.category, forceTabSignal?.seq]);

  const parentCandidates = useMemo(() => {
    if (!selectedClip) return [];
    return project.clips.filter(
      (c) =>
        c.id !== selectedClip.id &&
        c.type !== 'audio' &&
        !wouldCreateParentCycle(selectedClip.id, c.id, project.clips)
    );
  }, [project.clips, selectedClip]);

  if (!selectedClip) {
    return (
      <div
        data-tutorial-target="properties-panel"
        className="p-3 space-y-3 text-xs bg-[#222225] text-[#F4F4F5] h-full overflow-y-auto"
      >
        <div className="flex items-center gap-1.5 text-[#F4F4F5] font-medium border-b border-[#3E3E44] pb-2">
          <Camera className="w-3.5 h-3.5 text-[#D4D4D8]" />
          Sequence 3D Camera Controls
        </div>

        <div className="space-y-3">
          <SliderRow
            label="Camera Zoom"
            value={camera3D.zoom}
            min={0.5}
            max={2.5}
            step={0.05}
            unit="×"
            onChange={(v) => onUpdateCamera3D({ ...camera3D, zoom: v })}
          />
          <SliderRow
            label="Orbit X (Tilt)"
            value={camera3D.orbitX}
            min={-45}
            max={45}
            step={1}
            unit="°"
            onChange={(v) => onUpdateCamera3D({ ...camera3D, orbitX: v })}
          />
          <SliderRow
            label="Orbit Y (Pan)"
            value={camera3D.orbitY}
            min={-45}
            max={45}
            step={1}
            unit="°"
            onChange={(v) => onUpdateCamera3D({ ...camera3D, orbitY: v })}
          />
          <SliderRow
            label="Depth of Field Blur"
            value={camera3D.dofBlur}
            min={0}
            max={20}
            step={1}
            unit="px"
            onChange={(v) => onUpdateCamera3D({ ...camera3D, dofBlur: v })}
          />
          <button
            type="button"
            onClick={() =>
              onUpdateCamera3D({ fov: 50, orbitX: 0, orbitY: 0, zoom: 1, dofBlur: 0 })
            }
            className="w-full py-1.5 bg-[#2C2C30] hover:bg-[#2F3340] text-[#F4F4F5] rounded-[5px] border border-[#3E3E44] flex items-center justify-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset 3D Camera
          </button>
        </div>

        <div className="text-[11px] text-[#A1A1AA] pt-2 border-t border-[#3E3E44] leading-relaxed">
          Select any clip, text, effect layer, or Null Object on the timeline to inspect and keyframe its parameters.
        </div>
      </div>
    );
  }

  const safeTransform = { ...createDefaultTransform(), ...(selectedClip.transform || {}) };
  const safeEffects = { ...createDefaultEffects(), ...(selectedClip.effects || {}) };
  const safeColorGrade = {
    ...createDefaultColorGrade(),
    ...(selectedClip.colorGrade || {}),
  };
  const safeChromaKey = { ...createDefaultChromaKey(), ...(selectedClip.chromaKey || {}) };

  const localTime = Math.max(0, Math.min(selectedClip.duration, playheadTime - selectedClip.startTime));
  const evalTime = getClipAnimationEvalTime(selectedClip, localTime);

  const getEvalProp = (property: Keyframe['property'], fallback: number) =>
    evaluateKeyframeProperty(selectedClip.keyframes, property, evalTime, fallback);

  const setTransformWithKeyframe = (
    kfProperty: Keyframe['property'],
    transformKey: keyof TimelineClip['transform'],
    nextValue: number
  ) => {
    onUpdateClip(selectedClip.id, (c) => {
      const nextClipTime = Math.max(0, Math.min(c.duration, playheadTime - c.startTime));
      const roundedT = Math.round(nextClipTime * 100) / 100;
      const shouldKey =
        autoKeyframeEnabled || c.keyframes.some((k) => k.property === kfProperty);
      let nextKeyframes = c.keyframes;
      if (shouldKey) {
        const existingIdx = c.keyframes.findIndex(
          (k) => k.property === kfProperty && Math.abs(k.time - nextClipTime) < 0.12
        );
        if (existingIdx >= 0) {
          nextKeyframes = c.keyframes.map((k, idx) =>
            idx === existingIdx ? { ...k, value: nextValue } : k
          );
        } else {
          nextKeyframes = [
            ...c.keyframes,
            {
              id: `kf-${Date.now()}-${kfProperty}-${Math.random().toString(36).slice(2, 6)}`,
              time: roundedT,
              property: kfProperty,
              value: nextValue,
              easing: 'easeInOut' as AnimationEasing,
              bezier: [0.42, 0, 0.58, 1] as [number, number, number, number],
            },
          ].sort((a, b) => a.time - b.time);
        }
      }
      return {
        ...c,
        keyframes: nextKeyframes,
        transform: {
          ...(c.transform || createDefaultTransform()),
          [transformKey]: nextValue,
        },
      };
    });
  };

  const toggleKeyframe = (property: Keyframe['property'], currentValue: number) => {
    onUpdateClip(selectedClip.id, (c) => {
      const existingIdx = c.keyframes.findIndex(
        (k) => k.property === property && Math.abs(k.time - localTime) < 0.12
      );
      if (existingIdx >= 0) {
        return {
          ...c,
          keyframes: c.keyframes.filter((_, idx) => idx !== existingIdx),
        };
      }
      return {
        ...c,
        keyframes: [
          ...c.keyframes,
          {
            id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            time: Math.round(localTime * 100) / 100,
            property,
            value: currentValue,
            easing: 'easeInOut' as AnimationEasing,
            bezier: [0.42, 0, 0.58, 1] as [number, number, number, number],
          },
        ].sort((a, b) => a.time - b.time),
      };
    });
  };

  const hasKfAtPlayhead = (property: Keyframe['property']) =>
    selectedClip.keyframes.some(
      (k) => k.property === property && Math.abs(k.time - localTime) < 0.12
    );

  const stack = selectedClip.effectsStack || [];

  const updateEffect = (fxId: string, updater: (fx: EffectInstance) => EffectInstance) => {
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      effectsStack: (c.effectsStack || []).map((fx) => (fx.id === fxId ? updater(fx) : fx)),
    }));
  };

  const moveEffect = (idx: number, dir: -1 | 1) => {
    const nextIdx = idx + dir;
    if (nextIdx < 0 || nextIdx >= stack.length) return;
    onUpdateClip(selectedClip.id, (c) => {
      const copy = [...(c.effectsStack || [])];
      const [item] = copy.splice(idx, 1);
      copy.splice(nextIdx, 0, item);
      return { ...c, effectsStack: copy };
    });
  };

  const duplicateEffect = (idx: number) => {
    const src = stack[idx];
    if (!src) return;
    const dup: EffectInstance = {
      ...structuredClone(src),
      id: `fx-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name: `${src.name} Copy`,
    };
    onUpdateClip(selectedClip.id, (c) => {
      const copy = [...(c.effectsStack || [])];
      copy.splice(idx + 1, 0, dup);
      return { ...c, effectsStack: copy };
    });
  };

  const resetEffectParams = (fx: EffectInstance) => {
    const def = getEffectDefinition(fx.type);
    if (!def) return;
    const defaults: Record<string, number | string | boolean> = {};
    def.params.forEach((p) => {
      defaults[p.key] = p.defaultValue;
    });
    updateEffect(fx.id, (cur) => ({ ...cur, params: defaults }));
  };

  const handleCubeUpload = async (e: React.ChangeEvent<HTMLInputElement>, fxId: string) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const parsed = registerCubeLut(file.name, text);
    if (parsed) {
      updateEffect(fxId, (cur) => ({
        ...cur,
        params: { ...cur.params, customLut: parsed.name },
      }));
      setLutRefresh((n) => n + 1);
    }
    e.target.value = '';
  };

  const transitionInCfg: TransitionSettings =
    selectedClip.transitionInConfig || getDefaultTransitionSettings(selectedClip.transitionIn);
  const transitionOutCfg: TransitionSettings =
    selectedClip.transitionOutConfig || getDefaultTransitionSettings(selectedClip.transitionOut);

  const addAllTransformKeyframes = () => {
    const roundedT = Math.round(localTime * 100) / 100;
    const entries: Array<{ prop: Keyframe['property']; val: number }> =
      tab === 'effects'
        ? [
            { prop: 'blur', val: getEvalProp('blur', safeEffects.blur) },
            { prop: 'glow', val: getEvalProp('glow', safeEffects.glow) },
          ]
        : [
            { prop: 'x', val: getEvalProp('x', safeTransform.x) },
            { prop: 'y', val: getEvalProp('y', safeTransform.y) },
            { prop: 'scale', val: getEvalProp('scale', safeTransform.scale) },
            { prop: 'rotation', val: getEvalProp('rotation', safeTransform.rotation) },
            { prop: 'opacity', val: getEvalProp('opacity', safeTransform.opacity) },
          ];

    onUpdateClip(selectedClip.id, (c) => {
      let next = [...c.keyframes];
      for (const item of entries) {
        next = next.filter(
          (k) => !(k.property === item.prop && Math.abs(k.time - roundedT) < 0.12)
        );
        next.push({
          id: `kf-${Date.now()}-${item.prop}-${Math.random().toString(36).slice(2, 5)}`,
          time: roundedT,
          property: item.prop,
          value: item.val,
          easing: 'easeInOut',
          bezier: [0.42, 0, 0.58, 1],
        });
      }
      return { ...c, keyframes: next };
    });
  };

  const deletePlayheadKeyframes = () => {
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes: c.keyframes.filter((k) => Math.abs(k.time - localTime) >= 0.12),
    }));
  };

  const duplicatePlayheadKeyframes = () => {
    const atPlayhead = selectedClip.keyframes.filter((k) => Math.abs(k.time - localTime) < 0.12);
    const source = atPlayhead.length > 0 ? atPlayhead : selectedClip.keyframes.slice(-1);
    if (source.length === 0) return;
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes: [
        ...c.keyframes,
        ...source.map((k) => ({
          ...structuredClone(k),
          id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          time: Math.min(c.duration, Math.round((k.time + 0.5) * 100) / 100),
        })),
      ],
    }));
  };

  const jumpKeyframe = (dir: 'prev' | 'next') => {
    const sorted = [...selectedClip.keyframes].sort((a, b) => a.time - b.time);
    if (sorted.length === 0 || !onSeek) return;
    if (dir === 'prev') {
      const target =
        [...sorted].reverse().find((k) => k.time < localTime - 0.04) || sorted[sorted.length - 1];
      onSeek(selectedClip.startTime + target.time);
    } else {
      const target = sorted.find((k) => k.time > localTime + 0.04) || sorted[0];
      onSeek(selectedClip.startTime + target.time);
    }
  };

  const kfsAtPlayheadCount = selectedClip.keyframes.filter(
    (k) => Math.abs(k.time - localTime) < 0.12
  ).length;

  return (
    <div
      data-tutorial-target="properties-panel"
      className="flex flex-col h-full text-xs bg-[#222225] text-[#F4F4F5]"
    >
      {/* Selected Clip Header Banner */}
      <div className="px-3 py-2 border-b border-[#3E3E44] bg-[#2C2C30] flex items-center justify-between gap-2 shrink-0">
        <div className="min-w-0">
          <div className="font-semibold text-[#F4F4F5] truncate flex items-center gap-1.5">
            <span className="truncate">{selectedClip.name}</span>
            {selectedClip.parentClipId && (
              <span className="px-1.5 py-0.5 rounded-[4px] bg-[#71717A]/20 border border-[#A1A1AA]/45 text-[9px] text-[#E4E4E7] shrink-0">
                Parented
              </span>
            )}
          </div>
          <div className="text-[10px] text-[#A1A1AA] font-mono-tabular">
            {selectedClip.type.toUpperCase()} · {selectedClip.startTime.toFixed(2)}s →{' '}
            {(selectedClip.startTime + selectedClip.duration).toFixed(2)}s
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {onCopyAttributes && (
            <button
              type="button"
              onClick={() => onCopyAttributes(selectedClip.id)}
              title="Copy Transform, FX & Color Attributes"
              className="px-1.5 py-1 rounded-[5px] bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[10px] text-[#F4F4F5] flex items-center gap-1 transition-colors"
            >
              <Copy className="w-2.5 h-2.5 text-[#A1A1AA]" />
              Copy
            </button>
          )}
          {onPasteAttributes && (
            <button
              type="button"
              disabled={!hasCopiedAttributes}
              onClick={() => onPasteAttributes(selectedClip.id)}
              title="Paste Copied Attributes to Clip"
              className="px-1.5 py-1 rounded-[5px] bg-[#222225] hover:bg-[#2F3340] disabled:opacity-35 border border-[#3E3E44] text-[10px] text-[#F4F4F5] flex items-center gap-1 transition-colors"
            >
              <ClipboardPaste className="w-2.5 h-2.5 text-[#A1A1AA]" />
              Paste
            </button>
          )}
        </div>
      </div>

      {/* Contextual 5-Tab Inspector Navigation */}
      <div className="grid grid-cols-5 border-b border-[#3E3E44] bg-[#18181A] shrink-0">
        {(
          [
            { id: 'transform', label: 'Transform', icon: <Sliders className="w-3 h-3" /> },
            selectedClip.type === 'text'
              ? { id: 'text', label: 'Text', icon: <TypeIcon className="w-3 h-3" /> }
              : { id: 'video', label: 'Speed', icon: <Film className="w-3 h-3" /> },
            { id: 'effects', label: 'Effects', icon: <Sparkles className="w-3 h-3" /> },
            { id: 'color', label: 'Color', icon: <Palette className="w-3 h-3" /> },
            { id: 'audio', label: 'Audio', icon: <Volume2 className="w-3 h-3" /> },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id as InspectorTab)}
            className={`py-2 px-1 flex items-center justify-center gap-1 text-[10px] font-medium border-b-2 transition-colors whitespace-nowrap ${
              tab === t.id
                ? 'border-[#A1A1AA] text-[#F4F4F5] bg-[#222225]'
                : 'border-transparent text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#222225]/50'
            }`}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      {/* Master Keyframe Control Strip */}
      <div
        data-tutorial-target="keyframe-controls"
        className="px-2.5 py-1.5 bg-[#2C2C30] border-b border-[#3E3E44] flex flex-wrap items-center justify-between gap-1 shrink-0"
      >
        <div className="flex items-center gap-1">
          {onToggleAutoKeyframe && (
            <button
              type="button"
              onClick={onToggleAutoKeyframe}
              title="Toggle Auto Keyframe Recording"
              className={`px-1.5 py-0.5 rounded border text-[10px] font-medium flex items-center gap-1 transition-colors ${
                autoKeyframeEnabled
                  ? 'bg-[#52525B] border-[#A1A1AA] text-[#F4F4F5]'
                  : 'bg-[#222225] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
              }`}
            >
              <Diamond className="w-2.5 h-2.5 fill-current" />
              Auto {autoKeyframeEnabled ? 'ON' : 'OFF'}
            </button>
          )}
          <button
            type="button"
            onClick={addAllTransformKeyframes}
            title="Insert Keyframe at Playhead"
            className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#52525B] border border-[#3E3E44] text-[10px] text-[#F4F4F5] flex items-center gap-0.5 transition-colors"
          >
            <Plus className="w-2.5 h-2.5" />
            KF
          </button>
          <button
            type="button"
            disabled={kfsAtPlayheadCount === 0}
            onClick={deletePlayheadKeyframes}
            title="Delete Keyframes at Playhead"
            className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#2F3340] disabled:opacity-35 border border-[#3E3E44] text-[10px] text-red-300"
          >
            Del
          </button>
          <button
            type="button"
            disabled={selectedClip.keyframes.length === 0}
            onClick={duplicatePlayheadKeyframes}
            title="Duplicate Keyframe (+0.5s)"
            className="px-1.5 py-0.5 rounded bg-[#222225] hover:bg-[#2F3340] disabled:opacity-35 border border-[#3E3E44] text-[10px] text-[#F4F4F5]"
          >
            Dup
          </button>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            disabled={selectedClip.keyframes.length === 0 || !onSeek}
            onClick={() => jumpKeyframe('prev')}
            title="Previous Keyframe"
            className="p-0.5 rounded bg-[#222225] hover:bg-[#2F3340] disabled:opacity-35 border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]"
          >
            <ChevronLeft className="w-3 h-3" />
          </button>
          <button
            type="button"
            disabled={selectedClip.keyframes.length === 0 || !onSeek}
            onClick={() => jumpKeyframe('next')}
            title="Next Keyframe"
            className="p-0.5 rounded bg-[#222225] hover:bg-[#2F3340] disabled:opacity-35 border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]"
          >
            <ChevronRight className="w-3 h-3" />
          </button>
          <button
            type="button"
            disabled={selectedClip.keyframes.length === 0}
            onClick={() => setCopiedKeyframes(structuredClone(selectedClip.keyframes))}
            title="Copy Clip Keyframes"
            className="p-0.5 rounded bg-[#222225] hover:bg-[#2F3340] disabled:opacity-35 border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]"
          >
            <Copy className="w-3 h-3" />
          </button>
          <button
            type="button"
            disabled={copiedKeyframes.length === 0}
            onClick={() =>
              onUpdateClip(selectedClip.id, (c) => ({
                ...c,
                keyframes: [
                  ...c.keyframes,
                  ...copiedKeyframes.map((k) => ({
                    ...structuredClone(k),
                    id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                  })),
                ],
              }))
            }
            title="Paste Copied Keyframes"
            className="p-0.5 rounded bg-[#222225] hover:bg-[#2F3340] disabled:opacity-35 border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]"
          >
            <ClipboardPaste className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-2.5 space-y-2.5">
        {selectedClip.type === 'fx' && (tab === 'effects' || tab === 'color') && (
          <div className="p-2.5 bg-[#2C2C30] border border-[#A1A1AA]/55 rounded-[6px] space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[11px] font-semibold text-[#F4F4F5] truncate">
                  {selectedClip.name}
                </div>
                <div className="text-[10px] text-[#A1A1AA] truncate">
                  Effect Layer ({selectedClip.fxMeta?.category?.toUpperCase() || 'EFFECT'}) · {selectedClip.duration.toFixed(2)}s
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() =>
                    onUpdateClip(selectedClip.id, (c) => ({ ...c, disabled: !c.disabled }))
                  }
                  className={`px-2 py-1 rounded-[5px] text-[10px] font-medium flex items-center gap-1 border transition-colors ${
                    selectedClip.disabled
                      ? 'bg-[#222225] border-[#3E3E44] text-[#A1A1AA]'
                      : 'bg-[#52525B] border-[#A1A1AA] text-[#F4F4F5]'
                  }`}
                >
                  {selectedClip.disabled ? (
                    <>
                      <EyeOff className="w-3 h-3" /> Off
                    </>
                  ) : (
                    <>
                      <Eye className="w-3 h-3" /> Active
                    </>
                  )}
                </button>
                {onSaveReadyMadePreset && stack.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const cat: ReadyMadeCategoryId =
                        selectedClip.fxMeta?.category ||
                        (stack.some((s) => s.type === 'camera-shake') ? 'shake' : 'glitch');
                      onSaveReadyMadePreset({
                        id: `custom-fx-${Date.now()}`,
                        name: `${selectedClip.name} Custom`,
                        category: cat,
                        description: `Custom ${cat} layer preset`,
                        accentColor: '#A1A1AA',
                        defaultDuration: selectedClip.duration,
                        effectsStack: structuredClone(stack),
                      });
                    }}
                    title="Save FX Layer as Custom Preset in Effects Library"
                    className="px-2 py-1 bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] rounded-[5px] text-[10px] text-[#F4F4F5] flex items-center gap-1"
                  >
                    <Save className="w-3 h-3 text-[#D4D4D8]" />
                    Save
                  </button>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-1.5 pt-1 border-t border-[#3E3E44]">
              <SliderRow
                label="FX Duration"
                value={Math.round(selectedClip.duration * 100) / 100}
                min={0.2}
                max={30}
                step={0.1}
                unit="s"
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({ ...c, duration: Math.max(0.2, v) }))
                }
              />
              <SliderRow
                label="FX Speed"
                value={selectedClip.speed}
                min={0.25}
                max={4}
                step={0.05}
                unit="×"
                onChange={(v) => onUpdateClip(selectedClip.id, (c) => ({ ...c, speed: v }))}
              />
            </div>
          </div>
        )}

        {tab === 'text' && selectedClip.type === 'text' && selectedClip.textProps && (
          <div className="space-y-2.5">
            <InspectorSection title="Font & Content" defaultOpen>
              <textarea
                rows={2}
                value={selectedClip.textProps.text}
                onChange={(e) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    textProps: { ...(c.textProps as TextProperties), text: e.target.value },
                  }))
                }
                placeholder="Enter title or subtitle text..."
                className="w-full px-2 py-1.5 bg-[#18181A] border border-[#3E3E44] focus:border-[#A1A1AA] rounded-[5px] text-xs text-[#F4F4F5] focus:outline-none"
              />
              <div className="grid grid-cols-2 gap-1.5">
                <div>
                  <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Font Family</label>
                  <select
                    value={selectedClip.textProps.fontFamily}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: { ...(c.textProps as TextProperties), fontFamily: e.target.value },
                      }))
                    }
                    className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded-[5px] text-[11px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  >
                    <option value="Outfit">Outfit (Cinematic)</option>
                    <option value="Plus Jakarta Sans">Plus Jakarta Sans</option>
                    <option value="Bebas Neue">Bebas Neue</option>
                    <option value="Impact">Impact Poster</option>
                    <option value="Montserrat">Montserrat</option>
                    <option value="Inter">Inter Clean</option>
                    <option value="Georgia">Georgia Serif</option>
                    <option value="JetBrains Mono">JetBrains Mono</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Weight</label>
                  <select
                    value={String(selectedClip.textProps.fontWeight || 700)}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: {
                          ...(c.textProps as TextProperties),
                          fontWeight: Number(e.target.value),
                        },
                      }))
                    }
                    className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded-[5px] text-[11px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  >
                    <option value="400">Regular</option>
                    <option value="600">SemiBold</option>
                    <option value="700">Bold</option>
                    <option value="800">ExtraBold</option>
                    <option value="900">Black</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] text-[#A1A1AA]">Alignment</span>
                <div className="flex items-center bg-[#18181A] border border-[#3E3E44] rounded-[5px] p-0.5 gap-0.5">
                  {(['left', 'center', 'right'] as const).map((al) => (
                    <button
                      key={al}
                      type="button"
                      onClick={() =>
                        onUpdateClip(selectedClip.id, (c) => ({
                          ...c,
                          textProps: { ...(c.textProps as TextProperties), align: al },
                        }))
                      }
                      title={`Align ${al}`}
                      className={`px-2 py-0.5 rounded-[4px] transition-colors ${
                        (selectedClip.textProps?.align || 'center') === al
                          ? 'bg-[#52525B] text-[#F4F4F5]'
                          : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                      }`}
                    >
                      {al === 'left' ? (
                        <AlignLeft className="w-3 h-3" />
                      ) : al === 'center' ? (
                        <AlignCenter className="w-3 h-3" />
                      ) : (
                        <AlignRight className="w-3 h-3" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <SliderRow
                label="Size"
                value={selectedClip.textProps.fontSize}
                min={16}
                max={220}
                step={2}
                unit="px"
                keyframeActive={hasKfAtPlayhead('fontSize')}
                onToggleKeyframe={() => toggleKeyframe('fontSize', selectedClip.textProps!.fontSize)}
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    textProps: { ...(c.textProps as TextProperties), fontSize: v },
                  }))
                }
              />
              <SliderRow
                label="Letter Spacing"
                value={selectedClip.textProps.letterSpacing ?? 0}
                min={-10}
                max={60}
                step={1}
                unit="px"
                keyframeActive={hasKfAtPlayhead('textTracking')}
                onToggleKeyframe={() =>
                  toggleKeyframe('textTracking', selectedClip.textProps!.letterSpacing ?? 0)
                }
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    textProps: { ...(c.textProps as TextProperties), letterSpacing: v },
                  }))
                }
              />
            </InspectorSection>

            <InspectorSection title="Color, Stroke & Shadow" defaultOpen>
              <div className="grid grid-cols-3 gap-1.5">
                <label className="flex flex-col gap-0.5 text-[10px] text-[#A1A1AA]">
                  <span>Color</span>
                  <input
                    type="color"
                    value={selectedClip.textProps.color}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: { ...(c.textProps as TextProperties), color: e.target.value },
                      }))
                    }
                    className="w-full h-6 bg-transparent border border-[#3E3E44] rounded cursor-pointer"
                  />
                </label>
                <label className="flex flex-col gap-0.5 text-[10px] text-[#A1A1AA]">
                  <span>Stroke</span>
                  <input
                    type="color"
                    value={selectedClip.textProps.strokeColor}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: {
                          ...(c.textProps as TextProperties),
                          strokeColor: e.target.value,
                        },
                      }))
                    }
                    className="w-full h-6 bg-transparent border border-[#3E3E44] rounded cursor-pointer"
                  />
                </label>
                <label className="flex flex-col gap-0.5 text-[10px] text-[#A1A1AA]">
                  <span>Shadow</span>
                  <input
                    type="color"
                    value={
                      selectedClip.textProps.shadowColor?.startsWith('#')
                        ? selectedClip.textProps.shadowColor
                        : '#A1A1AA'
                    }
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: {
                          ...(c.textProps as TextProperties),
                          shadowColor: e.target.value,
                        },
                      }))
                    }
                    className="w-full h-6 bg-transparent border border-[#3E3E44] rounded cursor-pointer"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-1.5">
                <SliderRow
                  label="Stroke Width"
                  value={selectedClip.textProps.strokeWidth}
                  min={0}
                  max={16}
                  step={0.5}
                  unit="px"
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      textProps: { ...(c.textProps as TextProperties), strokeWidth: v },
                    }))
                  }
                />
                <SliderRow
                  label="Shadow / Glow"
                  value={selectedClip.textProps.shadowBlur ?? 12}
                  min={0}
                  max={60}
                  step={1}
                  unit="px"
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      textProps: { ...(c.textProps as TextProperties), shadowBlur: v },
                    }))
                  }
                />
              </div>

              <div className="flex items-center justify-between gap-2 pt-0.5">
                <label className="flex items-center gap-1.5 text-[11px] text-[#F4F4F5] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(selectedClip.textProps.extrude3D)}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: {
                          ...(c.textProps as TextProperties),
                          extrude3D: e.target.checked,
                          extrudeDepth: c.textProps?.extrudeDepth || 8,
                        },
                      }))
                    }
                    className="accent-[#A1A1AA]"
                  />
                  3D Extrude Depth
                </label>
                {selectedClip.textProps.extrude3D && (
                  <input
                    type="number"
                    min={1}
                    max={24}
                    value={selectedClip.textProps.extrudeDepth ?? 8}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: {
                          ...(c.textProps as TextProperties),
                          extrudeDepth: Math.max(1, Number(e.target.value) || 8),
                        },
                      }))
                    }
                    className="w-14 px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[10px] font-mono-tabular text-[#F4F4F5]"
                  />
                )}
              </div>
            </InspectorSection>

            <InspectorSection
              title="Animation"
              defaultOpen
              headerRight={
                <button
                  type="button"
                  onClick={() =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      textProps: {
                        ...(c.textProps as TextProperties),
                        effectSpeed: 1,
                        effectIntensity: 100,
                        effectDuration: 1.0,
                        effectDirection: 'center',
                        animationStrength: 100,
                      },
                    }))
                  }
                  className="px-1.5 py-0.5 bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] rounded text-[9px] text-[#A1A1AA] hover:text-[#F4F4F5] flex items-center gap-0.5"
                >
                  <RotateCcw className="w-2.5 h-2.5" />
                  Reset
                </button>
              }
            >
              <select
                value={selectedClip.textProps.animation}
                onChange={(e) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    textProps: {
                      ...(c.textProps as TextProperties),
                      animation: e.target.value as TextAnimationEffect,
                    },
                  }))
                }
                className="w-full px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded-[5px] text-[11px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
              >
                <option value="none">None</option>
                <option value="fade-up">Fade Up</option>
                <option value="pop-up">Pop-up Punch</option>
                <option value="text-zoom">Zoom Slam</option>
                <option value="text-shake">Impact Shake</option>
                <option value="text-glitch">Text Glitch</option>
                <option value="character-reveal">Character Reveal</option>
                <option value="typewriter">Typewriter</option>
                <option value="text-bounce">Bounce Text</option>
                <option value="3d-extrude">3D Text</option>
                <option value="cinematic-title">Cinematic Title</option>
                <option value="neon-text">Neon Glow</option>
                <option value="rgb-text">RGB Split Text</option>
                <option value="velocity-text">Velocity Text</option>
                <option value="distortion-text">Distortion Text</option>
                <option value="tracking-animation">Tracking Expand</option>
              </select>
              <div className="grid grid-cols-2 gap-1.5">
                <SliderRow
                  label="Speed"
                  value={selectedClip.textProps.effectSpeed ?? 1}
                  min={0.2}
                  max={3}
                  step={0.05}
                  unit="×"
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      textProps: { ...(c.textProps as TextProperties), effectSpeed: v },
                    }))
                  }
                />
                <SliderRow
                  label="Intensity"
                  value={selectedClip.textProps.effectIntensity ?? 100}
                  min={0}
                  max={200}
                  step={5}
                  unit="%"
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      textProps: { ...(c.textProps as TextProperties), effectIntensity: v },
                    }))
                  }
                />
              </div>
            </InspectorSection>
          </div>
        )}

        {tab === 'video' && (
          <div className="space-y-2.5">
            <InspectorSection title="Speed & Timing" defaultOpen>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Start (s)</label>
                  <input
                    type="number"
                    min={0}
                    step={0.1}
                    value={Math.round(selectedClip.startTime * 100) / 100}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        startTime: Math.max(0, Number(e.target.value) || 0),
                      }))
                    }
                    className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded font-mono-tabular text-[11px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Duration (s)</label>
                  <input
                    type="number"
                    min={0.2}
                    step={0.1}
                    value={Math.round(selectedClip.duration * 100) / 100}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        duration: Math.max(0.2, Number(e.target.value) || 0.2),
                      }))
                    }
                    className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded font-mono-tabular text-[11px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  />
                </div>
              </div>
              <SliderRow
                label="Playback Speed"
                value={selectedClip.speed}
                min={0.25}
                max={4}
                step={0.05}
                unit="×"
                onChange={(v) => onUpdateClip(selectedClip.id, (c) => ({ ...c, speed: v }))}
              />
              <label className="flex items-center gap-2 text-[#F4F4F5] cursor-pointer text-[11px]">
                <input
                  type="checkbox"
                  checked={selectedClip.reverse}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, (c) => ({ ...c, reverse: e.target.checked }))
                  }
                  className="accent-[#A1A1AA]"
                />
                Reverse Clip Playback
              </label>
            </InspectorSection>

            <InspectorSection title="Stabilization & Texture" defaultOpen>
              <SliderRow
                label="Video Stabilization"
                value={safeEffects.stabilization ?? 0}
                min={0}
                max={100}
                step={5}
                unit="%"
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    effects: { ...(c.effects || createDefaultEffects()), stabilization: v },
                  }))
                }
              />
              <SliderRow
                label="RGB Fringe / Lens Clarity"
                value={safeEffects.chromaticAberration ?? 0}
                min={0}
                max={50}
                step={1}
                unit="px"
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    effects: { ...(c.effects || createDefaultEffects()), chromaticAberration: v },
                  }))
                }
              />
              <SliderRow
                label="Cinema Film Grain"
                value={safeEffects.filmGrain ?? 0}
                min={0}
                max={100}
                step={2}
                unit="%"
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    effects: { ...(c.effects || createDefaultEffects()), filmGrain: v },
                  }))
                }
              />
            </InspectorSection>

            <InspectorSection title="Clip Transitions (In / Out)" defaultOpen={false}>
              {(
                [
                  { label: 'In', side: 'in' as const, cfg: transitionInCfg },
                  { label: 'Out', side: 'out' as const, cfg: transitionOutCfg },
                ] as const
              ).map(({ label, side, cfg }) => (
                <div key={side} className="space-y-1.5 border-b border-[#3E3E44] last:border-0 pb-1.5 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] text-[#A1A1AA] w-6">{label}</span>
                    <select
                      value={cfg.type}
                      onChange={(e) => {
                        const t = e.target.value as TransitionType;
                        const nextCfg: TransitionSettings = {
                          ...getDefaultTransitionSettings(t),
                          duration: cfg.duration || 0.5,
                        };
                        onUpdateClip(selectedClip.id, (c) =>
                          side === 'in'
                            ? {
                                ...c,
                                transitionIn: t,
                                transitionInDuration: nextCfg.duration,
                                transitionInConfig: nextCfg,
                              }
                            : {
                                ...c,
                                transitionOut: t,
                                transitionOutDuration: nextCfg.duration,
                                transitionOutConfig: nextCfg,
                              }
                        );
                      }}
                      className="flex-1 px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] text-[10px]"
                    >
                      <option value="none">None</option>
                      {TRANSITIONS_CATALOG.map((tr) => (
                        <option key={tr.type} value={tr.type}>
                          {tr.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  {cfg.type !== 'none' && (
                    <SliderRow
                      label={`${label} Duration`}
                      value={cfg.duration}
                      min={0.1}
                      max={2.5}
                      step={0.05}
                      unit="s"
                      onChange={(v) => {
                        const next = { ...cfg, duration: v };
                        onUpdateClip(selectedClip.id, (c) =>
                          side === 'in'
                            ? { ...c, transitionInDuration: v, transitionInConfig: next }
                            : { ...c, transitionOutDuration: v, transitionOutConfig: next }
                        );
                      }}
                    />
                  )}
                </div>
              ))}
            </InspectorSection>
          </div>
        )}

        {tab === 'effects' && (
          <>
            {selectedClip.type === 'text' && selectedClip.textProps && (
              <InspectorSection
                title="Text FX Parameters"
                defaultOpen
                headerRight={
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateClip(selectedClip.id, (c) => ({
                          ...c,
                          textProps: {
                            ...(c.textProps as TextProperties),
                            effectSpeed: 1,
                            effectIntensity: 100,
                            effectDuration: 1.0,
                            effectDirection: 'center',
                            animationStrength: 100,
                          },
                        }))
                      }
                      className="px-1.5 py-0.5 bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] rounded text-[9px] text-[#A1A1AA] hover:text-[#F4F4F5] flex items-center gap-0.5"
                    >
                      <RotateCcw className="w-2.5 h-2.5" />
                      Reset
                    </button>
                    {onSaveReadyMadePreset && (
                      <button
                        type="button"
                        onClick={() => {
                          const tp = selectedClip.textProps!;
                          onSaveReadyMadePreset({
                            id: `custom-text-${Date.now()}`,
                            name: `${selectedClip.name} Text FX`,
                            category: 'text',
                            description: `Custom ${tp.animation} preset`,
                            accentColor: '#A1A1AA',
                            defaultDuration: selectedClip.duration,
                            textPreset: {
                              animation: tp.animation,
                              effectSpeed: tp.effectSpeed ?? 1,
                              effectIntensity: tp.effectIntensity ?? 100,
                              effectDuration: tp.effectDuration ?? 1.0,
                              effectDirection: tp.effectDirection ?? 'center',
                              animationStrength: tp.animationStrength ?? 100,
                              fontWeight: tp.fontWeight,
                              color: tp.color,
                              strokeColor: tp.strokeColor,
                              strokeWidth: tp.strokeWidth,
                              shadowBlur: tp.shadowBlur,
                              shadowColor: tp.shadowColor,
                              extrude3D: tp.extrude3D,
                              extrudeDepth: tp.extrudeDepth,
                              letterSpacing: tp.letterSpacing,
                            },
                          });
                        }}
                        className="px-1.5 py-0.5 bg-[#52525B] hover:bg-[#6B7280] rounded text-[9px] text-[#F4F4F5] flex items-center gap-0.5"
                      >
                        <Save className="w-2.5 h-2.5" />
                        Save
                      </button>
                    )}
                  </div>
                }
              >
                <select
                  value={selectedClip.textProps.animation}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      textProps: {
                        ...(c.textProps as TextProperties),
                        animation: e.target.value as TextAnimationEffect,
                      },
                    }))
                  }
                  className="w-full px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5]"
                >
                  <option value="none">None</option>
                  <option value="text-shake">Text Shake</option>
                  <option value="text-glitch">Text Glitch</option>
                  <option value="character-reveal">Text Reveal</option>
                  <option value="typewriter">Typewriter</option>
                  <option value="text-bounce">Bounce Text</option>
                  <option value="pop-up">Pop-up Text</option>
                  <option value="text-zoom">Zoom Text</option>
                  <option value="fade-up">Fade Text</option>
                  <option value="3d-extrude">3D Text</option>
                  <option value="cinematic-title">Cinematic Text</option>
                  <option value="neon-text">Neon Text</option>
                  <option value="rgb-text">RGB Split Text</option>
                  <option value="velocity-text">Velocity Text</option>
                  <option value="distortion-text">Distortion Text</option>
                  <option value="tracking-animation">Tracking Text</option>
                </select>
                <div className="grid grid-cols-2 gap-1.5">
                  <SliderRow
                    label="Speed"
                    value={selectedClip.textProps.effectSpeed ?? 1}
                    min={0.2}
                    max={3}
                    step={0.05}
                    unit="×"
                    onChange={(v) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: { ...(c.textProps as TextProperties), effectSpeed: v },
                      }))
                    }
                  />
                  <SliderRow
                    label="Intensity"
                    value={selectedClip.textProps.effectIntensity ?? 100}
                    min={0}
                    max={200}
                    step={5}
                    unit="%"
                    onChange={(v) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: { ...(c.textProps as TextProperties), effectIntensity: v },
                      }))
                    }
                  />
                  <SliderRow
                    label="Duration"
                    value={selectedClip.textProps.effectDuration ?? 1.0}
                    min={0.2}
                    max={5}
                    step={0.1}
                    unit="s"
                    onChange={(v) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: { ...(c.textProps as TextProperties), effectDuration: v },
                      }))
                    }
                  />
                  <SliderRow
                    label="Strength"
                    value={selectedClip.textProps.animationStrength ?? 100}
                    min={0}
                    max={200}
                    step={5}
                    unit="%"
                    onChange={(v) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: { ...(c.textProps as TextProperties), animationStrength: v },
                      }))
                    }
                  />
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] text-[#A1A1AA]">Direction</span>
                  <select
                    value={selectedClip.textProps.effectDirection ?? 'center'}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        textProps: {
                          ...(c.textProps as TextProperties),
                          effectDirection: e.target.value as TransitionDirection,
                        },
                      }))
                    }
                    className="px-2 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]"
                  >
                    <option value="center">Center</option>
                    <option value="left">Left</option>
                    <option value="right">Right</option>
                    <option value="up">Up</option>
                    <option value="down">Down</option>
                  </select>
                </div>
              </InspectorSection>
            )}

            {/* Quick Keyframe Blur & Glow */}
            <InspectorSection title="Quick Keyframe FX" defaultOpen={selectedClip.type !== 'fx'}>
              <SliderRow
                label="Gaussian Blur"
                value={safeEffects.blur}
                min={0}
                max={40}
                step={0.5}
                unit="px"
                keyframeActive={hasKfAtPlayhead('blur')}
                onToggleKeyframe={() => toggleKeyframe('blur', safeEffects.blur)}
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    effects: { ...(c.effects || createDefaultEffects()), blur: v },
                  }))
                }
              />
              <SliderRow
                label="Accent Glow"
                value={safeEffects.glow}
                min={0}
                max={100}
                step={1}
                unit="%"
                keyframeActive={hasKfAtPlayhead('glow')}
                onToggleKeyframe={() => toggleKeyframe('glow', safeEffects.glow)}
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    effects: { ...(c.effects || createDefaultEffects()), glow: v },
                  }))
                }
              />
            </InspectorSection>

            {/* Quick Add + Stack Actions */}
            <div className="p-2 bg-[#2C2C30] border border-[#3E3E44] rounded-[6px] space-y-2">
              <div className="flex gap-1">
                <select
                  value={addEffectType}
                  onChange={(e) => setAddEffectType(e.target.value)}
                  className="flex-1 px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] text-[11px] focus:outline-none focus:border-[#A1A1AA]"
                >
                  {EFFECTS_CATALOG.map((ef) => (
                    <option key={ef.type} value={ef.type}>
                      {ef.name} ({ef.category})
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    const inst = createEffectInstance(addEffectType);
                    if (!inst) return;
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      effectsStack: [...(c.effectsStack || []), inst],
                    }));
                  }}
                  className="px-2.5 py-1 bg-[#52525B] hover:bg-[#6B7280] text-[#F4F4F5] rounded flex items-center gap-1 text-[11px] font-medium shrink-0 transition-colors"
                >
                  <Plus className="w-3 h-3" />
                  Add
                </button>
              </div>

              <div className="flex items-center justify-between gap-1">
                <button
                  type="button"
                  disabled={stack.length === 0}
                  onClick={() => onCopyEffectsStack(stack)}
                  className="flex-1 py-1 bg-[#222225] hover:bg-[#2F3340] disabled:opacity-40 border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5] flex items-center justify-center gap-1"
                >
                  <Copy className="w-3 h-3" />
                  Copy FX
                </button>
                <button
                  type="button"
                  disabled={copiedEffectsStack.length === 0}
                  onClick={() =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      effectsStack: [
                        ...(c.effectsStack || []),
                        ...copiedEffectsStack.map((fx) => ({
                          ...structuredClone(fx),
                          id: `fx-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                        })),
                      ],
                    }))
                  }
                  className="flex-1 py-1 bg-[#222225] hover:bg-[#2F3340] disabled:opacity-40 border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5] flex items-center justify-center gap-1"
                >
                  <ClipboardPaste className="w-3 h-3" />
                  Paste FX
                </button>
                <button
                  type="button"
                  disabled={stack.length === 0}
                  onClick={() =>
                    onSaveStackAsPreset({
                      id: `preset-${Date.now()}`,
                      name: `${selectedClip.name} FX`,
                      category: 'Cinematic',
                      kind: 'effects-stack',
                      description: `${stack.length} stacked effects`,
                      createdAt: Date.now(),
                      effectsStack: structuredClone(stack),
                    })
                  }
                  className="flex-1 py-1 bg-[#222225] hover:bg-[#2F3340] disabled:opacity-40 border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5] flex items-center justify-center gap-1"
                >
                  <Save className="w-3 h-3" />
                  Save Preset
                </button>
              </div>
            </div>

            {/* Effects Stack List */}
            {stack.length === 0 ? (
              <div className="p-3 bg-[#18181A] border border-[#3E3E44] rounded-[6px] text-[11px] text-[#A1A1AA] text-center">
                No effects in stack. Add any effect above or drag from the Effects tab.
              </div>
            ) : (
              <div className="space-y-2">
                {stack.map((fx, idx) => {
                  const def = getEffectDefinition(fx.type);
                  const allParams = def?.params || [];
                  const primaryKeys = new Set([
                    'intensity',
                    'strength',
                    'amount',
                    'speed',
                    'frequency',
                    'duration',
                    'radius',
                    'zoomStrength',
                    'preset',
                    'customLut',
                  ]);
                  const primaryParams = allParams.filter((p) => primaryKeys.has(p.key));
                  const advancedParams = allParams.filter((p) => !primaryKeys.has(p.key));
                  const displayPrimary = primaryParams.length > 0 ? primaryParams : allParams.slice(0, 3);
                  const displayAdvanced = primaryParams.length > 0 ? advancedParams : allParams.slice(3);

                  return (
                    <div
                      key={fx.id}
                      className={`rounded-[6px] border p-2 space-y-2 ${
                        fx.enabled
                          ? 'bg-[#2C2C30] border-[#3E3E44]'
                          : 'bg-[#18181A] border-[#3E3E44] opacity-65'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 border-b border-[#3E3E44] pb-1.5">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <button
                            type="button"
                            onClick={() =>
                              updateEffect(fx.id, (cur) => ({ ...cur, enabled: !cur.enabled }))
                            }
                            title="Enable / Disable Effect"
                            className={fx.enabled ? 'text-[#D4D4D8]' : 'text-[#A1A1AA]'}
                          >
                            {fx.enabled ? (
                              <Eye className="w-3.5 h-3.5" />
                            ) : (
                              <EyeOff className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <span className="font-semibold text-[#F4F4F5] truncate">{fx.name}</span>
                        </div>
                        <div className="flex items-center gap-0.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => moveEffect(idx, -1)}
                            disabled={idx === 0}
                            title="Move Up"
                            className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5] disabled:opacity-30"
                          >
                            <ArrowUp className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => moveEffect(idx, 1)}
                            disabled={idx === stack.length - 1}
                            title="Move Down"
                            className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5] disabled:opacity-30"
                          >
                            <ArrowDown className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => duplicateEffect(idx)}
                            title="Duplicate"
                            className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5]"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => resetEffectParams(fx)}
                            title="Reset Parameters"
                            className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5]"
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                          {onSaveReadyMadePreset && (
                            <button
                              type="button"
                              onClick={() => {
                                const catMap: Record<string, ReadyMadeCategoryId> = {
                                  shake: 'shake',
                                  glitch: 'glitch',
                                  blur: 'blur',
                                  distortion: 'distortion',
                                  glow: 'cinematic',
                                  shadow: 'cinematic',
                                  texture: 'cinematic',
                                  stylize: 'rgb',
                                  color: fx.type === 'rgb-split' ? 'rgb' : 'cc',
                                };
                                const cat: ReadyMadeCategoryId =
                                  selectedClip.fxMeta?.category ||
                                  catMap[fx.category] ||
                                  'glitch';
                                onSaveReadyMadePreset({
                                  id: `custom-${fx.type}-${Date.now()}`,
                                  name: `${fx.name} Custom`,
                                  category: cat,
                                  description: `Saved custom ${fx.name} preset`,
                                  accentColor: '#A1A1AA',
                                  defaultDuration: selectedClip.duration,
                                  effectsStack: [
                                    {
                                      ...structuredClone(fx),
                                      id: `fx_${Date.now()}`,
                                    },
                                  ],
                                });
                              }}
                              title="Save as Custom Preset"
                              className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5]"
                            >
                              <Save className="w-3 h-3" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateClip(selectedClip.id, (c) => ({
                                ...c,
                                effectsStack: (c.effectsStack || []).filter((e) => e.id !== fx.id),
                              }))
                            }
                            title="Delete Effect"
                            className="p-0.5 text-[#A1A1AA] hover:text-red-400"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Primary Effect Parameters */}
                      <div className="space-y-1.5">
                        {displayPrimary.map((param) => {
                          const rawVal = fx.params[param.key] ?? param.defaultValue;
                          const kfProp = `effect:${fx.id}:${param.key}` as Keyframe['property'];
                          if (param.type === 'slider') {
                            const num = typeof rawVal === 'number' ? rawVal : Number(param.defaultValue);
                            return (
                              <SliderRow
                                key={param.key}
                                label={param.label}
                                value={num}
                                min={param.min ?? 0}
                                max={param.max ?? 100}
                                step={param.step ?? 1}
                                unit={param.unit}
                                keyframeActive={hasKfAtPlayhead(kfProp)}
                                onToggleKeyframe={() => toggleKeyframe(kfProp, num)}
                                onChange={(v) =>
                                  updateEffect(fx.id, (cur) => ({
                                    ...cur,
                                    params: { ...cur.params, [param.key]: v },
                                  }))
                                }
                              />
                            );
                          }
                          if (param.type === 'color') {
                            return (
                              <div key={param.key} className="flex items-center justify-between">
                                <span className="text-[11px] text-[#A1A1AA]">{param.label}</span>
                                <input
                                  type="color"
                                  value={String(rawVal)}
                                  onChange={(e) =>
                                    updateEffect(fx.id, (cur) => ({
                                      ...cur,
                                      params: { ...cur.params, [param.key]: e.target.value },
                                    }))
                                  }
                                  className="w-6 h-6 bg-transparent border border-[#3E3E44] rounded cursor-pointer"
                                />
                              </div>
                            );
                          }
                          if (param.type === 'boolean') {
                            return (
                              <label
                                key={param.key}
                                className="flex items-center justify-between text-[11px] text-[#A1A1AA] cursor-pointer"
                              >
                                <span>{param.label}</span>
                                <input
                                  type="checkbox"
                                  checked={Boolean(rawVal)}
                                  onChange={(e) =>
                                    updateEffect(fx.id, (cur) => ({
                                      ...cur,
                                      params: { ...cur.params, [param.key]: e.target.checked },
                                    }))
                                  }
                                  className="accent-[#A1A1AA]"
                                />
                              </label>
                            );
                          }
                          if (param.type === 'select') {
                            const extraLuts =
                              fx.type === 'lut' && param.key === 'customLut'
                                ? getRegisteredLuts()
                                : [];
                            return (
                              <div key={param.key} className="flex items-center justify-between gap-2">
                                <span className="text-[11px] text-[#A1A1AA]">{param.label}</span>
                                <select
                                  value={String(rawVal)}
                                  onChange={(e) =>
                                    updateEffect(fx.id, (cur) => ({
                                      ...cur,
                                      params: { ...cur.params, [param.key]: e.target.value },
                                    }))
                                  }
                                  className="px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] text-[10px]"
                                >
                                  {param.options?.map((o) => (
                                    <option key={o.value} value={o.value}>
                                      {o.label}
                                    </option>
                                  ))}
                                  {extraLuts.map((lutName) => (
                                    <option key={lutName} value={lutName}>
                                      {lutName}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            );
                          }
                          return null;
                        })}

                        {fx.type === 'lut' && (
                          <div className="pt-1">
                            <input
                              ref={lutInputRef}
                              type="file"
                              accept=".cube"
                              onChange={(e) => handleCubeUpload(e, fx.id)}
                              className="hidden"
                            />
                            <button
                              type="button"
                              onClick={() => lutInputRef.current?.click()}
                              className="w-full py-1 bg-[#18181A] hover:bg-[#222225] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5] flex items-center justify-center gap-1"
                            >
                              <Upload className="w-3 h-3 text-[#D4D4D8]" />
                              Import .CUBE 3D LUT
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Collapsible Advanced Settings (Blend Mode + Secondary Fine-Tune Controls) */}
                      <InspectorSection title="Advanced Settings" defaultOpen={false}>
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="text-[#A1A1AA]">Blend Mode</span>
                          <select
                            value={fx.blendMode}
                            onChange={(e) =>
                              updateEffect(fx.id, (cur) => ({
                                ...cur,
                                blendMode: e.target.value as EffectBlendMode,
                              }))
                            }
                            className="px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5]"
                          >
                            <option value="normal">Normal</option>
                            <option value="screen">Screen</option>
                            <option value="add">Add</option>
                            <option value="overlay">Overlay</option>
                            <option value="multiply">Multiply</option>
                            <option value="soft-light">Soft Light</option>
                          </select>
                        </div>
                        {displayAdvanced.map((param) => {
                          const rawVal = fx.params[param.key] ?? param.defaultValue;
                          const kfProp = `effect:${fx.id}:${param.key}` as Keyframe['property'];
                          if (param.type === 'slider') {
                            const num = typeof rawVal === 'number' ? rawVal : Number(param.defaultValue);
                            return (
                              <SliderRow
                                key={param.key}
                                label={param.label}
                                value={num}
                                min={param.min ?? 0}
                                max={param.max ?? 100}
                                step={param.step ?? 1}
                                unit={param.unit}
                                keyframeActive={hasKfAtPlayhead(kfProp)}
                                onToggleKeyframe={() => toggleKeyframe(kfProp, num)}
                                onChange={(v) =>
                                  updateEffect(fx.id, (cur) => ({
                                    ...cur,
                                    params: { ...cur.params, [param.key]: v },
                                  }))
                                }
                              />
                            );
                          }
                          if (param.type === 'color') {
                            return (
                              <div key={param.key} className="flex items-center justify-between">
                                <span className="text-[11px] text-[#A1A1AA]">{param.label}</span>
                                <input
                                  type="color"
                                  value={String(rawVal)}
                                  onChange={(e) =>
                                    updateEffect(fx.id, (cur) => ({
                                      ...cur,
                                      params: { ...cur.params, [param.key]: e.target.value },
                                    }))
                                  }
                                  className="w-6 h-6 bg-transparent border border-[#3E3E44] rounded cursor-pointer"
                                />
                              </div>
                            );
                          }
                          if (param.type === 'boolean') {
                            return (
                              <label
                                key={param.key}
                                className="flex items-center justify-between text-[11px] text-[#A1A1AA] cursor-pointer"
                              >
                                <span>{param.label}</span>
                                <input
                                  type="checkbox"
                                  checked={Boolean(rawVal)}
                                  onChange={(e) =>
                                    updateEffect(fx.id, (cur) => ({
                                      ...cur,
                                      params: { ...cur.params, [param.key]: e.target.checked },
                                    }))
                                  }
                                  className="accent-[#A1A1AA]"
                                />
                              </label>
                            );
                          }
                          if (param.type === 'select') {
                            return (
                              <div key={param.key} className="flex items-center justify-between gap-2">
                                <span className="text-[11px] text-[#A1A1AA]">{param.label}</span>
                                <select
                                  value={String(rawVal)}
                                  onChange={(e) =>
                                    updateEffect(fx.id, (cur) => ({
                                      ...cur,
                                      params: { ...cur.params, [param.key]: e.target.value },
                                    }))
                                  }
                                  className="px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] text-[10px]"
                                >
                                  {param.options?.map((o) => (
                                    <option key={o.value} value={o.value}>
                                      {o.label}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            );
                          }
                          return null;
                        })}
                      </InspectorSection>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Transitions In / Out Settings */}
            <InspectorSection title="Transition In / Out" defaultOpen={false}>
              {(
                [
                  { label: 'Transition In', side: 'in' as const, cfg: transitionInCfg },
                  { label: 'Transition Out', side: 'out' as const, cfg: transitionOutCfg },
                ] as const
              ).map(({ label, side, cfg }) => (
                <div key={side} className="p-2 bg-[#18181A] border border-[#3E3E44] rounded space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] text-[#A1A1AA]">{label}</span>
                    <select
                      value={cfg.type}
                      onChange={(e) => {
                        const t = e.target.value as TransitionType;
                        const nextCfg: TransitionSettings = {
                          ...getDefaultTransitionSettings(t),
                          duration: cfg.duration || 0.5,
                        };
                        onUpdateClip(selectedClip.id, (c) =>
                          side === 'in'
                            ? {
                                ...c,
                                transitionIn: t,
                                transitionInDuration: nextCfg.duration,
                                transitionInConfig: nextCfg,
                              }
                            : {
                                ...c,
                                transitionOut: t,
                                transitionOutDuration: nextCfg.duration,
                                transitionOutConfig: nextCfg,
                              }
                        );
                      }}
                      className="flex-1 px-1.5 py-0.5 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#F4F4F5] text-[10px]"
                    >
                      <option value="none">None</option>
                      {TRANSITIONS_CATALOG.map((tr) => (
                        <option key={tr.type} value={tr.type}>
                          {tr.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  {cfg.type !== 'none' && (
                    <div className="grid grid-cols-2 gap-1.5">
                      <SliderRow
                        label="Duration"
                        value={cfg.duration}
                        min={0.1}
                        max={2.5}
                        step={0.05}
                        unit="s"
                        onChange={(v) => {
                          const next = { ...cfg, duration: v };
                          onUpdateClip(selectedClip.id, (c) =>
                            side === 'in'
                              ? { ...c, transitionInDuration: v, transitionInConfig: next }
                              : { ...c, transitionOutDuration: v, transitionOutConfig: next }
                          );
                        }}
                      />
                      <SliderRow
                        label="Intensity"
                        value={cfg.intensity}
                        min={10}
                        max={100}
                        step={5}
                        unit="%"
                        onChange={(v) => {
                          const next = { ...cfg, intensity: v };
                          onUpdateClip(selectedClip.id, (c) =>
                            side === 'in'
                              ? { ...c, transitionInConfig: next }
                              : { ...c, transitionOutConfig: next }
                          );
                        }}
                      />
                      <select
                        value={cfg.direction}
                        onChange={(e) => {
                          const next = { ...cfg, direction: e.target.value as TransitionDirection };
                          onUpdateClip(selectedClip.id, (c) =>
                            side === 'in'
                              ? { ...c, transitionInConfig: next }
                              : { ...c, transitionOutConfig: next }
                          );
                        }}
                        className="px-1.5 py-0.5 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#F4F4F5] text-[10px]"
                      >
                        <option value="left">Dir: Left</option>
                        <option value="right">Dir: Right</option>
                        <option value="up">Dir: Up</option>
                        <option value="down">Dir: Down</option>
                        <option value="center">Dir: Center</option>
                      </select>
                      <select
                        value={cfg.easing}
                        onChange={(e) => {
                          const next = { ...cfg, easing: e.target.value as AnimationEasing };
                          onUpdateClip(selectedClip.id, (c) =>
                            side === 'in'
                              ? { ...c, transitionInConfig: next }
                              : { ...c, transitionOutConfig: next }
                          );
                        }}
                        className="px-1.5 py-0.5 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#F4F4F5] text-[10px]"
                      >
                        <option value="linear">Linear</option>
                        <option value="easeIn">Ease In</option>
                        <option value="easeOut">Ease Out</option>
                        <option value="easeInOut">Ease InOut</option>
                      </select>
                    </div>
                  )}
                </div>
              ))}
            </InspectorSection>
          </>
        )}

        {tab === 'transform' && (
          <div className="space-y-2.5">
            {/* Null Object Controller Header Card */}
            {selectedClip.type === 'null' && (() => {
              const attachedChildren = project.clips.filter(
                (c) => c.parentClipId === selectedClip.id
              );
              const nullColor = selectedClip.labelColor || 'rose';
              return (
                <div className="p-2.5 bg-[#2C2C30] border border-[#A1A1AA]/55 rounded-[6px] space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <Crosshair className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0" />
                      <span className="font-semibold text-[#F4F4F5] truncate">
                        Null Object Controller
                      </span>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      {onRequestRenameClip && (
                        <button
                          type="button"
                          onClick={() => onRequestRenameClip(selectedClip.id)}
                          title="Rename Null Object (F2)"
                          className="p-1 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]"
                        >
                          <Pencil className="w-3 h-3" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateClip(selectedClip.id, (c) => ({ ...c, visible: !c.visible }))
                        }
                        title={
                          selectedClip.visible
                            ? 'Hide Null Gizmo (children stay driven)'
                            : 'Show Null Gizmo in Preview'
                        }
                        className="p-1 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]"
                      >
                        {selectedClip.visible ? (
                          <Eye className="w-3 h-3" />
                        ) : (
                          <EyeOff className="w-3 h-3 text-[#A1A1AA]" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateClip(selectedClip.id, (c) => ({ ...c, locked: !c.locked }))
                        }
                        title={selectedClip.locked ? 'Unlock Null Object' : 'Lock Null Object'}
                        className="p-1 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]"
                      >
                        {selectedClip.locked ? (
                          <Lock className="w-3 h-3 text-amber-400" />
                        ) : (
                          <Unlock className="w-3 h-3" />
                        )}
                      </button>
                      {onDuplicateClip && (
                        <button
                          type="button"
                          onClick={() => onDuplicateClip(selectedClip.id)}
                          title="Duplicate Null Object"
                          className="p-1 rounded bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]"
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                      )}
                      {onDeleteClip && (
                        <button
                          type="button"
                          onClick={() => onDeleteClip(selectedClip.id)}
                          title="Delete Null Object"
                          className="p-1 rounded bg-[#222225] hover:bg-red-500/20 border border-[#3E3E44] text-[#A1A1AA] hover:text-red-300"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Null Color Label Swatches */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] text-[#A1A1AA]">Label Color</span>
                    <div className="flex items-center gap-1.5">
                      {(['rose', 'amber', 'emerald', 'sky', 'violet'] as MarkerColor[]).map((col) => (
                        <button
                          key={col}
                          type="button"
                          onClick={() =>
                            onUpdateClip(selectedClip.id, (c) => ({ ...c, labelColor: col }))
                          }
                          title={`Set Null color: ${col}`}
                          style={{ backgroundColor: NULL_LABEL_HEX[col] }}
                          className={`w-3.5 h-3.5 rounded-sm transition-transform ${
                            nullColor === col
                              ? 'ring-2 ring-[#F4F4F5] scale-110'
                              : 'opacity-70 hover:opacity-100'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  {(() => {
                    const evalScaleZ = getEvalProp('scaleZ', safeTransform.scaleZ ?? 1);
                    return (
                      <SliderRow
                        label={`Scale Z (${Math.round(evalScaleZ * 100)}%)`}
                        value={Math.round(evalScaleZ * 100) / 100}
                        min={0.1}
                        max={3}
                        step={0.02}
                        unit="×"
                        keyframeActive={hasKfAtPlayhead('scaleZ')}
                        onToggleKeyframe={() => toggleKeyframe('scaleZ', evalScaleZ)}
                        onChange={(v) => setTransformWithKeyframe('scaleZ', 'scaleZ', v)}
                      />
                    );
                  })()}

                  <div className="pt-1 border-t border-[#3E3E44] space-y-1">
                    <div className="text-[10px] text-[#A1A1AA] flex items-center justify-between">
                      <span>Connected Child Layers ({attachedChildren.length})</span>
                      <span className="text-[9px] opacity-75">Non-rendering locator</span>
                    </div>
                    {attachedChildren.length === 0 ? (
                      <div className="text-[10px] text-[#A1A1AA] italic">
                        Drag a layer&apos;s Pick Whip onto this Null or assign Parent below.
                      </div>
                    ) : (
                      <div className="max-h-24 overflow-y-auto space-y-0.5">
                        {attachedChildren.map((ch) => (
                          <div
                            key={ch.id}
                            className="flex items-center justify-between px-1.5 py-0.5 bg-[#18181A] rounded border border-[#3E3E44]"
                          >
                            <button
                              type="button"
                              onClick={() => onSelectClip?.(ch.id)}
                              className="text-[10px] text-[#F4F4F5] hover:text-[#F4F4F5] truncate text-left flex-1"
                            >
                              {ch.type === 'null' ? `[NULL] ${ch.name}` : ch.name}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                onSetClipParent
                                  ? onSetClipParent(ch.id, undefined)
                                  : onUpdateClip(ch.id, (c) => ({ ...c, parentClipId: undefined }))
                              }
                              title="Detach from Null (Preserve World Position)"
                              className="p-0.5 text-[#A1A1AA] hover:text-red-400"
                            >
                              <Unlink className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}
            {/* Multi-Layer Selection, Group & Align/Distribute Controls */}
            {(() => {
              const effectiveIds =
                selectedClipIds.length > 0 ? selectedClipIds : [selectedClip.id];
              const multiClips = project.clips.filter(
                (c) => effectiveIds.includes(c.id) && c.type !== 'audio'
              );
              const anyGrouped = multiClips.some((c) => Boolean(c.groupId));

              const estimateHalfExtentsPct = (c: TimelineClip) => {
                const sx = c.transform.scale * (c.transform.scaleX ?? 1);
                const sy = c.transform.scale * (c.transform.scaleY ?? 1);
                if (c.type === 'shape' && c.shapeProps) {
                  return {
                    hw: ((c.shapeProps.widthPct || 36) * sx) / 2,
                    hh: ((c.shapeProps.heightPct || 36) * sy) / 2,
                  };
                }
                if (c.type === 'text') {
                  return { hw: 18 * sx, hh: 7 * sy };
                }
                return { hw: 50 * sx, hh: 50 * sy };
              };

              const handleAlign = (
                mode: 'left' | 'center-h' | 'right' | 'top' | 'center-v' | 'bottom'
              ) => {
                if (multiClips.length === 0) return;
                const targetList = multiClips;
                const minLeft =
                  targetList.length === 1
                    ? -50
                    : Math.min(...targetList.map((c) => c.transform.x - estimateHalfExtentsPct(c).hw));
                const maxRight =
                  targetList.length === 1
                    ? 50
                    : Math.max(...targetList.map((c) => c.transform.x + estimateHalfExtentsPct(c).hw));
                const minTop =
                  targetList.length === 1
                    ? -50
                    : Math.min(...targetList.map((c) => c.transform.y - estimateHalfExtentsPct(c).hh));
                const maxBottom =
                  targetList.length === 1
                    ? 50
                    : Math.max(...targetList.map((c) => c.transform.y + estimateHalfExtentsPct(c).hh));
                const midX = (minLeft + maxRight) / 2;
                const midY = (minTop + maxBottom) / 2;

                const updates: Record<string, (c: TimelineClip) => TimelineClip> = {};
                for (const mc of targetList) {
                  const ext = estimateHalfExtentsPct(mc);
                  let nx = mc.transform.x;
                  let ny = mc.transform.y;
                  if (mode === 'left') nx = minLeft + ext.hw;
                  if (mode === 'right') nx = maxRight - ext.hw;
                  if (mode === 'center-h') nx = midX;
                  if (mode === 'top') ny = minTop + ext.hh;
                  if (mode === 'bottom') ny = maxBottom - ext.hh;
                  if (mode === 'center-v') ny = midY;
                  updates[mc.id] = (c) => ({
                    ...c,
                    transform: {
                      ...c.transform,
                      x: Math.round(nx * 100) / 100,
                      y: Math.round(ny * 100) / 100,
                    },
                  });
                }
                if (onBatchUpdateClips) {
                  onBatchUpdateClips(updates, true);
                } else {
                  Object.entries(updates).forEach(([id, fn]) => onUpdateClip(id, fn));
                }
              };

              const handleDistribute = (axis: 'h' | 'v') => {
                if (multiClips.length < 3) return;
                const sorted = [...multiClips].sort((a, b) =>
                  axis === 'h' ? a.transform.x - b.transform.x : a.transform.y - b.transform.y
                );
                const first = axis === 'h' ? sorted[0].transform.x : sorted[0].transform.y;
                const last =
                  axis === 'h'
                    ? sorted[sorted.length - 1].transform.x
                    : sorted[sorted.length - 1].transform.y;
                const step = (last - first) / (sorted.length - 1);
                const updates: Record<string, (c: TimelineClip) => TimelineClip> = {};
                sorted.forEach((mc, idx) => {
                  const val = Math.round((first + step * idx) * 100) / 100;
                  updates[mc.id] = (c) => ({
                    ...c,
                    transform: {
                      ...c.transform,
                      ...(axis === 'h' ? { x: val } : { y: val }),
                    },
                  });
                });
                if (onBatchUpdateClips) {
                  onBatchUpdateClips(updates, true);
                } else {
                  Object.entries(updates).forEach(([id, fn]) => onUpdateClip(id, fn));
                }
              };

              return (
                <InspectorSection title={`Parenting & Align (${multiClips.length})`} defaultOpen={Boolean(selectedClip.parentClipId) || multiClips.length >= 2}>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <label className="text-[10px] font-medium text-[#A1A1AA] flex items-center gap-1">
                        <Link2 className="w-3 h-3 text-[#D4D4D8]" />
                        Parent Layer / Null
                      </label>
                      {selectedClip.parentClipId && (
                        <button
                          type="button"
                          onClick={() =>
                            onSetClipParent
                              ? onSetClipParent(selectedClip.id, undefined)
                              : onUpdateClip(selectedClip.id, (c) => ({ ...c, parentClipId: undefined }))
                          }
                          className="text-[10px] text-red-400 hover:text-red-300 flex items-center gap-0.5"
                          title="Unparent while preserving world position"
                        >
                          <Unlink className="w-2.5 h-2.5" />
                          Unparent
                        </button>
                      )}
                    </div>
                    <select
                      value={selectedClip.parentClipId || ''}
                      onChange={(e) => {
                        const nextParentId = e.target.value || undefined;
                        if (onSetClipParent) {
                          onSetClipParent(selectedClip.id, nextParentId);
                        } else {
                          onUpdateClip(selectedClip.id, (c) => ({ ...c, parentClipId: nextParentId }));
                        }
                      }}
                      className="w-full px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] text-[11px]"
                    >
                      <option value="">None (World Space)</option>
                      {parentCandidates.map((pc) => (
                        <option key={pc.id} value={pc.id}>
                          {pc.type === 'null'
                            ? `[NULL] ${pc.name}`
                            : pc.type === 'fx'
                            ? `[FX] ${pc.name}`
                            : pc.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <div className="grid grid-cols-6 gap-1 flex-1">
                      <button type="button" onClick={() => handleAlign('left')} title="Align Left" className="py-1 bg-[#18181A] hover:bg-[#2F3340] border border-[#3E3E44] rounded flex items-center justify-center text-[#A1A1AA] hover:text-[#F4F4F5]"><AlignLeft className="w-3 h-3" /></button>
                      <button type="button" onClick={() => handleAlign('center-h')} title="Align Horizontal Center" className="py-1 bg-[#18181A] hover:bg-[#2F3340] border border-[#3E3E44] rounded flex items-center justify-center text-[#A1A1AA] hover:text-[#F4F4F5]"><AlignCenterHorizontal className="w-3 h-3" /></button>
                      <button type="button" onClick={() => handleAlign('right')} title="Align Right" className="py-1 bg-[#18181A] hover:bg-[#2F3340] border border-[#3E3E44] rounded flex items-center justify-center text-[#A1A1AA] hover:text-[#F4F4F5]"><AlignRight className="w-3 h-3" /></button>
                      <button type="button" onClick={() => handleAlign('top')} title="Align Top" className="py-1 bg-[#18181A] hover:bg-[#2F3340] border border-[#3E3E44] rounded flex items-center justify-center text-[#A1A1AA] hover:text-[#F4F4F5]"><AlignStartVertical className="w-3 h-3" /></button>
                      <button type="button" onClick={() => handleAlign('center-v')} title="Align Vertical Center" className="py-1 bg-[#18181A] hover:bg-[#2F3340] border border-[#3E3E44] rounded flex items-center justify-center text-[#A1A1AA] hover:text-[#F4F4F5]"><AlignCenterVertical className="w-3 h-3" /></button>
                      <button type="button" onClick={() => handleAlign('bottom')} title="Align Bottom" className="py-1 bg-[#18181A] hover:bg-[#2F3340] border border-[#3E3E44] rounded flex items-center justify-center text-[#A1A1AA] hover:text-[#F4F4F5]"><AlignEndVertical className="w-3 h-3" /></button>
                    </div>
                  </div>
                  {(multiClips.length >= 2 && onGroupSelected) || (anyGrouped && onUngroupSelected) ? (
                    <div className="flex items-center gap-1 pt-1">
                      {multiClips.length >= 2 && onGroupSelected && (
                        <button type="button" onClick={onGroupSelected} className="flex-1 py-1 bg-[#222225] hover:bg-[#52525B] border border-[#3E3E44] rounded text-[#F4F4F5] flex items-center justify-center gap-1 text-[10px] transition-colors">
                          <Group className="w-3 h-3" /> Group
                        </button>
                      )}
                      {anyGrouped && onUngroupSelected && (
                        <button type="button" onClick={onUngroupSelected} className="flex-1 py-1 bg-[#222225] hover:bg-[#2F3340] border border-[#A1A1AA]/60 rounded text-[#F4F4F5] flex items-center justify-center gap-1 text-[10px]">
                          <Ungroup className="w-3 h-3 text-[#D4D4D8]" /> Ungroup
                        </button>
                      )}
                    </div>
                  ) : null}
                  {multiClips.length >= 3 && (
                    <div className="grid grid-cols-2 gap-1">
                      <button type="button" onClick={() => handleDistribute('h')} className="py-1 bg-[#18181A] hover:bg-[#2F3340] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]">Distribute H</button>
                      <button type="button" onClick={() => handleDistribute('v')} className="py-1 bg-[#18181A] hover:bg-[#2F3340] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]">Distribute V</button>
                    </div>
                  )}
                </InspectorSection>
              );
            })()}

            {(() => {
              const evalX = getEvalProp('x', safeTransform.x);
              const evalY = getEvalProp('y', safeTransform.y);
              const evalZ = getEvalProp('z', safeTransform.zDepth || 0);
              const evalScale = getEvalProp('scale', safeTransform.scale);
              const evalScaleX = getEvalProp('scaleX', safeTransform.scaleX ?? 1);
              const evalScaleY = getEvalProp('scaleY', safeTransform.scaleY ?? 1);
              const evalRot = getEvalProp('rotation', safeTransform.rotation);
              const evalRotX = getEvalProp('rotX', safeTransform.rotX || 0);
              const evalRotY = getEvalProp('rotY', safeTransform.rotY || 0);
              const evalAnchorX = getEvalProp('anchorX', safeTransform.anchorX ?? 0.5);
              const evalAnchorY = getEvalProp('anchorY', safeTransform.anchorY ?? 0.5);
              const evalOpacity = getEvalProp('opacity', safeTransform.opacity);

              const baseW =
                selectedClip.type === 'shape' && selectedClip.shapeProps
                  ? ((selectedClip.shapeProps.widthPct || 36) / 100) * project.width
                  : project.width;
              const baseH =
                selectedClip.type === 'shape' && selectedClip.shapeProps
                  ? ((selectedClip.shapeProps.heightPct || 36) / 100) * project.height
                  : project.height;
              const curW = Math.round(baseW * evalScale * evalScaleX);
              const curH = Math.round(baseH * evalScale * evalScaleY);

              return (
                <>
                  <InspectorSection title="Position & Anchor" defaultOpen>
                    <SliderRow
                      label="Position X"
                      value={Math.round(evalX * 100) / 100}
                      min={-100}
                      max={100}
                      step={0.5}
                      unit="%"
                      keyframeActive={hasKfAtPlayhead('x')}
                      onToggleKeyframe={() => toggleKeyframe('x', evalX)}
                      onChange={(v) => setTransformWithKeyframe('x', 'x', v)}
                    />
                    <SliderRow
                      label="Position Y"
                      value={Math.round(evalY * 100) / 100}
                      min={-100}
                      max={100}
                      step={0.5}
                      unit="%"
                      keyframeActive={hasKfAtPlayhead('y')}
                      onToggleKeyframe={() => toggleKeyframe('y', evalY)}
                      onChange={(v) => setTransformWithKeyframe('y', 'y', v)}
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <SliderRow
                        label="Anchor X"
                        value={Math.round(evalAnchorX * 100) / 100}
                        min={0}
                        max={1}
                        step={0.01}
                        keyframeActive={hasKfAtPlayhead('anchorX')}
                        onToggleKeyframe={() => toggleKeyframe('anchorX', evalAnchorX)}
                        onChange={(v) => setTransformWithKeyframe('anchorX', 'anchorX', v)}
                      />
                      <SliderRow
                        label="Anchor Y"
                        value={Math.round(evalAnchorY * 100) / 100}
                        min={0}
                        max={1}
                        step={0.01}
                        keyframeActive={hasKfAtPlayhead('anchorY')}
                        onToggleKeyframe={() => toggleKeyframe('anchorY', evalAnchorY)}
                        onChange={(v) => setTransformWithKeyframe('anchorY', 'anchorY', v)}
                      />
                    </div>
                  </InspectorSection>

                  <InspectorSection title="Scale & Dimensions" defaultOpen>
                    <SliderRow
                      label={`Uniform Scale (${Math.round(evalScale * 100)}%)`}
                      value={Math.round(evalScale * 100) / 100}
                      min={0.1}
                      max={4}
                      step={0.02}
                      unit="×"
                      keyframeActive={hasKfAtPlayhead('scale')}
                      onToggleKeyframe={() => toggleKeyframe('scale', evalScale)}
                      onChange={(v) => setTransformWithKeyframe('scale', 'scale', v)}
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <SliderRow
                        label="Scale X"
                        value={Math.round(evalScaleX * 100) / 100}
                        min={0.1}
                        max={3}
                        step={0.02}
                        unit="×"
                        keyframeActive={hasKfAtPlayhead('scaleX')}
                        onToggleKeyframe={() => toggleKeyframe('scaleX', evalScaleX)}
                        onChange={(v) => setTransformWithKeyframe('scaleX', 'scaleX', v)}
                      />
                      <SliderRow
                        label="Scale Y"
                        value={Math.round(evalScaleY * 100) / 100}
                        min={0.1}
                        max={3}
                        step={0.02}
                        unit="×"
                        keyframeActive={hasKfAtPlayhead('scaleY')}
                        onToggleKeyframe={() => toggleKeyframe('scaleY', evalScaleY)}
                        onChange={(v) => setTransformWithKeyframe('scaleY', 'scaleY', v)}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div>
                        <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Width (px)</label>
                        <input
                          type="number"
                          min={16}
                          max={project.width * 4}
                          value={curW}
                          onChange={(e) => {
                            const targetW = Math.max(16, Number(e.target.value) || curW);
                            const nextScaleX =
                              Math.round(
                                (targetW / Math.max(1, baseW * evalScale)) * 1000
                              ) / 1000;
                            setTransformWithKeyframe(
                              'scaleX',
                              'scaleX',
                              Math.max(0.05, Math.min(5, nextScaleX))
                            );
                          }}
                          className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded font-mono-tabular text-[11px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Height (px)</label>
                        <input
                          type="number"
                          min={16}
                          max={project.height * 4}
                          value={curH}
                          onChange={(e) => {
                            const targetH = Math.max(16, Number(e.target.value) || curH);
                            const nextScaleY =
                              Math.round(
                                (targetH / Math.max(1, baseH * evalScale)) * 1000
                              ) / 1000;
                            setTransformWithKeyframe(
                              'scaleY',
                              'scaleY',
                              Math.max(0.05, Math.min(5, nextScaleY))
                            );
                          }}
                          className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded font-mono-tabular text-[11px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                        />
                      </div>
                    </div>
                  </InspectorSection>

                  <InspectorSection title="Rotation & 3D Depth" defaultOpen>
                    <SliderRow
                      label="Rotation (Z)"
                      value={Math.round(evalRot * 10) / 10}
                      min={-360}
                      max={360}
                      step={1}
                      unit="°"
                      keyframeActive={hasKfAtPlayhead('rotation')}
                      onToggleKeyframe={() => toggleKeyframe('rotation', evalRot)}
                      onChange={(v) => setTransformWithKeyframe('rotation', 'rotation', v)}
                    />
                    <SliderRow
                      label="Z Depth"
                      value={Math.round(evalZ * 10) / 10}
                      min={-400}
                      max={400}
                      step={5}
                      keyframeActive={hasKfAtPlayhead('z')}
                      onToggleKeyframe={() => toggleKeyframe('z', evalZ)}
                      onChange={(v) => setTransformWithKeyframe('z', 'zDepth', v)}
                    />
                    <label className="flex items-center gap-1.5 text-[11px] text-[#F4F4F5] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedClip.is3DLayer}
                        onChange={(e) =>
                          onUpdateClip(selectedClip.id, (c) => ({ ...c, is3DLayer: e.target.checked }))
                        }
                        className="accent-[#A1A1AA]"
                      />
                      Enable 3D Layer (Rot X / Y)
                    </label>
                    {selectedClip.is3DLayer && (
                      <div className="grid grid-cols-2 gap-2">
                        <SliderRow
                          label="Rot X"
                          value={Math.round(evalRotX * 10) / 10}
                          min={-85}
                          max={85}
                          step={1}
                          unit="°"
                          keyframeActive={hasKfAtPlayhead('rotX')}
                          onToggleKeyframe={() => toggleKeyframe('rotX', evalRotX)}
                          onChange={(v) => setTransformWithKeyframe('rotX', 'rotX', v)}
                        />
                        <SliderRow
                          label="Rot Y"
                          value={Math.round(evalRotY * 10) / 10}
                          min={-85}
                          max={85}
                          step={1}
                          unit="°"
                          keyframeActive={hasKfAtPlayhead('rotY')}
                          onToggleKeyframe={() => toggleKeyframe('rotY', evalRotY)}
                          onChange={(v) => setTransformWithKeyframe('rotY', 'rotY', v)}
                        />
                      </div>
                    )}
                  </InspectorSection>

                  <InspectorSection title="Opacity, Blending & Speed" defaultOpen>
                    <SliderRow
                      label="Opacity"
                      value={Math.round(evalOpacity * 100)}
                      min={0}
                      max={100}
                      step={1}
                      unit="%"
                      keyframeActive={hasKfAtPlayhead('opacity')}
                      onToggleKeyframe={() => toggleKeyframe('opacity', evalOpacity)}
                      onChange={(v) => setTransformWithKeyframe('opacity', 'opacity', v / 100)}
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Blend Mode</label>
                        <select
                          value={selectedClip.blendMode}
                          onChange={(e) =>
                            onUpdateClip(selectedClip.id, (c) => ({
                              ...c,
                              blendMode: e.target.value as BlendMode,
                            }))
                          }
                          className="w-full px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] text-[11px]"
                        >
                          <option value="normal">Normal</option>
                          <option value="screen">Screen</option>
                          <option value="multiply">Multiply</option>
                          <option value="overlay">Overlay</option>
                          <option value="add">Add</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Speed</label>
                        <select
                          value={String(selectedClip.speed)}
                          onChange={(e) =>
                            onUpdateClip(selectedClip.id, (c) => ({
                              ...c,
                              speed: Number(e.target.value),
                            }))
                          }
                          className="w-full px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] text-[11px] font-mono-tabular"
                        >
                          <option value="0.25">0.25×</option>
                          <option value="0.5">0.50×</option>
                          <option value="1">1.00×</option>
                          <option value="1.5">1.50×</option>
                          <option value="2">2.00×</option>
                          <option value="4">4.00×</option>
                        </select>
                      </div>
                    </div>
                  </InspectorSection>
                </>
              );
            })()}
          </div>
        )}

        {tab === 'color' && (
          <div className="space-y-2.5">
            <InspectorSection
              title="Color Correction & LUT"
              defaultOpen
              headerRight={
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        colorGrade: {
                          preset: 'none',
                          exposure: 0,
                          contrast: 0,
                          saturation: 0,
                          temperature: 0,
                          tint: 0,
                          vignette: 0,
                          highlights: 0,
                          shadows: 0,
                          whites: 0,
                          blacks: 0,
                          vibrance: 0,
                          rgbCurves: { master: 0, red: 0, green: 0, blue: 0 },
                          colorBalance: {
                            shadowsRed: 0,
                            shadowsGreen: 0,
                            shadowsBlue: 0,
                            highlightsRed: 0,
                            highlightsGreen: 0,
                            highlightsBlue: 0,
                          },
                          lutIntensity: 90,
                        },
                      }))
                    }
                    className="px-1.5 py-0.5 bg-[#222225] hover:bg-[#2F3340] border border-[#3E3E44] rounded text-[9px] text-[#A1A1AA] hover:text-[#F4F4F5] flex items-center gap-0.5"
                  >
                    <RotateCcw className="w-2.5 h-2.5" />
                    Reset
                  </button>
                  {onSaveReadyMadePreset && (
                    <button
                      type="button"
                      onClick={() =>
                        onSaveReadyMadePreset({
                          id: `custom-cc-${Date.now()}`,
                          name: `${selectedClip.name} CC`,
                          category: 'cc',
                          description: 'Custom color grade preset',
                          accentColor: '#A1A1AA',
                          defaultDuration: selectedClip.duration,
                          colorGrade: structuredClone(safeColorGrade) as unknown as Record<string, unknown>,
                        })
                      }
                      className="px-1.5 py-0.5 bg-[#52525B] hover:bg-[#6B7280] rounded text-[9px] text-[#F4F4F5] flex items-center gap-0.5"
                    >
                      <Save className="w-2.5 h-2.5" />
                      Save
                    </button>
                  )}
                </div>
              }
            >
              <select
                value={safeColorGrade.preset}
                onChange={(e) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), preset: e.target.value as ColorGrade['preset'] },
                  }))
                }
                className="w-full px-2 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5]"
              >
                <option value="none">Neutral Rec.709</option>
                <option value="cinematic-cc">Cinematic CC</option>
                <option value="dark-cc">Dark CC</option>
                <option value="moody-cc">Moody CC</option>
                <option value="cinematic-teal-orange">Teal &amp; Orange</option>
                <option value="blue-cinematic">Blue Cinematic</option>
                <option value="warm-film">Warm Film</option>
                <option value="cold-film">Cold Film</option>
                <option value="vintage-35mm">Vintage Film 35mm</option>
                <option value="anime-cc">Anime CC</option>
                <option value="hdr-look">HDR Look</option>
                <option value="high-contrast">High Contrast</option>
                <option value="dark-fantasy">Dark Fantasy</option>
                <option value="film-pro">Professional Film Look</option>
                <option value="crimson-noir">Crimson Noir</option>
                <option value="golden-hour">Golden Hour</option>
                <option value="monochrome">Monochrome B&amp;W</option>
              </select>

              <SliderRow
                label="LUT Intensity"
                value={safeColorGrade.lutIntensity ?? 95}
                min={0}
                max={100}
                step={1}
                unit="%"
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), lutIntensity: v },
                  }))
                }
              />
            </InspectorSection>

            <InspectorSection title="Exposure & Tone" defaultOpen>
              <SliderRow
                label="Exposure"
                value={safeColorGrade.exposure}
                min={-80}
                max={80}
                step={1}
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), exposure: v },
                  }))
                }
              />
              <SliderRow
                label="Contrast"
                value={safeColorGrade.contrast}
                min={-80}
                max={80}
                step={1}
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), contrast: v },
                  }))
                }
              />
              <div className="grid grid-cols-2 gap-1.5">
                <SliderRow
                  label="Highlights"
                  value={safeColorGrade.highlights}
                  min={-100}
                  max={100}
                  step={1}
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), highlights: v },
                    }))
                  }
                />
                <SliderRow
                  label="Shadows"
                  value={safeColorGrade.shadows}
                  min={-100}
                  max={100}
                  step={1}
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), shadows: v },
                    }))
                  }
                />
                <SliderRow
                  label="Whites"
                  value={safeColorGrade.whites ?? 0}
                  min={-100}
                  max={100}
                  step={1}
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), whites: v },
                    }))
                  }
                />
                <SliderRow
                  label="Blacks"
                  value={safeColorGrade.blacks ?? 0}
                  min={-100}
                  max={100}
                  step={1}
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), blacks: v },
                    }))
                  }
                />
              </div>
            </InspectorSection>

            <InspectorSection title="Saturation, WB & Vignette" defaultOpen>
              <SliderRow
                label="Saturation"
                value={safeColorGrade.saturation}
                min={-100}
                max={100}
                step={1}
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), saturation: v },
                  }))
                }
              />
              <SliderRow
                label="Vibrance"
                value={safeColorGrade.vibrance ?? 0}
                min={-100}
                max={100}
                step={1}
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), vibrance: v },
                  }))
                }
              />
              <div className="grid grid-cols-2 gap-1.5">
                <SliderRow
                  label="Temperature"
                  value={safeColorGrade.temperature}
                  min={-80}
                  max={80}
                  step={1}
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), temperature: v },
                    }))
                  }
                />
                <SliderRow
                  label="Tint"
                  value={safeColorGrade.tint}
                  min={-80}
                  max={80}
                  step={1}
                  onChange={(v) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), tint: v },
                    }))
                  }
                />
              </div>
              <SliderRow
                label="Vignette"
                value={safeColorGrade.vignette}
                min={0}
                max={100}
                step={1}
                unit="%"
                onChange={(v) =>
                  onUpdateClip(selectedClip.id, (c) => ({
                    ...c,
                    colorGrade: { ...(c.colorGrade || createDefaultColorGrade()), vignette: v },
                  }))
                }
              />
            </InspectorSection>

            <InspectorSection title="RGB Curves & Color Wheels" defaultOpen={false}>
              <div className="grid grid-cols-2 gap-1.5">
                {(['master', 'red', 'green', 'blue'] as const).map((ch) => (
                  <SliderRow
                    key={ch}
                    label={ch.charAt(0).toUpperCase() + ch.slice(1)}
                    value={safeColorGrade.rgbCurves?.[ch] ?? 0}
                    min={-100}
                    max={100}
                    step={1}
                    onChange={(v) =>
                      onUpdateClip(selectedClip.id, (c) => {
                        const baseCg = c.colorGrade || createDefaultColorGrade();
                        return {
                          ...c,
                          colorGrade: {
                            ...baseCg,
                            rgbCurves: {
                              master: baseCg.rgbCurves?.master ?? 0,
                              red: baseCg.rgbCurves?.red ?? 0,
                              green: baseCg.rgbCurves?.green ?? 0,
                              blue: baseCg.rgbCurves?.blue ?? 0,
                              [ch]: v,
                            },
                          },
                        };
                      })
                    }
                  />
                ))}
              </div>
              <div className="grid grid-cols-3 gap-1 pt-1 border-t border-[#3E3E44]">
                {(
                  [
                    { key: 'shadowsRed', label: 'Sh R' },
                    { key: 'shadowsGreen', label: 'Sh G' },
                    { key: 'shadowsBlue', label: 'Sh B' },
                    { key: 'highlightsRed', label: 'Hl R' },
                    { key: 'highlightsGreen', label: 'Hl G' },
                    { key: 'highlightsBlue', label: 'Hl B' },
                  ] as const
                ).map(({ key, label }) => (
                  <SliderRow
                    key={key}
                    label={label}
                    value={safeColorGrade.colorBalance?.[key] ?? 0}
                    min={-100}
                    max={100}
                    step={1}
                    onChange={(v) =>
                      onUpdateClip(selectedClip.id, (c) => {
                        const baseCg = c.colorGrade || createDefaultColorGrade();
                        return {
                          ...c,
                          colorGrade: {
                            ...baseCg,
                            colorBalance: {
                              shadowsRed: baseCg.colorBalance?.shadowsRed ?? 0,
                              shadowsGreen: baseCg.colorBalance?.shadowsGreen ?? 0,
                              shadowsBlue: baseCg.colorBalance?.shadowsBlue ?? 0,
                              highlightsRed: baseCg.colorBalance?.highlightsRed ?? 0,
                              highlightsGreen: baseCg.colorBalance?.highlightsGreen ?? 0,
                              highlightsBlue: baseCg.colorBalance?.highlightsBlue ?? 0,
                              [key]: v,
                            },
                          },
                        };
                      })
                    }
                  />
                ))}
              </div>
            </InspectorSection>

            <InspectorSection title="Green Screen / Chroma Key" defaultOpen={safeChromaKey.enabled}>
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-1.5 text-[#F4F4F5] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={safeChromaKey.enabled}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        chromaKey: { ...(c.chromaKey || createDefaultChromaKey()), enabled: e.target.checked },
                      }))
                    }
                    className="accent-[#A1A1AA]"
                  />
                  Enable Chroma Key
                </label>
                <input
                  type="color"
                  value={safeChromaKey.color}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, (c) => ({
                      ...c,
                      chromaKey: { ...(c.chromaKey || createDefaultChromaKey()), color: e.target.value },
                    }))
                  }
                  className="w-6 h-6 bg-transparent border border-[#3E3E44] rounded"
                />
              </div>
              {safeChromaKey.enabled && (
                <>
                  <SliderRow
                    label="Tolerance"
                    value={safeChromaKey.tolerance}
                    min={5}
                    max={95}
                    step={1}
                    onChange={(v) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        chromaKey: { ...(c.chromaKey || createDefaultChromaKey()), tolerance: v },
                      }))
                    }
                  />
                  <SliderRow
                    label="Spill Suppression"
                    value={safeChromaKey.spillSuppression}
                    min={0}
                    max={100}
                    step={1}
                    unit="%"
                    onChange={(v) =>
                      onUpdateClip(selectedClip.id, (c) => ({
                        ...c,
                        chromaKey: { ...(c.chromaKey || createDefaultChromaKey()), spillSuppression: v },
                      }))
                    }
                  />
                </>
              )}
            </InspectorSection>
          </div>
        )}

        {tab === 'audio' && (
          <div className="space-y-2.5">
            <InspectorSection title="Audio Gain & Fades" defaultOpen>
              <SliderRow
                label="Clip Volume"
                value={Math.round(selectedClip.volume * 100)}
                min={0}
                max={200}
                step={2}
                unit="%"
                onChange={(v) => onUpdateClip(selectedClip.id, (c) => ({ ...c, volume: v / 100 }))}
              />
              <SliderRow
                label="Fade In"
                value={selectedClip.fadeIn}
                min={0}
                max={5}
                step={0.1}
                unit="s"
                onChange={(v) => onUpdateClip(selectedClip.id, (c) => ({ ...c, fadeIn: v }))}
              />
              <SliderRow
                label="Fade Out"
                value={selectedClip.fadeOut}
                min={0}
                max={5}
                step={0.1}
                unit="s"
                onChange={(v) => onUpdateClip(selectedClip.id, (c) => ({ ...c, fadeOut: v }))}
              />
            </InspectorSection>
            <InspectorSection title="Audio Speed" defaultOpen>
              <SliderRow
                label="Playback Speed"
                value={selectedClip.speed}
                min={0.25}
                max={4}
                step={0.05}
                unit="×"
                onChange={(v) => onUpdateClip(selectedClip.id, (c) => ({ ...c, speed: v }))}
              />
              <label className="flex items-center gap-2 text-[#F4F4F5] cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedClip.reverse}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, (c) => ({ ...c, reverse: e.target.checked }))
                  }
                  className="accent-[#A1A1AA]"
                />
                Reverse Clip Playback
              </label>
            </InspectorSection>
          </div>
        )}
      </div>
    </div>
  );
};

interface InspectorSectionProps {
  title: string;
  defaultOpen?: boolean;
  headerRight?: React.ReactNode;
  children: React.ReactNode;
}

const InspectorSection: React.FC<InspectorSectionProps> = ({
  title,
  defaultOpen = true,
  headerRight,
  children,
}) => {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="bg-[#2C2C30] border border-[#3E3E44] rounded-[6px] overflow-hidden">
      <div
        onClick={() => setOpen((v) => !v)}
        className="px-2.5 py-1.5 flex items-center justify-between gap-2 cursor-pointer select-none hover:bg-[#343439] transition-colors"
      >
        <div className="flex items-center gap-1.5 min-w-0">
          {open ? (
            <ChevronDown className="w-3 h-3 text-[#D4D4D8] shrink-0" />
          ) : (
            <ChevronRight className="w-3 h-3 text-[#A1A1AA] shrink-0" />
          )}
          <span className="text-[10px] font-semibold text-[#F4F4F5] uppercase tracking-wider truncate">
            {title}
          </span>
        </div>
        {headerRight && (
          <div onClick={(e) => e.stopPropagation()} className="shrink-0">
            {headerRight}
          </div>
        )}
      </div>
      {open && (
        <div className="px-2.5 py-2 border-t border-[#3E3E44] bg-[#222225] space-y-2">
          {children}
        </div>
      )}
    </div>
  );
};

interface SliderRowProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit?: string;
  keyframeActive?: boolean;
  onToggleKeyframe?: () => void;
  onChange: (val: number) => void;
}

const SliderRow: React.FC<SliderRowProps> = ({
  label,
  value,
  min,
  max,
  step,
  unit = '',
  keyframeActive,
  onToggleKeyframe,
  onChange,
}) => (
  <div className="space-y-0.5">
    <div className="flex items-center justify-between text-[11px] gap-2">
      <div className="flex items-center gap-1.5 text-[#A1A1AA] min-w-0">
        {onToggleKeyframe && (
          <button
            type="button"
            onClick={onToggleKeyframe}
            title="Toggle Keyframe at Playhead"
            className={`p-0.5 rounded transition-colors ${
              keyframeActive ? 'text-[#D4D4D8]' : 'text-[#6E7280] hover:text-[#F4F4F5]'
            }`}
          >
            <Diamond className="w-3 h-3 fill-current" />
          </button>
        )}
        <span className="truncate">{label}</span>
      </div>
      <div className="flex items-center gap-0.5 shrink-0">
        <input
          type="number"
          min={min}
          max={max}
          step={step}
          value={Number.isInteger(step) ? Math.round(value) : Number(value.toFixed(2))}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-12 px-1 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-right font-mono-tabular text-[10px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
        />
        {unit && <span className="text-[10px] text-[#A1A1AA]">{unit}</span>}
      </div>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="w-full h-1 accent-[#A1A1AA] cursor-pointer"
    />
  </div>
);
