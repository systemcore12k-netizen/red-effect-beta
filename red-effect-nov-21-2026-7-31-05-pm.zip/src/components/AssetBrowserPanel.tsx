import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Film,
  Sparkles,
  Type,
  ArrowRightLeft,
  Music,
  Palette,
  LayoutTemplate,
  Shapes,
  Search,
  Star,
  Plus,
  Upload,
} from 'lucide-react';
import {
  ColorGrade,
  MediaAsset,
  TextProperties,
  TimelineClip,
} from '../types/studio';
import {
  ReadyMadeCategoryId,
  ReadyMadeEffectPreset,
  ShapeKind,
  ShapeProperties,
  TransitionSettings,
} from '../types/effects';
import { READY_MADE_PRESETS } from '../services/readyMadeEffects';
import { EFFECTS_CATALOG } from '../services/effectsCatalog';
import { applyEffectsStackToCanvas, applyFullColorGradeToCanvas } from '../services/effectsProcessor';
import {
  BuiltinAudioKind,
  createBuiltinAudioAsset,
  SavedCustomTemplate,
  TrailerTemplateCustomization,
} from '../services/trailerTemplate';
import { MediaExplorerPanel } from './MediaExplorerPanel';
import { TextStudioPanel } from './TextStudioPanel';
import { TransitionsPanel } from './TransitionsPanel';
import { TemplatesBrowserTab } from './TemplatesBrowserTab';
import { catalogEffectToHoverPreset } from '../services/hoverPreviewCache';

export type AssetBrowserTabId =
  | 'media'
  | 'effects'
  | 'text'
  | 'transitions'
  | 'audio'
  | 'color'
  | 'templates'
  | 'stickers';

const FAVORITE_EFFECTS_KEY = 'redeffect_favorite_effects_v1';

interface AssetBrowserPanelProps {
  activeTab: AssetBrowserTabId;
  onChangeTab: (tab: AssetBrowserTabId) => void;
  assets: MediaAsset[];
  activeFolder: string;
  selectedAssetId: string | null;
  selectedClip: TimelineClip | null;
  playheadTime: number;
  customReadyPresets: ReadyMadeEffectPreset[];
  customTemplates: SavedCustomTemplate[];
  hoverPreviewEnabled?: boolean;
  onSelectAsset: (assetId: string) => void;
  onImportFiles: (files: FileList) => void;
  onAddAssetToTimeline: (asset: MediaAsset) => void;
  onAddBuiltinAudioAsset: (asset: MediaAsset) => void;
  onOpen3DForAsset: (asset: MediaAsset) => void;
  onDeleteAsset: (assetId: string) => void;
  onApplyReadyPreset: (preset: ReadyMadeEffectPreset) => void;
  onHoverReadyPreset: (preset: ReadyMadeEffectPreset | null) => void;
  onClearHoverImmediate?: () => void;
  onAddCatalogEffect: (effectType: string, targetClipId?: string) => void;
  onApplyTransition: (
    side: 'in' | 'out' | 'both',
    settings: TransitionSettings,
    targetClipId?: string
  ) => void;
  onAddTextClip: (isSubtitle?: boolean, overrides?: Partial<TextProperties>) => void;
  onAddStickerShape: (
    kind: ShapeKind,
    label: string,
    overrides?: Partial<ShapeProperties>
  ) => void;
  onUpdateClip: (clipId: string, updater: (c: TimelineClip) => TimelineClip) => void;
  onSaveReadyMadePreset: (preset: ReadyMadeEffectPreset) => void;
  onOpenTemplate: (customization?: TrailerTemplateCustomization) => void;
  onCustomizeTemplate: (customization?: TrailerTemplateCustomization) => void;
  onDeleteCustomTemplate: (id: string) => void;
}

const BROWSER_TABS: Array<{ id: AssetBrowserTabId; label: string; icon: React.ReactNode }> = [
  { id: 'media', label: 'Media', icon: <Film className="w-4 h-4" /> },
  { id: 'effects', label: 'Effects', icon: <Sparkles className="w-4 h-4" /> },
  { id: 'text', label: 'Text', icon: <Type className="w-4 h-4" /> },
  { id: 'transitions', label: 'Transitions', icon: <ArrowRightLeft className="w-4 h-4" /> },
  { id: 'audio', label: 'Audio', icon: <Music className="w-4 h-4" /> },
  { id: 'color', label: 'CC / Color', icon: <Palette className="w-4 h-4" /> },
  { id: 'templates', label: 'Templates', icon: <LayoutTemplate className="w-4 h-4" /> },
  { id: 'stickers', label: 'Shapes', icon: <Shapes className="w-4 h-4" /> },
];

const EFFECT_SUBCATS: Array<{ id: ReadyMadeCategoryId | 'favorites' | 'all-fx'; label: string }> = [
  { id: 'shake', label: 'Shake' },
  { id: 'glitch', label: 'Glitch' },
  { id: 'text', label: 'Text FX' },
  { id: 'rgb', label: 'RGB' },
  { id: 'blur', label: 'Blur' },
  { id: 'cinematic', label: 'Cinematic' },
  { id: 'distortion', label: 'Distortion' },
  { id: 'cc', label: 'Color FX' },
  { id: 'favorites', label: 'Favorites' },
  { id: 'all-fx', label: 'Nodes' },
];

const STICKER_PRESETS: Array<{
  id: string;
  label: string;
  desc: string;
  kind: ShapeKind;
  overrides: Partial<ShapeProperties>;
}> = [
  {
    id: 'stk-bar',
    label: 'Accent Lower Bar',
    desc: 'Animated lower-third accent line',
    kind: 'rectangle',
    overrides: { fillColor: '#A1A1AA', widthPct: 58, heightPct: 2.5, cornerRadius: 2, strokeWidth: 0 },
  },
  {
    id: 'stk-frame',
    label: 'Cinema Frame Border',
    desc: 'Widescreen border overlay',
    kind: 'rectangle',
    overrides: {
      fillColor: 'transparent',
      strokeColor: '#A1A1AA',
      strokeWidth: 4,
      widthPct: 86,
      heightPct: 78,
      cornerRadius: 4,
    },
  },
  {
    id: 'stk-badge',
    label: 'Title Backing Plate',
    desc: 'Dark obsidian backing container',
    kind: 'rectangle',
    overrides: {
      fillColor: '#18181A',
      strokeColor: '#A1A1AA',
      strokeWidth: 2,
      widthPct: 48,
      heightPct: 16,
      cornerRadius: 8,
    },
  },
  {
    id: 'stk-aura',
    label: 'Violet Spotlight Orb',
    desc: 'Glowing radial spotlight orb',
    kind: 'circle',
    overrides: {
      fillColor: '#A1A1AA',
      fillOpacity: 0.72,
      strokeColor: '#A1A1AA',
      strokeWidth: 0,
      widthPct: 42,
      heightPct: 42,
    },
  },
  {
    id: 'stk-star',
    label: 'Impact Starburst',
    desc: 'Geometric 5-point burst icon',
    kind: 'star',
    overrides: {
      fillColor: '#F59E0B',
      strokeColor: '#FFFFFF',
      strokeWidth: 2,
      widthPct: 26,
      heightPct: 26,
      points: 5,
    },
  },
  {
    id: 'stk-hex',
    label: 'Cyber Hexagon Badge',
    desc: 'Clean HUD hex badge',
    kind: 'polygon',
    overrides: {
      fillColor: '#222225',
      strokeColor: '#0EA5E9',
      strokeWidth: 3,
      widthPct: 30,
      heightPct: 30,
      points: 6,
    },
  },
];

const BUILTIN_AUDIO_ITEMS: Array<{
  kind: BuiltinAudioKind;
  title: string;
  meta: string;
}> = [
  { kind: 'trailer-beat', title: 'Crimson Trailer Pulse 120 BPM', meta: '8.0s · Dark Synth Beat' },
  { kind: 'sub-impact', title: 'Cinematic Sub-Bass Boom', meta: '2.0s · Impact Hit' },
  { kind: 'riser-whoosh', title: 'Metallic Tension Riser', meta: '3.0s · Transition Swell' },
  { kind: 'glitch-pulse', title: 'Digital Glitch Burst', meta: '3.0s · Stutter FX' },
];

const EffectMiniCanvas: React.FC<{ preset: ReadyMadeEffectPreset; activeHover: boolean }> = ({
  preset,
  activeHover,
}) => {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const w = 112;
    const h = 54;
    canvas.width = w;
    canvas.height = h;

    let raf = 0;
    const draw = (t: number) => {
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) return;

      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, '#131621');
      grad.addColorStop(1, '#261E3D');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      ctx.fillStyle = preset.accentColor || '#A1A1AA';
      ctx.beginPath();
      ctx.arc(w * 0.72, h * 0.35, 11, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#0D0F14';
      ctx.beginPath();
      ctx.moveTo(0, h);
      ctx.lineTo(w * 0.35, h * 0.45);
      ctx.lineTo(w * 0.68, h * 0.72);
      ctx.lineTo(w, h * 0.42);
      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fill();

      if (preset.effectsStack?.length) {
        applyEffectsStackToCanvas(canvas, preset.effectsStack, t, [], 2.0);
      } else if (preset.colorGrade) {
        applyFullColorGradeToCanvas(canvas, {
          preset: 'none',
          exposure: 0,
          contrast: 0,
          saturation: 0,
          temperature: 0,
          tint: 0,
          vignette: 0,
          highlights: 0,
          shadows: 0,
          whites: 0,
          blacks: 0,
          vibrance: 0,
          lutIntensity: 100,
          ...(preset.colorGrade as Partial<ColorGrade>),
        });
      } else if (preset.textPreset) {
        ctx.fillStyle = '#161618';
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = preset.textPreset.color || '#F4F4F5';
        ctx.font = '800 13px "Outfit", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('FX TEXT', w * 0.5, h * 0.5);
      }
    };

    if (activeHover) {
      const s = performance.now();
      const tick = () => {
        draw((performance.now() - s) / 1000);
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
      return () => cancelAnimationFrame(raf);
    } else {
      draw(0.45);
    }
  }, [preset, activeHover]);

  return (
    <canvas
      ref={ref}
      className="w-full h-12 rounded-sm bg-[#18181A] border border-[#3E3E44] block object-cover"
    />
  );
};

export const AssetBrowserPanel: React.FC<AssetBrowserPanelProps> = ({
  activeTab,
  onChangeTab,
  assets,
  activeFolder,
  selectedAssetId,
  selectedClip,
  playheadTime,
  customReadyPresets,
  customTemplates,
  hoverPreviewEnabled = true,
  onSelectAsset,
  onImportFiles,
  onAddAssetToTimeline,
  onAddBuiltinAudioAsset,
  onOpen3DForAsset,
  onDeleteAsset,
  onApplyReadyPreset,
  onHoverReadyPreset,
  onClearHoverImmediate,
  onAddCatalogEffect,
  onApplyTransition,
  onAddTextClip,
  onAddStickerShape,
  onUpdateClip,
  onSaveReadyMadePreset,
  onOpenTemplate,
  onCustomizeTemplate,
  onDeleteCustomTemplate,
}) => {
  const [fxSearch, setFxSearch] = useState('');
  const [fxSubCat, setFxSubCat] = useState<ReadyMadeCategoryId | 'favorites' | 'all-fx'>('shake');
  const [ccSearch, setCcSearch] = useState('');
  const [showCcFavoritesOnly, setShowCcFavoritesOnly] = useState(false);
  const [hoveredFxId, setHoveredFxId] = useState<string | null>(null);
  const [hoveredCcId, setHoveredCcId] = useState<string | null>(null);

  const clearHover = () => {
    setHoveredFxId(null);
    setHoveredCcId(null);
    if (onClearHoverImmediate) {
      onClearHoverImmediate();
    } else {
      onHoverReadyPreset(null);
    }
  };

  useEffect(() => {
    return () => {
      clearHover();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(FAVORITE_EFFECTS_KEY);
      return raw ? (JSON.parse(raw) as string[]) : [];
    } catch {
      return [];
    }
  });
  const audioUploadRef = useRef<HTMLInputElement | null>(null);

  const toggleFavorite = (id: string) => {
    setFavorites((prev) => {
      const next = prev.includes(id) ? prev.filter((i) => i !== id) : [id, ...prev];
      try {
        localStorage.setItem(FAVORITE_EFFECTS_KEY, JSON.stringify(next));
      } catch {
        // Ignore
      }
      return next;
    });
  };

  const allReadyPresets = useMemo(
    () => [...customReadyPresets, ...READY_MADE_PRESETS],
    [customReadyPresets]
  );

  const filteredPresets = useMemo(() => {
    const q = fxSearch.trim().toLowerCase();
    if (q) {
      return allReadyPresets.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      );
    }
    if (fxSubCat === 'favorites') {
      return allReadyPresets.filter((p) => favorites.includes(p.id));
    }
    if (fxSubCat === 'all-fx') return [];
    return allReadyPresets.filter((p) => p.category === fxSubCat);
  }, [allReadyPresets, favorites, fxSearch, fxSubCat]);

  const ccPresets = useMemo(() => {
    const q = ccSearch.trim().toLowerCase();
    return allReadyPresets.filter((p) => {
      if (p.category !== 'cc') return false;
      if (showCcFavoritesOnly && !favorites.includes(p.id)) return false;
      if (!q) return true;
      return p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q);
    });
  }, [allReadyPresets, ccSearch, favorites, showCcFavoritesOnly]);

  const audioAssets = useMemo(
    () => assets.filter((a) => a.type === 'audio'),
    [assets]
  );

  return (
    <div
      data-tutorial-target="asset-browser-panel"
      className="flex h-full bg-[#222225] text-[#F4F4F5] select-none overflow-hidden"
    >
      {/* Left Vertical Sidebar Tabs */}
      <nav
        aria-label="Asset Categories"
        className="w-[64px] shrink-0 bg-[#18181A] border-r border-[#3E3E44] py-1.5 px-1 flex flex-col gap-1 overflow-y-auto"
      >
        {BROWSER_TABS.map((t) => {
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                clearHover();
                onChangeTab(t.id);
              }}
              title={t.label}
              className={`w-full py-2 px-1 rounded flex flex-col items-center justify-center gap-1 transition-colors border ${
                isActive
                  ? 'bg-[#71717A]/15 border-[#A1A1AA]/70 text-[#F4F4F5]'
                  : 'border-transparent text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
              }`}
            >
              <span className={isActive ? 'text-[#D4D4D8]' : ''}>{t.icon}</span>
              <span className="text-[9px] font-medium leading-tight text-center truncate max-w-full">
                {t.label === 'Transitions' ? 'Trans' : t.label === 'CC / Color' ? 'Color' : t.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Right Content Area: Search, Categories, Import, Favorites & Thumbnail Grid */}
      <div className="flex-1 min-w-0 flex flex-col overflow-hidden bg-[#222225]">
        {activeTab === 'media' && (
          <MediaExplorerPanel
            assets={assets}
            activeFolder={activeFolder}
            selectedAssetId={selectedAssetId}
            onSelectAsset={onSelectAsset}
            onImportFiles={onImportFiles}
            onAddAssetToTimeline={onAddAssetToTimeline}
            onOpen3DForAsset={onOpen3DForAsset}
            onDeleteAsset={onDeleteAsset}
          />
        )}

        {activeTab === 'effects' && (
          <div className="flex-1 min-h-0 flex flex-col">
            <div className="p-2 space-y-2 border-b border-[#3E3E44] bg-[#2C2C30] shrink-0">
              <div className="flex items-center gap-1.5">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-[#A1A1AA] absolute left-2 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={fxSearch}
                    onChange={(e) => setFxSearch(e.target.value)}
                    placeholder="Search effects..."
                    className="w-full pl-7 pr-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] placeholder-[#A1A1AA]/70 focus:outline-none focus:border-[#A1A1AA]"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setFxSearch('');
                    setFxSubCat((prev) => (prev === 'favorites' ? 'shake' : 'favorites'));
                  }}
                  title="Show Favorites"
                  className={`p-1.5 rounded border transition-colors ${
                    fxSubCat === 'favorites'
                      ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                      : 'bg-[#18181A] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                  }`}
                >
                  <Star className={`w-3.5 h-3.5 ${fxSubCat === 'favorites' ? 'fill-[#A1A1AA] text-[#D4D4D8]' : ''}`} />
                </button>
              </div>

              <div className="flex flex-wrap gap-1">
                {EFFECT_SUBCATS.map((sc) => {
                  const active = !fxSearch.trim() && fxSubCat === sc.id;
                  return (
                    <button
                      key={sc.id}
                      type="button"
                      onClick={() => {
                        setFxSearch('');
                        setFxSubCat(sc.id);
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-medium whitespace-nowrap transition-colors border ${
                        active
                          ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                          : 'bg-[#18181A] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                      }`}
                    >
                      {sc.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div
              onMouseLeave={clearHover}
              className="flex-1 min-h-0 overflow-y-auto p-2"
            >
              {fxSubCat === 'all-fx' && !fxSearch.trim() ? (
                <div className="space-y-1">
                  {EFFECTS_CATALOG.map((ef) => {
                    const payload = JSON.stringify({ kind: 'effectStackItem', effectType: ef.type });
                    return (
                      <div
                        key={ef.type}
                        draggable
                        onMouseEnter={() => {
                          if (hoverPreviewEnabled) {
                            onHoverReadyPreset(catalogEffectToHoverPreset(ef));
                          }
                        }}
                        onMouseLeave={() => {
                          if (hoverPreviewEnabled) {
                            onHoverReadyPreset(null);
                          }
                        }}
                        onDragStart={(e) => {
                          clearHover();
                          e.dataTransfer.setData('application/x-redeffect-fx', payload);
                          e.dataTransfer.effectAllowed = 'copy';
                        }}
                        onClick={() => {
                          clearHover();
                          onAddCatalogEffect(ef.type, selectedClip?.id);
                        }}
                        className="p-2 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA] flex items-center justify-between gap-2 cursor-grab active:cursor-grabbing transition-colors"
                      >
                        <div className="min-w-0">
                          <div className="text-[11px] font-medium text-[#F4F4F5] truncate">{ef.name}</div>
                          <div className="text-[9px] text-[#A1A1AA] truncate">{ef.description}</div>
                        </div>
                        <Plus className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0" />
                      </div>
                    );
                  })}
                </div>
              ) : filteredPresets.length === 0 ? (
                <div className="py-8 text-center text-[11px] text-[#A1A1AA]">
                  {fxSubCat === 'favorites'
                    ? 'Click the star icon on any effect to bookmark it here.'
                    : 'No matching effects found.'}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-1.5">
                  {filteredPresets.map((preset) => {
                    const isFav = favorites.includes(preset.id);
                    const isHov = hoveredFxId === preset.id;
                    return (
                      <div
                        key={preset.id}
                        draggable
                        onDragStart={(e) => {
                          clearHover();
                          e.dataTransfer.setData(
                            'application/x-redeffect-fx',
                            JSON.stringify({ kind: 'readyPreset', presetId: preset.id })
                          );
                          e.dataTransfer.effectAllowed = 'copy';
                        }}
                        onMouseEnter={() => {
                          setHoveredFxId(preset.id);
                          if (hoverPreviewEnabled) {
                            onHoverReadyPreset(preset);
                          }
                        }}
                        onMouseLeave={() => {
                          setHoveredFxId((prev) => (prev === preset.id ? null : prev));
                          if (hoverPreviewEnabled) {
                            onHoverReadyPreset(null);
                          }
                        }}
                        onClick={() => {
                          clearHover();
                          onApplyReadyPreset(preset);
                        }}
                        title={`${preset.name}: ${preset.description}`}
                        className={`group p-1.5 rounded bg-[#2C2C30] border cursor-grab active:cursor-grabbing flex flex-col gap-1 transition-colors ${
                          isHov
                            ? 'border-[#A1A1AA] bg-[#71717A]/15'
                            : 'border-[#3E3E44] hover:border-[#A1A1AA]/60'
                        }`}
                      >
                        <EffectMiniCanvas preset={preset} activeHover={isHov} />
                        <div className="flex items-center justify-between gap-1 px-0.5">
                          <span className="text-[10px] font-medium text-[#F4F4F5] truncate">
                            {preset.name}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleFavorite(preset.id);
                            }}
                            title={isFav ? 'Remove Favorite' : 'Bookmark Effect'}
                            className={`p-0.5 rounded shrink-0 ${
                              isFav ? 'text-amber-400' : 'text-[#A1A1AA]/60 hover:text-[#F4F4F5]'
                            }`}
                          >
                            <Star className={`w-3 h-3 ${isFav ? 'fill-current' : ''}`} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'text' && (
          <TextStudioPanel
            selectedClip={selectedClip}
            playheadTime={playheadTime}
            hoverPreviewEnabled={hoverPreviewEnabled}
            onAddTextClip={onAddTextClip}
            onUpdateClip={onUpdateClip}
            onSaveReadyMadePreset={onSaveReadyMadePreset}
            onHoverTextPreset={onHoverReadyPreset}
            onClearHoverImmediate={onClearHoverImmediate}
          />
        )}

        {activeTab === 'transitions' && (
          <TransitionsPanel
            selectedClip={selectedClip}
            hoverPreviewEnabled={hoverPreviewEnabled}
            onApplyTransition={onApplyTransition}
            onHoverTransition={onHoverReadyPreset}
            onClearHoverImmediate={onClearHoverImmediate}
          />
        )}

        {activeTab === 'audio' && (
          <div className="flex-1 min-h-0 overflow-y-auto p-2 space-y-3 text-xs">
            <input
              ref={audioUploadRef}
              type="file"
              multiple
              accept="audio/*,.mp3,.wav,.aac,.m4a,.ogg"
              onChange={(e) => {
                if (e.target.files?.length) onImportFiles(e.target.files);
                e.target.value = '';
              }}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => audioUploadRef.current?.click()}
              className="w-full py-1.5 px-3 bg-[#52525B] hover:bg-[#6B7280] text-white font-medium rounded flex items-center justify-center gap-1.5 transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              Import Audio / SFX
            </button>

            <div className="space-y-1.5">
              <div className="text-[10px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
                Built-in Sound &amp; Beats
              </div>
              {BUILTIN_AUDIO_ITEMS.map((item) => (
                <div
                  key={item.kind}
                  onClick={() => onAddBuiltinAudioAsset(createBuiltinAudioAsset(item.kind))}
                  className="p-2 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA] cursor-pointer flex items-center justify-between gap-2 transition-colors"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <Music className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-[11px] font-medium text-[#F4F4F5] truncate">{item.title}</div>
                      <div className="text-[9px] font-mono-tabular text-[#A1A1AA]">{item.meta}</div>
                    </div>
                  </div>
                  <Plus className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0" />
                </div>
              ))}
            </div>

            {audioAssets.length > 0 && (
              <div className="space-y-1.5">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
                  Project Audio ({audioAssets.length})
                </div>
                {audioAssets.map((a) => (
                  <div
                    key={a.id}
                    draggable
                    onDragStart={(e) => {
                      e.dataTransfer.setData('application/x-redeffect-asset', a.id);
                      e.dataTransfer.effectAllowed = 'copy';
                    }}
                    onClick={() => onAddAssetToTimeline(a)}
                    className="p-2 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA] cursor-grab flex items-center justify-between gap-2 transition-colors"
                  >
                    <div className="min-w-0">
                      <div className="text-[11px] font-medium text-[#F4F4F5] truncate">{a.name}</div>
                      <div className="text-[9px] font-mono-tabular text-[#A1A1AA]">
                        {a.duration.toFixed(1)}s · Drag or click
                      </div>
                    </div>
                    <Plus className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0" />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'color' && (
          <div className="flex-1 min-h-0 flex flex-col">
            <div className="p-2 border-b border-[#3E3E44] bg-[#2C2C30] flex items-center gap-1.5 shrink-0">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 text-[#A1A1AA] absolute left-2 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={ccSearch}
                  onChange={(e) => setCcSearch(e.target.value)}
                  placeholder="Search color LUTs..."
                  className="w-full pl-7 pr-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] placeholder-[#A1A1AA]/70 focus:outline-none focus:border-[#A1A1AA]"
                />
              </div>
              <button
                type="button"
                onClick={() => setShowCcFavoritesOnly((v) => !v)}
                title="Filter Favorites"
                className={`p-1.5 rounded border transition-colors ${
                  showCcFavoritesOnly
                    ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                    : 'bg-[#18181A] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                <Star className={`w-3.5 h-3.5 ${showCcFavoritesOnly ? 'fill-[#A1A1AA] text-[#D4D4D8]' : ''}`} />
              </button>
            </div>
            <div
              onMouseLeave={clearHover}
              className="flex-1 min-h-0 overflow-y-auto p-2 space-y-2"
            >
              <div className="text-[10px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
                Color Grades ({ccPresets.length})
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {ccPresets.map((preset) => {
                  const isHov = hoveredCcId === preset.id;
                  const isFav = favorites.includes(preset.id);
                  return (
                    <div
                      key={preset.id}
                      draggable
                      onDragStart={(e) => {
                        clearHover();
                        e.dataTransfer.setData(
                          'application/x-redeffect-fx',
                          JSON.stringify({ kind: 'readyPreset', presetId: preset.id })
                        );
                        e.dataTransfer.effectAllowed = 'copy';
                      }}
                      onMouseEnter={() => {
                        setHoveredCcId(preset.id);
                        if (hoverPreviewEnabled) {
                          onHoverReadyPreset(preset);
                        }
                      }}
                      onMouseLeave={() => {
                        setHoveredCcId((prev) => (prev === preset.id ? null : prev));
                        if (hoverPreviewEnabled) {
                          onHoverReadyPreset(null);
                        }
                      }}
                      onClick={() => {
                        clearHover();
                        onApplyReadyPreset(preset);
                      }}
                      className={`p-1.5 rounded bg-[#2C2C30] border cursor-grab space-y-1 transition-colors ${
                        isHov
                          ? 'border-[#A1A1AA] bg-[#71717A]/15'
                          : 'border-[#3E3E44] hover:border-[#A1A1AA]/60'
                      }`}
                    >
                      <EffectMiniCanvas preset={preset} activeHover={isHov} />
                      <div className="flex items-center justify-between gap-1 px-0.5">
                        <span className="text-[10px] font-medium text-[#F4F4F5] truncate">
                          {preset.name}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(preset.id);
                          }}
                          className={`p-0.5 rounded shrink-0 ${
                            isFav ? 'text-amber-400' : 'text-[#A1A1AA]/60 hover:text-[#F4F4F5]'
                          }`}
                        >
                          <Star className={`w-3 h-3 ${isFav ? 'fill-current' : ''}`} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'templates' && (
          <TemplatesBrowserTab
            customTemplates={customTemplates}
            onOpenTemplate={onOpenTemplate}
            onCustomizeTemplate={onCustomizeTemplate}
            onDeleteCustomTemplate={onDeleteCustomTemplate}
          />
        )}

        {activeTab === 'stickers' && (
          <div className="flex-1 min-h-0 overflow-y-auto p-2 space-y-2">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
              Vector Shapes &amp; Overlays
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {STICKER_PRESETS.map((stk) => (
                <button
                  key={stk.id}
                  type="button"
                  onClick={() => onAddStickerShape(stk.kind, stk.label, stk.overrides)}
                  className="p-2 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA] text-left flex flex-col gap-1 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <Shapes className="w-4 h-4 text-[#D4D4D8]" />
                    <Plus className="w-3 h-3 text-[#A1A1AA]" />
                  </div>
                  <div className="text-[11px] font-medium text-[#F4F4F5] truncate">{stk.label}</div>
                  <div className="text-[9px] text-[#A1A1AA] line-clamp-2">{stk.desc}</div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
