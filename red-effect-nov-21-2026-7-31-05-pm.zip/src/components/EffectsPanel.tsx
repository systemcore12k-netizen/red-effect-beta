import React, { useEffect, useMemo, useState } from 'react';
import {
  Sparkles,
  Palette,
  Wind,
  Layers,
  Zap,
  Droplet,
  Sun,
  Contrast,
  Plus,
  Search,
  Wand2,
} from 'lucide-react';
import { EffectCategoryId, ReadyMadeEffectPreset } from '../types/effects';
import { TimelineClip } from '../types/studio';
import { EFFECT_CATEGORIES, EFFECTS_CATALOG } from '../services/effectsCatalog';
import { catalogEffectToHoverPreset } from '../services/hoverPreviewCache';

interface EffectsPanelProps {
  selectedClip: TimelineClip | null;
  hoverPreviewEnabled?: boolean;
  onAddEffectToClip: (effectType: string, targetClipId?: string) => void;
  onApplyEffectPayload: (payload: string, targetClipId?: string) => void;
  onHoverEffect?: (preset: ReadyMadeEffectPreset | null) => void;
  onClearHoverImmediate?: () => void;
}

export const EffectsPanel: React.FC<EffectsPanelProps> = ({
  selectedClip,
  hoverPreviewEnabled = true,
  onAddEffectToClip,
  onApplyEffectPayload,
  onHoverEffect,
  onClearHoverImmediate,
}) => {
  const [search, setSearch] = useState('');
  const [activeCat, setActiveCat] = useState<EffectCategoryId | 'all'>('all');

  const clearHover = () => {
    if (onClearHoverImmediate) {
      onClearHoverImmediate();
    } else {
      onHoverEffect?.(null);
    }
  };

  useEffect(() => {
    return () => {
      clearHover();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const items = useMemo(() => {
    const q = search.trim().toLowerCase();
    return EFFECTS_CATALOG.filter((ef) => {
      if (activeCat !== 'all' && ef.category !== activeCat) return false;
      if (q && !ef.name.toLowerCase().includes(q) && !ef.description.toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [activeCat, search]);

  const getCatIcon = (cat: EffectCategoryId) => {
    switch (cat) {
      case 'blur':
        return <Droplet className="w-3.5 h-3.5 text-sky-400 shrink-0" />;
      case 'glow':
        return <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
      case 'color':
        return <Palette className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
      case 'distortion':
        return <Wind className="w-3.5 h-3.5 text-violet-400 shrink-0" />;
      case 'glitch':
        return <Zap className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0" />;
      case 'shadow':
        return <Contrast className="w-3.5 h-3.5 text-zinc-300 shrink-0" />;
      case 'texture':
        return <Layers className="w-3.5 h-3.5 text-orange-300 shrink-0" />;
      case 'stylize':
        return <Sparkles className="w-3.5 h-3.5 text-pink-400 shrink-0" />;
    }
  };

  return (
    <div
      data-tutorial-target="effects-panel"
      className="p-3 flex flex-col gap-2.5 h-full text-xs bg-[#222225] text-[#F4F4F5]"
    >
      <div className="relative">
        <Search className="w-3.5 h-3.5 text-[#A1A1AA] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search 76 effects (Blur, Glow, Glitch, LUT)..."
          className="w-full pl-8 pr-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] placeholder:text-[#A1A1AA] focus:outline-none focus:border-[#A1A1AA]"
        />
      </div>

      {/* Category Filter Grid */}
      <div className="flex flex-wrap gap-1">
        <button
          type="button"
          onClick={() => setActiveCat('all')}
          className={`px-2 py-1 rounded text-[10px] font-medium transition-colors ${
            activeCat === 'all'
              ? 'bg-[#52525B] text-white'
              : 'bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5] border border-[#3E3E44]'
          }`}
        >
          All ({EFFECTS_CATALOG.length})
        </button>
        {EFFECT_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setActiveCat(cat.id)}
            className={`px-2 py-1 rounded text-[10px] font-medium transition-colors whitespace-nowrap ${
              activeCat === cat.id
                ? 'bg-[#52525B] text-white'
                : 'bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5] border border-[#3E3E44]'
            }`}
          >
            {cat.label.replace(' Effects', '')}
          </button>
        ))}
      </div>

      {/* Effects List */}
      <div
        onMouseLeave={clearHover}
        className="flex-1 overflow-y-auto space-y-1.5 pr-0.5"
      >
        {items.map((ef) => {
          const payload = JSON.stringify({ kind: 'effectStackItem', effectType: ef.type });
          return (
            <div
              key={ef.type}
              draggable
              onMouseEnter={() => {
                if (hoverPreviewEnabled && onHoverEffect) {
                  onHoverEffect(catalogEffectToHoverPreset(ef));
                }
              }}
              onMouseLeave={() => {
                if (hoverPreviewEnabled && onHoverEffect) {
                  onHoverEffect(null);
                }
              }}
              onDragStart={(e) => {
                clearHover();
                e.dataTransfer.setData('application/x-redeffect-fx', payload);
                e.dataTransfer.effectAllowed = 'copy';
              }}
              onClick={() => {
                clearHover();
                onAddEffectToClip(ef.type, selectedClip?.id);
              }}
              className="p-2 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded cursor-pointer flex items-center justify-between gap-2 transition-colors group"
            >
              <div className="flex items-center gap-2 min-w-0">
                {getCatIcon(ef.category)}
                <div className="min-w-0">
                  <div className="text-[#F4F4F5] font-medium truncate">{ef.name}</div>
                  <div className="text-[10px] text-[#A1A1AA] truncate">{ef.description}</div>
                </div>
              </div>
              <span className="px-1.5 py-0.5 rounded bg-[#18181A] border border-[#3E3E44] group-hover:border-[#A1A1AA] text-[10px] text-[#D4D4D8] font-medium shrink-0 flex items-center gap-0.5">
                <Plus className="w-2.5 h-2.5" />
                {selectedClip ? 'Add' : 'Drag'}
              </span>
            </div>
          );
        })}

        {items.length === 0 && (
          <div className="text-center py-6 text-[#A1A1AA] text-[11px]">
            No matching effects found.
          </div>
        )}
      </div>

      {/* Motion Graphics Quick Templates */}
      <div className="border-t border-[#3E3E44] pt-2 space-y-1.5">
        <div className="flex items-center justify-between text-[10px] font-medium text-[#A1A1AA] uppercase tracking-wider">
          <span>Quick Motion Templates</span>
          <Wand2 className="w-3 h-3 text-[#D4D4D8]" />
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={() =>
              onApplyEffectPayload(JSON.stringify({ kind: 'template', value: 'cinematic-intro' }))
            }
            className="py-1.5 px-2 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded text-[11px] text-[#F4F4F5] text-left truncate"
          >
            + 3D Title Intro
          </button>
          <button
            type="button"
            onClick={() =>
              onApplyEffectPayload(JSON.stringify({ kind: 'template', value: 'lower-third' }))
            }
            className="py-1.5 px-2 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded text-[11px] text-[#F4F4F5] text-left truncate"
          >
            + Broadcast Lower 3rd
          </button>
        </div>
      </div>
    </div>
  );
};
