import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  MousePointer2,
  Scissors,
  Magnet,
  ZoomIn,
  ZoomOut,
  Merge,
  Copy,
  ClipboardPaste,
  Trash2,
  Type as TypeIcon,
  Volume2,
  VolumeX,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  SplitSquareHorizontal,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  X,
  Plus,
  Pencil,
  ArrowUp,
  ArrowDown,
  Maximize2,
  Minimize2,
  Diamond,
  GripVertical,
  Link2,
  Sparkles,
  Crosshair,
  Activity,
  ArrowLeftToLine,
} from 'lucide-react';
import { AnimationEasing } from '../types/effects';
import {
  Keyframe,
  MarkerColor,
  StudioProject,
  TimelineClip,
  TimelineMarker,
  TimelineTrack,
} from '../types/studio';
import {
  evaluateKeyframeProperty,
  getClipAnimationEvalTime,
  wouldCreateParentCycle,
} from '../services/videoCompositor';
import { ContextMenuTarget, TimelineContextMenu } from './TimelineContextMenu';
import { KeyframeGraphPanel } from './KeyframeGraphPanel';

const MARKER_COLOR_STYLES: Record<
  MarkerColor,
  {
    hex: string;
    bg: string;
    softBg: string;
    border: string;
    text: string;
    line: string;
    title: string;
  }
> = {
  rose: {
    hex: '#E11D48',
    bg: 'bg-rose-600',
    softBg: 'bg-rose-600/20',
    border: 'border-rose-400',
    text: 'text-rose-300',
    line: 'border-rose-500/40',
    title: 'Edit / Cut (Crimson)',
  },
  amber: {
    hex: '#F59E0B',
    bg: 'bg-amber-500',
    softBg: 'bg-amber-500/20',
    border: 'border-amber-300',
    text: 'text-amber-300',
    line: 'border-amber-400/40',
    title: 'Audio Beat (Amber)',
  },
  emerald: {
    hex: '#10B981',
    bg: 'bg-emerald-500',
    softBg: 'bg-emerald-500/20',
    border: 'border-emerald-300',
    text: 'text-emerald-300',
    line: 'border-emerald-400/40',
    title: 'Sync Cue (Emerald)',
  },
  sky: {
    hex: '#0EA5E9',
    bg: 'bg-sky-500',
    softBg: 'bg-sky-500/20',
    border: 'border-sky-300',
    text: 'text-sky-300',
    line: 'border-sky-400/40',
    title: 'VFX Note (Sky)',
  },
  violet: {
    hex: '#8B5CF6',
    bg: 'bg-violet-500',
    softBg: 'bg-violet-500/20',
    border: 'border-violet-300',
    text: 'text-violet-300',
    line: 'border-violet-400/40',
    title: 'Chapter / Beat (Violet)',
  },
};

const MARKER_COLOR_ORDER: MarkerColor[] = ['rose', 'amber', 'emerald', 'sky', 'violet'];

function formatMarkerTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const cs = Math.floor((seconds % 1) * 100);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(cs).padStart(
    2,
    '0'
  )}`;
}

interface TimelineEditorPanelProps {
  project: StudioProject;
  playheadTime: number;
  selectedClipId: string | null;
  selectedClipIds?: string[];
  selectedMarkerId: string | null;
  activeTool: 'select' | 'cut';
  hasClipboard: boolean;
  timelineHeight: number;
  renamingClipId?: string | null;
  onRequestRenameClip?: (clipId: string | null) => void;
  onSelectClip: (clipId: string | null, additive?: boolean) => void;
  onSelectMultipleClips?: (clipIds: string[], primaryId?: string | null) => void;
  onSelectMarker: (markerId: string | null) => void;
  onSetTool: (tool: 'select' | 'cut') => void;
  onSeek: (time: number) => void;
  onToggleSnap: () => void;
  onUpdateClip: (clipId: string, updater: (c: TimelineClip) => TimelineClip, commitHistory?: boolean) => void;
  onBatchUpdateClips?: (
    updates: Record<string, (c: TimelineClip) => TimelineClip>,
    commitHistory?: boolean
  ) => void;
  onSplitClip: (clipId: string, splitTime: number) => void;
  onMergeWithNext: (clipId: string) => void;
  onDeleteClip: (clipId: string) => void;
  onRippleDeleteClip?: (clipId: string) => void;
  onCutClip?: (clipId: string) => void;
  onCopyClip: (clipId: string) => void;
  onPasteClip: (atTime?: number) => void;
  onDuplicateClip?: (clipId: string) => void;
  onSetClipParent?: (clipId: string, parentId: string | undefined) => void;
  onDropAssetOnTrack: (assetId: string, trackId: string, startTime: number) => void;
  onDropFilesOnTrack: (files: FileList, trackId: string, startTime: number) => void;
  onDropEffectOnClip: (effectPayload: string, clipId: string) => void;
  onDropEffectOnTrack?: (effectPayload: string, trackId: string, startTime: number) => void;
  onAddTextClip: () => void;
  onAddNullClip?: () => void;
  onAddShapeClip?: () => void;
  onAddEffectLayer?: () => void;
  onAddTrack: (kind: TimelineTrack['kind']) => void;
  onRenameTrack: (trackId: string, name: string) => void;
  onDeleteTrack: (trackId: string) => void;
  onMoveTrack: (trackId: string, direction: 'up' | 'down') => void;
  onReorderTracks?: (fromIdx: number, toIdx: number) => void;
  onSetTrackColor?: (trackId: string, color: MarkerColor) => void;
  onToggleTrackCollapsed?: (trackId: string) => void;
  onToggleTrackProp: (trackId: string, prop: 'muted' | 'solo' | 'locked' | 'visible') => void;
  onChangeTimelineHeight: (nextHeight: number) => void;
  onAddMarker: (time: number, color?: MarkerColor, label?: string) => void;
  onUpdateMarker: (
    markerId: string,
    updater: (m: TimelineMarker) => TimelineMarker,
    commitHistory?: boolean
  ) => void;
  onDeleteMarker: (markerId: string) => void;
  onQuickAddEffect?: (clipId: string, effectType: string) => void;
  onQuickApplyPreset?: (clipId: string, presetId: string) => void;
  onDetachAudio?: (clipId: string) => void;
  onCreateCompoundClip?: () => void;
  onConvertTextToShape?: (clipId: string) => void;
  onOpenSpeedDuration?: (clipId: string) => void;
  onFocusEffectInProperties?: (clipId: string) => void;
}

export const TimelineEditorPanel: React.FC<TimelineEditorPanelProps> = ({
  project,
  playheadTime,
  selectedClipId,
  selectedClipIds = [],
  selectedMarkerId,
  activeTool,
  hasClipboard,
  timelineHeight,
  renamingClipId,
  onRequestRenameClip,
  onSelectClip,
  onSelectMultipleClips,
  onSelectMarker,
  onSetTool,
  onSeek,
  onToggleSnap,
  onUpdateClip,
  onBatchUpdateClips,
  onSplitClip,
  onMergeWithNext,
  onDeleteClip,
  onRippleDeleteClip,
  onCutClip,
  onCopyClip,
  onPasteClip,
  onDuplicateClip,
  onSetClipParent,
  onDropAssetOnTrack,
  onDropFilesOnTrack,
  onDropEffectOnClip,
  onDropEffectOnTrack,
  onAddTextClip,
  onAddNullClip,
  onAddShapeClip,
  onAddEffectLayer,
  onAddTrack,
  onRenameTrack,
  onDeleteTrack,
  onMoveTrack,
  onReorderTracks,
  onSetTrackColor,
  onToggleTrackCollapsed,
  onToggleTrackProp,
  onChangeTimelineHeight,
  onAddMarker,
  onUpdateMarker,
  onDeleteMarker,
  onQuickAddEffect,
  onQuickApplyPreset,
  onDetachAudio,
  onCreateCompoundClip,
  onConvertTextToShape,
  onOpenSpeedDuration,
  onFocusEffectInProperties,
}) => {
  const [pxPerSec, setPxPerSec] = useState(52);
  const [trackDensity, setTrackDensity] = useState<'compact' | 'normal' | 'tall'>('normal');
  const [activeMarkerColor, setActiveMarkerColor] = useState<MarkerColor>('rose');
  const [showMarkersBar, setShowMarkersBar] = useState(false);
  const [draggingMarkerId, setDraggingMarkerId] = useState<string | null>(null);
  const [editingTrackId, setEditingTrackId] = useState<string | null>(null);
  const [trackDraftName, setTrackDraftName] = useState('');
  const [clipDraftName, setClipDraftName] = useState('');
  const [selectedKfIds, setSelectedKfIds] = useState<string[]>([]);
  const [copiedKeyframes, setCopiedKeyframes] = useState<Keyframe[]>([]);
  const [dragOverClipId, setDragOverClipId] = useState<string | null>(null);
  const [contextMenuTarget, setContextMenuTarget] = useState<ContextMenuTarget | null>(null);
  const [showCurveEditor, setShowCurveEditor] = useState(false);

  // Pick Whip live SVG tether drag state
  const [pickWhipDrag, setPickWhipDrag] = useState<{
    sourceClipId: string;
    startX: number;
    startY: number;
    curX: number;
    curY: number;
    hoverParentClipId: string | null;
  } | null>(null);

  // Track vertical drag-to-reorder state
  const [trackReorderDrag, setTrackReorderDrag] = useState<{
    fromIdx: number;
    overIdx: number;
  } | null>(null);

  // Marquee Box Multi-Selection state
  const [marqueeBox, setMarqueeBox] = useState<{
    startX: number;
    startY: number;
    curX: number;
    curY: number;
  } | null>(null);

  const tracksAreaRef = useRef<HTMLDivElement>(null);
  const tracksContainerRef = useRef<HTMLDivElement>(null);
  const trackHeadersRef = useRef<HTMLDivElement>(null);
  const labelInputRef = useRef<HTMLInputElement>(null);
  const justFinishedMarqueeRef = useRef(false);

  const trackRowHeight = trackDensity === 'compact' ? 42 : trackDensity === 'tall' ? 74 : 56;
  const subRowHeight = 64;

  useEffect(() => {
    if (renamingClipId) {
      const target = project.clips.find((c) => c.id === renamingClipId);
      if (target) setClipDraftName(target.name);
    }
  }, [renamingClipId, project.clips]);

  const [dragState, setDragState] = useState<{
    clipId: string;
    mode: 'move' | 'trim-left' | 'trim-right';
    startX: number;
    origStart: number;
    origDuration: number;
    origOffset: number;
  } | null>(null);

  const markers = useMemo(
    () => [...(project.markers ?? [])].sort((a, b) => a.time - b.time),
    [project.markers]
  );
  const selectedMarker = markers.find((m) => m.id === selectedMarkerId) || null;

  const maxClipEnd = useMemo(
    () =>
      Math.max(
        20,
        ...project.clips.map((c) => c.startTime + c.duration + 6),
        ...markers.map((m) => m.time + 4)
      ),
    [project.clips, markers]
  );
  const timelineWidth = useMemo(
    () => Math.max(900, Math.round(maxClipEnd * pxPerSec)),
    [maxClipEnd, pxPerSec]
  );

  const snapTime = (
    t: number,
    ignoreClipId?: string,
    ignoreMarkerId?: string
  ): number => {
    const clamped = Math.max(0, t);
    if (!project.snapEnabled) return clamped;
    const snapThresholdSec = 10 / pxPerSec;
    const candidates = [0, playheadTime];
    for (const c of project.clips) {
      if (c.id === ignoreClipId) continue;
      candidates.push(c.startTime, c.startTime + c.duration);
    }
    for (const m of markers) {
      if (m.id === ignoreMarkerId) continue;
      candidates.push(m.time);
    }
    let best = clamped;
    let bestDist = snapThresholdSec;
    for (const cand of candidates) {
      const d = Math.abs(clamped - cand);
      if (d < bestDist) {
        bestDist = d;
        best = cand;
      }
    }
    return Math.round(best * 100) / 100;
  };

  const handleRulerMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const updateFromClientX = (clientX: number) => {
      const x = Math.max(0, clientX - rect.left);
      onSeek(Math.max(0, x / pxPerSec));
    };
    updateFromClientX(e.clientX);

    const onMove = (ev: MouseEvent) => updateFromClientX(ev.clientX);
    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  const handleRulerDoubleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const rawTime = Math.max(0, (e.clientX - rect.left) / pxPerSec);
    const clickTime = snapTime(rawTime);
    onAddMarker(clickTime, activeMarkerColor);
    onSeek(clickTime);
  };

  const startMarkerDrag = (e: React.MouseEvent, marker: TimelineMarker) => {
    e.stopPropagation();
    onSelectMarker(marker.id);
    onSelectClip(null);
    onSeek(marker.time);

    const startX = e.clientX;
    const origTime = marker.time;
    let latestTime = origTime;
    let moved = false;

    setDraggingMarkerId(marker.id);

    const onMove = (ev: MouseEvent) => {
      const dxSec = (ev.clientX - startX) / pxPerSec;
      if (Math.abs(ev.clientX - startX) > 2) moved = true;
      const raw = Math.max(0, origTime + dxSec);
      const nextTime = ev.shiftKey
        ? Math.round(raw * 100) / 100
        : snapTime(raw, undefined, marker.id);
      latestTime = nextTime;
      onUpdateMarker(marker.id, (m) => ({ ...m, time: nextTime }), false);
      onSeek(nextTime);
    };

    const onUp = () => {
      setDraggingMarkerId(null);
      if (moved && latestTime !== origTime) {
        onUpdateMarker(marker.id, (m) => ({ ...m, time: latestTime }), true);
      }
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  const jumpToAdjacentMarker = (direction: 'prev' | 'next') => {
    if (markers.length === 0) return;
    if (direction === 'prev') {
      const prev = [...markers]
        .reverse()
        .find((m) => m.time < playheadTime - 0.04);
      const target = prev || markers[markers.length - 1];
      onSeek(target.time);
      onSelectMarker(target.id);
    } else {
      const next = markers.find((m) => m.time > playheadTime + 0.04);
      const target = next || markers[0];
      onSeek(target.time);
      onSelectMarker(target.id);
    }
  };

  const getTrackRowOffsetTop = (trackIndex: number): number => {
    let y = 0;
    for (let i = 0; i < trackIndex && i < project.tracks.length; i++) {
      y += trackRowHeight;
      if (!project.tracks[i].collapsed && project.tracks[i].collapsed !== undefined) {
        y += subRowHeight;
      }
    }
    return y;
  };

  const findTrackIndexAtLocalY = (localY: number): number => {
    let y = 0;
    for (let i = 0; i < project.tracks.length; i++) {
      const h =
        trackRowHeight +
        (project.tracks[i].collapsed === false ? subRowHeight : 0);
      if (localY >= y && localY < y + h) return i;
      y += h;
    }
    return Math.max(0, Math.min(project.tracks.length - 1, project.tracks.length - 1));
  };

  const startClipDrag = (
    e: React.MouseEvent,
    clip: TimelineClip,
    mode: 'move' | 'trim-left' | 'trim-right'
  ) => {
    e.stopPropagation();

    // Right-click selects clip cleanly without starting a drag
    if (e.button === 2) {
      if (!selectedClipIds.includes(clip.id)) {
        onSelectClip(clip.id, false);
      }
      onSelectMarker(null);
      return;
    }
    if (e.button !== 0) return;

    const currentTrack = project.tracks.find((t) => t.id === clip.trackId);

    if (activeTool === 'cut' && mode === 'move') {
      if (clip.locked || currentTrack?.locked) return;
      const clipRect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const offsetSec = (e.clientX - clipRect.left) / pxPerSec;
      const splitAt = clip.startTime + offsetSec;
      onSplitClip(clip.id, splitAt);
      return;
    }

    // Immediate reliable 1-click selection (single, Ctrl-toggle, or Shift-range)
    if (e.shiftKey && selectedClipId && onSelectMultipleClips) {
      const ordered = project.tracks.flatMap((t) =>
        project.clips
          .filter((c) => c.trackId === t.id)
          .sort((a, b) => a.startTime - b.startTime)
      );
      const idxA = ordered.findIndex((c) => c.id === selectedClipId);
      const idxB = ordered.findIndex((c) => c.id === clip.id);
      if (idxA >= 0 && idxB >= 0) {
        const [lo, hi] = idxA <= idxB ? [idxA, idxB] : [idxB, idxA];
        const rangeIds = ordered.slice(lo, hi + 1).map((c) => c.id);
        onSelectMultipleClips(Array.from(new Set([...selectedClipIds, ...rangeIds])), clip.id);
      } else {
        onSelectClip(clip.id, true);
      }
    } else if (e.ctrlKey || e.metaKey) {
      onSelectClip(clip.id, true);
    } else if (!selectedClipIds.includes(clip.id) || selectedClipIds.length <= 1) {
      onSelectClip(clip.id, false);
    } else {
      // Clicking one of already-multi-selected clips keeps group active for multi-drag
      if (onSelectMultipleClips) {
        onSelectMultipleClips(selectedClipIds, clip.id);
      } else {
        onSelectClip(clip.id, false);
      }
    }
    onSelectMarker(null);

    if (clip.locked || currentTrack?.locked) return;

    const startX = e.clientX;
    const startY = e.clientY;
    const origStart = clip.startTime;
    const origDuration = clip.duration;
    const origOffset = clip.sourceOffset;
    const origTrackIndex = project.tracks.findIndex((t) => t.id === clip.trackId);
    const tracksRect = tracksContainerRef.current?.getBoundingClientRect();
    const startLocalY = tracksRect ? startY - tracksRect.top : 0;

    // Multi-clip initial positions if dragging multiple selected clips together
    const activeBatchIds =
      selectedClipIds.includes(clip.id) && selectedClipIds.length > 1
        ? selectedClipIds
        : [clip.id];
    const batchInitialStarts: Record<string, number> = {};
    for (const id of activeBatchIds) {
      const target = project.clips.find((c) => c.id === id);
      const tTrack = target ? project.tracks.find((t) => t.id === target.trackId) : null;
      if (target && !target.locked && !tTrack?.locked) {
        batchInitialStarts[id] = target.startTime;
      }
    }

    let hasCrossedThreshold = false;

    const onMove = (ev: MouseEvent) => {
      const dist = Math.hypot(ev.clientX - startX, ev.clientY - startY);
      if (!hasCrossedThreshold) {
        if (dist < 4) return;
        hasCrossedThreshold = true;
        setDragState({ clipId: clip.id, mode, startX, origStart, origDuration, origOffset });
      }

      const dxSec = (ev.clientX - startX) / pxPerSec;
      if (mode === 'move') {
        const nextStart = ev.shiftKey
          ? Math.max(0, Math.round((origStart + dxSec) * 100) / 100)
          : snapTime(origStart + dxSec, clip.id);
        const appliedDeltaSec = nextStart - origStart;

        let nextTrackId = clip.trackId;
        if (origTrackIndex >= 0 && activeBatchIds.length === 1) {
          const curLocalY = startLocalY + (ev.clientY - startY);
          const candidateIdx = findTrackIndexAtLocalY(curLocalY);
          const candidateTrack = project.tracks[candidateIdx];
          if (candidateTrack && !candidateTrack.locked) {
            const isAudioClip = clip.type === 'audio';
            const isAudioTrack = candidateTrack.kind === 'audio';
            if (isAudioClip === isAudioTrack) {
              nextTrackId = candidateTrack.id;
            }
          }
        }

        if (activeBatchIds.length > 1 && onBatchUpdateClips) {
          const updates: Record<string, (c: TimelineClip) => TimelineClip> = {};
          for (const [id, initS] of Object.entries(batchInitialStarts)) {
            updates[id] = (c) => ({
              ...c,
              startTime: Math.max(0, Math.round((initS + appliedDeltaSec) * 100) / 100),
            });
          }
          onBatchUpdateClips(updates, false);
        } else {
          onUpdateClip(
            clip.id,
            (c) => ({ ...c, startTime: Math.max(0, nextStart), trackId: nextTrackId }),
            false
          );
        }
      } else if (mode === 'trim-left') {
        const maxDelta = origDuration - 0.3;
        const delta = Math.max(-origStart, Math.min(maxDelta, dxSec));
        const snappedStart = snapTime(origStart + delta, clip.id);
        const finalDelta = snappedStart - origStart;
        if (origDuration - finalDelta >= 0.3 && origStart + finalDelta >= 0) {
          onUpdateClip(
            clip.id,
            (c) => ({
              ...c,
              startTime: origStart + finalDelta,
              duration: origDuration - finalDelta,
              sourceOffset: Math.max(0, origOffset + finalDelta),
            }),
            false
          );
        }
      } else if (mode === 'trim-right') {
        const rawEnd = origStart + Math.max(0.3, origDuration + dxSec);
        const snappedEnd = snapTime(rawEnd, clip.id);
        onUpdateClip(
          clip.id,
          (c) => ({ ...c, duration: Math.max(0.3, snappedEnd - origStart) }),
          false
        );
      }
    };

    const onUp = () => {
      if (hasCrossedThreshold) {
        onUpdateClip(clip.id, (c) => c, true);
      }
      setDragState(null);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  // Pick Whip Drag Handler (drag from Pick Whip icon to any clip or track parent)
  const startPickWhipDrag = (e: React.MouseEvent, sourceClip: TimelineClip) => {
    e.stopPropagation();
    e.preventDefault();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const startX = rect.left + rect.width * 0.5;
    const startY = rect.top + rect.height * 0.5;
    let hoveredParentId: string | null = null;

    setPickWhipDrag({
      sourceClipId: sourceClip.id,
      startX,
      startY,
      curX: e.clientX,
      curY: e.clientY,
      hoverParentClipId: null,
    });

    const findTargetAtPoint = (clientX: number, clientY: number): string | null => {
      const el = document.elementFromPoint(clientX, clientY) as HTMLElement | null;
      const targetEl = el?.closest('[data-pickwhip-target-clip]') as HTMLElement | null;
      const candidateId = targetEl?.getAttribute('data-pickwhip-target-clip') || null;
      if (!candidateId || candidateId === sourceClip.id) return null;
      if (wouldCreateParentCycle(sourceClip.id, candidateId, project.clips)) return null;
      return candidateId;
    };

    const onMove = (ev: MouseEvent) => {
      hoveredParentId = findTargetAtPoint(ev.clientX, ev.clientY);
      setPickWhipDrag({
        sourceClipId: sourceClip.id,
        startX,
        startY,
        curX: ev.clientX,
        curY: ev.clientY,
        hoverParentClipId: hoveredParentId,
      });
    };

    const onUp = (ev: MouseEvent) => {
      const finalTarget = findTargetAtPoint(ev.clientX, ev.clientY) || hoveredParentId;
      if (finalTarget && onSetClipParent) {
        onSetClipParent(sourceClip.id, finalTarget);
      }
      setPickWhipDrag(null);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  // Vertical Track Drag-to-Reorder Handler (stacking order ONLY, never changes timing)
  const startTrackReorderDrag = (e: React.MouseEvent, fromIdx: number) => {
    e.stopPropagation();
    e.preventDefault();
    const startY = e.clientY;
    let overIdx = fromIdx;
    setTrackReorderDrag({ fromIdx, overIdx });

    const onMove = (ev: MouseEvent) => {
      const dy = ev.clientY - startY;
      const deltaRows = Math.round(dy / trackRowHeight);
      overIdx = Math.max(0, Math.min(project.tracks.length - 1, fromIdx + deltaRows));
      setTrackReorderDrag({ fromIdx, overIdx });
    };

    const onUp = () => {
      if (overIdx !== fromIdx && onReorderTracks) {
        onReorderTracks(fromIdx, overIdx);
      }
      setTrackReorderDrag(null);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  // Marquee Box Selection on empty lane background
  const startMarqueeSelection = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.button !== 0 || activeTool !== 'select') return;
    if (e.target !== e.currentTarget && !(e.target as HTMLElement).hasAttribute('data-track-lane-bg')) {
      return;
    }
    const container = tracksContainerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const startX = e.clientX - rect.left;
    const startY = e.clientY - rect.top;
    let moved = false;

    const onMove = (ev: MouseEvent) => {
      const curX = ev.clientX - rect.left;
      const curY = ev.clientY - rect.top;
      if (!moved && Math.hypot(curX - startX, curY - startY) >= 5) {
        moved = true;
      }
      if (!moved) return;

      const minX = Math.min(startX, curX);
      const maxX = Math.max(startX, curX);
      const minY = Math.min(startY, curY);
      const maxY = Math.max(startY, curY);
      setMarqueeBox({ startX, startY, curX, curY });

      const hits: string[] = [];
      project.tracks.forEach((tr, ti) => {
        const rowTop = getTrackRowOffsetTop(ti);
        const rowBottom = rowTop + trackRowHeight;
        if (rowBottom < minY || rowTop > maxY) return;
        project.clips
          .filter((c) => c.trackId === tr.id)
          .forEach((c) => {
            const clLeft = c.startTime * pxPerSec;
            const clRight = clLeft + Math.max(24, c.duration * pxPerSec);
            if (clRight >= minX && clLeft <= maxX) {
              hits.push(c.id);
            }
          });
      });

      if (onSelectMultipleClips) {
        onSelectMultipleClips(hits, hits[0] || null);
      } else if (hits[0]) {
        onSelectClip(hits[0], false);
      }
    };

    const onUp = () => {
      if (moved) {
        justFinishedMarqueeRef.current = true;
        setTimeout(() => {
          justFinishedMarqueeRef.current = false;
        }, 40);
      }
      setMarqueeBox(null);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  const handleTrackDrop = (e: React.DragEvent<HTMLDivElement>, track: TimelineTrack) => {
    e.preventDefault();
    setDragOverClipId(null);
    if (track.locked) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const dropTime = snapTime(Math.max(0, (e.clientX - rect.left) / pxPerSec));

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onDropFilesOnTrack(e.dataTransfer.files, track.id, dropTime);
      return;
    }

    const fxPayload = e.dataTransfer.getData('application/x-redeffect-fx');
    if (fxPayload) {
      onDropEffectOnTrack?.(fxPayload, track.id, dropTime);
      return;
    }

    const assetId = e.dataTransfer.getData('application/x-redeffect-asset');
    if (assetId) {
      onDropAssetOnTrack(assetId, track.id, dropTime);
    }
  };

  const getClipColor = (clip: TimelineClip) => {
    if (clip.disabled) {
      return 'bg-[#18181A] border-[#3E3E44] text-[#6E7280] opacity-60';
    }
    if (clip.labelColor) {
      switch (clip.labelColor) {
        case 'rose':
          return 'bg-rose-950/85 border-rose-500/75 text-[#F4F4F5]';
        case 'amber':
          return 'bg-amber-950/85 border-amber-500/70 text-amber-100';
        case 'emerald':
          return 'bg-emerald-950/85 border-emerald-500/70 text-emerald-100';
        case 'sky':
          return 'bg-sky-950/85 border-sky-500/70 text-sky-100';
        case 'violet':
          return 'bg-[#2A2247] border-[#A1A1AA] text-[#F4F4F5]';
      }
    }
    switch (clip.type) {
      case 'text':
        return 'bg-amber-950/75 border-amber-500/55 text-amber-100';
      case 'image':
        return 'bg-sky-950/75 border-sky-500/55 text-sky-100';
      case 'audio':
        return 'bg-emerald-950/75 border-emerald-500/55 text-emerald-100';
      case 'model3d':
        return 'bg-indigo-950/80 border-indigo-400/55 text-indigo-100';
      case 'shape':
        return 'bg-purple-950/80 border-purple-500/55 text-purple-100';
      case 'fx': {
        const cat = clip.fxMeta?.category;
        if (cat === 'shake') return 'bg-[#2B1F42] border-[#A1A1AA] text-[#F4F4F5]';
        if (cat === 'glitch') return 'bg-cyan-950/85 border-cyan-400/75 text-cyan-100';
        if (cat === 'cc') return 'bg-orange-950/85 border-orange-400/75 text-orange-100';
        if (cat === 'blur') return 'bg-blue-950/85 border-blue-400/75 text-blue-100';
        if (cat === 'rgb') return 'bg-pink-950/85 border-pink-400/75 text-pink-100';
        if (cat === 'distortion') return 'bg-purple-950/85 border-purple-400/75 text-purple-100';
        if (cat === 'cinematic') return 'bg-amber-950/85 border-amber-400/75 text-amber-100';
        return 'bg-[#2A2247] border-[#A1A1AA]/80 text-[#F4F4F5]';
      }
      case 'null':
        return 'bg-[#292242] border-[#A1A1AA] border-dashed text-[#F4F4F5]';
      default:
        return 'bg-[#252B3D] border-indigo-400/55 text-[#F4F4F5]';
    }
  };

  const commitTrackRename = (trackId: string) => {
    const trimmed = trackDraftName.trim();
    if (trimmed) {
      onRenameTrack(trackId, trimmed);
    }
    setEditingTrackId(null);
  };

  const commitClipRename = (clipId: string) => {
    const trimmed = clipDraftName.trim();
    if (trimmed) {
      onUpdateClip(clipId, (c) => ({ ...c, name: trimmed }));
    }
    onRequestRenameClip?.(null);
  };

  const rulerStep = pxPerSec < 35 ? 5 : pxPerSec < 75 ? 2 : 1;
  const ticks = useMemo(() => {
    const arr: number[] = [];
    for (let t = 0; t <= maxClipEnd; t += rulerStep) {
      arr.push(t);
    }
    return arr;
  }, [maxClipEnd, rulerStep]);

  const selectedClip = project.clips.find((c) => c.id === selectedClipId) || null;

  const addKeyframeAtPlayhead = () => {
    if (!selectedClip) return;
    const localTime = Math.max(
      0,
      Math.min(selectedClip.duration, Math.round((playheadTime - selectedClip.startTime) * 100) / 100)
    );
    const evalTime = getClipAnimationEvalTime(selectedClip, localTime);
    const entries: Array<{ property: Keyframe['property']; value: number }> = [
      {
        property: 'x',
        value: evaluateKeyframeProperty(selectedClip.keyframes, 'x', evalTime, selectedClip.transform.x),
      },
      {
        property: 'y',
        value: evaluateKeyframeProperty(selectedClip.keyframes, 'y', evalTime, selectedClip.transform.y),
      },
      {
        property: 'scale',
        value: evaluateKeyframeProperty(selectedClip.keyframes, 'scale', evalTime, selectedClip.transform.scale),
      },
      {
        property: 'rotation',
        value: evaluateKeyframeProperty(selectedClip.keyframes, 'rotation', evalTime, selectedClip.transform.rotation),
      },
      {
        property: 'opacity',
        value: evaluateKeyframeProperty(selectedClip.keyframes, 'opacity', evalTime, selectedClip.transform.opacity),
      },
    ];
    onUpdateClip(selectedClip.id, (c) => {
      let next = [...c.keyframes];
      for (const item of entries) {
        next = next.filter(
          (k) => !(k.property === item.property && Math.abs(k.time - localTime) < 0.08)
        );
        next.push({
          id: `kf-${Date.now()}-${item.property}-${Math.random().toString(36).slice(2, 5)}`,
          time: localTime,
          property: item.property,
          value: item.value,
          easing: 'easeInOut',
          bezier: [0.42, 0, 0.58, 1],
        });
      }
      next.sort((a, b) => a.time - b.time);
      return { ...c, keyframes: next };
    });
  };

  const deleteSelectedOrPlayheadKeyframes = () => {
    if (!selectedClip) return;
    const localTime = playheadTime - selectedClip.startTime;
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes:
        selectedKfIds.length > 0
          ? c.keyframes.filter((k) => !selectedKfIds.includes(k.id))
          : c.keyframes.filter((k) => Math.abs(k.time - localTime) >= 0.12),
    }));
    setSelectedKfIds([]);
  };

  const jumpClipKeyframe = (dir: 'prev' | 'next') => {
    if (!selectedClip || selectedClip.keyframes.length === 0) return;
    const sorted = [...selectedClip.keyframes].sort((a, b) => a.time - b.time);
    const localTime = playheadTime - selectedClip.startTime;
    const target =
      dir === 'prev'
        ? [...sorted].reverse().find((k) => k.time < localTime - 0.04) || sorted[sorted.length - 1]
        : sorted.find((k) => k.time > localTime + 0.04) || sorted[0];
    setSelectedKfIds([target.id]);
    onSeek(selectedClip.startTime + target.time);
  };

  const duplicateSelectedKeyframes = () => {
    if (!selectedClip) return;
    const pool =
      selectedKfIds.length > 0
        ? selectedClip.keyframes.filter((k) => selectedKfIds.includes(k.id))
        : selectedClip.keyframes.filter(
            (k) => Math.abs(k.time - (playheadTime - selectedClip.startTime)) < 0.12
          );
    if (pool.length === 0) return;
    const clones = pool.map((k) => ({
      ...structuredClone(k),
      id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      time: Math.min(selectedClip.duration, Math.round((k.time + 0.5) * 100) / 100),
    }));
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes: [...c.keyframes, ...clones],
    }));
    setSelectedKfIds(clones.map((k) => k.id));
  };

  const applyQuickEasing = (easing: AnimationEasing) => {
    if (!selectedClip || selectedClip.keyframes.length === 0) return;
    const bezier: [number, number, number, number] =
      easing === 'easeIn'
        ? [0.42, 0, 1, 1]
        : easing === 'easeOut'
        ? [0, 0, 0.58, 1]
        : easing === 'easeInOut'
        ? [0.42, 0, 0.58, 1]
        : [0.25, 0.1, 0.25, 1];
    const localTime = playheadTime - selectedClip.startTime;
    const nearKfs = selectedClip.keyframes.filter((k) => Math.abs(k.time - localTime) < 0.12);
    const targetIds = new Set(
      selectedKfIds.length > 0
        ? selectedKfIds
        : nearKfs.length > 0
        ? nearKfs.map((k) => k.id)
        : selectedClip.keyframes.map((k) => k.id)
    );
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes: c.keyframes.map((k) => (targetIds.has(k.id) ? { ...k, easing, bezier } : k)),
    }));
  };

  const addSinglePropKeyframeAtPlayhead = (
    clip: TimelineClip,
    prop: Keyframe['property']
  ) => {
    const localTime = Math.max(
      0,
      Math.min(clip.duration, Math.round((playheadTime - clip.startTime) * 100) / 100)
    );
    const evalTime = getClipAnimationEvalTime(clip, localTime);
    const baseVal =
      prop === 'x'
        ? clip.transform.x
        : prop === 'y'
        ? clip.transform.y
        : prop === 'scale'
        ? clip.transform.scale
        : prop === 'rotation'
        ? clip.transform.rotation
        : clip.transform.opacity;
    const val = evaluateKeyframeProperty(clip.keyframes, prop, evalTime, baseVal);
    onUpdateClip(clip.id, (c) => {
      const next = c.keyframes.filter(
        (k) => !(k.property === prop && Math.abs(k.time - localTime) < 0.08)
      );
      next.push({
        id: `kf-${Date.now()}-${prop}-${Math.random().toString(36).slice(2, 5)}`,
        time: localTime,
        property: prop,
        value: val,
        easing: 'easeInOut',
        bezier: [0.42, 0, 0.58, 1],
      });
      next.sort((a, b) => a.time - b.time);
      return { ...c, keyframes: next };
    });
  };

  const startKeyframeDrag = (e: React.MouseEvent, clip: TimelineClip, kf: Keyframe) => {
    e.stopPropagation();
    onSelectClip(clip.id);
    const additive = e.shiftKey || e.ctrlKey || e.metaKey;
    const nextSel = additive
      ? selectedKfIds.includes(kf.id)
        ? selectedKfIds
        : [...selectedKfIds, kf.id]
      : [kf.id];
    setSelectedKfIds(nextSel);

    const startX = e.clientX;
    const origTimes: Record<string, number> = {};
    clip.keyframes.forEach((item) => {
      if (nextSel.includes(item.id)) origTimes[item.id] = item.time;
    });
    let moved = false;
    const onMove = (ev: MouseEvent) => {
      const dxSec = (ev.clientX - startX) / pxPerSec;
      if (Math.abs(ev.clientX - startX) > 2) moved = true;
      onUpdateClip(
        clip.id,
        (c) => ({
          ...c,
          keyframes: c.keyframes.map((item) =>
            origTimes[item.id] !== undefined
              ? {
                  ...item,
                  time: Math.max(
                    0,
                    Math.min(c.duration, Math.round((origTimes[item.id] + dxSec) * 100) / 100)
                  ),
                }
              : item
          ),
        }),
        false
      );
    };
    const onUp = () => {
      if (moved) {
        onUpdateClip(clip.id, (c) => c, true);
      }
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  return (
    <div
      data-tutorial-target="timeline-panel"
      className="flex flex-col h-full bg-[#18181A] text-[#F4F4F5] text-xs select-none"
    >
      {/* Timeline Toolbar */}
      <div className="h-9 px-2.5 bg-[#222225] border-b border-[#3E3E44] flex items-center justify-between gap-2 shrink-0 overflow-x-auto">
        <div data-tutorial-target="timeline-edit-tools" className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => onSetTool('select')}
            title="Selection Tool (V)"
            className={`px-2 py-1 rounded flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 ${
              activeTool === 'select'
                ? 'bg-[#52525B] text-white font-medium'
                : 'text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
            }`}
          >
            <MousePointer2 className="w-3.5 h-3.5" />
            Select
          </button>
          <button
            type="button"
            onClick={() => onSetTool('cut')}
            title="Razor / Cut Tool (C)"
            className={`px-2 py-1 rounded flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 ${
              activeTool === 'cut'
                ? 'bg-[#52525B] text-white font-medium'
                : 'text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
            }`}
          >
            <Scissors className="w-3.5 h-3.5" />
            Razor
          </button>

          <div className="w-px h-4 bg-[#3E3E44] mx-1 shrink-0" />

          <button
            type="button"
            disabled={!selectedClipId}
            onClick={() => selectedClipId && onSplitClip(selectedClipId, playheadTime)}
            title="Split Selected Clip at Playhead"
            className="px-2 py-1 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <SplitSquareHorizontal className="w-3.5 h-3.5" />
            Split
          </button>
          <button
            type="button"
            disabled={!selectedClipId}
            onClick={() => selectedClipId && onMergeWithNext(selectedClipId)}
            title="Merge Selected Clip with Next Clip on Track"
            className="px-2 py-1 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <Merge className="w-3.5 h-3.5" />
            Merge
          </button>
          <button
            type="button"
            disabled={!selectedClipId}
            onClick={() => selectedClipId && onCopyClip(selectedClipId)}
            title="Copy Clip (Ctrl+C)"
            className="p-1.5 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 shrink-0"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            disabled={!hasClipboard}
            onClick={() => onPasteClip()}
            title="Paste Clip at Playhead (Ctrl+V)"
            className="p-1.5 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 shrink-0"
          >
            <ClipboardPaste className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            disabled={!selectedClipId && !selectedMarkerId}
            onClick={() => {
              if (selectedClipId) onDeleteClip(selectedClipId);
              else if (selectedMarkerId) onDeleteMarker(selectedMarkerId);
            }}
            title="Delete Selected Clip or Marker (Delete)"
            className="p-1.5 rounded text-[#A1A1AA] hover:text-rose-400 hover:bg-[#2C2C30] disabled:opacity-35 shrink-0"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          {onRippleDeleteClip && (
            <button
              type="button"
              disabled={!selectedClipId}
              onClick={() => selectedClipId && onRippleDeleteClip(selectedClipId)}
              title="Ripple Delete Selected Clip (Closes gap on track)"
              className="px-1.5 py-1 rounded text-[#A1A1AA] hover:text-rose-400 hover:bg-[#2C2C30] disabled:opacity-35 flex items-center gap-1 whitespace-nowrap shrink-0"
            >
              <ArrowLeftToLine className="w-3.5 h-3.5" />
              Ripple
            </button>
          )}

          <div className="w-px h-4 bg-[#3E3E44] mx-1 shrink-0" />

          {/* Track & Layer Creation */}
          <button
            type="button"
            onClick={() => onAddTrack('video')}
            title="Add New Video Track"
            className="px-2 py-1 rounded bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <Plus className="w-3 h-3 text-indigo-400" />
            Video
          </button>
          <button
            type="button"
            onClick={() => onAddTrack('audio')}
            title="Add New Audio Track"
            className="px-2 py-1 rounded bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <Plus className="w-3 h-3 text-emerald-400" />
            Audio
          </button>
          <button
            type="button"
            onClick={() => onAddTrack('image')}
            title="Add Image Overlay Layer Track"
            className="px-2 py-1 rounded bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <Plus className="w-3 h-3 text-sky-400" />
            Image
          </button>
          <button
            type="button"
            onClick={onAddTextClip}
            title="Add Text / Subtitle Clip at Playhead"
            className="px-2 py-1 rounded bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <TypeIcon className="w-3 h-3 text-amber-400" />
            Text
          </button>
          {onAddShapeClip && (
            <button
              type="button"
              onClick={onAddShapeClip}
              title="Add Vector Shape Layer at Playhead"
              className="px-2 py-1 rounded bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap shrink-0"
            >
              <Plus className="w-3 h-3 text-purple-400" />
              Shape
            </button>
          )}
          {onAddNullClip && (
            <button
              type="button"
              onClick={onAddNullClip}
              title="Add Null Object Controller at Playhead"
              className="px-2 py-1 rounded bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap shrink-0"
            >
              <Crosshair className="w-3 h-3 text-[#D4D4D8]" />
              Null
            </button>
          )}
          {onAddEffectLayer && (
            <button
              type="button"
              onClick={onAddEffectLayer}
              title="Add Adjustment / Effect Layer above selected track"
              className="px-2 py-1 rounded bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap shrink-0"
            >
              <Sparkles className="w-3 h-3 text-[#D4D4D8]" />
              FX Layer
            </button>
          )}

          <div className="w-px h-4 bg-[#3E3E44] mx-1 shrink-0" />

          {/* Timeline Keyframe Quick Controls */}
          <div className="flex items-center gap-0.5 px-1 py-0.5 bg-[#18181A] rounded border border-[#3E3E44] shrink-0">
            <button
              type="button"
              disabled={!selectedClip}
              onClick={addKeyframeAtPlayhead}
              title="Add Transform Keyframes at Playhead"
              className="px-1.5 py-0.5 rounded bg-[#2C2C30] hover:bg-[#52525B] disabled:opacity-35 text-[#F4F4F5] flex items-center gap-1 text-[10px]"
            >
              <Diamond className="w-2.5 h-2.5 fill-current text-amber-400" />
              +KF
            </button>
            <button
              type="button"
              disabled={!selectedClip || selectedClip.keyframes.length === 0}
              onClick={deleteSelectedOrPlayheadKeyframes}
              title="Delete Selected / Playhead Keyframes"
              className="px-1 py-0.5 rounded text-[#A1A1AA] hover:text-rose-400 disabled:opacity-35 text-[10px]"
            >
              Del
            </button>
            <button
              type="button"
              disabled={!selectedClip || selectedClip.keyframes.length === 0}
              onClick={() => jumpClipKeyframe('prev')}
              title="Previous Keyframe"
              className="p-0.5 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35"
            >
              <ChevronLeft className="w-3 h-3" />
            </button>
            <button
              type="button"
              disabled={!selectedClip || selectedClip.keyframes.length === 0}
              onClick={() => jumpClipKeyframe('next')}
              title="Next Keyframe"
              className="p-0.5 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35"
            >
              <ChevronRight className="w-3 h-3" />
            </button>
            <button
              type="button"
              disabled={!selectedClip || selectedClip.keyframes.length === 0}
              onClick={duplicateSelectedKeyframes}
              title="Duplicate Keyframes (+0.5s)"
              className="px-1 py-0.5 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 text-[10px]"
            >
              Dup
            </button>
            <button
              type="button"
              disabled={!selectedClip || selectedClip.keyframes.length === 0}
              onClick={() =>
                selectedClip &&
                setCopiedKeyframes(
                  structuredClone(
                    selectedKfIds.length > 0
                      ? selectedClip.keyframes.filter((k) => selectedKfIds.includes(k.id))
                      : selectedClip.keyframes
                  )
                )
              }
              title="Copy Keyframes"
              className="px-1 py-0.5 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 text-[10px]"
            >
              CpKF
            </button>
            <button
              type="button"
              disabled={!selectedClip || copiedKeyframes.length === 0}
              onClick={() =>
                selectedClip &&
                onUpdateClip(selectedClip.id, (c) => ({
                  ...c,
                  keyframes: [
                    ...c.keyframes,
                    ...copiedKeyframes.map((k) => ({
                      ...structuredClone(k),
                      id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                    })),
                  ],
                }))
              }
              title="Paste Keyframes"
              className="px-1 py-0.5 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 text-[10px]"
            >
              PsKF
            </button>

            <span className="w-px h-3 bg-[#3E3E44] mx-0.5" />

            {(
              [
                { id: 'linear', label: 'Lin', title: 'Linear Easing' },
                { id: 'easeIn', label: 'In', title: 'Ease In' },
                { id: 'easeOut', label: 'Out', title: 'Ease Out' },
                { id: 'easeInOut', label: 'InOut', title: 'Ease In Out' },
              ] as const
            ).map((es) => (
              <button
                key={es.id}
                type="button"
                disabled={!selectedClip || selectedClip.keyframes.length === 0}
                onClick={() => applyQuickEasing(es.id)}
                title={es.title}
                className="px-1 py-0.5 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 text-[9px] font-mono-tabular whitespace-nowrap"
              >
                {es.label}
              </button>
            ))}

            <button
              type="button"
              onClick={() => setShowCurveEditor((v) => !v)}
              title="Toggle Inline Keyframe Curve / Graph Editor"
              className={`ml-0.5 px-1.5 py-0.5 rounded flex items-center gap-1 text-[10px] whitespace-nowrap transition-colors ${
                showCurveEditor
                  ? 'bg-[#52525B] text-white'
                  : 'text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
              }`}
            >
              <Activity className="w-3 h-3" />
              Curve
            </button>
          </div>

          <div className="w-px h-4 bg-[#3E3E44] mx-1 shrink-0" />

          {/* Timeline Marker Controls */}
          <div className="flex items-center gap-1 shrink-0">
            <div className="flex items-center gap-1 px-1 py-0.5 bg-[#18181A] rounded border border-[#3E3E44]">
              {MARKER_COLOR_ORDER.map((col) => {
                const st = MARKER_COLOR_STYLES[col];
                const isActive = activeMarkerColor === col;
                return (
                  <button
                    key={col}
                    type="button"
                    onClick={() => setActiveMarkerColor(col)}
                    title={st.title}
                    className={`w-2.5 h-2.5 rounded-xs transition-transform ${st.bg} ${
                      isActive ? 'ring-1 ring-white scale-110' : 'opacity-55 hover:opacity-100'
                    }`}
                  />
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => onAddMarker(playheadTime, activeMarkerColor)}
              title="Add Colored Timeline Marker at Playhead (M) · Or double-click ruler"
              className="px-2 py-1 rounded bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] border border-[#3E3E44] flex items-center gap-1 whitespace-nowrap shrink-0"
            >
              <Bookmark
                className="w-3.5 h-3.5"
                style={{
                  color: MARKER_COLOR_STYLES[activeMarkerColor].hex,
                  fill: MARKER_COLOR_STYLES[activeMarkerColor].hex,
                }}
              />
              Marker
            </button>

            <button
              type="button"
              disabled={markers.length === 0}
              onClick={() => jumpToAdjacentMarker('prev')}
              title="Jump to Previous Marker"
              className="p-1 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 shrink-0"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              disabled={markers.length === 0}
              onClick={() => jumpToAdjacentMarker('next')}
              title="Jump to Next Marker"
              className="p-1 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-35 shrink-0"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => setShowMarkersBar((v) => !v)}
              title="Toggle Markers Bookmark Strip & Editor"
              className={`px-2 py-1 rounded border flex items-center gap-1 whitespace-nowrap shrink-0 transition-colors ${
                showMarkersBar || selectedMarker
                  ? 'border-[#A1A1AA] bg-[#71717A]/15 text-[#F4F4F5]'
                  : 'border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
              }`}
            >
              <span className="font-mono-tabular text-[11px]">
                Markers · {markers.length}
              </span>
            </button>
          </div>
        </div>

        {/* Layout Density, Dock Height, Snapping & Zoom */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center bg-[#18181A] rounded border border-[#3E3E44] p-0.5">
            {(['compact', 'normal', 'tall'] as const).map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setTrackDensity(d)}
                title={`Track Height: ${d}`}
                className={`px-1.5 py-0.5 rounded text-[10px] font-mono-tabular uppercase ${
                  trackDensity === d ? 'bg-[#52525B] text-white' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                {d === 'compact' ? 'S' : d === 'normal' ? 'M' : 'L'}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => onChangeTimelineHeight(timelineHeight >= 380 ? 295 : 420)}
            title={timelineHeight >= 380 ? 'Restore Timeline Height' : 'Expand Timeline Height'}
            className="p-1 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]"
          >
            {timelineHeight >= 380 ? (
              <Minimize2 className="w-3.5 h-3.5" />
            ) : (
              <Maximize2 className="w-3.5 h-3.5" />
            )}
          </button>

          <button
            type="button"
            onClick={onToggleSnap}
            title="Toggle Magnetic Snapping (Clips & Markers)"
            className={`px-2 py-1 rounded border flex items-center gap-1 whitespace-nowrap shrink-0 transition-colors ${
              project.snapEnabled
                ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#E4E4E7]'
                : 'border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <Magnet className="w-3.5 h-3.5" />
            Snap
          </button>

          <div data-tutorial-target="timeline-zoom" className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() => setPxPerSec((z) => Math.max(16, z - 12))}
              title="Zoom Out Timeline"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <input
              type="range"
              min={16}
              max={160}
              value={pxPerSec}
              onChange={(e) => setPxPerSec(Number(e.target.value))}
              className="w-20 cursor-pointer"
            />
            <button
              type="button"
              onClick={() => setPxPerSec((z) => Math.min(160, z + 12))}
              title="Zoom In Timeline"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Timeline Marker Strip & Selected Marker Inspector */}
      {(showMarkersBar || selectedMarker) && (
        <div className="px-2.5 py-1.5 bg-[#222225] border-b border-[#3E3E44] flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-1.5 overflow-x-auto max-w-full py-0.5">
            {markers.length === 0 ? (
              <span className="text-[11px] text-[#A1A1AA]">
                No markers placed yet — press M or double-click the time ruler to bookmark an edit or beat.
              </span>
            ) : (
              markers.map((m) => {
                const st = MARKER_COLOR_STYLES[m.color];
                const isSel = m.id === selectedMarkerId;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      onSelectMarker(m.id);
                      onSelectClip(null);
                      onSeek(m.time);
                    }}
                    title={m.notes ? `${m.label} — ${m.notes}` : m.label}
                    className={`px-2 py-0.5 rounded border flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors ${
                      isSel
                        ? `${st.softBg} ${st.border} text-[#F4F4F5]`
                        : 'bg-[#2C2C30] border-[#3E3E44] text-[#F4F4F5] hover:border-[#A1A1AA]/60'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-xs shrink-0 ${st.bg}`} />
                    <span className="font-mono-tabular text-[10px] text-[#A1A1AA]">
                      {formatMarkerTime(m.time)}
                    </span>
                    <span className="text-[11px] font-medium truncate max-w-[120px]">
                      {m.label}
                    </span>
                  </button>
                );
              })
            )}
          </div>

          {selectedMarker && (
            <div className="flex items-center gap-1.5 shrink-0 ml-auto">
              <div className="flex items-center gap-1 px-1.5 py-1 bg-[#18181A] rounded border border-[#3E3E44]">
                {MARKER_COLOR_ORDER.map((col) => {
                  const st = MARKER_COLOR_STYLES[col];
                  const active = selectedMarker.color === col;
                  return (
                    <button
                      key={col}
                      type="button"
                      onClick={() =>
                        onUpdateMarker(selectedMarker.id, (m) => ({ ...m, color: col }))
                      }
                      title={st.title}
                      className={`w-2.5 h-2.5 rounded-xs ${st.bg} ${
                        active ? 'ring-1 ring-white scale-110' : 'opacity-50 hover:opacity-100'
                      }`}
                    />
                  );
                })}
              </div>

              <input
                ref={labelInputRef}
                type="text"
                value={selectedMarker.label}
                onChange={(e) =>
                  onUpdateMarker(
                    selectedMarker.id,
                    (m) => ({ ...m, label: e.target.value }),
                    false
                  )
                }
                placeholder="Marker label..."
                className="w-28 px-2 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
              />

              <input
                type="text"
                value={selectedMarker.notes || ''}
                onChange={(e) =>
                  onUpdateMarker(
                    selectedMarker.id,
                    (m) => ({ ...m, notes: e.target.value }),
                    false
                  )
                }
                placeholder="Beat / edit note..."
                className="w-36 px-2 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#A1A1AA] focus:outline-none focus:border-[#A1A1AA]"
              />

              <label className="flex items-center gap-1 text-[10px] text-[#A1A1AA] font-mono-tabular">
                <span>t:</span>
                <input
                  type="number"
                  min={0}
                  step={0.1}
                  value={selectedMarker.time}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value) || 0);
                    onUpdateMarker(selectedMarker.id, (m) => ({
                      ...m,
                      time: Math.round(val * 100) / 100,
                    }));
                    onSeek(val);
                  }}
                  className="w-14 px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                />
              </label>

              <button
                type="button"
                onClick={() => onDeleteMarker(selectedMarker.id)}
                title="Delete Marker"
                className="p-1 rounded text-[#A1A1AA] hover:text-rose-400 hover:bg-[#2C2C30]"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => {
                  onSelectMarker(null);
                  setShowMarkersBar(false);
                }}
                title="Close Marker Inspector"
                className="p-1 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tracks + Parent & Link + Ruler Area */}
      <div
        data-tutorial-target="timeline-tracks"
        className="flex-1 min-h-0 flex overflow-hidden"
      >
        {/* After Effects-Style Layer Stack + Parent & Link Columns */}
        <div className="w-[300px] shrink-0 bg-[#222225] border-r border-[#3E3E44] flex flex-col">
          <div className="h-7 border-b border-[#3E3E44] flex items-center text-[10px] font-mono-tabular text-[#A1A1AA] shrink-0">
            <div className="flex-1 px-2 flex items-center justify-between truncate">
              <span>LAYERS ({project.tracks.length})</span>
              {markers.length > 0 && (
                <span className="text-[#A1A1AA]">{markers.length} MK</span>
              )}
            </div>
            <div className="w-[118px] px-2 border-l border-[#3E3E44] text-[#A1A1AA] truncate shrink-0">
              PARENT &amp; LINK
            </div>
          </div>

          <div ref={trackHeadersRef} className="flex-1 overflow-y-hidden">
            {project.tracks.map((track, idx) => {
              const trackClips = project.clips
                .filter((c) => c.trackId === track.id)
                .sort((a, b) => a.startTime - b.startTime);
              const primaryRowClip =
                trackClips.find((c) => c.id === selectedClipId) || trackClips[0] || null;
              const trackColorHex = MARKER_COLOR_STYLES[track.color || 'sky'].hex;
              const isExpanded = track.collapsed === false;
              const isReorderTarget =
                trackReorderDrag &&
                trackReorderDrag.overIdx === idx &&
                trackReorderDrag.fromIdx !== idx;
              const isPickWhipTarget =
                pickWhipDrag &&
                primaryRowClip &&
                pickWhipDrag.hoverParentClipId === primaryRowClip.id;

              return (
                <React.Fragment key={track.id}>
                  <div
                    data-pickwhip-target-clip={primaryRowClip?.id || undefined}
                    style={{ height: trackRowHeight }}
                    className={`border-b border-[#3E3E44] flex items-stretch group transition-colors ${
                      isReorderTarget ? 'border-t-2 border-t-[#A1A1AA] bg-[#71717A]/12' : ''
                    } ${isPickWhipTarget ? 'bg-[#71717A]/20 ring-1 ring-inset ring-[#A1A1AA]' : ''}`}
                  >
                    {/* Left Layer Header */}
                    <div className="flex-1 min-w-0 px-1.5 flex flex-col justify-center gap-1">
                      <div className="flex items-center justify-between gap-1">
                        <div className="flex items-center gap-1 min-w-0 flex-1">
                          {/* Drag Handle to Reorder Layer Stack */}
                          <button
                            type="button"
                            onMouseDown={(e) => startTrackReorderDrag(e, idx)}
                            title="Drag vertically to reorder layer stack"
                            className="p-0.5 text-zinc-600 hover:text-zinc-200 cursor-ns-resize shrink-0"
                          >
                            <GripVertical className="w-3 h-3" />
                          </button>

                          {/* Expand/Collapse Sub-rows Chevron */}
                          <button
                            type="button"
                            onClick={() => onToggleTrackCollapsed?.(track.id)}
                            title={isExpanded ? 'Collapse Layer Properties' : 'Expand Layer Properties'}
                            className="p-0.5 text-zinc-500 hover:text-white shrink-0"
                          >
                            {isExpanded ? (
                              <ChevronDown className="w-3 h-3" />
                            ) : (
                              <ChevronRight className="w-3 h-3" />
                            )}
                          </button>

                          {/* Clickable Color Label Swatch */}
                          <button
                            type="button"
                            onClick={() => {
                              const curIdx = MARKER_COLOR_ORDER.indexOf(track.color || 'sky');
                              const nextCol =
                                MARKER_COLOR_ORDER[(curIdx + 1) % MARKER_COLOR_ORDER.length];
                              onSetTrackColor?.(track.id, nextCol);
                            }}
                            title="Click to cycle layer color label"
                            className="w-2.5 h-2.5 rounded-xs shrink-0 border border-white/25"
                            style={{ backgroundColor: trackColorHex }}
                          />

                          {editingTrackId === track.id ? (
                            <input
                              autoFocus
                              type="text"
                              value={trackDraftName}
                              onChange={(e) => setTrackDraftName(e.target.value)}
                              onBlur={() => commitTrackRename(track.id)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') commitTrackRename(track.id);
                                if (e.key === 'Escape') setEditingTrackId(null);
                              }}
                              className="flex-1 min-w-0 px-1 py-0.5 bg-[#18181A] border border-[#A1A1AA] rounded text-[11px] text-[#F4F4F5] focus:outline-none"
                            />
                          ) : (
                            <span
                              onDoubleClick={() => {
                                setEditingTrackId(track.id);
                                setTrackDraftName(track.name);
                              }}
                              title="Double-click to rename layer"
                              className="text-[11px] font-medium text-[#F4F4F5] truncate cursor-text"
                            >
                              {track.name}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingTrackId(track.id);
                              setTrackDraftName(track.name);
                            }}
                            title="Rename Layer"
                            className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5]"
                          >
                            <Pencil className="w-2.5 h-2.5" />
                          </button>
                          {idx > 0 && (
                            <button
                              type="button"
                              onClick={() => onMoveTrack(track.id, 'up')}
                              title="Move Layer Up"
                              className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5]"
                            >
                              <ArrowUp className="w-2.5 h-2.5" />
                            </button>
                          )}
                          {idx < project.tracks.length - 1 && (
                            <button
                              type="button"
                              onClick={() => onMoveTrack(track.id, 'down')}
                              title="Move Layer Down"
                              className="p-0.5 text-[#A1A1AA] hover:text-[#F4F4F5]"
                            >
                              <ArrowDown className="w-2.5 h-2.5" />
                            </button>
                          )}
                          {project.tracks.length > 2 && (
                            <button
                              type="button"
                              onClick={() => onDeleteTrack(track.id)}
                              title="Delete Layer"
                              className="p-0.5 text-[#A1A1AA] hover:text-rose-400"
                            >
                              <Trash2 className="w-2.5 h-2.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1 pl-4">
                        <button
                          type="button"
                          onClick={() => onToggleTrackProp(track.id, 'muted')}
                          title="Mute Layer"
                          className={`p-0.5 rounded ${
                            track.muted ? 'bg-rose-600/30 text-rose-300' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                          }`}
                        >
                          {track.muted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                        </button>
                        <button
                          type="button"
                          onClick={() => onToggleTrackProp(track.id, 'solo')}
                          title="Solo Layer"
                          className={`px-1 text-[10px] font-mono-tabular rounded ${
                            track.solo ? 'bg-amber-500/30 text-amber-300' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                          }`}
                        >
                          S
                        </button>
                        <button
                          type="button"
                          onClick={() => onToggleTrackProp(track.id, 'locked')}
                          title="Lock / Unlock Layer"
                          className={`p-0.5 rounded ${
                            track.locked ? 'text-amber-400' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                          }`}
                        >
                          {track.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                        </button>
                        {track.kind !== 'audio' && (
                          <button
                            type="button"
                            onClick={() => onToggleTrackProp(track.id, 'visible')}
                            title="Show / Hide Layer"
                            className={`p-0.5 rounded ${
                              !track.visible ? 'text-[#5C606D]' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                            }`}
                          >
                            {track.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Right Parent & Link Column (Pick Whip + Parent Dropdown) */}
                    <div className="w-[118px] shrink-0 border-l border-[#3E3E44] px-1.5 flex items-center gap-1 bg-[#202023]">
                      {primaryRowClip && track.kind !== 'audio' ? (
                        <>
                          <button
                            type="button"
                            onMouseDown={(e) => startPickWhipDrag(e, primaryRowClip)}
                            title={`Drag Pick Whip from "${primaryRowClip.name}" to a Null or Parent layer`}
                            className={`p-1 rounded border transition-colors shrink-0 cursor-crosshair ${
                              primaryRowClip.parentClipId
                                ? 'border-[#A1A1AA] bg-[#71717A]/20 text-[#E4E4E7]'
                                : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5] hover:border-[#A1A1AA]'
                            }`}
                          >
                            <Link2 className="w-3 h-3" />
                          </button>
                          <select
                            value={primaryRowClip.parentClipId || ''}
                            onChange={(e) =>
                              onSetClipParent?.(
                                primaryRowClip.id,
                                e.target.value || undefined
                              )
                            }
                            title="Parent Layer (Preserves World Position)"
                            className="flex-1 min-w-0 bg-[#18181A] border border-[#3E3E44] rounded px-1 py-0.5 text-[10px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                          >
                            <option value="">None</option>
                            {project.clips
                              .filter(
                                (cand) =>
                                  cand.id !== primaryRowClip.id &&
                                  cand.type !== 'audio' &&
                                  !wouldCreateParentCycle(primaryRowClip.id, cand.id, project.clips)
                              )
                              .sort((a, b) =>
                                a.type === 'null' && b.type !== 'null'
                                  ? -1
                                  : a.type !== 'null' && b.type === 'null'
                                  ? 1
                                  : a.name.localeCompare(b.name)
                              )
                              .map((cand) => (
                                <option key={cand.id} value={cand.id}>
                                  {cand.type === 'null' ? `[N] ${cand.name}` : cand.name}
                                </option>
                              ))}
                          </select>
                        </>
                      ) : (
                        <span className="text-[10px] text-[#6E7280] mx-auto">—</span>
                      )}
                    </div>
                  </div>

                  {/* Expanded Sub-row Header (Position / Scale / Rotation / Opacity / FX) */}
                  {isExpanded && (
                    <div
                      style={{ height: subRowHeight }}
                      className="border-b border-[#3E3E44] bg-[#1F1F22] px-2.5 py-1 flex flex-col justify-between text-[10px] text-[#A1A1AA]"
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="truncate font-mono-tabular text-[9px] text-[#A1A1AA]">
                          {primaryRowClip
                            ? `Pos · Scl · Rot · Opa · FX(${primaryRowClip.effectsStack?.length || 0})`
                            : 'No clip on track'}
                        </span>
                        {primaryRowClip && (
                          <button
                            type="button"
                            onClick={() => {
                              onSelectClip(primaryRowClip.id, false);
                              onFocusEffectInProperties?.(primaryRowClip.id);
                            }}
                            className="px-1.5 py-0.5 rounded bg-[#2C2C30] hover:bg-[#52525B] text-[#F4F4F5] text-[9px] shrink-0"
                          >
                            FX
                          </button>
                        )}
                      </div>
                      {primaryRowClip && track.kind !== 'audio' && (
                        <div className="flex items-center gap-1">
                          {(
                            [
                              { label: '+X', prop: 'x' },
                              { label: '+Y', prop: 'y' },
                              { label: '+Scl', prop: 'scale' },
                              { label: '+Rot', prop: 'rotation' },
                              { label: '+Opa', prop: 'opacity' },
                            ] as const
                          ).map((item) => (
                            <button
                              key={item.prop}
                              type="button"
                              onClick={() => addSinglePropKeyframeAtPlayhead(primaryRowClip, item.prop)}
                              title={`Add ${item.prop} keyframe at playhead`}
                              className="px-1 py-0 rounded bg-[#2C2C30] hover:bg-[#52525B] border border-[#3E3E44] text-[9px] font-mono-tabular text-[#F4F4F5]"
                            >
                              {item.label}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Scrollable Lanes + Playhead */}
        <div
          ref={tracksAreaRef}
          onScroll={(e) => {
            if (trackHeadersRef.current) {
              trackHeadersRef.current.scrollTop = e.currentTarget.scrollTop;
            }
          }}
          onWheel={(e) => {
            if (e.ctrlKey) {
              e.preventDefault();
              setPxPerSec((z) =>
                Math.max(16, Math.min(160, z + (e.deltaY < 0 ? 8 : -8)))
              );
            }
          }}
          className="flex-1 overflow-auto relative bg-[#18181A]"
        >
          <div style={{ width: timelineWidth }} className="relative min-h-full">
            {/* Time Ruler (double-click to place a colored marker) */}
            <div
              onMouseDown={handleRulerMouseDown}
              onDoubleClick={handleRulerDoubleClick}
              title="Click or drag to scrub · Double-click to place a Timeline Marker"
              className="h-7 bg-[#222225] border-b border-[#3E3E44] relative cursor-ew-resize sticky top-0 z-20"
            >
              {ticks.map((sec) => (
                <div
                  key={sec}
                  style={{ left: sec * pxPerSec }}
                  className="absolute top-0 bottom-0 border-l border-[#3E3E44] pl-1 text-[10px] font-mono-tabular text-[#A1A1AA] flex items-center pointer-events-none"
                >
                  {sec}s
                </div>
              ))}

              {/* Colored Bookmark Flags on Ruler */}
              {markers.map((marker) => {
                const st = MARKER_COLOR_STYLES[marker.color];
                const isSelected = marker.id === selectedMarkerId;
                const isDragging = marker.id === draggingMarkerId;
                return (
                  <div
                    key={marker.id}
                    style={{ left: marker.time * pxPerSec }}
                    onMouseDown={(e) => startMarkerDrag(e, marker)}
                    onDoubleClick={(e) => {
                      e.stopPropagation();
                      onSelectMarker(marker.id);
                      setTimeout(() => labelInputRef.current?.focus(), 0);
                    }}
                    title={`${marker.label} (${formatMarkerTime(marker.time)})${
                      marker.notes ? `\n${marker.notes}` : ''
                    }\nDrag to move · Hold Shift for free placement`}
                    className={`absolute top-0.5 bottom-0 -translate-x-1/2 z-30 flex flex-col items-center cursor-grab active:cursor-grabbing group ${
                      isDragging ? 'opacity-90' : ''
                    }`}
                  >
                    <div
                      className={`h-4 px-1 rounded-t-xs flex items-center gap-1 border shadow-sm transition-transform ${
                        st.bg
                      } ${
                        isSelected
                          ? 'border-white ring-1 ring-white/80 scale-105'
                          : 'border-black/40 group-hover:brightness-110'
                      }`}
                    >
                      <Bookmark className="w-2.5 h-2.5 text-white fill-white shrink-0" />
                      {(pxPerSec >= 44 || isSelected) && (
                        <span className="text-[9px] font-semibold text-white max-w-[74px] truncate leading-none">
                          {marker.label}
                        </span>
                      )}
                    </div>
                    <div
                      className="w-0 h-0 border-l-[4px] border-r-[4px] border-t-[4px] border-l-transparent border-r-transparent"
                      style={{ borderTopColor: st.hex }}
                    />
                  </div>
                );
              })}
            </div>

            {/* Track Lanes (Supports Marquee Multi-Selection & Empty Area Context Menu) */}
            <div
              ref={tracksContainerRef}
              onMouseDown={startMarqueeSelection}
              className="relative"
            >
              {project.tracks.map((track) => {
                const trackClips = project.clips.filter((c) => c.trackId === track.id);
                const isExpanded = track.collapsed === false;
                return (
                  <React.Fragment key={track.id}>
                    <div
                      data-track-lane-bg="true"
                      style={{ height: trackRowHeight }}
                      onDragOver={(e) => {
                        if (
                          e.dataTransfer.types.includes('application/x-redeffect-asset') ||
                          e.dataTransfer.types.includes('application/x-redeffect-fx') ||
                          e.dataTransfer.types.includes('Files')
                        ) {
                          e.preventDefault();
                        }
                      }}
                      onDrop={(e) => handleTrackDrop(e, track)}
                      onClick={(e) => {
                        if (e.target === e.currentTarget && !justFinishedMarqueeRef.current) {
                          onSelectClip(null);
                          onSelectMarker(null);
                        }
                      }}
                      onContextMenu={(e) => {
                        if (e.target !== e.currentTarget) return;
                        e.preventDefault();
                        const rect = e.currentTarget.getBoundingClientRect();
                        const clickTime = Math.max(0, (e.clientX - rect.left) / pxPerSec);
                        setContextMenuTarget({
                          kind: 'empty',
                          trackId: track.id,
                          x: e.clientX,
                          y: e.clientY,
                          time: Math.round(clickTime * 100) / 100,
                        });
                      }}
                      className={`border-b border-[#3E3E44] relative ${
                        track.locked ? 'opacity-60' : ''
                      } ${!track.visible ? 'opacity-45' : ''} ${
                        track.kind === 'audio' ? 'bg-[#151A19]' : 'bg-[#18181A]'
                      }`}
                    >
                      {trackClips.map((clip) => {
                        const left = clip.startTime * pxPerSec;
                        const width = Math.max(24, clip.duration * pxPerSec);
                        const isSelected = clip.id === selectedClipId || selectedClipIds.includes(clip.id);
                        const asset = project.assets.find((a) => a.id === clip.assetId);
                        const thumbUrl =
                          asset?.thumbnailUrl || (clip.type === 'image' ? asset?.url : undefined);
                        const parentObj = clip.parentClipId
                          ? project.clips.find((p) => p.id === clip.parentClipId)
                          : null;
                        const isHoveredTarget = pickWhipDrag?.hoverParentClipId === clip.id;

                        return (
                          <div
                            key={clip.id}
                            data-pickwhip-target-clip={clip.type !== 'audio' ? clip.id : undefined}
                            style={{ left, width }}
                            onMouseDown={(e) => startClipDrag(e, clip, 'move')}
                            onClick={(e) => {
                              e.stopPropagation();
                            }}
                            onContextMenu={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              if (!selectedClipIds.includes(clip.id)) {
                                onSelectClip(clip.id, false);
                              }
                              const rect = e.currentTarget.parentElement?.getBoundingClientRect();
                              const clickTime = rect
                                ? Math.max(0, (e.clientX - rect.left) / pxPerSec)
                                : playheadTime;
                              setContextMenuTarget({
                                kind:
                                  clip.type === 'null'
                                    ? 'null'
                                    : clip.type === 'text'
                                    ? 'text'
                                    : 'clip',
                                clipId: clip.id,
                                x: e.clientX,
                                y: e.clientY,
                                time: Math.round(clickTime * 100) / 100,
                              });
                            }}
                            onDragOver={(e) => {
                              if (e.dataTransfer.types.includes('application/x-redeffect-fx')) {
                                e.preventDefault();
                                e.stopPropagation();
                                if (dragOverClipId !== clip.id) setDragOverClipId(clip.id);
                              }
                            }}
                            onDragLeave={() => {
                              if (dragOverClipId === clip.id) setDragOverClipId(null);
                            }}
                            onDrop={(e) => {
                              setDragOverClipId(null);
                              const fx = e.dataTransfer.getData('application/x-redeffect-fx');
                              if (fx) {
                                e.stopPropagation();
                                onDropEffectOnClip(fx, clip.id);
                              }
                            }}
                            className={`absolute top-1.5 bottom-1.5 rounded border overflow-hidden group ${getClipColor(
                              clip
                            )} ${
                              isSelected
                                ? 'ring-2 ring-[#A1A1AA] border-white z-10'
                                : 'hover:brightness-110'
                            } ${dragOverClipId === clip.id ? 'ring-2 ring-amber-400 brightness-125' : ''} ${
                              isHoveredTarget ? 'ring-2 ring-emerald-400 brightness-125' : ''
                            } ${
                              activeTool === 'cut' ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'
                            } ${dragState?.clipId === clip.id ? 'opacity-90' : ''}`}
                          >
                            {/* Subtle Filmstrip / Image Thumbnail on Video & Image Clips */}
                            {thumbUrl && width >= 68 && (
                              <img
                                src={thumbUrl}
                                alt=""
                                draggable={false}
                                className="absolute left-0 top-0 bottom-0 w-10 object-cover opacity-55 border-r border-white/10 pointer-events-none"
                              />
                            )}

                            {/* Left Trim Handle */}
                            <div
                              onMouseDown={(e) => startClipDrag(e, clip, 'trim-left')}
                              onClick={(e) => e.stopPropagation()}
                              className="absolute left-0 top-0 bottom-0 w-2 cursor-ew-resize bg-white/0 hover:bg-white/25 z-20"
                            />
                            {/* Right Trim Handle */}
                            <div
                              onMouseDown={(e) => startClipDrag(e, clip, 'trim-right')}
                              onClick={(e) => e.stopPropagation()}
                              className="absolute right-0 top-0 bottom-0 w-2 cursor-ew-resize bg-white/0 hover:bg-white/25 z-20"
                            />

                            {/* Audio Waveform Bars */}
                            {asset?.waveformPeaks && asset.waveformPeaks.length > 0 && (
                              <div
                                className={`absolute inset-x-1 bottom-0.5 flex items-end gap-px pointer-events-none ${
                                  clip.type === 'audio' ? 'h-5 opacity-65' : 'h-3.5 opacity-45'
                                }`}
                              >
                                {asset.waveformPeaks.map((pk, idx) => (
                                  <div
                                    key={idx}
                                    style={{ height: `${Math.max(12, pk * 100)}%` }}
                                    className={`flex-1 rounded-t-xs ${
                                      clip.type === 'audio' ? 'bg-emerald-300' : 'bg-[#E4E4E7]'
                                    }`}
                                  />
                                ))}
                              </div>
                            )}

                            {/* Clip Label & Metadata + Inline Rename */}
                            <div
                              className={`relative z-10 ${
                                thumbUrl && width >= 68 ? 'pl-11 pr-2' : 'px-2'
                              } py-0.5 flex items-center justify-between gap-1 text-[11px] font-medium truncate`}
                            >
                              {renamingClipId === clip.id ? (
                                <input
                                  autoFocus
                                  type="text"
                                  value={clipDraftName}
                                  onMouseDown={(e) => e.stopPropagation()}
                                  onClick={(e) => e.stopPropagation()}
                                  onChange={(e) => setClipDraftName(e.target.value)}
                                  onBlur={() => commitClipRename(clip.id)}
                                  onKeyDown={(e) => {
                                    e.stopPropagation();
                                    if (e.key === 'Enter') commitClipRename(clip.id);
                                    if (e.key === 'Escape') onRequestRenameClip?.(null);
                                  }}
                                  className="flex-1 min-w-0 px-1 py-0 bg-[#18181A] border border-[#A1A1AA] rounded text-[11px] text-[#F4F4F5] focus:outline-none z-30"
                                />
                              ) : (
                                <span
                                  onDoubleClick={(e) => {
                                    e.stopPropagation();
                                    onRequestRenameClip?.(clip.id);
                                  }}
                                  className="truncate pointer-events-none"
                                >
                                  {clip.type === 'null' ? `[NULL] ` : clip.type === 'fx' ? `[FX] ` : ''}
                                  {clip.muted ? `[Muted] ${clip.name}` : clip.name}
                                  {parentObj ? ` ↳ ${parentObj.name}` : ''}
                                </span>
                              )}
                              <div className="flex items-center gap-1 shrink-0">
                                {clip.type === 'fx' && (
                                  <button
                                    type="button"
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onUpdateClip(
                                        clip.id,
                                        (c) => ({ ...c, disabled: !c.disabled }),
                                        true
                                      );
                                    }}
                                    title={clip.disabled ? 'Enable FX Layer' : 'Disable FX Layer'}
                                    className={`p-0.5 rounded transition-colors ${
                                      clip.disabled
                                        ? 'bg-[#2C2C30] text-[#A1A1AA] hover:text-white'
                                        : 'bg-black/45 text-[#F4F4F5] hover:bg-[#52525B] hover:text-white'
                                    }`}
                                  >
                                    {clip.disabled ? (
                                      <EyeOff className="w-2.5 h-2.5" />
                                    ) : (
                                      <Eye className="w-2.5 h-2.5" />
                                    )}
                                  </button>
                                )}
                                {clip.type !== 'audio' && (
                                  <button
                                    type="button"
                                    onMouseDown={(e) => startPickWhipDrag(e, clip)}
                                    onClick={(e) => e.stopPropagation()}
                                    title="Drag Pick Whip onto parent Null / Layer"
                                    className="opacity-0 group-hover:opacity-100 p-0.5 rounded bg-black/40 hover:bg-[#52525B] text-white cursor-crosshair transition-opacity"
                                  >
                                    <Link2 className="w-2.5 h-2.5" />
                                  </button>
                                )}
                                {(clip.effectsStack?.length ?? 0) > 0 && (
                                  <button
                                    type="button"
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onSelectClip(clip.id, false);
                                      onFocusEffectInProperties?.(clip.id);
                                    }}
                                    title="Open Effect Settings"
                                    className="text-[9px] px-1 rounded bg-[#52525B] hover:bg-[#6B7280] text-white font-mono-tabular"
                                  >
                                    FX:{clip.effectsStack!.length}
                                  </button>
                                )}
                                {clip.speed !== 1 && (
                                  <span className="text-[9px] font-mono-tabular opacity-80 pointer-events-none">
                                    {clip.speed}x
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Interactive Keyframe Diamond Indicators */}
                            {clip.keyframes.length > 0 && (
                              <div className="absolute bottom-0.5 inset-x-0 h-3 z-20 pointer-events-none">
                                {clip.keyframes.map((kf) => {
                                  const isSel = selectedKfIds.includes(kf.id);
                                  return (
                                    <button
                                      key={kf.id}
                                      type="button"
                                      onMouseDown={(e) => startKeyframeDrag(e, clip, kf)}
                                      onClick={(e) => e.stopPropagation()}
                                      onContextMenu={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        setSelectedKfIds([kf.id]);
                                        setContextMenuTarget({
                                          kind: 'keyframe',
                                          clipId: clip.id,
                                          keyframeId: kf.id,
                                          x: e.clientX,
                                          y: e.clientY,
                                        });
                                      }}
                                      title={`${kf.property} = ${kf.value.toFixed(2)} @ ${kf.time.toFixed(
                                        2
                                      )}s (${kf.easing})\nDrag to retime · Right-click for easing`}
                                      style={{
                                        left: `${Math.min(
                                          98,
                                          Math.max(2, (kf.time / clip.duration) * 100)
                                        )}%`,
                                      }}
                                      className={`pointer-events-auto absolute top-0.5 -translate-x-1/2 cursor-ew-resize transition-transform ${
                                        isSel ? 'scale-125' : 'hover:scale-125'
                                      }`}
                                    >
                                      <span
                                        className={`block w-2 h-2 rotate-45 border ${
                                          isSel
                                            ? 'bg-white border-[#A1A1AA]'
                                            : 'bg-amber-400 border-black/60'
                                        }`}
                                      />
                                    </button>
                                  );
                                })}
                              </div>
                            )}

                            {/* Transition In/Out Markers */}
                            {clip.transitionIn !== 'none' && (
                              <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#52525B] pointer-events-none" />
                            )}
                            {clip.transitionOut !== 'none' && (
                              <div className="absolute right-0 top-0 bottom-0 w-1.5 bg-[#52525B] pointer-events-none" />
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Expanded Sub-row Lane */}
                    {isExpanded && (
                      <div
                        style={{ height: subRowHeight }}
                        className="border-b border-[#3E3E44] bg-[#141416] relative"
                      >
                        {trackClips.map((clip) => {
                          const left = clip.startTime * pxPerSec;
                          const width = Math.max(24, clip.duration * pxPerSec);
                          return (
                            <div
                              key={`sub-${clip.id}`}
                              style={{ left, width }}
                              className="absolute top-1 bottom-1 rounded bg-[#222225] border border-[#3E3E44] px-1.5 flex flex-col justify-center gap-0.5 overflow-hidden"
                            >
                              <div className="flex items-center gap-1 text-[9px] text-[#A1A1AA] truncate">
                                <span className="font-mono-tabular">
                                  X:{clip.transform.x.toFixed(0)} Y:{clip.transform.y.toFixed(0)} S:{clip.transform.scale.toFixed(2)} R:{clip.transform.rotation.toFixed(0)}°
                                </span>
                                {(clip.effectsStack || []).slice(0, 3).map((fx) => (
                                  <button
                                    key={fx.id}
                                    type="button"
                                    onClick={() => {
                                      onSelectClip(clip.id, false);
                                      onFocusEffectInProperties?.(clip.id);
                                    }}
                                    className="px-1 py-0 rounded bg-[#71717A]/20 border border-[#A1A1AA]/50 text-[#F4F4F5] hover:bg-[#52525B] hover:text-white"
                                  >
                                    {fx.name}
                                  </button>
                                ))}
                              </div>
                              <div className="relative h-2.5 bg-[#18181A] rounded">
                                {clip.keyframes.map((kf) => (
                                  <button
                                    key={`subkf-${kf.id}`}
                                    type="button"
                                    onMouseDown={(e) => startKeyframeDrag(e, clip, kf)}
                                    onContextMenu={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      setContextMenuTarget({
                                        kind: 'keyframe',
                                        clipId: clip.id,
                                        keyframeId: kf.id,
                                        x: e.clientX,
                                        y: e.clientY,
                                      });
                                    }}
                                    style={{
                                      left: `${Math.min(
                                        98,
                                        Math.max(2, (kf.time / clip.duration) * 100)
                                      )}%`,
                                    }}
                                    className="absolute top-0.5 -translate-x-1/2 w-1.5 h-1.5 rotate-45 bg-amber-400 border border-black"
                                    title={`${kf.property}: ${kf.value.toFixed(2)} @ ${kf.time.toFixed(2)}s`}
                                  />
                                ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </React.Fragment>
                );
              })}

              {/* Marquee Multi-Selection Rectangle */}
              {marqueeBox && (
                <div
                  style={{
                    left: Math.min(marqueeBox.startX, marqueeBox.curX),
                    top: Math.min(marqueeBox.startY, marqueeBox.curY),
                    width: Math.abs(marqueeBox.curX - marqueeBox.startX),
                    height: Math.abs(marqueeBox.curY - marqueeBox.startY),
                  }}
                  className="absolute pointer-events-none bg-[#71717A]/15 border border-[#A1A1AA] z-40"
                />
              )}

              {/* Vertical Dashed Marker Guide Lines across Track Lanes */}
              {markers.map((marker) => {
                const st = MARKER_COLOR_STYLES[marker.color];
                const isSelected = marker.id === selectedMarkerId;
                return (
                  <div
                    key={`guide-${marker.id}`}
                    style={{ left: marker.time * pxPerSec }}
                    className={`absolute top-0 bottom-0 w-0 border-l border-dashed pointer-events-none z-10 ${
                      st.line
                    } ${isSelected ? 'opacity-100 border-solid' : 'opacity-65'}`}
                  />
                );
              })}

              {/* Playhead Needle */}
              <div
                style={{ left: playheadTime * pxPerSec }}
                className="absolute top-0 bottom-0 w-px bg-[#52525B] z-30 pointer-events-none"
              >
                <div className="w-3 h-3 -ml-[5px] -mt-1.5 bg-[#52525B] rotate-45 shadow-sm" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Inline Curve / Graph Editor Drawer */}
      {showCurveEditor && (
        <div className="h-[195px] shrink-0 border-t border-[#3E3E44] bg-[#18181A] flex flex-col overflow-hidden">
          <div className="h-7 px-3 bg-[#222225] border-b border-[#3E3E44] flex items-center justify-between text-[11px] shrink-0">
            <div className="flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-[#D4D4D8]" />
              <span className="font-semibold text-[#F4F4F5]">Animation Curve &amp; Graph Editor</span>
              {selectedClip && (
                <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">
                  · {selectedClip.name} ({selectedClip.keyframes.length} keyframes)
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={() => setShowCurveEditor(false)}
              className="p-0.5 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]"
              title="Close Curve Editor"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="flex-1 min-h-0 overflow-hidden">
            <KeyframeGraphPanel
              selectedClip={selectedClip}
              playheadTime={playheadTime}
              onUpdateClip={(clipId, updater) => onUpdateClip(clipId, updater, true)}
              onSeek={onSeek}
            />
          </div>
        </div>
      )}

      {/* Live Pick Whip SVG Tether Overlay */}
      {pickWhipDrag && (
        <svg className="fixed inset-0 w-screen h-screen pointer-events-none z-[95]">
          <path
            d={`M ${pickWhipDrag.startX} ${pickWhipDrag.startY} C ${pickWhipDrag.startX + 60} ${
              pickWhipDrag.startY
            }, ${pickWhipDrag.curX - 60} ${pickWhipDrag.curY}, ${pickWhipDrag.curX} ${
              pickWhipDrag.curY
            }`}
            fill="none"
            stroke={pickWhipDrag.hoverParentClipId ? '#10B981' : '#A1A1AA'}
            strokeWidth={2.5}
          />
          <circle
            cx={pickWhipDrag.curX}
            cy={pickWhipDrag.curY}
            r={5}
            fill={pickWhipDrag.hoverParentClipId ? '#10B981' : '#A1A1AA'}
          />
        </svg>
      )}

      {/* Smart Contextual Right-Click Menu */}
      <TimelineContextMenu
        target={contextMenuTarget}
        clips={project.clips}
        selectedClipIds={selectedClipIds}
        hasClipboard={hasClipboard}
        hasCopiedKeyframe={copiedKeyframes.length > 0}
        snapEnabled={project.snapEnabled}
        onClose={() => setContextMenuTarget(null)}
        onCutClip={(id) => (onCutClip ? onCutClip(id) : onCopyClip(id))}
        onCopyClip={onCopyClip}
        onPasteClip={(atTime) => onPasteClip(atTime)}
        onDuplicateClip={(id) =>
          onDuplicateClip
            ? onDuplicateClip(id)
            : onCopyClip(id)
        }
        onSplitClip={(id) => onSplitClip(id, playheadTime)}
        onTrimStartToPlayhead={(id) => {
          const target = project.clips.find((c) => c.id === id);
          if (!target) return;
          const end = target.startTime + target.duration;
          if (playheadTime <= target.startTime || playheadTime >= end - 0.25) return;
          const delta = playheadTime - target.startTime;
          onUpdateClip(id, (c) => ({
            ...c,
            startTime: playheadTime,
            duration: Math.max(0.25, c.duration - delta),
            sourceOffset: c.sourceOffset + delta * c.speed,
          }));
        }}
        onTrimEndToPlayhead={(id) => {
          const target = project.clips.find((c) => c.id === id);
          if (!target) return;
          const nextDur = Math.max(0.25, playheadTime - target.startTime);
          if (playheadTime <= target.startTime + 0.25) return;
          onUpdateClip(id, (c) => ({ ...c, duration: nextDur }));
        }}
        onToggleEnableClip={(id) =>
          onUpdateClip(id, (c) => ({ ...c, disabled: !c.disabled }))
        }
        onToggleMuteClip={(id) =>
          onUpdateClip(id, (c) => ({ ...c, muted: !c.muted }))
        }
        onToggleLockClip={(id) =>
          onUpdateClip(id, (c) => ({ ...c, locked: !c.locked }))
        }
        onToggleHideClip={(id) =>
          onUpdateClip(id, (c) => ({ ...c, visible: !c.visible }))
        }
        onOpenSpeedDuration={(id) => onOpenSpeedDuration?.(id)}
        onQuickAddEffect={(id, fx) => onQuickAddEffect?.(id, fx)}
        onQuickApplyPreset={(id, presetId) => onQuickApplyPreset?.(id, presetId)}
        onDetachAudio={(id) => onDetachAudio?.(id)}
        onCreateCompoundClip={() => onCreateCompoundClip?.()}
        onSetClipParent={(id, pid) => onSetClipParent?.(id, pid)}
        onRenameClip={(id) => onRequestRenameClip?.(id)}
        onDeleteClip={onDeleteClip}
        onEditText={(id) => {
          onSelectClip(id, false);
          onFocusEffectInProperties?.(id);
        }}
        onConvertTextToShape={(id) => onConvertTextToShape?.(id)}
        onAddTextAnimation={(id, anim) =>
          onUpdateClip(id, (c) =>
            c.textProps ? { ...c, textProps: { ...c.textProps, animation: anim } } : c
          )
        }
        onSetNullColor={(id, color) =>
          onUpdateClip(id, (c) => ({ ...c, labelColor: color }))
        }
        onAddNullKeyframe={(id, kind) => {
          const target = project.clips.find((c) => c.id === id);
          if (!target) return;
          const relTime = Math.max(0, Math.min(target.duration, Math.round((playheadTime - target.startTime) * 100) / 100));
          onUpdateClip(id, (c) => {
            const propsToAdd: Array<{ property: Keyframe['property']; value: number }> =
              kind === 'position'
                ? [
                    { property: 'x', value: c.transform.x },
                    { property: 'y', value: c.transform.y },
                  ]
                : kind === 'scale'
                ? [{ property: 'scale', value: c.transform.scale }]
                : [{ property: 'rotation', value: c.transform.rotation }];
            let nextKfs = [...c.keyframes];
            for (const p of propsToAdd) {
              nextKfs = nextKfs.filter(
                (k) => !(k.property === p.property && Math.abs(k.time - relTime) < 0.08)
              );
              nextKfs.push({
                id: `kf-${Date.now()}-${p.property}-${Math.random().toString(36).slice(2, 5)}`,
                time: relTime,
                property: p.property,
                value: p.value,
                easing: 'easeInOut',
              });
            }
            return { ...c, keyframes: nextKfs };
          });
        }}
        onSelectNullChildren={(id) => {
          const childIds = project.clips
            .filter((c) => c.parentClipId === id)
            .map((c) => c.id);
          if (childIds.length > 0 && onSelectMultipleClips) {
            onSelectMultipleClips([id, ...childIds], id);
          }
        }}
        onToggleNullChildrenVisibility={(id) => {
          if (!onBatchUpdateClips) return;
          const children = project.clips.filter((c) => c.parentClipId === id);
          if (children.length === 0) return;
          const anyVisible = children.some((c) => c.visible);
          const updates: Record<string, (c: TimelineClip) => TimelineClip> = {};
          for (const ch of children) {
            updates[ch.id] = (c) => ({ ...c, visible: !anyVisible });
          }
          onBatchUpdateClips(updates, true);
        }}
        onSetKeyframeEasing={(clipId, kfId, easing: AnimationEasing | 'hold') => {
          onUpdateClip(clipId, (c) => ({
            ...c,
            keyframes: c.keyframes.map((k) => {
              if (k.id !== kfId) return k;
              const normalizedEasing: AnimationEasing = easing === 'hold' ? 'linear' : easing;
              const bezier: [number, number, number, number] =
                easing === 'hold'
                  ? [1, 0, 1, 0]
                  : easing === 'easeIn'
                  ? [0.42, 0, 1, 1]
                  : easing === 'easeOut'
                  ? [0, 0, 0.58, 1]
                  : easing === 'easeInOut'
                  ? [0.42, 0, 0.58, 1]
                  : [0.25, 0.1, 0.25, 1];
              return { ...k, easing: normalizedEasing, bezier };
            }),
          }));
        }}
        onCopyKeyframe={(clipId, kfId) => {
          const src = project.clips.find((c) => c.id === clipId);
          const found = src?.keyframes.find((k) => k.id === kfId);
          if (found) setCopiedKeyframes([structuredClone(found)]);
        }}
        onPasteKeyframe={(clipId) => {
          if (copiedKeyframes.length === 0) return;
          const target = project.clips.find((c) => c.id === clipId);
          if (!target) return;
          const relTime = Math.max(0, Math.min(target.duration, Math.round((playheadTime - target.startTime) * 100) / 100));
          onUpdateClip(clipId, (c) => ({
            ...c,
            keyframes: [
              ...c.keyframes,
              ...copiedKeyframes.map((k) => ({
                ...structuredClone(k),
                id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                time: relTime,
              })),
            ],
          }));
        }}
        onDeleteKeyframe={(clipId, kfId) => {
          onUpdateClip(clipId, (c) => ({
            ...c,
            keyframes: c.keyframes.filter((k) => k.id !== kfId),
          }));
          setSelectedKfIds((prev) => prev.filter((id) => id !== kfId));
        }}
        onAddNullClip={() => onAddNullClip?.()}
        onAddTextClip={onAddTextClip}
        onAddShapeClip={() => onAddShapeClip?.()}
        onAddEffectLayer={() => onAddEffectLayer?.()}
        onAddTrack={(kind) => onAddTrack(kind)}
        onAddMarkerAtTime={(t) => onAddMarker(t, activeMarkerColor)}
        onZoomToFit={() => {
          const areaW = tracksAreaRef.current?.clientWidth || 900;
          const fit = Math.max(16, Math.min(160, Math.floor((areaW - 80) / Math.max(10, maxClipEnd - 4))));
          setPxPerSec(fit);
        }}
        onToggleSnap={onToggleSnap}
      />
    </div>
  );
};
