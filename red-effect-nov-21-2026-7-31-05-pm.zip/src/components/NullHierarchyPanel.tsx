import React, { useState } from 'react';
import {
  Crosshair,
  Plus,
  Link2,
  Unlink,
  Trash2,
  Edit3,
  Check,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Copy,
} from 'lucide-react';
import { MarkerColor, StudioProject, TimelineClip } from '../types/studio';
import { wouldCreateParentCycle } from '../services/videoCompositor';

const COLOR_HEX: Record<MarkerColor, string> = {
  rose: '#E11D48',
  amber: '#F59E0B',
  emerald: '#10B981',
  sky: '#0EA5E9',
  violet: '#8B5CF6',
};

interface NullHierarchyPanelProps {
  project: StudioProject;
  selectedClipId: string | null;
  onSelectClip: (clipId: string) => void;
  onCreateNullObject: () => void;
  onUpdateClip: (clipId: string, updater: (c: TimelineClip) => TimelineClip) => void;
  onSetClipParent?: (clipId: string, parentId: string | undefined) => void;
  onDuplicateClip?: (clipId: string) => void;
  onDeleteClip: (clipId: string) => void;
}

export const NullHierarchyPanel: React.FC<NullHierarchyPanelProps> = ({
  project,
  selectedClipId,
  onSelectClip,
  onCreateNullObject,
  onUpdateClip,
  onSetClipParent,
  onDuplicateClip,
  onDeleteClip,
}) => {
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameText, setRenameText] = useState('');

  const visualClips = project.clips.filter((c) => c.type !== 'audio');
  const nullObjects = visualClips.filter((c) => c.type === 'null');
  const rootClips = visualClips.filter(
    (c) => !c.parentClipId || !visualClips.some((p) => p.id === c.parentClipId)
  );

  const cycleLabelColor = (clip: TimelineClip) => {
    const order: MarkerColor[] = ['rose', 'amber', 'emerald', 'sky', 'violet'];
    const cur = clip.labelColor || 'rose';
    const next = order[(order.indexOf(cur) + 1) % order.length];
    onUpdateClip(clip.id, (c) => ({ ...c, labelColor: next }));
  };

  const renderNode = (clip: TimelineClip, depth: number) => {
    const children = visualClips.filter((c) => c.parentClipId === clip.id);
    const isSelected = clip.id === selectedClipId;
    const isNull = clip.type === 'null';
    const swatchHex = COLOR_HEX[clip.labelColor || (isNull ? 'rose' : 'sky')];

    return (
      <div key={clip.id}>
        <div
          onClick={() => onSelectClip(clip.id)}
          style={{ paddingLeft: `${8 + depth * 18}px` }}
          className={`flex items-center justify-between gap-2 pr-2 py-1.5 border-b border-[#3E3E44]/60 cursor-pointer transition-colors ${
            isSelected ? 'bg-[#71717A]/15 border-l-2 border-l-[#A1A1AA]' : 'hover:bg-[#2C2C30]'
          }`}
        >
          <div className="flex items-center gap-1.5 min-w-0">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                cycleLabelColor(clip);
              }}
              title="Click to cycle layer color label"
              style={{ backgroundColor: swatchHex }}
              className="w-2.5 h-2.5 rounded-xs shrink-0 ring-1 ring-white/20"
            />
            {isNull ? (
              <Crosshair className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0" />
            ) : (
              <Link2 className="w-3 h-3 text-[#A1A1AA] shrink-0" />
            )}
            {renamingId === clip.id ? (
              <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                <input
                  type="text"
                  value={renameText}
                  onChange={(e) => setRenameText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && renameText.trim()) {
                      onUpdateClip(clip.id, (c) => ({ ...c, name: renameText.trim() }));
                      setRenamingId(null);
                    } else if (e.key === 'Escape') {
                      setRenamingId(null);
                    }
                  }}
                  className="px-1.5 py-0.5 bg-[#18181A] border border-[#A1A1AA] rounded text-[11px] text-[#F4F4F5] w-36 focus:outline-none"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => {
                    if (renameText.trim()) {
                      onUpdateClip(clip.id, (c) => ({ ...c, name: renameText.trim() }));
                    }
                    setRenamingId(null);
                  }}
                  className="text-[#D4D4D8]"
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <span className="truncate font-medium text-[#F4F4F5]">
                {clip.name}{' '}
                <span className="text-[10px] text-[#A1A1AA]">
                  ({clip.type}
                  {children.length > 0 ? ` · ${children.length} child` : ''})
                </span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
            {/* Parent Assignment Selector */}
            <select
              value={clip.parentClipId || ''}
              onChange={(e) => {
                const nextParent = e.target.value || undefined;
                if (onSetClipParent) {
                  onSetClipParent(clip.id, nextParent);
                } else {
                  onUpdateClip(clip.id, (c) => ({ ...c, parentClipId: nextParent }));
                }
              }}
              title="Parent Layer / Null Object"
              className="px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5] max-w-[130px] focus:outline-none focus:border-[#A1A1AA]"
            >
              <option value="">No Parent</option>
              {visualClips
                .filter(
                  (cand) =>
                    cand.id !== clip.id &&
                    !wouldCreateParentCycle(clip.id, cand.id, project.clips)
                )
                .map((cand) => (
                  <option key={cand.id} value={cand.id}>
                    ↳ {cand.type === 'null' ? `[Null] ${cand.name}` : cand.name}
                  </option>
                ))}
            </select>

            {clip.parentClipId && (
              <button
                type="button"
                onClick={() =>
                  onSetClipParent
                    ? onSetClipParent(clip.id, undefined)
                    : onUpdateClip(clip.id, (c) => ({ ...c, parentClipId: undefined }))
                }
                title="Unparent Layer"
                className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
              >
                <Unlink className="w-3 h-3" />
              </button>
            )}

            <button
              type="button"
              onClick={() =>
                onUpdateClip(clip.id, (c) => ({ ...c, visible: !c.visible }))
              }
              title={clip.visible ? 'Hide in Preview' : 'Show in Preview'}
              className={`p-1 ${clip.visible ? 'text-[#A1A1AA] hover:text-[#F4F4F5]' : 'text-[#6E7280]'}`}
            >
              {clip.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            </button>

            <button
              type="button"
              onClick={() =>
                onUpdateClip(clip.id, (c) => ({ ...c, locked: !c.locked }))
              }
              title={clip.locked ? 'Unlock Layer' : 'Lock Layer'}
              className={`p-1 ${clip.locked ? 'text-amber-400' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'}`}
            >
              {clip.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
            </button>

            <button
              type="button"
              onClick={() => {
                setRenamingId(clip.id);
                setRenameText(clip.name);
              }}
              title="Rename"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
            >
              <Edit3 className="w-3 h-3" />
            </button>

            {isNull && onDuplicateClip && (
              <button
                type="button"
                onClick={() => onDuplicateClip(clip.id)}
                title="Duplicate Null Object"
                className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5]"
              >
                <Copy className="w-3 h-3" />
              </button>
            )}

            {isNull && (
              <button
                type="button"
                onClick={() => onDeleteClip(clip.id)}
                title="Delete Null Object"
                className="p-1 text-[#A1A1AA] hover:text-rose-400"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
        {children.map((ch) => renderNode(ch, depth + 1))}
      </div>
    );
  };

  return (
    <div
      data-tutorial-target="null-hierarchy-panel"
      className="h-full bg-[#222225] text-[#F4F4F5] text-xs flex overflow-hidden"
    >
      <div className="flex-1 flex flex-col min-w-0">
        <div className="px-3 py-1.5 bg-[#18181A] border-b border-[#3E3E44] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Crosshair className="w-3.5 h-3.5 text-[#D4D4D8]" />
            <span className="font-semibold">Null Object &amp; Parent-Child Hierarchy</span>
            <span className="text-[10px] text-[#A1A1AA]">
              ({nullObjects.length} Null controllers · non-rendering in export)
            </span>
          </div>
          <button
            type="button"
            onClick={onCreateNullObject}
            className="px-2.5 py-1 bg-[#52525B] hover:bg-[#6B7280] text-white rounded text-[11px] font-medium flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            Create Null Object
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {rootClips.length === 0 ? (
            <div className="p-4 text-center text-[#A1A1AA]">
              Add clips or click <strong className="text-[#F4F4F5]">Create Null Object</strong> to build multi-layer parent rigs.
            </div>
          ) : (
            rootClips.map((c) => renderNode(c, 0))
          )}
        </div>
      </div>
    </div>
  );
};

