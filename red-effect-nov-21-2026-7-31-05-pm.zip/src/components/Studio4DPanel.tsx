import React, { useCallback, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import {
  Play,
  Pause,
  Square,
  Repeat,
  Move,
  RotateCw,
  Maximize2,
  MousePointer2,
  Plus,
  Trash2,
  Copy,
  Eye,
  EyeOff,
  Download,
  Upload,
  Loader2,
  Sparkles,
  Sun,
  Video,
  Activity,
  Sliders,
  Layers,
  Boxes,
  Bone,
  Camera,
  Film,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';
import {
  AnimationClipEntry4D,
  CameraAnimMode4D,
  CameraConfig4D,
  CharacterMotionPreset,
  FacialRigState,
  Hyper4DConfig,
  Keyframe4D,
  LightingConfig4D,
  LightingPreset4D,
  ObjectAnimPreset,
  ParticleConfig4D,
  ParticlePreset4D,
  PhysicsConfig4D,
  SceneNodeInfo,
  Studio4DTransferPayload,
} from '../types/studio4d';
import { buildComposite3DGroup, createDefaultShowcase3DBlueprint, createStudioEnvironment } from '../services/threeModelBuilder';
import {
  applyBoxUVProjection,
  applyFacialRigState,
  applyImageFileAsTexture,
  applyObjectAnimationPreset,
  applyProceduralCharacterMotion,
  applyProceduralFinishTexture,
  applyVertexNoiseSculpt,
  autoRigObject,
  cloneTransferableObject,
  collectSceneNodes,
  createHyper4DObject,
  createParticleSystem4D,
  evaluateKeyframes4D,
  export4DToFBXAscii,
  export4DToGLB,
  export4DToGLTF,
  export4DToOBJ,
  findBonesInObject,
  PhysicsBodyState,
  restoreBasePoses,
  saveBasePoses,
  stepParticleSystem4D,
  stepPhysicsSimulation4D,
  updateHyper4DObject,
} from '../services/studio4DEngine';
import { saveBlobWithWindowsDialog } from '../services/projectStorage';

interface Studio4DPanelProps {
  transferPayload: Studio4DTransferPayload | null;
  onSendVideoToTimeline: (
    targetWorkspace: 'editing' | 'motion',
    name: string,
    blob: Blob,
    duration: number,
    width: number,
    height: number
  ) => void;
}

const LIGHTING_PRESETS: Record<LightingPreset4D, Partial<LightingConfig4D>> = {
  'realistic-studio': {
    preset: 'realistic-studio',
    keyIntensity: 2.5,
    keyColor: '#FFF8F0',
    fillIntensity: 1.0,
    fillColor: '#DBEAFE',
    rimIntensity: 1.3,
    rimColor: '#93C5FD',
    ambientIntensity: 0.85,
    envIntensity: 1.15,
    shadowsEnabled: true,
    fogDensity: 0.025,
  },
  'crimson-cinema': {
    preset: 'crimson-cinema',
    keyIntensity: 2.3,
    keyColor: '#FFF1E0',
    fillIntensity: 0.85,
    fillColor: '#93C5FD',
    rimIntensity: 2.4,
    rimColor: '#E11D48',
    ambientIntensity: 0.65,
    envIntensity: 1.0,
    shadowsEnabled: true,
    fogDensity: 0.045,
  },
  'sunset-golden': {
    preset: 'sunset-golden',
    keyIntensity: 2.8,
    keyColor: '#FDBA74',
    fillIntensity: 0.9,
    fillColor: '#FDE68A',
    rimIntensity: 2.2,
    rimColor: '#F97316',
    ambientIntensity: 0.75,
    envIntensity: 1.0,
    shadowsEnabled: true,
    fogDensity: 0.04,
  },
  'moonlight-noir': {
    preset: 'moonlight-noir',
    keyIntensity: 1.8,
    keyColor: '#BFDBFE',
    fillIntensity: 0.45,
    fillColor: '#3B82F6',
    rimIntensity: 1.9,
    rimColor: '#E11D48',
    ambientIntensity: 0.4,
    envIntensity: 0.65,
    shadowsEnabled: true,
    fogDensity: 0.06,
  },
  'neon-cyber': {
    preset: 'neon-cyber',
    keyIntensity: 2.1,
    keyColor: '#38BDF8',
    fillIntensity: 1.2,
    fillColor: '#F43F5E',
    rimIntensity: 2.6,
    rimColor: '#FB7185',
    ambientIntensity: 0.55,
    envIntensity: 1.2,
    shadowsEnabled: true,
    fogDensity: 0.05,
  },
};

export const Studio4DPanel: React.FC<Studio4DPanelProps> = ({
  transferPayload,
  onSendVideoToTimeline,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textureInputRef = useRef<HTMLInputElement>(null);
  const mocapVideoRef = useRef<HTMLVideoElement | null>(null);
  const mocapCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Studio UI Tabs
  const [leftTab, setLeftTab] = useState<'lighting' | 'camera' | 'physics' | 'math4d'>('lighting');
  const [rightTab, setRightTab] = useState<'object' | 'material' | 'mesh' | 'rig'>('object');

  // Tool & Selection State
  const [gizmoMode, setGizmoMode] = useState<'select' | 'translate' | 'rotate' | 'scale'>('translate');
  const [gizmoSpace, setGizmoSpace] = useState<'world' | 'local'>('world');
  const [showSkeleton, setShowSkeleton] = useState(true);
  const [sceneNodes, setSceneNodes] = useState<SceneNodeInfo[]>([]);
  const [selectedUuid, setSelectedUuid] = useState<string | null>(null);
  const [modelTitle, setModelTitle] = useState('Crimson Cinema Drone');
  const [statusBanner, setStatusBanner] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Temporal Timeline & Playback State
  const [duration, setDuration] = useState(8);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [loopEnabled, setLoopEnabled] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [keyframes, setKeyframes] = useState<Keyframe4D[]>([]);
  const [kfInterpolation, setKfInterpolation] = useState<'linear' | 'smooth' | 'step'>('smooth');

  // Embedded & Procedural Animations
  const [clipEntries, setClipEntries] = useState<AnimationClipEntry4D[]>([]);
  const [characterMotion, setCharacterMotion] = useState<CharacterMotionPreset>('none');
  const [characterSpeed, setCharacterSpeed] = useState(1);
  const [objectAnim, setObjectAnim] = useState<ObjectAnimPreset>('none');
  const [objectAnimSpeed, setObjectAnimSpeed] = useState(1);

  // Character Rig & Facial Controls
  const [boneNames, setBoneNames] = useState<string[]>([]);
  const [selectedBoneName, setSelectedBoneName] = useState<string>('');
  const [boneRot, setBoneRot] = useState<[number, number, number]>([0, 0, 0]);
  const [facial, setFacial] = useState<FacialRigState>({
    smile: 0,
    blink: 0,
    browRaise: 0,
    jawOpen: 0,
    surprise: 0,
  });
  const [mocapActive, setMocapActive] = useState(false);

  // Selected Object & Material Inspector Snapshot
  const [objTransform, setObjTransform] = useState({
    px: 0,
    py: 0,
    pz: 0,
    rx: 0,
    ry: 0,
    rz: 0,
    sx: 1,
    sy: 1,
    sz: 1,
  });
  const [matProps, setMatProps] = useState({
    color: '#E11D48',
    metalness: 0.75,
    roughness: 0.25,
    clearcoat: 0.4,
    emissive: '#000000',
    emissiveIntensity: 0,
    wireframe: false,
    flatShading: false,
  });

  // Lighting, Camera, Physics, Particles, Mathematical 4D
  const [lighting, setLighting] = useState<LightingConfig4D>({
    preset: 'crimson-cinema',
    keyIntensity: 2.3,
    keyColor: '#FFF1E0',
    fillIntensity: 0.85,
    fillColor: '#93C5FD',
    rimIntensity: 2.4,
    rimColor: '#E11D48',
    ambientIntensity: 0.65,
    envIntensity: 1.0,
    shadowsEnabled: true,
    fogDensity: 0.045,
  });
  const [cameraCfg, setCameraCfg] = useState<CameraConfig4D>({
    mode: 'free',
    fov: 45,
    speed: 0.8,
    autoAnimate: false,
    distance: 4.6,
    elevation: 2.1,
  });
  const [physics, setPhysics] = useState<PhysicsConfig4D>({
    enabled: false,
    gravity: 9.8,
    restitution: 0.45,
    drag: 0.15,
    windX: 0,
    floorY: 0,
  });
  const [particles, setParticles] = useState<ParticleConfig4D>({
    enabled: false,
    preset: 'crimson-sparks',
    count: 240,
    speed: 1.1,
    size: 0.08,
    color: '#E11D48',
    turbulence: 0.8,
  });
  const [hyper4D, setHyper4D] = useState<Hyper4DConfig>({
    enabled: false,
    shape: 'tesseract',
    wAngleXW: 0.4,
    wAngleYW: 0.2,
    wAngleZW: 0,
    wSlice: 0,
    spin4DSpeed: 0.75,
    color: '#E11D48',
  });

  // Transfer recording progress
  const [renderProgress, setRenderProgress] = useState<number | null>(null);

  // Three.js Scene Refs
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const orbitRef = useRef<OrbitControls | null>(null);
  const transformCtrlRef = useRef<TransformControls | null>(null);
  const sceneRootRef = useRef<THREE.Group | null>(null);
  const activeModelRef = useRef<THREE.Object3D | null>(null);
  const mixerRef = useRef<THREE.AnimationMixer | null>(null);
  const actionsMapRef = useRef<Map<string, THREE.AnimationAction>>(new Map());
  const skeletonHelperRef = useRef<THREE.SkeletonHelper | null>(null);
  const particlePointsRef = useRef<THREE.Points | null>(null);
  const hyper4DRef = useRef<THREE.LineSegments | null>(null);
  const physicsBodiesRef = useRef<Map<string, PhysicsBodyState>>(new Map());
  const lightsRef = useRef<{
    hemi: THREE.HemisphereLight;
    key: THREE.DirectionalLight;
    fill: THREE.DirectionalLight;
    rim: THREE.DirectionalLight;
  } | null>(null);

  // Live Mutable Refs for Render Loop (Zero React teardown)
  const isPlayingRef = useRef(isPlaying);
  const loopEnabledRef = useRef(loopEnabled);
  const durationRef = useRef(duration);
  const currentTimeRef = useRef(currentTime);
  const playbackSpeedRef = useRef(playbackSpeed);
  const keyframesRef = useRef(keyframes);
  const charMotionRef = useRef(characterMotion);
  const charSpeedRef = useRef(characterSpeed);
  const objAnimRef = useRef(objectAnim);
  const objAnimSpeedRef = useRef(objectAnimSpeed);
  const facialRef = useRef(facial);
  const cameraCfgRef = useRef(cameraCfg);
  const physicsRef = useRef(physics);
  const particlesRef = useRef(particles);
  const hyper4DRefCfg = useRef(hyper4D);
  const selectedUuidRef = useRef(selectedUuid);
  const mocapActiveRef = useRef(mocapActive);
  const mocapMotionRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  isPlayingRef.current = isPlaying;
  loopEnabledRef.current = loopEnabled;
  durationRef.current = duration;
  currentTimeRef.current = currentTime;
  playbackSpeedRef.current = playbackSpeed;
  keyframesRef.current = keyframes;
  charMotionRef.current = characterMotion;
  charSpeedRef.current = characterSpeed;
  objAnimRef.current = objectAnim;
  objAnimSpeedRef.current = objectAnimSpeed;
  facialRef.current = facial;
  cameraCfgRef.current = cameraCfg;
  physicsRef.current = physics;
  particlesRef.current = particles;
  hyper4DRefCfg.current = hyper4D;
  selectedUuidRef.current = selectedUuid;
  mocapActiveRef.current = mocapActive;

  const refreshSceneTree = useCallback(() => {
    const root = sceneRootRef.current;
    if (!root) return;
    setSceneNodes(collectSceneNodes(root));
  }, []);

  const syncInspectorFromUuid = useCallback((uuid: string | null) => {
    const root = sceneRootRef.current;
    if (!root || !uuid) return;
    const obj = root.getObjectByProperty('uuid', uuid);
    if (!obj) return;

    setObjTransform({
      px: Number(obj.position.x.toFixed(3)),
      py: Number(obj.position.y.toFixed(3)),
      pz: Number(obj.position.z.toFixed(3)),
      rx: Number(THREE.MathUtils.radToDeg(obj.rotation.x).toFixed(1)),
      ry: Number(THREE.MathUtils.radToDeg(obj.rotation.y).toFixed(1)),
      rz: Number(THREE.MathUtils.radToDeg(obj.rotation.z).toFixed(1)),
      sx: Number(obj.scale.x.toFixed(3)),
      sy: Number(obj.scale.y.toFixed(3)),
      sz: Number(obj.scale.z.toFixed(3)),
    });

    if (obj instanceof THREE.Mesh) {
      const mat = Array.isArray(obj.material) ? obj.material[0] : obj.material;
      if (mat instanceof THREE.MeshStandardMaterial) {
        setMatProps({
          color: `#${mat.color.getHexString()}`,
          metalness: Number(mat.metalness.toFixed(2)),
          roughness: Number(mat.roughness.toFixed(2)),
          clearcoat:
            mat instanceof THREE.MeshPhysicalMaterial ? Number(mat.clearcoat.toFixed(2)) : 0,
          emissive: `#${mat.emissive.getHexString()}`,
          emissiveIntensity: Number(mat.emissiveIntensity.toFixed(2)),
          wireframe: mat.wireframe,
          flatShading: mat.flatShading,
        });
      }
    }
  }, []);

  const selectSceneObject = useCallback(
    (uuid: string | null) => {
      setSelectedUuid(uuid);
      const tc = transformCtrlRef.current;
      const root = sceneRootRef.current;
      if (!tc || !root) return;
      if (!uuid) {
        tc.detach();
        return;
      }
      const found = root.getObjectByProperty('uuid', uuid);
      if (found && !found.userData?.isEditorHelper) {
        tc.attach(found);
        syncInspectorFromUuid(uuid);
      } else {
        tc.detach();
      }
    },
    [syncInspectorFromUuid]
  );

  // Mount Scene Object into 4D Viewport cleanly
  const loadObjectInto4DScene = useCallback(
    (
      obj: THREE.Object3D,
      title: string,
      animations: THREE.AnimationClip[] = [],
      lightPreset?: LightingPreset4D,
      cameraPose?: Studio4DTransferPayload['cameraPose']
    ) => {
      const scene = sceneRef.current;
      const root = sceneRootRef.current;
      if (!scene || !root) return;

      transformCtrlRef.current?.detach();
      if (skeletonHelperRef.current) {
        scene.remove(skeletonHelperRef.current);
        skeletonHelperRef.current.dispose();
        skeletonHelperRef.current = null;
      }
      if (mixerRef.current) {
        mixerRef.current.stopAllAction();
        mixerRef.current = null;
      }
      actionsMapRef.current.clear();

      // Clear previous sceneRoot children cleanly
      while (root.children.length > 0) {
        const c = root.children[0];
        root.remove(c);
      }

      saveBasePoses(obj);
      root.add(obj);
      activeModelRef.current = obj;
      setModelTitle(title);

      // Setup AnimationMixer for embedded animations
      const mixer = new THREE.AnimationMixer(obj);
      mixerRef.current = mixer;
      const entries: AnimationClipEntry4D[] = animations.map((clip, i) => {
        const act = mixer.clipAction(clip);
        act.enabled = true;
        if (i === 0) {
          act.setEffectiveWeight(1);
          act.play();
        } else {
          act.setEffectiveWeight(0);
          act.play();
        }
        actionsMapRef.current.set(clip.name, act);
        return {
          name: clip.name || `Clip_${i + 1}`,
          duration: Math.max(0.5, clip.duration),
          weight: i === 0 ? 1 : 0,
          speed: 1,
          playing: i === 0,
          loop: true,
        };
      });
      setClipEntries(entries);

      // Detect bones & skeleton
      const bones = findBonesInObject(obj);
      setBoneNames(bones.map((b) => b.name || 'Bone'));
      setSelectedBoneName(bones[0]?.name || '');
      if (bones.length > 0) {
        const skelHelper = new THREE.SkeletonHelper(obj);
        skelHelper.userData.isEditorHelper = true;
        skelHelper.visible = showSkeleton;
        skeletonHelperRef.current = skelHelper;
        scene.add(skelHelper);
      }

      // Restore lighting & camera if transferred from 3D Studio
      if (lightPreset && LIGHTING_PRESETS[lightPreset]) {
        setLighting((prev) => ({ ...prev, ...LIGHTING_PRESETS[lightPreset] }));
      }
      if (cameraPose && cameraRef.current && orbitRef.current) {
        cameraRef.current.position.set(...cameraPose.position);
        cameraRef.current.fov = cameraPose.fov;
        cameraRef.current.updateProjectionMatrix();
        orbitRef.current.target.set(...cameraPose.target);
        orbitRef.current.update();
      }

      physicsBodiesRef.current.clear();
      refreshSceneTree();
      selectSceneObject(obj.uuid);
    },
    [refreshSceneTree, selectSceneObject, showSkeleton]
  );

  // Initialize Three.js WebGL Viewport once
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const w = Math.max(320, container.clientWidth);
    const h = Math.max(240, container.clientHeight);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#09090B');
    scene.fog = new THREE.FogExp2('#09090B', 0.045);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, w / h, 0.05, 150);
    camera.position.set(3.4, 2.2, 4.4);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(w, h);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const envTex = createStudioEnvironment(renderer);
    scene.environment = envTex;

    // 3-Point + Hemisphere Lighting Rig
    const hemi = new THREE.HemisphereLight(0xdbeafe, 0x18181b, 0.65);
    scene.add(hemi);

    const key = new THREE.DirectionalLight(0xfff1e0, 2.3);
    key.position.set(4, 6, 4);
    key.castShadow = !isSoftwareGl;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0005;
    key.shadow.normalBias = 0.02;
    scene.add(key);

    const fill = new THREE.DirectionalLight(0x93c5fd, 0.85);
    fill.position.set(-5, 3, 2);
    scene.add(fill);

    const rim = new THREE.DirectionalLight(0xe11d48, 2.4);
    rim.position.set(0, 4, -5);
    scene.add(rim);

    lightsRef.current = { hemi, key, fill, rim };

    // Ground Stage Grid + Shadow Receiver
    const grid = new THREE.GridHelper(18, 28, 0x3f3f46, 0x18181b);
    grid.userData.isEditorHelper = true;
    scene.add(grid);

    const floor = new THREE.Mesh(
      new THREE.CircleGeometry(8, 48),
      new THREE.MeshStandardMaterial({
        color: 0x0b0b0f,
        roughness: 0.88,
        metalness: 0.12,
      })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.01;
    floor.receiveShadow = true;
    floor.userData.isEditorHelper = true;
    scene.add(floor);

    // Scene Root for Editable 3D/4D Models
    const sceneRoot = new THREE.Group();
    sceneRoot.name = 'Scene_Root';
    sceneRootRef.current = sceneRoot;
    scene.add(sceneRoot);

    // Particle Emitter & Experimental Math 4D Object
    const pts = createParticleSystem4D();
    particlePointsRef.current = pts;
    scene.add(pts);

    const h4 = createHyper4DObject();
    hyper4DRef.current = h4;
    scene.add(h4);

    // OrbitControls & TransformControls
    const orbit = new OrbitControls(camera, renderer.domElement);
    orbit.target.set(0, 1.0, 0);
    orbit.enableDamping = !isSoftwareGl;
    orbit.dampingFactor = 0.06;
    orbitRef.current = orbit;

    const tc = new TransformControls(camera, renderer.domElement);
    tc.setMode('translate');
    tc.addEventListener('dragging-changed', (ev) => {
      orbit.enabled = !ev.value;
    });
    tc.addEventListener('objectChange', () => {
      if (selectedUuidRef.current) {
        syncInspectorFromUuid(selectedUuidRef.current);
      }
    });
    const tcHelper = tc.getHelper();
    tcHelper.userData.isEditorHelper = true;
    scene.add(tcHelper);
    transformCtrlRef.current = tc;

    // Click Raycasting Selection in Viewport
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    let downPos = { x: 0, y: 0 };

    const onPointerDown = (e: PointerEvent) => {
      downPos = { x: e.clientX, y: e.clientY };
    };
    const onPointerUp = (e: PointerEvent) => {
      if (tc.dragging) return;
      const moved = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
      if (moved > 5) return;
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(sceneRoot.children, true);
      const validHit = hits.find((hit) => !hit.object.userData?.isEditorHelper);
      if (validHit) {
        selectSceneObject(validHit.object.uuid);
      }
    };
    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointerup', onPointerUp);

    // Render Loop
    let frameId = 0;
    const clock = new THREE.Clock();
    let lastUiSync = 0;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      const rawDt = Math.min(0.1, clock.getDelta());
      const dt = rawDt * playbackSpeedRef.current;

      if (isPlayingRef.current) {
        let nextT = currentTimeRef.current + dt;
        if (nextT >= durationRef.current) {
          if (loopEnabledRef.current) {
            nextT = nextT % Math.max(0.5, durationRef.current);
          } else {
            nextT = durationRef.current;
            setIsPlaying(false);
          }
        }
        currentTimeRef.current = nextT;
        if (performance.now() - lastUiSync > 50) {
          lastUiSync = performance.now();
          setCurrentTime(nextT);
        }
      }

      const simTime = currentTimeRef.current;

      // 1. Evaluate Embedded Skeletal AnimationMixer
      if (mixerRef.current && actionsMapRef.current.size > 0) {
        if (isPlayingRef.current) {
          mixerRef.current.update(dt);
        } else {
          mixerRef.current.setTime(simTime);
        }
      }

      // 2. Evaluate Keyframes
      if (keyframesRef.current.length > 0) {
        evaluateKeyframes4D(keyframesRef.current, sceneRoot, simTime);
      }

      // 3. Apply Procedural Character Gait / Facial / Object Animations
      const model = activeModelRef.current;
      if (model) {
        if (charMotionRef.current !== 'none') {
          applyProceduralCharacterMotion(model, charMotionRef.current, simTime, charSpeedRef.current);
        }
        applyFacialRigState(model, facialRef.current);

        // Live Webcam Mocap offset if active
        if (mocapActiveRef.current) {
          model.rotation.y += (mocapMotionRef.current.x * 0.9 - model.rotation.y) * 0.12;
          model.rotation.x += (mocapMotionRef.current.y * 0.35 - model.rotation.x) * 0.12;
        }
      }

      if (objAnimRef.current !== 'none') {
        const target =
          (selectedUuidRef.current && sceneRoot.getObjectByProperty('uuid', selectedUuidRef.current)) ||
          activeModelRef.current;
        if (target) {
          applyObjectAnimationPreset(target, objAnimRef.current, simTime, objAnimSpeedRef.current);
        }
      }

      // 4. Step Physics Simulation
      if (physicsRef.current.enabled && isPlayingRef.current) {
        stepPhysicsSimulation4D(sceneRoot, physicsRef.current, physicsBodiesRef.current, rawDt);
      }

      // 5. Step GPU Particles
      if (particlePointsRef.current) {
        stepParticleSystem4D(particlePointsRef.current, particlesRef.current, rawDt);
      }

      // 6. Step Experimental Mathematical 4D Hypercube Projection
      if (hyper4DRef.current) {
        updateHyper4DObject(hyper4DRef.current, hyper4DRefCfg.current, simTime);
      }

      // 7. Animated Camera Modes
      const camCfg = cameraCfgRef.current;
      if (camCfg.autoAnimate && camCfg.mode !== 'free') {
        const ct = simTime * camCfg.speed;
        const d = camCfg.distance;
        if (camCfg.mode === 'cinematic-orbit') {
          camera.position.set(Math.cos(ct * 0.8) * d, camCfg.elevation, Math.sin(ct * 0.8) * d);
        } else if (camCfg.mode === 'dolly-zoom') {
          const z = d * (0.75 + 0.35 * Math.sin(ct * 1.1));
          camera.position.set(z * 0.65, camCfg.elevation, z);
        } else if (camCfg.mode === 'crane-sweep') {
          camera.position.set(
            Math.sin(ct * 0.7) * d * 0.9,
            1.0 + Math.abs(Math.sin(ct * 0.5)) * 2.8,
            d
          );
        } else if (camCfg.mode === 'handheld-chase') {
          camera.position.set(
            2.6 + Math.sin(ct * 3.1) * 0.18,
            camCfg.elevation + Math.cos(ct * 4.3) * 0.12,
            d + Math.sin(ct * 2.2) * 0.25
          );
        }
        orbit.target.set(0, 1.0, 0);
      }

      orbit.update();
      renderer.render(scene, camera);

      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    };
    tick();

    const ro = new ResizeObserver(() => {
      if (!container) return;
      const rw = Math.max(320, container.clientWidth);
      const rh = Math.max(240, container.clientHeight);
      camera.aspect = rw / rh;
      camera.updateProjectionMatrix();
      renderer.setSize(rw, rh);
    });
    ro.observe(container);

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      ro.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('pointerup', onPointerUp);
      tc.dispose();
      orbit.dispose();
      envTex.dispose();
      renderer.dispose();
    };
  }, [selectSceneObject, syncInspectorFromUuid]);

  // Apply incoming 3D -> 4D Transfer Payload or default showcase model
  useEffect(() => {
    if (!sceneRef.current) return;
    if (transferPayload) {
      let obj: THREE.Object3D;
      if (transferPayload.object3D) {
        obj = cloneTransferableObject(transferPayload.object3D);
      } else if (transferPayload.blueprint) {
        obj = buildComposite3DGroup(transferPayload.blueprint, false);
      } else {
        obj = buildComposite3DGroup(createDefaultShowcase3DBlueprint(), false);
      }
      loadObjectInto4DScene(
        obj,
        transferPayload.name,
        transferPayload.animations || [],
        transferPayload.lightingMode,
        transferPayload.cameraPose
      );
      setStatusBanner(
        `Transferred "${transferPayload.name}" from 3D Studio (${transferPayload.format.toUpperCase()} · ${
          (transferPayload.animations || []).length
        } animations preserved)`
      );
    } else if (!activeModelRef.current) {
      const defBp = createDefaultShowcase3DBlueprint();
      const obj = buildComposite3DGroup(defBp, false);
      loadObjectInto4DScene(obj, defBp.title, []);
    }
  }, [transferPayload, loadObjectInto4DScene]);

  // Sync Gizmo Mode & Space & Skeleton Helper
  useEffect(() => {
    const tc = transformCtrlRef.current;
    if (!tc) return;
    if (gizmoMode === 'select') {
      tc.detach();
    } else {
      tc.setMode(gizmoMode);
      tc.setSpace(gizmoSpace);
      if (selectedUuid && sceneRootRef.current) {
        const obj = sceneRootRef.current.getObjectByProperty('uuid', selectedUuid);
        if (obj) tc.attach(obj);
      }
    }
  }, [gizmoMode, gizmoSpace, selectedUuid]);

  useEffect(() => {
    if (skeletonHelperRef.current) {
      skeletonHelperRef.current.visible = showSkeleton;
    }
  }, [showSkeleton]);

  // Sync Lighting Rig Props Live
  useEffect(() => {
    const l = lightsRef.current;
    const s = sceneRef.current;
    if (!l || !s) return;
    l.key.intensity = lighting.keyIntensity;
    l.key.color.set(lighting.keyColor);
    l.key.castShadow = lighting.shadowsEnabled;
    l.fill.intensity = lighting.fillIntensity;
    l.fill.color.set(lighting.fillColor);
    l.rim.intensity = lighting.rimIntensity;
    l.rim.color.set(lighting.rimColor);
    l.hemi.intensity = lighting.ambientIntensity;
    s.environmentIntensity = lighting.envIntensity;
    if (s.fog instanceof THREE.FogExp2) {
      s.fog.density = lighting.fogDensity;
    }
  }, [lighting]);

  // Sync Camera FOV
  useEffect(() => {
    if (cameraRef.current) {
      cameraRef.current.fov = cameraCfg.fov;
      cameraRef.current.updateProjectionMatrix();
    }
  }, [cameraCfg.fov]);

  // Viewport Transform Shortcuts (G = Translate, R = Rotate, S = Scale)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.key.toLowerCase() === 'g') setGizmoMode('translate');
      else if (e.key.toLowerCase() === 'r') setGizmoMode('rotate');
      else if (e.key.toLowerCase() === 's') setGizmoMode('scale');
      else if (e.key === ' ') {
        e.preventDefault();
        setIsPlaying((p) => !p);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Webcam Motion Capture Optical Silhouette Tracker
  useEffect(() => {
    if (!mocapActive) {
      if (mocapVideoRef.current?.srcObject) {
        const stream = mocapVideoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((t) => t.stop());
        mocapVideoRef.current.srcObject = null;
      }
      return;
    }

    let cancelled = false;
    let raf = 0;

    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 160, height: 120 } });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        const vid = document.createElement('video');
        vid.srcObject = stream;
        vid.muted = true;
        await vid.play();
        mocapVideoRef.current = vid;

        const cnv = document.createElement('canvas');
        cnv.width = 64;
        cnv.height = 48;
        mocapCanvasRef.current = cnv;
        const ctx = cnv.getContext('2d', { willReadFrequently: true })!;
        let prevData: Uint8ClampedArray | null = null;

        const loop = () => {
          if (cancelled) return;
          ctx.drawImage(vid, 0, 0, 64, 48);
          const frame = ctx.getImageData(0, 0, 64, 48).data;
          if (prevData) {
            let sumX = 0;
            let sumY = 0;
            let weight = 0;
            for (let y = 0; y < 48; y++) {
              for (let x = 0; x < 64; x++) {
                const idx = (y * 64 + x) * 4;
                const diff =
                  Math.abs(frame[idx] - prevData[idx]) +
                  Math.abs(frame[idx + 1] - prevData[idx + 1]);
                if (diff > 35) {
                  sumX += (x / 64 - 0.5) * diff;
                  sumY += (y / 48 - 0.5) * diff;
                  weight += diff;
                }
              }
            }
            if (weight > 800) {
              mocapMotionRef.current = {
                x: Math.max(-1, Math.min(1, (sumX / weight) * -3.5)),
                y: Math.max(-1, Math.min(1, (sumY / weight) * 3.5)),
              };
            }
          }
          prevData = new Uint8ClampedArray(frame);
          raf = requestAnimationFrame(loop);
        };
        raf = requestAnimationFrame(loop);
      } catch (err) {
        setMocapActive(false);
        setErrorMsg(
          err instanceof Error
            ? `Webcam Motion Capture unavailable: ${err.message}`
            : 'Webcam permission denied.'
        );
      }
    })();

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      if (mocapVideoRef.current?.srcObject) {
        (mocapVideoRef.current.srcObject as MediaStream).getTracks().forEach((t) => t.stop());
      }
    };
  }, [mocapActive]);

  const getSelectedObject = (): THREE.Object3D | null => {
    if (!sceneRootRef.current || !selectedUuid) return activeModelRef.current;
    return sceneRootRef.current.getObjectByProperty('uuid', selectedUuid) || activeModelRef.current;
  };

  // Scene Import (GLB, GLTF, FBX, OBJ) directly into 4D Studio
  const handleImport4DFile = async (file: File) => {
    setErrorMsg(null);
    const ext = file.name.split('.').pop()?.toLowerCase();
    try {
      let obj: THREE.Object3D | null = null;
      let anims: THREE.AnimationClip[] = [];
      if (ext === 'obj') {
        obj = new OBJLoader().parse(await file.text());
      } else if (ext === 'glb' || ext === 'gltf') {
        const gltf = await new GLTFLoader().parseAsync(await file.arrayBuffer(), '');
        obj = gltf.scene;
        anims = gltf.animations || [];
      } else if (ext === 'fbx') {
        const fbx = new FBXLoader().parse(await file.arrayBuffer(), '');
        obj = fbx;
        anims = fbx.animations || [];
      } else {
        throw new Error(`Unsupported format .${ext}. Import GLB, GLTF, FBX, or OBJ.`);
      }

      if (obj) {
        const wrapper = new THREE.Group();
        wrapper.name = file.name.replace(/\.[^.]+$/, '');
        const box = new THREE.Box3().setFromObject(obj);
        const sz = box.getSize(new THREE.Vector3());
        const scale = 2.2 / Math.max(0.001, sz.x, sz.y, sz.z);
        obj.scale.multiplyScalar(scale);
        const sbox = new THREE.Box3().setFromObject(obj);
        const ctr = sbox.getCenter(new THREE.Vector3());
        obj.position.x -= ctr.x;
        obj.position.z -= ctr.z;
        obj.position.y -= sbox.min.y;
        obj.traverse((n) => {
          if (n instanceof THREE.Mesh) {
            n.castShadow = true;
            n.receiveShadow = true;
          }
        });
        wrapper.add(obj);
        loadObjectInto4DScene(wrapper, wrapper.name, anims);
        setStatusBanner(`Imported ${file.name} (${anims.length} animations)`);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to import 3D/4D model.');
    }
  };

  // Add Primitive or Point Light to Scene Composition
  const handleAddSceneElement = (kind: 'box' | 'sphere' | 'cylinder' | 'torus' | 'plane' | 'light') => {
    const root = sceneRootRef.current;
    if (!root) return;
    if (kind === 'light') {
      const pt = new THREE.PointLight('#E11D48', 3, 12);
      pt.name = `PointLight_${root.children.length + 1}`;
      pt.position.set(1.8, 2.2, 1.5);
      pt.castShadow = true;
      root.add(pt);
      saveBasePoses(pt);
      refreshSceneTree();
      selectSceneObject(pt.uuid);
      return;
    }

    const geo =
      kind === 'sphere'
        ? new THREE.SphereGeometry(0.45, 32, 24)
        : kind === 'cylinder'
        ? new THREE.CylinderGeometry(0.4, 0.4, 1, 28)
        : kind === 'torus'
        ? new THREE.TorusGeometry(0.45, 0.14, 18, 36)
        : kind === 'plane'
        ? new THREE.PlaneGeometry(2.5, 2.5)
        : new THREE.BoxGeometry(0.85, 0.85, 0.85);

    const mat = new THREE.MeshPhysicalMaterial({
      color: '#E11D48',
      metalness: 0.6,
      roughness: 0.28,
      clearcoat: 0.4,
      side: kind === 'plane' ? THREE.DoubleSide : THREE.FrontSide,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = `${kind.toUpperCase()}_${root.children.length + 1}`;
    mesh.position.set((Math.random() - 0.5) * 2.4, kind === 'plane' ? 1.2 : 1.5, (Math.random() - 0.5) * 1.6);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    root.add(mesh);
    saveBasePoses(mesh);
    refreshSceneTree();
    selectSceneObject(mesh.uuid);
  };

  // Update Object Transform from Properties Panel
  const updateSelectedTransform = (field: keyof typeof objTransform, val: number) => {
    const obj = getSelectedObject();
    if (!obj) return;
    const next = { ...objTransform, [field]: val };
    setObjTransform(next);
    obj.position.set(next.px, next.py, next.pz);
    obj.rotation.set(
      THREE.MathUtils.degToRad(next.rx),
      THREE.MathUtils.degToRad(next.ry),
      THREE.MathUtils.degToRad(next.rz)
    );
    obj.scale.set(
      Math.max(0.02, next.sx),
      Math.max(0.02, next.sy),
      Math.max(0.02, next.sz)
    );
    obj.userData.basePose4D = {
      pos: [obj.position.x, obj.position.y, obj.position.z],
      rot: [obj.rotation.x, obj.rotation.y, obj.rotation.z],
      scale: [obj.scale.x, obj.scale.y, obj.scale.z],
    };
  };

  // Update Material Properties (Selected Mesh or Whole Model)
  const applyMaterialChange = (
    updates: Partial<typeof matProps>,
    scope: 'selected' | 'all' = 'selected'
  ) => {
    const next = { ...matProps, ...updates };
    setMatProps(next);
    const target = scope === 'all' ? sceneRootRef.current : getSelectedObject();
    if (!target) return;

    target.traverse((node) => {
      if (node instanceof THREE.Mesh && !node.userData?.isEditorHelper) {
        const mats = Array.isArray(node.material) ? node.material : [node.material];
        mats.forEach((m) => {
          if (m instanceof THREE.MeshStandardMaterial) {
            m.color.set(next.color);
            m.metalness = next.metalness;
            m.roughness = next.roughness;
            m.emissive.set(next.emissive);
            m.emissiveIntensity = next.emissiveIntensity;
            m.wireframe = next.wireframe;
            m.flatShading = next.flatShading;
            if (m instanceof THREE.MeshPhysicalMaterial) {
              m.clearcoat = next.clearcoat;
            }
            m.needsUpdate = true;
          }
        });
      }
    });
  };

  // Add Transform or Material Keyframe at Current Playhead Time
  const addKeyframeAtPlayhead = (category: 'transform' | 'material') => {
    const obj = getSelectedObject();
    if (!obj) return;
    const t = Number(currentTime.toFixed(2));
    const additions: Keyframe4D[] = [];
    const mk = (prop: Keyframe4D['property'], value: number) => ({
      id: `kf4d-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      objectUuid: obj.uuid,
      objectName: obj.name || 'Node',
      property: prop,
      time: t,
      value,
      interpolation: kfInterpolation,
    });

    if (category === 'transform') {
      additions.push(
        mk('position.x', obj.position.x),
        mk('position.y', obj.position.y),
        mk('position.z', obj.position.z),
        mk('rotation.x', obj.rotation.x),
        mk('rotation.y', obj.rotation.y),
        mk('rotation.z', obj.rotation.z),
        mk('scale.x', obj.scale.x),
        mk('scale.y', obj.scale.y),
        mk('scale.z', obj.scale.z)
      );
    } else {
      additions.push(
        mk('material.metalness', matProps.metalness),
        mk('material.roughness', matProps.roughness),
        mk('material.emissiveIntensity', matProps.emissiveIntensity)
      );
    }

    setKeyframes((prev) => {
      const filtered = prev.filter(
        (k) => !(k.objectUuid === obj.uuid && Math.abs(k.time - t) < 0.04 && additions.some((a) => a.property === k.property))
      );
      return [...filtered, ...additions].sort((a, b) => a.time - b.time);
    });
    setStatusBanner(`Keyframe added for ${obj.name} at ${t.toFixed(2)}s`);
  };

  // Multi-Format Export (GLB / GLTF / FBX / OBJ)
  const handleExport4D = async (format: 'glb' | 'gltf' | 'fbx' | 'obj') => {
    const root = sceneRootRef.current;
    if (!root) return;
    setErrorMsg(null);
    setStatusBanner(`Exporting 4D Scene as .${format.toUpperCase()}...`);
    try {
      const clips = Array.from(actionsMapRef.current.values()).map((a) => a.getClip());
      const safeName = modelTitle.replace(/[^a-zA-Z0-9_-]/g, '_') || 'RED_EFFECT_4D';
      let blob: Blob;
      let mimeMap: Record<string, string[]>;

      if (format === 'glb') {
        blob = await export4DToGLB(root, clips);
        mimeMap = { 'model/gltf-binary': ['.glb'] };
      } else if (format === 'gltf') {
        blob = await export4DToGLTF(root, clips);
        mimeMap = { 'model/gltf+json': ['.gltf'] };
      } else if (format === 'fbx') {
        blob = export4DToFBXAscii(root);
        mimeMap = { 'text/plain': ['.fbx'] };
      } else {
        blob = export4DToOBJ(root);
        mimeMap = { 'text/plain': ['.obj'] };
      }

      const res = await saveBlobWithWindowsDialog(
        blob,
        `${safeName}.${format}`,
        mimeMap,
        `${format.toUpperCase()} 3D/4D Model`
      );
      setStatusBanner(res.cancelled ? null : `Saved ${res.fileName}`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : '4D Export failed.');
      setStatusBanner(null);
    }
  };

  // Transfer Animated 4D Render Sequence to RED EFFECT Video Editor or Motion Graphics
  const handleSendToRedEffectTimeline = async (target: 'editing' | 'motion') => {
    const renderer = rendererRef.current;
    const scene = sceneRef.current;
    const camera = cameraRef.current;
    if (!renderer || !scene || !camera) return;

    setErrorMsg(null);
    setRenderProgress(0);
    const prevGizmo = gizmoMode;
    transformCtrlRef.current?.detach();

    try {
      const recDuration = Math.min(8, Math.max(3, duration));
      const canvas = renderer.domElement;
      const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';

      const stream = canvas.captureStream(30);
      const recorder = new MediaRecorder(stream, {
        mimeType: mime,
        videoBitsPerSecond: 8_000_000,
      });
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };
      const done = new Promise<Blob>((resolve) => {
        recorder.onstop = () => resolve(new Blob(chunks, { type: mime }));
      });

      setCurrentTime(0);
      currentTimeRef.current = 0;
      setIsPlaying(true);
      isPlayingRef.current = true;
      recorder.start(100);

      const steps = 20;
      const stepMs = (recDuration * 1000) / steps;
      for (let i = 1; i <= steps; i++) {
        await new Promise((r) => setTimeout(r, stepMs));
        setRenderProgress(Math.round((i / steps) * 95));
      }

      recorder.stop();
      const blob = await done;
      setRenderProgress(100);

      const safeTitle = `${modelTitle.replace(/\s+/g, '_')}_4D.webm`;
      onSendVideoToTimeline(target, safeTitle, blob, recDuration, canvas.width, canvas.height);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to transfer 4D sequence.');
    } finally {
      setRenderProgress(null);
      setGizmoMode(prevGizmo);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#18181A] text-[#F4F4F5] text-xs overflow-hidden">
      {/* 4D Studio Action Toolbar */}
      <div className="h-10 px-3 bg-[#222225] border-b border-[#3E3E44] flex items-center justify-between gap-2 overflow-x-auto shrink-0">
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1.5 pr-2 border-r border-[#3E3E44]">
            <Boxes className="w-4 h-4 text-[#D4D4D8]" />
            <span className="font-display font-semibold text-[#F4F4F5] whitespace-nowrap">
              4D STUDIO
            </span>
          </div>

          {/* Transform Gizmo Tools */}
          <div className="flex items-center gap-0.5 bg-[#18181A] p-0.5 rounded border border-[#3E3E44]">
            {(
              [
                { id: 'select', icon: MousePointer2, label: 'Select' },
                { id: 'translate', icon: Move, label: 'Move (G)' },
                { id: 'rotate', icon: RotateCw, label: 'Rotate (R)' },
                { id: 'scale', icon: Maximize2, label: 'Scale (S)' },
              ] as const
            ).map((tool) => {
              const Icon = tool.icon;
              return (
                <button
                  key={tool.id}
                  type="button"
                  onClick={() => setGizmoMode(tool.id)}
                  title={tool.label}
                  className={`px-2 py-1 rounded flex items-center gap-1 text-[11px] whitespace-nowrap ${
                    gizmoMode === tool.id
                      ? 'bg-[#52525B] text-white'
                      : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span className="hidden xl:inline">{tool.label.split(' ')[0]}</span>
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={() => setGizmoSpace((s) => (s === 'world' ? 'local' : 'world'))}
            className="px-2 py-1 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] uppercase whitespace-nowrap"
          >
            {gizmoSpace}
          </button>

          <button
            type="button"
            onClick={() => setShowSkeleton((s) => !s)}
            className={`px-2 py-1 rounded border text-[11px] flex items-center gap-1 whitespace-nowrap ${
              showSkeleton
                ? 'border-[#A1A1AA]/60 bg-[#71717A]/20 text-[#E4E4E7]'
                : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA]'
            }`}
          >
            <Bone className="w-3 h-3" />
            Rig
          </button>

          {/* Scene Composition Quick Add */}
          <div className="flex items-center gap-1 pl-2 border-l border-[#3E3E44]">
            {(['box', 'sphere', 'torus', 'light'] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => handleAddSceneElement(item)}
                className="px-2 py-1 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5] capitalize whitespace-nowrap"
              >
                + {item}
              </button>
            ))}
          </div>
        </div>

        {/* Import / Multi-Format Export / Transfer to Video & Motion Graphics */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="px-2.5 py-1 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] flex items-center gap-1 whitespace-nowrap"
          >
            <Upload className="w-3.5 h-3.5" />
            Import
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".glb,.gltf,.fbx,.obj"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void handleImport4DFile(f);
              e.target.value = '';
            }}
            className="hidden"
          />

          <div className="flex items-center gap-0.5 bg-[#18181A] p-0.5 rounded border border-[#3E3E44]">
            {(['glb', 'gltf', 'fbx', 'obj'] as const).map((fmt) => (
              <button
                key={fmt}
                type="button"
                onClick={() => void handleExport4D(fmt)}
                title={`Export 4D Scene as .${fmt.toUpperCase()}`}
                className="px-2 py-0.5 text-[10px] font-mono-tabular uppercase text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] rounded flex items-center gap-1"
              >
                <Download className="w-2.5 h-2.5" />
                {fmt}
              </button>
            ))}
          </div>

          <button
            type="button"
            disabled={renderProgress !== null}
            onClick={() => void handleSendToRedEffectTimeline('editing')}
            className="px-2.5 py-1 bg-[#52525B] hover:bg-[#6B7280] disabled:opacity-50 text-white font-semibold rounded text-[11px] flex items-center gap-1 whitespace-nowrap"
          >
            <Film className="w-3.5 h-3.5" />
            To Video Editor
          </button>
          <button
            type="button"
            disabled={renderProgress !== null}
            onClick={() => void handleSendToRedEffectTimeline('motion')}
            className="px-2.5 py-1 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#A1A1AA]/40 disabled:opacity-50 text-[#E4E4E7] font-medium rounded text-[11px] flex items-center gap-1 whitespace-nowrap"
          >
            <Layers className="w-3.5 h-3.5" />
            To Motion Graphics
          </button>
        </div>
      </div>

      {/* Main 4D Workspace Split: Left Dock | Center Viewport | Right Inspector */}
      <div className="flex-1 min-h-0 flex overflow-hidden">
        {/* LEFT DOCK: Scene Explorer + Lighting/Camera/Physics/4D Controls */}
        <aside className="w-64 shrink-0 bg-[#222225] border-r border-[#3E3E44] flex flex-col min-h-0">
          {/* Scene Explorer */}
          <div className="h-[44%] flex flex-col border-b border-[#3E3E44] min-h-0">
            <div className="px-3 py-1.5 bg-[#2C2C30] border-b border-[#3E3E44] flex items-center justify-between">
              <span className="font-display font-semibold text-[11px] uppercase tracking-wider text-[#F4F4F5]">
                Scene Explorer
              </span>
              <span className="text-[10px] font-mono-tabular text-[#A1A1AA]">
                {sceneNodes.length} nodes
              </span>
            </div>
            <div className="flex-1 overflow-y-auto p-1.5 space-y-0.5">
              {sceneNodes.map((node) => (
                <div
                  key={node.uuid}
                  onClick={() => selectSceneObject(node.uuid)}
                  style={{ paddingLeft: `${8 + Math.min(4, node.depth) * 12}px` }}
                  className={`pr-1.5 py-1 rounded flex items-center justify-between gap-1 cursor-pointer text-[11px] ${
                    selectedUuid === node.uuid
                      ? 'bg-[#71717A]/20 border border-[#A1A1AA] text-[#F4F4F5]'
                      : 'hover:bg-[#2C2C30] text-[#F4F4F5] border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="text-[9px] font-mono-tabular uppercase px-1 bg-[#18181A] border border-[#3E3E44] text-[#A1A1AA] rounded shrink-0">
                      {node.isBone
                        ? 'BN'
                        : node.isSkinnedMesh
                        ? 'SK'
                        : node.isLight
                        ? 'LT'
                        : node.hasGeometry
                        ? 'MS'
                        : 'GR'}
                    </span>
                    <span className="truncate">{node.name}</span>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      const obj = sceneRootRef.current?.getObjectByProperty('uuid', node.uuid);
                      if (obj) {
                        obj.visible = !obj.visible;
                        refreshSceneTree();
                      }
                    }}
                    className="text-[#A1A1AA] hover:text-[#F4F4F5] shrink-0"
                  >
                    {node.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Lighting / Camera / Physics / Math 4D Tabs */}
          <div className="flex-1 flex flex-col min-h-0">
            <div className="grid grid-cols-4 bg-[#2C2C30] border-b border-[#3E3E44] shrink-0">
              {(
                [
                  { id: 'lighting', label: 'Light', icon: Sun },
                  { id: 'camera', label: 'Cam', icon: Camera },
                  { id: 'physics', label: 'Sim', icon: Activity },
                  { id: 'math4d', label: '4D', icon: Sparkles },
                ] as const
              ).map((t) => {
                const Icon = t.icon;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setLeftTab(t.id)}
                    className={`py-1.5 text-[10px] font-medium flex items-center justify-center gap-1 border-b-2 ${
                      leftTab === t.id
                        ? 'border-[#A1A1AA] text-[#F4F4F5] bg-[#222225]'
                        : 'border-transparent text-[#A1A1AA] hover:text-[#F4F4F5]'
                    }`}
                  >
                    <Icon className="w-3 h-3" />
                    {t.label}
                  </button>
                );
              })}
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-3 text-[11px]">
              {leftTab === 'lighting' && (
                <>
                  <div className="grid grid-cols-2 gap-1">
                    {(Object.keys(LIGHTING_PRESETS) as LightingPreset4D[]).map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() =>
                          setLighting((prev) => ({ ...prev, ...LIGHTING_PRESETS[p] }))
                        }
                        className={`px-2 py-1 rounded text-[10px] capitalize border ${
                          lighting.preset === p
                            ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#E4E4E7]'
                            : 'bg-[#2C2C30] border-[#3E3E44] text-[#F4F4F5]'
                        }`}
                      >
                        {p.replace('-', ' ')}
                      </button>
                    ))}
                  </div>
                  <div className="space-y-2">
                    <label className="flex items-center justify-between text-[#A1A1AA]">
                      <span>Key Intensity ({lighting.keyIntensity.toFixed(1)})</span>
                      <input
                        type="color"
                        value={lighting.keyColor}
                        onChange={(e) => setLighting({ ...lighting, keyColor: e.target.value })}
                        className="w-5 h-4 bg-transparent border-0"
                      />
                    </label>
                    <input
                      type="range"
                      min={0}
                      max={5}
                      step={0.1}
                      value={lighting.keyIntensity}
                      onChange={(e) =>
                        setLighting({ ...lighting, keyIntensity: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                    <label className="flex items-center justify-between text-[#A1A1AA]">
                      <span>Rim Intensity ({lighting.rimIntensity.toFixed(1)})</span>
                      <input
                        type="color"
                        value={lighting.rimColor}
                        onChange={(e) => setLighting({ ...lighting, rimColor: e.target.value })}
                        className="w-5 h-4 bg-transparent border-0"
                      />
                    </label>
                    <input
                      type="range"
                      min={0}
                      max={5}
                      step={0.1}
                      value={lighting.rimIntensity}
                      onChange={(e) =>
                        setLighting({ ...lighting, rimIntensity: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                    <label className="flex items-center justify-between text-[#A1A1AA]">
                      <span>Environment IBL ({lighting.envIntensity.toFixed(1)})</span>
                    </label>
                    <input
                      type="range"
                      min={0}
                      max={2.5}
                      step={0.05}
                      value={lighting.envIntensity}
                      onChange={(e) =>
                        setLighting({ ...lighting, envIntensity: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                    <label className="flex items-center justify-between pt-1 cursor-pointer">
                      <span className="text-[#F4F4F5]">Cast Shadows</span>
                      <input
                        type="checkbox"
                        checked={lighting.shadowsEnabled}
                        onChange={(e) =>
                          setLighting({ ...lighting, shadowsEnabled: e.target.checked })
                        }
                        className="accent-[#A1A1AA]"
                      />
                    </label>
                  </div>
                </>
              )}

              {leftTab === 'camera' && (
                <div className="space-y-3">
                  <div>
                    <div className="text-[#A1A1AA] mb-1">Camera Animation Path</div>
                    <select
                      value={cameraCfg.mode}
                      onChange={(e) => {
                        const mode = e.target.value as CameraAnimMode4D;
                        setCameraCfg({ ...cameraCfg, mode, autoAnimate: mode !== 'free' });
                      }}
                      className="w-full px-2 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value="free">Free Orbit Control</option>
                      <option value="cinematic-orbit">Cinematic Orbit</option>
                      <option value="dolly-zoom">Dolly Push-In / Out</option>
                      <option value="crane-sweep">Crane Sweep Up/Down</option>
                      <option value="handheld-chase">Handheld Dynamic</option>
                    </select>
                  </div>

                  <label className="flex items-center justify-between cursor-pointer">
                    <span className="text-[#F4F4F5]">Animate Camera</span>
                    <input
                      type="checkbox"
                      checked={cameraCfg.autoAnimate}
                      onChange={(e) =>
                        setCameraCfg({ ...cameraCfg, autoAnimate: e.target.checked })
                      }
                      className="accent-[#A1A1AA]"
                    />
                  </label>

                  <div>
                    <div className="flex justify-between text-[#A1A1AA]">
                      <span>Lens FOV</span>
                      <span className="font-mono-tabular">{cameraCfg.fov}°</span>
                    </div>
                    <input
                      type="range"
                      min={25}
                      max={85}
                      value={cameraCfg.fov}
                      onChange={(e) =>
                        setCameraCfg({ ...cameraCfg, fov: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-[#A1A1AA]">
                      <span>Motion Speed</span>
                      <span className="font-mono-tabular">{cameraCfg.speed.toFixed(1)}×</span>
                    </div>
                    <input
                      type="range"
                      min={0.2}
                      max={3}
                      step={0.1}
                      value={cameraCfg.speed}
                      onChange={(e) =>
                        setCameraCfg({ ...cameraCfg, speed: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setCameraCfg({ ...cameraCfg, mode: 'free', autoAnimate: false });
                      if (cameraRef.current && orbitRef.current) {
                        cameraRef.current.position.set(3.4, 2.2, 4.4);
                        orbitRef.current.target.set(0, 1.0, 0);
                        orbitRef.current.update();
                      }
                    }}
                    className="w-full py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5]"
                  >
                    Reset Camera View
                  </button>
                </div>
              )}

              {leftTab === 'physics' && (
                <div className="space-y-3">
                  <div className="p-2 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-2">
                    <label className="flex items-center justify-between font-medium text-[#F4F4F5] cursor-pointer">
                      <span>Physics Simulation</span>
                      <input
                        type="checkbox"
                        checked={physics.enabled}
                        onChange={(e) =>
                          setPhysics({ ...physics, enabled: e.target.checked })
                        }
                        className="accent-[#A1A1AA]"
                      />
                    </label>
                    <div>
                      <div className="flex justify-between text-[#A1A1AA] text-[10px]">
                        <span>Gravity</span>
                        <span>{physics.gravity} m/s²</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={20}
                        step={0.5}
                        value={physics.gravity}
                        onChange={(e) =>
                          setPhysics({ ...physics, gravity: Number(e.target.value) })
                        }
                        className="w-full"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-[#A1A1AA] text-[10px]">
                        <span>Bounce (Restitution)</span>
                        <span>{physics.restitution}</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={0.95}
                        step={0.05}
                        value={physics.restitution}
                        onChange={(e) =>
                          setPhysics({ ...physics, restitution: Number(e.target.value) })
                        }
                        className="w-full"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        physicsBodiesRef.current.clear();
                        if (sceneRootRef.current) restoreBasePoses(sceneRootRef.current);
                      }}
                      className="w-full py-1 bg-[#18181A] hover:bg-[#3E3E44]/60 border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5] flex items-center justify-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" />
                      Reset Physics Pose
                    </button>
                  </div>

                  <div className="p-2 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-2">
                    <label className="flex items-center justify-between font-medium text-[#F4F4F5] cursor-pointer">
                      <span>3D Particle Emitter</span>
                      <input
                        type="checkbox"
                        checked={particles.enabled}
                        onChange={(e) =>
                          setParticles({ ...particles, enabled: e.target.checked })
                        }
                        className="accent-[#A1A1AA]"
                      />
                    </label>
                    <select
                      value={particles.preset}
                      onChange={(e) =>
                        setParticles({
                          ...particles,
                          enabled: e.target.value !== 'none',
                          preset: e.target.value as ParticlePreset4D,
                        })
                      }
                      className="w-full px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value="crimson-sparks">Crimson Sparks</option>
                      <option value="volumetric-smoke">Volumetric Smoke</option>
                      <option value="fire-embers">Fire Embers</option>
                      <option value="cyber-rain">Cyber Rain</option>
                      <option value="stardust">Orbital Stardust</option>
                    </select>
                    <div className="flex justify-between text-[#A1A1AA] text-[10px]">
                      <span>Count</span>
                      <span>{particles.count}</span>
                    </div>
                    <input
                      type="range"
                      min={50}
                      max={600}
                      step={25}
                      value={particles.count}
                      onChange={(e) =>
                        setParticles({ ...particles, count: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>
                </div>
              )}

              {leftTab === 'math4d' && (
                <div className="space-y-3">
                  <div className="p-2 bg-[#71717A]/15 border border-[#A1A1AA]/40 rounded text-[10px] text-[#F4F4F5] leading-relaxed">
                    Experimental mathematical 4D geometry (X, Y, Z, W) projected into 3D space via 4D orthogonal rotations.
                  </div>
                  <label className="flex items-center justify-between font-medium text-[#F4F4F5] cursor-pointer">
                    <span>Enable 4D Projection</span>
                    <input
                      type="checkbox"
                      checked={hyper4D.enabled}
                      onChange={(e) => setHyper4D({ ...hyper4D, enabled: e.target.checked })}
                      className="accent-[#A1A1AA]"
                    />
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(['tesseract', '16-cell'] as const).map((shp) => (
                      <button
                        key={shp}
                        type="button"
                        onClick={() => setHyper4D({ ...hyper4D, enabled: true, shape: shp })}
                        className={`py-1 rounded text-[10px] border capitalize ${
                          hyper4D.shape === shp
                            ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                            : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA]'
                        }`}
                      >
                        {shp}
                      </button>
                    ))}
                  </div>
                  <div>
                    <div className="flex justify-between text-[#A1A1AA] text-[10px]">
                      <span>XW Plane Angle</span>
                      <span>{hyper4D.wAngleXW.toFixed(2)} rad</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={6.28}
                      step={0.05}
                      value={hyper4D.wAngleXW}
                      onChange={(e) =>
                        setHyper4D({ ...hyper4D, wAngleXW: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-[#A1A1AA] text-[10px]">
                      <span>W-Axis Slice Offset</span>
                      <span>{hyper4D.wSlice.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={-1.2}
                      max={1.2}
                      step={0.05}
                      value={hyper4D.wSlice}
                      onChange={(e) =>
                        setHyper4D({ ...hyper4D, wSlice: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-[#A1A1AA] text-[10px]">
                      <span>4D W-Spin Speed</span>
                      <span>{hyper4D.spin4DSpeed.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={2.5}
                      step={0.05}
                      value={hyper4D.spin4DSpeed}
                      onChange={(e) =>
                        setHyper4D({ ...hyper4D, spin4DSpeed: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </aside>

        {/* CENTER 3D/4D VIEWPORT */}
        <section className="flex-1 min-w-0 relative bg-[#000000] overflow-hidden">
          <div ref={mountRef} className="w-full h-full" />

          {/* Clean Top-Left Viewport Info */}
          <div className="pointer-events-none absolute top-3 left-3 bg-[#222225]/90 border border-[#3E3E44] px-3 py-1.5 rounded">
            <div className="font-display font-semibold text-[#F4F4F5]">{modelTitle}</div>
            <div className="text-[10px] font-mono-tabular text-[#A1A1AA]">
              {sceneNodes.filter((n) => n.hasGeometry).length} meshes · {boneNames.length} bones ·{' '}
              {clipEntries.length} clips
            </div>
          </div>

          {/* Clean Top-Right Timecode */}
          <div className="pointer-events-none absolute top-3 right-3 bg-[#222225]/90 border border-[#3E3E44] px-3 py-1.5 rounded font-mono-tabular text-[11px] text-[#D4D4D8]">
            {currentTime.toFixed(2)}s / {duration.toFixed(2)}s
          </div>

          {/* Render Transfer Progress Bar */}
          {renderProgress !== null && (
            <div className="absolute top-14 left-1/2 -translate-x-1/2 bg-[#222225] border border-[#A1A1AA]/60 px-4 py-2 rounded shadow-2xl flex items-center gap-3">
              <Loader2 className="w-4 h-4 animate-spin text-[#D4D4D8]" />
              <span className="text-[#F4F4F5] font-medium">
                Rendering 4D Temporal Sequence... {renderProgress}%
              </span>
            </div>
          )}

          {/* Status or Error Toast */}
          {(statusBanner || errorMsg) && (
            <div
              className={`absolute bottom-3 left-3 right-3 px-3 py-1.5 rounded border flex items-center justify-between text-[11px] ${
                errorMsg
                  ? 'bg-rose-950/90 border-rose-500/50 text-rose-200'
                  : 'bg-[#222225]/95 border-[#3E3E44] text-emerald-400'
              }`}
            >
              <div className="flex items-center gap-1.5 truncate">
                {errorMsg ? (
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                )}
                <span className="truncate">{errorMsg || statusBanner}</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setErrorMsg(null);
                  setStatusBanner(null);
                }}
                className="text-[#A1A1AA] hover:text-[#F4F4F5] ml-2 shrink-0"
              >
                Dismiss
              </button>
            </div>
          )}
        </section>

        {/* RIGHT DOCK: Object Properties, Materials, Mesh/UV, Rig/Face */}
        <aside className="w-80 shrink-0 bg-[#222225] border-l border-[#3E3E44] flex flex-col min-h-0">
          {/* Inspector Tabs */}
          <div className="flex-1 flex flex-col min-h-0">
            <div className="grid grid-cols-4 bg-[#2C2C30] border-b border-[#3E3E44] shrink-0">
              {(
                [
                  { id: 'object', label: 'Object', icon: Sliders },
                  { id: 'material', label: 'Material', icon: Sparkles },
                  { id: 'mesh', label: 'Mesh/UV', icon: Layers },
                  { id: 'rig', label: 'Rig/Face', icon: Bone },
                ] as const
              ).map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setRightTab(tab.id)}
                    className={`py-1.5 text-[10px] font-medium flex items-center justify-center gap-1 border-b-2 ${
                      rightTab === tab.id
                        ? 'border-[#A1A1AA] text-[#F4F4F5] bg-[#222225]'
                        : 'border-transparent text-[#A1A1AA] hover:text-[#F4F4F5]'
                    }`}
                  >
                    <Icon className="w-3 h-3" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-3 text-[11px]">
              {rightTab === 'object' && (
                <>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#F4F4F5] truncate">
                      {getSelectedObject()?.name || 'No Selection'}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          const obj = getSelectedObject();
                          if (obj && obj !== activeModelRef.current && sceneRootRef.current) {
                            const cloned = cloneTransferableObject(obj);
                            cloned.name = `${obj.name}_Copy`;
                            cloned.position.x += 0.6;
                            sceneRootRef.current.add(cloned);
                            refreshSceneTree();
                            selectSceneObject(cloned.uuid);
                          }
                        }}
                        title="Duplicate Selected"
                        className="p-1 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5]"
                      >
                        <Copy className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const obj = getSelectedObject();
                          if (obj && obj.parent && obj !== activeModelRef.current) {
                            transformCtrlRef.current?.detach();
                            obj.parent.remove(obj);
                            refreshSceneTree();
                            selectSceneObject(activeModelRef.current?.uuid || null);
                          }
                        }}
                        title="Delete Selected"
                        className="p-1 bg-[#2C2C30] hover:bg-rose-600/30 border border-[#3E3E44] rounded text-rose-400"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Position / Rotation / Scale */}
                  {(
                    [
                      { label: 'Position', keys: ['px', 'py', 'pz'] as const, step: 0.05 },
                      { label: 'Rotation (°)', keys: ['rx', 'ry', 'rz'] as const, step: 1 },
                      { label: 'Scale', keys: ['sx', 'sy', 'sz'] as const, step: 0.05 },
                    ] as const
                  ).map((grp) => (
                    <div key={grp.label} className="space-y-1">
                      <div className="text-[10px] text-[#A1A1AA] uppercase tracking-wider">
                        {grp.label}
                      </div>
                      <div className="grid grid-cols-3 gap-1.5">
                        {grp.keys.map((k, idx) => (
                          <div key={k} className="flex items-center bg-[#18181A] border border-[#3E3E44] rounded px-1.5 py-1">
                            <span className="text-[9px] text-[#A1A1AA] mr-1">
                              {['X', 'Y', 'Z'][idx]}
                            </span>
                            <input
                              type="number"
                              step={grp.step}
                              value={objTransform[k]}
                              onChange={(e) => updateSelectedTransform(k, Number(e.target.value))}
                              className="w-full bg-transparent text-[#F4F4F5] font-mono-tabular text-[10px] focus:outline-none"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}

                  {/* Procedural Object Temporal Motion */}
                  <div className="pt-2 border-t border-[#3E3E44] space-y-2">
                    <div className="text-[10px] text-[#A1A1AA] uppercase tracking-wider">
                      Object Motion Loop
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      {(['none', 'rotate-y', 'orbit', 'bounce', 'pulse-scale', 'hover'] as const).map(
                        (anim) => (
                          <button
                            key={anim}
                            type="button"
                            onClick={() => {
                              setObjectAnim(anim);
                              if (anim !== 'none') setIsPlaying(true);
                            }}
                            className={`px-1.5 py-1 rounded text-[10px] border capitalize ${
                              objectAnim === anim
                                ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                                : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA]'
                            }`}
                          >
                            {anim.replace('-', ' ')}
                          </button>
                        )
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => addKeyframeAtPlayhead('transform')}
                      className="w-full py-1.5 bg-[#71717A]/20 hover:bg-[#71717A]/30 border border-[#A1A1AA]/50 rounded text-[#E4E4E7] font-medium"
                    >
                      + Keyframe Transform at {currentTime.toFixed(2)}s
                    </button>
                  </div>
                </>
              )}

              {rightTab === 'material' && (
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[#F4F4F5]">Base Color</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={matProps.color}
                        onChange={(e) => applyMaterialChange({ color: e.target.value }, 'selected')}
                        className="w-7 h-5 bg-transparent border-0 cursor-pointer"
                      />
                      <button
                        type="button"
                        onClick={() => applyMaterialChange({}, 'all')}
                        className="px-2 py-0.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]"
                      >
                        Apply All
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[#A1A1AA] text-[10px]">
                      <span>Metalness</span>
                      <span>{matProps.metalness.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.02}
                      value={matProps.metalness}
                      onChange={(e) =>
                        applyMaterialChange({ metalness: Number(e.target.value) }, 'selected')
                      }
                      className="w-full"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-[#A1A1AA] text-[10px]">
                      <span>Roughness</span>
                      <span>{matProps.roughness.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0.04}
                      max={1}
                      step={0.02}
                      value={matProps.roughness}
                      onChange={(e) =>
                        applyMaterialChange({ roughness: Number(e.target.value) }, 'selected')
                      }
                      className="w-full"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-[#A1A1AA] text-[10px]">
                      <span>Clearcoat</span>
                      <span>{matProps.clearcoat.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.02}
                      value={matProps.clearcoat}
                      onChange={(e) =>
                        applyMaterialChange({ clearcoat: Number(e.target.value) }, 'selected')
                      }
                      className="w-full"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-[#A1A1AA] text-[10px]">Emissive Glow</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={matProps.emissive}
                        onChange={(e) =>
                          applyMaterialChange({ emissive: e.target.value }, 'selected')
                        }
                        className="w-6 h-4 bg-transparent border-0"
                      />
                      <input
                        type="range"
                        min={0}
                        max={3}
                        step={0.1}
                        value={matProps.emissiveIntensity}
                        onChange={(e) =>
                          applyMaterialChange(
                            { emissiveIntensity: Number(e.target.value) },
                            'selected'
                          )
                        }
                        className="w-24"
                      />
                    </div>
                  </div>

                  <div className="pt-1 border-t border-[#3E3E44] space-y-1.5">
                    <div className="text-[10px] text-[#A1A1AA] uppercase">Surface Texture</div>
                    <div className="grid grid-cols-3 gap-1">
                      {(['none', 'brushed-metal', 'carbon-weave', 'grid', 'checker'] as const).map(
                        (tex) => (
                          <button
                            key={tex}
                            type="button"
                            onClick={() => {
                              const obj = getSelectedObject();
                              if (obj instanceof THREE.Mesh) {
                                applyProceduralFinishTexture(obj, tex, matProps.color);
                              } else {
                                obj?.traverse((c) => {
                                  if (c instanceof THREE.Mesh) {
                                    applyProceduralFinishTexture(c, tex, matProps.color);
                                  }
                                });
                              }
                            }}
                            className="px-1.5 py-1 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5] capitalize"
                          >
                            {tex.replace('-', ' ')}
                          </button>
                        )
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => textureInputRef.current?.click()}
                      className="w-full py-1 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]"
                    >
                      Upload Image Texture (PNG/JPG)
                    </button>
                    <input
                      ref={textureInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        const obj = getSelectedObject();
                        if (f && obj) {
                          if (obj instanceof THREE.Mesh) void applyImageFileAsTexture(obj, f);
                          else {
                            obj.traverse((c) => {
                              if (c instanceof THREE.Mesh) void applyImageFileAsTexture(c, f);
                            });
                          }
                        }
                        e.target.value = '';
                      }}
                      className="hidden"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => addKeyframeAtPlayhead('material')}
                    className="w-full py-1.5 bg-[#71717A]/20 hover:bg-[#71717A]/30 border border-[#A1A1AA]/50 rounded text-[#E4E4E7] font-medium"
                  >
                    + Keyframe Material at {currentTime.toFixed(2)}s
                  </button>
                </div>
              )}

              {rightTab === 'mesh' && (
                <div className="space-y-2.5">
                  <div className="text-[10px] text-[#A1A1AA]">
                    Geometry, Normal &amp; UV Operations on Selected Mesh
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        const obj = getSelectedObject();
                        if (obj instanceof THREE.Mesh) {
                          applyVertexNoiseSculpt(obj, 0.05);
                          setStatusBanner(`Sculpt displaced vertices on ${obj.name}`);
                        }
                      }}
                      className="px-2 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5]"
                    >
                      Sculpt Displace
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const obj = getSelectedObject();
                        if (obj instanceof THREE.Mesh) {
                          applyBoxUVProjection(obj);
                          setStatusBanner(`Recomputed UVs for ${obj.name}`);
                        }
                      }}
                      className="px-2 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5]"
                    >
                      Project UVs
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const obj = getSelectedObject();
                        if (obj instanceof THREE.Mesh) {
                          obj.geometry.computeVertexNormals();
                          applyMaterialChange({ flatShading: !matProps.flatShading });
                        }
                      }}
                      className="px-2 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5]"
                    >
                      Toggle Flat / Smooth
                    </button>
                    <button
                      type="button"
                      onClick={() => applyMaterialChange({ wireframe: !matProps.wireframe }, 'all')}
                      className="px-2 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5]"
                    >
                      Toggle Wireframe
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const obj = getSelectedObject();
                        if (obj) {
                          const box = new THREE.Box3().setFromObject(obj);
                          if (!box.isEmpty()) obj.position.y -= box.min.y;
                          syncInspectorFromUuid(obj.uuid);
                        }
                      }}
                      className="px-2 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5]"
                    >
                      Ground to Floor (Y=0)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (sceneRootRef.current) restoreBasePoses(sceneRootRef.current);
                        if (selectedUuid) syncInspectorFromUuid(selectedUuid);
                      }}
                      className="px-2 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5]"
                    >
                      Reset Base Pose
                    </button>
                  </div>
                </div>
              )}

              {rightTab === 'rig' && (
                <div className="space-y-3">
                  {/* Character Motion Presets */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-[#A1A1AA] uppercase">
                        Character Motion
                      </span>
                      <span className="text-[10px] font-mono-tabular text-[#A1A1AA]">
                        {characterSpeed.toFixed(1)}×
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-1">
                      {(['none', 'idle', 'walk', 'run', 'jump', 'dance', 'wave'] as const).map(
                        (m) => (
                          <button
                            key={m}
                            type="button"
                            onClick={() => {
                              setCharacterMotion(m);
                              if (m !== 'none') setIsPlaying(true);
                            }}
                            className={`px-1.5 py-1 rounded text-[10px] border capitalize ${
                              characterMotion === m
                                ? 'bg-[#52525B] text-white border-[#A1A1AA]'
                                : 'bg-[#2C2C30] border-[#3E3E44] text-[#F4F4F5]'
                            }`}
                          >
                            {m}
                          </button>
                        )
                      )}
                    </div>
                    <input
                      type="range"
                      min={0.3}
                      max={2.5}
                      step={0.1}
                      value={characterSpeed}
                      onChange={(e) => setCharacterSpeed(Number(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Skeleton & Auto-Rig */}
                  <div className="pt-2 border-t border-[#3E3E44] space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-[#A1A1AA] uppercase">
                        Rigging ({boneNames.length} bones)
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          if (!activeModelRef.current || !sceneRef.current) return;
                          const res = autoRigObject(activeModelRef.current);
                          const names = findBonesInObject(activeModelRef.current).map((b) => b.name);
                          setBoneNames(names);
                          setSelectedBoneName(names[0] || '');
                          if (!skeletonHelperRef.current) {
                            const h = new THREE.SkeletonHelper(activeModelRef.current);
                            h.userData.isEditorHelper = true;
                            h.visible = true;
                            skeletonHelperRef.current = h;
                            sceneRef.current.add(h);
                          }
                          setShowSkeleton(true);
                          refreshSceneTree();
                          setStatusBanner(
                            res.alreadyRigged
                              ? `Existing skeleton active (${res.boneCount} bones)`
                              : `Attached ${res.boneCount} humanoid rig bones`
                          );
                        }}
                        className="px-2 py-0.5 bg-[#71717A]/20 hover:bg-[#71717A]/30 border border-[#A1A1AA]/50 rounded text-[10px] text-[#E4E4E7]"
                      >
                        Auto-Rig Bones
                      </button>
                    </div>
                    {boneNames.length > 0 && (
                      <div className="space-y-1">
                        <select
                          value={selectedBoneName}
                          onChange={(e) => setSelectedBoneName(e.target.value)}
                          className="w-full px-2 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]"
                        >
                          {boneNames.map((bn, idx) => (
                            <option key={`${bn}-${idx}`} value={bn}>
                              {bn}
                            </option>
                          ))}
                        </select>
                        <div className="grid grid-cols-3 gap-1">
                          {(['X', 'Y', 'Z'] as const).map((axis, idx) => (
                            <input
                              key={axis}
                              type="range"
                              min={-90}
                              max={90}
                              value={boneRot[idx]}
                              onChange={(e) => {
                                const deg = Number(e.target.value);
                                const next: [number, number, number] = [...boneRot] as [
                                  number,
                                  number,
                                  number,
                                ];
                                next[idx] = deg;
                                setBoneRot(next);
                                const bone = activeModelRef.current
                                  ? findBonesInObject(activeModelRef.current).find(
                                      (b) => b.name === selectedBoneName
                                    )
                                  : null;
                                if (bone) {
                                  bone.rotation.set(
                                    THREE.MathUtils.degToRad(next[0]),
                                    THREE.MathUtils.degToRad(next[1]),
                                    THREE.MathUtils.degToRad(next[2])
                                  );
                                }
                              }}
                              title={`Bone ${axis} Rotation`}
                              className="w-full"
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Facial Expression Morph Targets */}
                  <div className="pt-2 border-t border-[#3E3E44] space-y-1.5">
                    <div className="text-[10px] text-[#A1A1AA] uppercase">Facial Animation</div>
                    {(
                      [
                        { k: 'smile', label: 'Smile' },
                        { k: 'blink', label: 'Blink' },
                        { k: 'browRaise', label: 'Brow Raise' },
                        { k: 'jawOpen', label: 'Jaw Open' },
                        { k: 'surprise', label: 'Surprise' },
                      ] as const
                    ).map((f) => (
                      <div key={f.k} className="flex items-center gap-2">
                        <span className="w-16 text-[10px] text-[#A1A1AA]">{f.label}</span>
                        <input
                          type="range"
                          min={0}
                          max={1}
                          step={0.05}
                          value={facial[f.k]}
                          onChange={(e) =>
                            setFacial({ ...facial, [f.k]: Number(e.target.value) })
                          }
                          className="flex-1"
                        />
                      </div>
                    ))}
                  </div>

                  {/* Motion Capture Integration */}
                  <div className="pt-2 border-t border-[#3E3E44]">
                    <button
                      type="button"
                      onClick={() => setMocapActive((v) => !v)}
                      className={`w-full py-1.5 rounded border font-medium flex items-center justify-center gap-1.5 ${
                        mocapActive
                          ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                          : 'bg-[#2C2C30] hover:bg-[#2E323E] border-[#3E3E44] text-[#F4F4F5]'
                      }`}
                    >
                      <Video className="w-3.5 h-3.5" />
                      {mocapActive ? 'Stop Webcam Motion Capture' : 'Live Webcam Motion Capture'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </aside>
      </div>

      {/* BOTTOM DOCK: 4D Temporal Timeline & Animation Blending Editor */}
      <footer className="h-44 shrink-0 bg-[#222225] border-t border-[#3E3E44] flex flex-col">
        {/* Timeline Transport Bar */}
        <div className="h-8 px-3 bg-[#2C2C30] border-b border-[#3E3E44] flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsPlaying((p) => !p)}
              className="px-2.5 py-1 bg-[#52525B] hover:bg-[#6B7280] text-white rounded text-[11px] font-medium flex items-center gap-1"
            >
              {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              {isPlaying ? 'Pause' : 'Play'}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsPlaying(false);
                setCurrentTime(0);
                currentTimeRef.current = 0;
              }}
              className="p-1 bg-[#18181A] hover:bg-[#3E3E44]/60 border border-[#3E3E44] rounded text-[#F4F4F5]"
              title="Stop & Rewind"
            >
              <Square className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => setLoopEnabled((l) => !l)}
              className={`p-1 rounded border ${
                loopEnabled
                  ? 'border-[#A1A1AA]/60 bg-[#71717A]/20 text-[#E4E4E7]'
                  : 'border-[#3E3E44] bg-[#18181A] text-[#A1A1AA]'
              }`}
              title="Loop Playback"
            >
              <Repeat className="w-3 h-3" />
            </button>

            <div className="flex items-center gap-1.5 pl-2 border-l border-[#3E3E44] text-[11px]">
              <span className="text-[#A1A1AA]">Speed</span>
              <select
                value={playbackSpeed}
                onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
                className="px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] font-mono-tabular"
              >
                <option value={0.5}>0.5x</option>
                <option value={1}>1.0x</option>
                <option value={1.5}>1.5x</option>
                <option value={2}>2.0x</option>
              </select>
              <span className="text-[#A1A1AA] ml-2">Duration</span>
              <input
                type="number"
                min={3}
                max={30}
                value={duration}
                onChange={(e) => setDuration(Math.max(3, Math.min(30, Number(e.target.value) || 8)))}
                className="w-12 px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] font-mono-tabular"
              />
              <span className="text-[#A1A1AA]">s</span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px]">
            <span className="text-[#A1A1AA]">Interpolation</span>
            <select
              value={kfInterpolation}
              onChange={(e) =>
                setKfInterpolation(e.target.value as 'linear' | 'smooth' | 'step')
              }
              className="px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5]"
            >
              <option value="smooth">Smooth</option>
              <option value="linear">Linear</option>
              <option value="step">Step</option>
            </select>
            <button
              type="button"
              onClick={() => addKeyframeAtPlayhead('transform')}
              className="px-2 py-0.5 bg-[#18181A] hover:bg-[#3E3E44]/60 border border-[#3E3E44] rounded text-[#F4F4F5] flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-[#D4D4D8]" />
              Keyframe
            </button>
          </div>
        </div>

        {/* Bottom Content: Animation Clip Blending Mixer (Left) + Keyframe Scrubber Tracks (Right) */}
        <div className="flex-1 min-h-0 flex overflow-hidden">
          {/* Animation Blending Panel */}
          <div className="w-72 shrink-0 border-r border-[#3E3E44] p-2 overflow-y-auto space-y-1.5">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
              Animation Clips &amp; Blending
            </div>
            {clipEntries.length === 0 ? (
              <div className="text-[10px] text-[#A1A1AA] leading-relaxed">
                No embedded GLB/FBX clips loaded. Use Character Motion presets, Object Loop, or add Keyframes on the timeline.
              </div>
            ) : (
              clipEntries.map((clip, i) => (
                <div
                  key={`${clip.name}-${i}`}
                  className="p-1.5 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-1"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-medium text-[#F4F4F5] truncate">
                      {clip.name}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const act = actionsMapRef.current.get(clip.name);
                        const nextPlay = !clip.playing;
                        if (act) {
                          if (nextPlay) act.play();
                          else act.stop();
                        }
                        setClipEntries((prev) =>
                          prev.map((c, idx) => (idx === i ? { ...c, playing: nextPlay } : c))
                        );
                      }}
                      className={`px-1.5 py-0.5 rounded text-[9px] ${
                        clip.playing ? 'bg-[#52525B] text-white' : 'bg-[#18181A] text-[#A1A1AA]'
                      }`}
                    >
                      {clip.playing ? 'Active' : 'Muted'}
                    </button>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-[#A1A1AA]">
                    <span>Blend</span>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={clip.weight}
                      onChange={(e) => {
                        const w = Number(e.target.value);
                        const act = actionsMapRef.current.get(clip.name);
                        if (act) act.setEffectiveWeight(w);
                        setClipEntries((prev) =>
                          prev.map((c, idx) => (idx === i ? { ...c, weight: w } : c))
                        );
                      }}
                      className="flex-1"
                    />
                    <span className="font-mono-tabular w-7 text-right">
                      {Math.round(clip.weight * 100)}%
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Temporal Scrubber & Keyframe Diamond Tracks */}
          <div className="flex-1 min-w-0 flex flex-col overflow-hidden p-2 space-y-1.5">
            {/* Scrubber Bar */}
            <div className="flex items-center gap-3">
              <span className="w-24 text-[10px] font-mono-tabular text-[#D4D4D8] shrink-0">
                t = {currentTime.toFixed(2)}s
              </span>
              <input
                type="range"
                min={0}
                max={duration}
                step={0.02}
                value={currentTime}
                onChange={(e) => {
                  const t = Number(e.target.value);
                  setCurrentTime(t);
                  currentTimeRef.current = t;
                }}
                className="flex-1 cursor-pointer"
              />
            </div>

            {/* Keyframe Tracks */}
            <div className="flex-1 overflow-y-auto space-y-1">
              {(
                [
                  { label: 'Position', prefix: 'position.' },
                  { label: 'Rotation', prefix: 'rotation.' },
                  { label: 'Scale', prefix: 'scale.' },
                  { label: 'Material', prefix: 'material.' },
                ] as const
              ).map((track) => {
                const trackKfs = keyframes.filter((k) => k.property.startsWith(track.prefix));
                const uniqueTimes = Array.from(
                  new Set(trackKfs.map((k) => Number(k.time.toFixed(2))))
                );

                return (
                  <div
                    key={track.label}
                    className="h-6 bg-[#18181A] border border-[#3E3E44] rounded flex items-center"
                  >
                    <div className="w-24 px-2 text-[10px] text-[#F4F4F5] border-r border-[#3E3E44] shrink-0">
                      {track.label}
                    </div>
                    <div className="flex-1 relative h-full mx-2">
                      {/* Playhead needle */}
                      <div
                        style={{ left: `${(currentTime / Math.max(0.1, duration)) * 100}%` }}
                        className="absolute top-0 bottom-0 w-px bg-[#52525B] pointer-events-none"
                      />
                      {uniqueTimes.map((kt) => (
                        <button
                          key={kt}
                          type="button"
                          onClick={() => {
                            setCurrentTime(kt);
                            currentTimeRef.current = kt;
                          }}
                          onContextMenu={(e) => {
                            e.preventDefault();
                            setKeyframes((prev) =>
                              prev.filter(
                                (k) =>
                                  !(
                                    k.property.startsWith(track.prefix) &&
                                    Math.abs(k.time - kt) < 0.03
                                  )
                              )
                            );
                          }}
                          title={`Keyframe at ${kt.toFixed(2)}s (Right-click to remove)`}
                          style={{ left: `${(kt / Math.max(0.1, duration)) * 100}%` }}
                          className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 bg-[#52525B] hover:bg-[#A1A1AA] rotate-45 border border-white/60"
                        />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
