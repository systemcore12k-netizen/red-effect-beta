import React, { useEffect, useRef } from 'react';
import { Play, Sliders, Trash2, Layers } from 'lucide-react';
import {
  createDefaultRedRebellionCustomization,
  RED_REBELLION_META,
  SavedCustomTemplate,
  TrailerTemplateCustomization,
} from '../services/trailerTemplate';

interface TemplatesBrowserTabProps {
  customTemplates: SavedCustomTemplate[];
  onOpenTemplate: (customization?: TrailerTemplateCustomization) => void;
  onCustomizeTemplate: (customization?: TrailerTemplateCustomization) => void;
  onDeleteCustomTemplate: (id: string) => void;
}

const TrailerLivePreviewCanvas: React.FC<{
  customization: TrailerTemplateCustomization;
}> = ({ customization }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const w = 320;
    const h = 180;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    const start = performance.now();
    const sections = customization.sections;
    const accent = customization.accentColor || '#E50914';
    const primary = customization.primaryColor || '#FFFFFF';

    const drawFrame = (now: number) => {
      // Smooth 10s preview loop stepping across key trailer beats
      const elapsed = (((now - start) / 1000) * customization.animationSpeed) % 10;
      const beatTime = (elapsed / 10) * 20;
      const activeSec =
        sections.find((s) => beatTime >= s.startTime && beatTime < s.endTime) ||
        sections[sections.length - 1];
      const localBeat = beatTime - activeSec.startTime;

      ctx.clearRect(0, 0, w, h);
      // Obsidian crimson gradient sky
      const bg = ctx.createRadialGradient(w * 0.5, h * 0.55, 8, w * 0.5, h * 0.5, w * 0.72);
      bg.addColorStop(0, beatTime >= 18 ? '#2A040A' : '#3C060E');
      bg.addColorStop(0.55, '#120307');
      bg.addColorStop(1, '#050507');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      // Red smoke plumes + embers
      for (let i = 0; i < 16; i++) {
        const px = ((i * 53 + beatTime * 22) % (w + 20)) - 10;
        const py = h - ((i * 37 + beatTime * 34) % (h + 10));
        ctx.fillStyle = i % 3 === 0 ? 'rgba(255, 220, 180, 0.55)' : `${accent}66`;
        ctx.beginPath();
        ctx.arc(px, py, (i % 3) + 1.1, 0, Math.PI * 2);
        ctx.fill();
      }

      // Impact red flash right at beat transitions
      if (localBeat < 0.35 && activeSec.startTime > 0) {
        ctx.fillStyle = accent;
        ctx.globalAlpha = (1 - localBeat / 0.35) * 0.42;
        ctx.fillRect(0, 0, w, h);
        ctx.globalAlpha = 1;
      }

      // Subtle camera shake offset on impact beats
      const shakeAmp =
        beatTime >= 3 && beatTime < 18
          ? Math.exp(-localBeat * 2.5) * 3.5 * customization.shakeStrength
          : 0.5;
      const ox = Math.sin(beatTime * 38) * shakeAmp;
      const oy = Math.cos(beatTime * 46) * shakeAmp;

      // Zoom punch curve
      const zoomScale =
        localBeat < 0.4
          ? 1.25 - (localBeat / 0.4) * 0.25
          : 1.0 + Math.min(0.12, localBeat * 0.04);

      ctx.save();
      ctx.translate(w * 0.5 + ox, h * 0.48 + oy);
      ctx.scale(zoomScale, zoomScale);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = `900 ${activeSec.mainText.length > 14 ? 17 : 22}px "${customization.fontFamily}", sans-serif`;

      // RGB glitch split highlight on Chaos & Impact sections
      if (beatTime >= 3 && beatTime < 17.8 && localBeat < 0.85) {
        ctx.fillStyle = '#00F0FF';
        ctx.fillText(activeSec.mainText, 2.2, 0);
        ctx.fillStyle = accent;
        ctx.fillText(activeSec.mainText, -2.2, 0);
      }

      ctx.shadowColor = accent;
      ctx.shadowBlur = 14;
      ctx.fillStyle = primary;
      ctx.fillText(activeSec.mainText, 0, 0);

      ctx.shadowBlur = 0;
      ctx.font = '600 8px "JetBrains Mono", monospace';
      ctx.fillStyle = accent;
      ctx.fillText(activeSec.subText, 0, 22);
      ctx.restore();

      // Beat progress thin crimson progress bar at bottom edge
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.fillRect(0, h - 2, w, 2);
      ctx.fillStyle = accent;
      ctx.fillRect(0, h - 2, w * (beatTime / 20), 2);

      rafId = requestAnimationFrame(drawFrame);
    };

    rafId = requestAnimationFrame(drawFrame);
    return () => cancelAnimationFrame(rafId);
  }, [customization]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full aspect-video bg-[#050507] block rounded-sm border border-white/[0.08]"
    />
  );
};

export const TemplatesBrowserTab: React.FC<TemplatesBrowserTabProps> = ({
  customTemplates,
  onOpenTemplate,
  onCustomizeTemplate,
  onDeleteCustomTemplate,
}) => {
  const defaultCfg = createDefaultRedRebellionCustomization();

  return (
    <div className="flex-1 min-h-0 overflow-y-auto p-2.5 space-y-3 text-xs text-[#F4F4F5] bg-[#222225]">
      {/* Header Metadata Strip */}
      <div className="flex items-center justify-between text-[10px] text-[#A1A1AA] border-b border-[#3E3E44] pb-1.5">
        <span className="font-semibold uppercase tracking-wider text-[#F4F4F5]">
          Trailer &amp; Title Templates
        </span>
        <span className="font-mono-tabular">16:9 · 1080p · 60 FPS</span>
      </div>

      {/* Primary Built-in RED REBELLION Card */}
      <div className="bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA] rounded p-2 space-y-2 transition-colors">
        <div className="relative group">
          <TrailerLivePreviewCanvas customization={defaultCfg} />
          <div className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-xs bg-black/75 border border-[#3E3E44] font-mono-tabular text-[9px] text-[#F4F4F5]">
            20s · 12 LAYERS
          </div>
          <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-xs bg-[#52525B] font-mono-tabular text-[9px] font-semibold text-white">
            READY-MADE
          </div>
        </div>

        <div className="space-y-0.5 px-0.5">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-xs font-bold text-[#F4F4F5] tracking-wide">
              {RED_REBELLION_META.name}
            </h3>
            <span className="text-[10px] font-mono-tabular text-[#A1A1AA] shrink-0">
              {RED_REBELLION_META.category}
            </span>
          </div>
          <p className="text-[10px] text-[#A1A1AA] leading-relaxed">
            {RED_REBELLION_META.description}
          </p>
        </div>

        <div className="flex items-center gap-1.5 pt-0.5">
          <button
            type="button"
            onClick={() => onOpenTemplate()}
            className="flex-1 py-1.5 px-2.5 bg-[#52525B] hover:bg-[#6B7280] text-white font-semibold rounded flex items-center justify-center gap-1.5 whitespace-nowrap"
          >
            <Play className="w-3 h-3 fill-current" />
            Open Template
          </button>
          <button
            type="button"
            onClick={() => onCustomizeTemplate()}
            className="py-1.5 px-2.5 bg-[#18181A] hover:bg-[#343439] border border-[#3E3E44] text-[#F4F4F5] font-medium rounded flex items-center justify-center gap-1 whitespace-nowrap"
          >
            <Sliders className="w-3 h-3 text-[#D4D4D8]" />
            Customize
          </button>
        </div>
      </div>

      {/* Custom Saved User Templates */}
      {customTemplates.length > 0 && (
        <div className="space-y-2 pt-1">
          <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
            <Layers className="w-3 h-3 text-amber-400" />
            Saved Custom Templates ({customTemplates.length})
          </div>
          {customTemplates.map((tpl) => (
            <div
              key={tpl.id}
              className="bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded p-2 space-y-2"
            >
              <TrailerLivePreviewCanvas customization={tpl.customization} />
              <div className="flex items-center justify-between gap-2 px-0.5">
                <div className="min-w-0">
                  <div className="text-[11px] font-semibold text-[#F4F4F5] truncate">{tpl.name}</div>
                  <div className="text-[9px] font-mono-tabular text-[#A1A1AA]">
                    {tpl.category} · {tpl.duration}s · {tpl.fps} FPS
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onDeleteCustomTemplate(tpl.id)}
                  title="Delete Saved Template"
                  className="p-1 text-[#A1A1AA] hover:text-rose-400 rounded shrink-0"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => onOpenTemplate(tpl.customization)}
                  className="flex-1 py-1 px-2 bg-[#52525B] hover:bg-[#6B7280] text-white font-medium rounded flex items-center justify-center gap-1 whitespace-nowrap"
                >
                  <Play className="w-3 h-3 fill-current" />
                  Open
                </button>
                <button
                  type="button"
                  onClick={() => onCustomizeTemplate(tpl.customization)}
                  className="py-1 px-2 bg-[#18181A] hover:bg-[#343439] border border-[#3E3E44] text-[#F4F4F5] rounded flex items-center justify-center gap-1 whitespace-nowrap"
                >
                  <Sliders className="w-3 h-3" />
                  Edit
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
