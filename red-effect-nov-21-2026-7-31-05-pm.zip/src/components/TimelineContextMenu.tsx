import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import {
  ChevronRight,
  Copy,
  Scissors,
  ClipboardPaste,
  Trash2,
  CopyPlus,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  VolumeX,
  Volume2,
  Sparkles,
  Link2,
  Unlink,
  Diamond,
  Type,
  Layers,
  Sliders,
  Plus,
  Edit3,
  Clock,
  Bookmark,
  Maximize2,
  Magnet,
  Film,
  Music,
  Square,
  Crosshair,
  Palette,
} from 'lucide-react';
import { AnimationEasing } from '../types/effects';
import { Keyframe, MarkerColor, TimelineClip } from '../types/studio';

export type ContextMenuTarget =
  | { kind: 'clip'; clipId: string; x: number; y: number; time: number }
  | { kind: 'text'; clipId: string; x: number; y: number; time: number }
  | { kind: 'null'; clipId: string; x: number; y: number; time: number }
  | { kind: 'keyframe'; clipId: string; keyframeId: string; x: number; y: number }
  | { kind: 'empty'; trackId?: string; x: number; y: number; time: number };

interface TimelineContextMenuProps {
  target: ContextMenuTarget | null;
  clips: TimelineClip[];
  selectedClipIds: string[];
  hasClipboard: boolean;
  hasCopiedKeyframe: boolean;
  snapEnabled: boolean;
  onClose: () => void;
  // Actions
  onCutClip: (clipId: string) => void;
  onCopyClip: (clipId: string) => void;
  onPasteClip: (time?: number) => void;
  onDuplicateClip: (clipId: string) => void;
  onSplitClip: (clipId: string) => void;
  onTrimStartToPlayhead: (clipId: string) => void;
  onTrimEndToPlayhead: (clipId: string) => void;
  onToggleEnableClip: (clipId: string) => void;
  onToggleMuteClip: (clipId: string) => void;
  onToggleLockClip: (clipId: string) => void;
  onToggleHideClip: (clipId: string) => void;
  onOpenSpeedDuration: (clipId: string) => void;
  onQuickAddEffect: (clipId: string, effectType: string) => void;
  onQuickApplyPreset: (clipId: string, presetId: string) => void;
  onDetachAudio: (clipId: string) => void;
  onCreateCompoundClip: () => void;
  onSetClipParent: (clipId: string, parentId: string | undefined) => void;
  onRenameClip: (clipId: string) => void;
  onDeleteClip: (clipId: string) => void;
  // Text specific
  onEditText: (clipId: string) => void;
  onConvertTextToShape: (clipId: string) => void;
  onAddTextAnimation: (clipId: string, anim: NonNullable<TimelineClip['textProps']>['animation']) => void;
  // Null specific
  onSetNullColor: (clipId: string, color: MarkerColor) => void;
  onAddNullKeyframe: (clipId: string, kind: 'position' | 'scale' | 'rotation') => void;
  onSelectNullChildren: (clipId: string) => void;
  onToggleNullChildrenVisibility: (clipId: string) => void;
  // Keyframe specific
  onSetKeyframeEasing: (clipId: string, keyframeId: string, easing: AnimationEasing | 'hold') => void;
  onCopyKeyframe: (clipId: string, keyframeId: string) => void;
  onPasteKeyframe: (clipId: string) => void;
  onDeleteKeyframe: (clipId: string, keyframeId: string) => void;
  // Empty area specific
  onAddNullClip: () => void;
  onAddTextClip: () => void;
  onAddShapeClip: () => void;
  onAddEffectLayer: () => void;
  onAddTrack: (kind: 'video' | 'audio' | 'text' | 'null' | 'fx') => void;
  onAddMarkerAtTime: (time: number) => void;
  onZoomToFit: () => void;
  onToggleSnap: () => void;
}

const COLOR_SWATCHES: Array<{ id: MarkerColor; label: string; hex: string }> = [
  { id: 'rose', label: 'Crimson', hex: '#E50914' },
  { id: 'amber', label: 'Amber', hex: '#F59E0B' },
  { id: 'emerald', label: 'Emerald', hex: '#10B981' },
  { id: 'sky', label: 'Cyan', hex: '#38BDF8' },
  { id: 'violet', label: 'Violet', hex: '#A855F7' },
];

const QUICK_EFFECTS: Array<{ id: string; label: string }> = [
  { id: 'gaussian-blur', label: 'Gaussian Blur' },
  { id: 'glow', label: 'Cinematic Glow' },
  { id: 'rgb-split', label: 'RGB Split' },
  { id: 'chromatic-aberration', label: 'Chromatic Aberration' },
  { id: 'film-grain', label: 'Film Grain' },
  { id: 'vignette', label: 'Vignette' },
  { id: 'drop-shadow', label: 'Drop Shadow' },
];

const QUICK_PRESETS: Array<{ id: string; label: string }> = [
  { id: 'preset-velocity-punch', label: 'Velocity Punch' },
  { id: 'preset-trending-3d-tilt', label: '3D Tilt Reveal' },
  { id: 'preset-cyber-glitch', label: 'Cyber Glitch Impact' },
  { id: 'preset-anime-aura', label: 'Anime Crimson Aura' },
  { id: 'preset-crimson-blockbuster', label: 'Crimson Blockbuster' },
];

export const TimelineContextMenu: React.FC<TimelineContextMenuProps> = ({
  target,
  clips,
  selectedClipIds,
  hasClipboard,
  hasCopiedKeyframe,
  snapEnabled,
  onClose,
  onCutClip,
  onCopyClip,
  onPasteClip,
  onDuplicateClip,
  onSplitClip,
  onTrimStartToPlayhead,
  onTrimEndToPlayhead,
  onToggleEnableClip,
  onToggleMuteClip,
  onToggleLockClip,
  onToggleHideClip,
  onOpenSpeedDuration,
  onQuickAddEffect,
  onQuickApplyPreset,
  onDetachAudio,
  onCreateCompoundClip,
  onSetClipParent,
  onRenameClip,
  onDeleteClip,
  onEditText,
  onConvertTextToShape,
  onAddTextAnimation,
  onSetNullColor,
  onAddNullKeyframe,
  onSelectNullChildren,
  onToggleNullChildrenVisibility,
  onSetKeyframeEasing,
  onCopyKeyframe,
  onPasteKeyframe,
  onDeleteKeyframe,
  onAddNullClip,
  onAddTextClip,
  onAddShapeClip,
  onAddEffectLayer,
  onAddTrack,
  onAddMarkerAtTime,
  onZoomToFit,
  onToggleSnap,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number }>({ left: 0, top: 0 });
  const [openSub, setOpenSub] = useState<string | null>(null);

  useLayoutEffect(() => {
    if (!target || !menuRef.current) return;
    const rect = menuRef.current.getBoundingClientRect();
    const pad = 10;
    const left = Math.min(target.x, Math.max(pad, window.innerWidth - rect.width - pad));
    const top = Math.min(target.y, Math.max(pad, window.innerHeight - rect.height - pad));
    setPos({ left, top });
  }, [target]);

  useEffect(() => {
    setOpenSub(null);
  }, [target]);

  useEffect(() => {
    if (!target) return;
    const onDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('mousedown', onDown);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('mousedown', onDown);
      window.removeEventListener('keydown', onKey);
    };
  }, [target, onClose]);

  if (!target) return null;

  const clip =
    target.kind !== 'empty' ? clips.find((c) => c.id === target.clipId) || null : null;
  const nullCandidates = clips.filter(
    (c) => c.type === 'null' && c.id !== clip?.id
  );
  const otherParents = clips.filter(
    (c) => c.type !== 'null' && c.type !== 'audio' && c.id !== clip?.id
  );

  const itemCls =
    'w-full px-3 py-1.5 text-left text-[11px] text-[#F4F4F5] hover:bg-[#52525B] hover:text-white flex items-center justify-between gap-4 transition-colors';
  const subTriggerCls =
    'w-full px-3 py-1.5 text-left text-[11px] text-[#F4F4F5] hover:bg-[#2C2C30] hover:text-white flex items-center justify-between gap-4 transition-colors relative';
  const dangerCls =
    'w-full px-3 py-1.5 text-left text-[11px] text-rose-400 hover:bg-rose-600 hover:text-white flex items-center justify-between gap-4 transition-colors';
  const sepCls = 'my-1 border-t border-[#3E3E44]';

  const renderParentSubmenu = (clipId: string) => (
    <div
      className="relative"
      onMouseEnter={() => setOpenSub('parent')}
      onMouseLeave={() => setOpenSub((s) => (s === 'parent' ? null : s))}
    >
      <button type="button" className={subTriggerCls}>
        <span className="flex items-center gap-2">
          <Link2 className="w-3.5 h-3.5 text-[#D4D4D8]" />
          Parent to Null / Layer
        </span>
        <ChevronRight className="w-3.5 h-3.5 text-[#A1A1AA]" />
      </button>
      {openSub === 'parent' && (
        <div className="absolute left-full top-0 ml-0.5 w-52 max-h-64 overflow-y-auto bg-[#222225] border border-[#3E3E44] rounded shadow-2xl py-1 z-[110]">
          {nullCandidates.length === 0 && otherParents.length === 0 ? (
            <div className="px-3 py-2 text-[10px] text-[#A1A1AA]">No parent layers available</div>
          ) : (
            <>
              {nullCandidates.length > 0 && (
                <div className="px-2.5 py-1 text-[9px] uppercase tracking-wider text-[#A1A1AA] font-semibold">
                  Null Objects
                </div>
              )}
              {nullCandidates.map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => {
                    onSetClipParent(clipId, n.id);
                    onClose();
                  }}
                  className={itemCls}
                >
                  <span className="truncate flex items-center gap-1.5">
                    <Crosshair className="w-3 h-3 text-[#D4D4D8]" />
                    {n.name}
                  </span>
                  {clip?.parentClipId === n.id && (
                    <span className="text-[9px] text-emerald-400 font-bold">ACTIVE</span>
                  )}
                </button>
              ))}
              {otherParents.length > 0 && (
                <div className="px-2.5 py-1 text-[9px] uppercase tracking-wider text-[#A1A1AA] font-semibold border-t border-[#3E3E44] mt-1">
                  Other Layers
                </div>
              )}
              {otherParents.slice(0, 10).map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    onSetClipParent(clipId, p.id);
                    onClose();
                  }}
                  className={itemCls}
                >
                  <span className="truncate">{p.name}</span>
                  {clip?.parentClipId === p.id && (
                    <span className="text-[9px] text-emerald-400 font-bold">ACTIVE</span>
                  )}
                </button>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  );

  const renderEffectsSubmenu = (clipId: string) => (
    <div
      className="relative"
      onMouseEnter={() => setOpenSub('effect')}
      onMouseLeave={() => setOpenSub((s) => (s === 'effect' ? null : s))}
    >
      <button type="button" className={subTriggerCls}>
        <span className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-[#D4D4D8]" />
          Add Effect
        </span>
        <ChevronRight className="w-3.5 h-3.5 text-[#A1A1AA]" />
      </button>
      {openSub === 'effect' && (
        <div className="absolute left-full top-0 ml-0.5 w-48 bg-[#222225] border border-[#3E3E44] rounded shadow-2xl py-1 z-[110]">
          {QUICK_EFFECTS.map((fx) => (
            <button
              key={fx.id}
              type="button"
              onClick={() => {
                onQuickAddEffect(clipId, fx.id);
                onClose();
              }}
              className={itemCls}
            >
              <span>{fx.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div
      ref={menuRef}
      style={{ left: pos.left, top: pos.top }}
      onContextMenu={(e) => e.preventDefault()}
      className="fixed z-[100] w-60 bg-[#222225] border border-[#3E3E44] rounded-md shadow-2xl py-1 select-none"
    >
      {/* 1. CLIP CONTEXT MENU (Video / Image / Overlay / Shape / FX / Audio) */}
      {target.kind === 'clip' && clip && (
        <>
          <div className="px-3 py-1 border-b border-[#3E3E44] text-[10px] font-semibold text-[#A1A1AA] truncate flex items-center justify-between">
            <span className="text-[#F4F4F5] truncate">{clip.name}</span>
            <span className="uppercase text-[9px] text-[#D4D4D8]">{clip.type}</span>
          </div>

          <button type="button" onClick={() => { onCutClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Scissors className="w-3.5 h-3.5" />Cut</span>
            <span className="text-[10px] text-zinc-500 font-mono-tabular">Ctrl+X</span>
          </button>
          <button type="button" onClick={() => { onCopyClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Copy className="w-3.5 h-3.5" />Copy</span>
            <span className="text-[10px] text-zinc-500 font-mono-tabular">Ctrl+C</span>
          </button>
          {hasClipboard && (
            <button type="button" onClick={() => { onPasteClip(target.time); onClose(); }} className={itemCls}>
              <span className="flex items-center gap-2"><ClipboardPaste className="w-3.5 h-3.5" />Paste</span>
              <span className="text-[10px] text-zinc-500 font-mono-tabular">Ctrl+V</span>
            </button>
          )}
          <button type="button" onClick={() => { onDuplicateClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><CopyPlus className="w-3.5 h-3.5" />Duplicate</span>
            <span className="text-[10px] text-zinc-500 font-mono-tabular">Ctrl+D</span>
          </button>

          <div className={sepCls} />

          <button type="button" onClick={() => { onSplitClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Scissors className="w-3.5 h-3.5" />Split at Playhead</span>
          </button>
          <button type="button" onClick={() => { onTrimStartToPlayhead(clip.id); onClose(); }} className={itemCls}>
            <span>Trim Start</span>
          </button>
          <button type="button" onClick={() => { onTrimEndToPlayhead(clip.id); onClose(); }} className={itemCls}>
            <span>Trim End</span>
          </button>
          <button type="button" onClick={() => { onOpenSpeedDuration(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Clock className="w-3.5 h-3.5" />Speed / Duration...</span>
          </button>

          <div className={sepCls} />

          <button type="button" onClick={() => { onToggleEnableClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2">
              {clip.disabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              {clip.disabled ? 'Enable Clip' : 'Disable Clip'}
            </span>
          </button>
          <button type="button" onClick={() => { onToggleMuteClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2">
              {clip.muted ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              {clip.muted ? 'Unmute' : 'Mute'}
            </span>
          </button>
          <button type="button" onClick={() => { onToggleLockClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2">
              {clip.locked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
              {clip.locked ? 'Unlock' : 'Lock'}
            </span>
          </button>

          <div className={sepCls} />

          {renderEffectsSubmenu(clip.id)}

          <div
            className="relative"
            onMouseEnter={() => setOpenSub('preset')}
            onMouseLeave={() => setOpenSub((s) => (s === 'preset' ? null : s))}
          >
            <button type="button" className={subTriggerCls}>
              <span className="flex items-center gap-2">
                <Sliders className="w-3.5 h-3.5 text-[#D4D4D8]" />
                Apply Preset
              </span>
              <ChevronRight className="w-3.5 h-3.5 text-[#A1A1AA]" />
            </button>
            {openSub === 'preset' && (
              <div className="absolute left-full top-0 ml-0.5 w-48 bg-[#222225] border border-[#3E3E44] rounded shadow-2xl py-1 z-[110]">
                {QUICK_PRESETS.map((pr) => (
                  <button
                    key={pr.id}
                    type="button"
                    onClick={() => {
                      onQuickApplyPreset(clip.id, pr.id);
                      onClose();
                    }}
                    className={itemCls}
                  >
                    <span>{pr.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {clip.type === 'video' && (
            <button type="button" onClick={() => { onDetachAudio(clip.id); onClose(); }} className={itemCls}>
              <span className="flex items-center gap-2"><Music className="w-3.5 h-3.5" />Detach Audio</span>
            </button>
          )}
          {selectedClipIds.length >= 2 && (
            <button type="button" onClick={() => { onCreateCompoundClip(); onClose(); }} className={itemCls}>
              <span className="flex items-center gap-2"><Layers className="w-3.5 h-3.5" />Create Compound Clip</span>
            </button>
          )}

          <div className={sepCls} />

          {renderParentSubmenu(clip.id)}
          {clip.parentClipId && (
            <button type="button" onClick={() => { onSetClipParent(clip.id, undefined); onClose(); }} className={itemCls}>
              <span className="flex items-center gap-2"><Unlink className="w-3.5 h-3.5" />Unparent</span>
            </button>
          )}
          <button type="button" onClick={() => { onRenameClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Edit3 className="w-3.5 h-3.5" />Rename</span>
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">F2</span>
          </button>

          <div className={sepCls} />

          <button type="button" onClick={() => { onDeleteClip(clip.id); onClose(); }} className={dangerCls}>
            <span className="flex items-center gap-2"><Trash2 className="w-3.5 h-3.5" />Delete</span>
            <span className="text-[10px] font-mono-tabular">Del</span>
          </button>
        </>
      )}

      {/* 2. TEXT LAYER CONTEXT MENU */}
      {target.kind === 'text' && clip && (
        <>
          <div className="px-3 py-1 border-b border-[#3E3E44] text-[10px] font-semibold text-amber-300 truncate flex items-center justify-between">
            <span>{clip.name}</span>
            <span className="uppercase text-[9px]">TEXT</span>
          </div>

          <button type="button" onClick={() => { onEditText(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Type className="w-3.5 h-3.5 text-amber-400" />Edit Text</span>
          </button>
          <button type="button" onClick={() => { onDuplicateClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><CopyPlus className="w-3.5 h-3.5" />Duplicate Text Layer</span>
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">Ctrl+D</span>
          </button>
          <button type="button" onClick={() => { onConvertTextToShape(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Square className="w-3.5 h-3.5" />Convert to Shape / Graphic</span>
          </button>

          <div
            className="relative"
            onMouseEnter={() => setOpenSub('textAnim')}
            onMouseLeave={() => setOpenSub((s) => (s === 'textAnim' ? null : s))}
          >
            <button type="button" className={subTriggerCls}>
              <span className="flex items-center gap-2"><Sparkles className="w-3.5 h-3.5 text-amber-400" />Add Text Animation</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#A1A1AA]" />
            </button>
            {openSub === 'textAnim' && (
              <div className="absolute left-full top-0 ml-0.5 w-48 bg-[#222225] border border-[#3E3E44] rounded shadow-2xl py-1 z-[110]">
                {(
                  [
                    ['fade-up', 'Fade Up'],
                    ['typewriter', 'Typewriter'],
                    ['kinetic-typography', 'Kinetic Zoom'],
                    ['neon-text', 'Neon Pulse'],
                    ['text-glitch', 'Glitch Flicker'],
                    ['cinematic-title', 'Cinematic Tracking'],
                  ] as const
                ).map(([animId, animLabel]) => (
                  <button
                    key={animId}
                    type="button"
                    onClick={() => {
                      onAddTextAnimation(clip.id, animId);
                      onClose();
                    }}
                    className={itemCls}
                  >
                    <span>{animLabel}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {renderEffectsSubmenu(clip.id)}

          <div className={sepCls} />

          {renderParentSubmenu(clip.id)}
          {clip.parentClipId && (
            <button type="button" onClick={() => { onSetClipParent(clip.id, undefined); onClose(); }} className={itemCls}>
              <span className="flex items-center gap-2"><Unlink className="w-3.5 h-3.5" />Unparent</span>
            </button>
          )}
          <button type="button" onClick={() => { onToggleLockClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2">
              {clip.locked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
              {clip.locked ? 'Unlock' : 'Lock'}
            </span>
          </button>
          <button type="button" onClick={() => { onRenameClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Edit3 className="w-3.5 h-3.5" />Rename</span>
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">F2</span>
          </button>

          <div className={sepCls} />

          <button type="button" onClick={() => { onDeleteClip(clip.id); onClose(); }} className={dangerCls}>
            <span className="flex items-center gap-2"><Trash2 className="w-3.5 h-3.5" />Delete</span>
            <span className="text-[10px] font-mono-tabular">Del</span>
          </button>
        </>
      )}

      {/* 3. NULL OBJECT CONTEXT MENU */}
      {target.kind === 'null' && clip && (
        <>
          <div className="px-3 py-1 border-b border-[#3E3E44] text-[10px] font-semibold text-[#E4E4E7] truncate flex items-center justify-between">
            <span>{clip.name}</span>
            <span className="uppercase text-[9px]">NULL OBJECT</span>
          </div>

          <button type="button" onClick={() => { onRenameClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Edit3 className="w-3.5 h-3.5" />Rename Null</span>
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">F2</span>
          </button>
          <button type="button" onClick={() => { onDuplicateClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><CopyPlus className="w-3.5 h-3.5" />Duplicate Null</span>
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">Ctrl+D</span>
          </button>
          <button type="button" onClick={() => { onToggleLockClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2">
              {clip.locked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
              {clip.locked ? 'Unlock Null' : 'Lock Null'}
            </span>
          </button>
          <button type="button" onClick={() => { onToggleHideClip(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2">
              {clip.visible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              {clip.visible ? 'Hide Null' : 'Show Null'}
            </span>
          </button>

          <div
            className="relative"
            onMouseEnter={() => setOpenSub('nullColor')}
            onMouseLeave={() => setOpenSub((s) => (s === 'nullColor' ? null : s))}
          >
            <button type="button" className={subTriggerCls}>
              <span className="flex items-center gap-2"><Palette className="w-3.5 h-3.5" />Color Label</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#A1A1AA]" />
            </button>
            {openSub === 'nullColor' && (
              <div className="absolute left-full top-0 ml-0.5 w-44 bg-[#222225] border border-[#3E3E44] rounded shadow-2xl py-1 z-[110]">
                {COLOR_SWATCHES.map((sw) => (
                  <button
                    key={sw.id}
                    type="button"
                    onClick={() => {
                      onSetNullColor(clip.id, sw.id);
                      onClose();
                    }}
                    className={itemCls}
                  >
                    <span className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: sw.hex }} />
                      {sw.label}
                    </span>
                    {(clip.labelColor || 'rose') === sw.id && (
                      <span className="text-[9px] text-emerald-400">✓</span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className={sepCls} />

          <button type="button" onClick={() => { onAddNullKeyframe(clip.id, 'position'); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Diamond className="w-3.5 h-3.5 text-[#D4D4D8]" />Add Position Keyframe</span>
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">P</span>
          </button>
          <button type="button" onClick={() => { onAddNullKeyframe(clip.id, 'scale'); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Diamond className="w-3.5 h-3.5 text-[#D4D4D8]" />Add Scale Keyframe</span>
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">S</span>
          </button>
          <button type="button" onClick={() => { onAddNullKeyframe(clip.id, 'rotation'); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Diamond className="w-3.5 h-3.5 text-[#D4D4D8]" />Add Rotation Keyframe</span>
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">R</span>
          </button>

          <div className={sepCls} />

          <button type="button" onClick={() => { onSelectNullChildren(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Layers className="w-3.5 h-3.5" />Select All Children</span>
          </button>
          <button type="button" onClick={() => { onToggleNullChildrenVisibility(clip.id); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Eye className="w-3.5 h-3.5" />Show/Hide Children</span>
          </button>
          {renderParentSubmenu(clip.id)}
          {clip.parentClipId && (
            <button type="button" onClick={() => { onSetClipParent(clip.id, undefined); onClose(); }} className={itemCls}>
              <span className="flex items-center gap-2"><Unlink className="w-3.5 h-3.5" />Unparent</span>
            </button>
          )}

          <div className={sepCls} />

          <button type="button" onClick={() => { onDeleteClip(clip.id); onClose(); }} className={dangerCls}>
            <span className="flex items-center gap-2"><Trash2 className="w-3.5 h-3.5" />Delete Null</span>
            <span className="text-[10px] font-mono-tabular">Del</span>
          </button>
        </>
      )}

      {/* 4. KEYFRAME DIAMOND CONTEXT MENU */}
      {target.kind === 'keyframe' && clip && (
        <>
          <div className="px-3 py-1 border-b border-[#3E3E44] text-[10px] font-semibold text-[#F4F4F5] truncate">
            Keyframe ·{' '}
            {(() => {
              const kf: Keyframe | undefined = clip.keyframes.find((k) => k.id === target.keyframeId);
              return kf ? `${kf.property} (${kf.time.toFixed(2)}s)` : 'Selected';
            })()}
          </div>

          {(
            [
              ['linear', 'Linear'],
              ['easeIn', 'Ease In'],
              ['easeOut', 'Ease Out'],
              ['easeInOut', 'Ease In/Out'],
              ['bezier', 'Bezier Curve'],
              ['hold', 'Hold Keyframe'],
            ] as const
          ).map(([mode, label]) => (
            <button
              key={mode}
              type="button"
              onClick={() => {
                onSetKeyframeEasing(target.clipId, target.keyframeId, mode);
                onClose();
              }}
              className={itemCls}
            >
              <span className="flex items-center gap-2">
                <Diamond className="w-3 h-3 text-[#D4D4D8]" />
                {label}
              </span>
            </button>
          ))}

          <div className={sepCls} />

          <button
            type="button"
            onClick={() => {
              onCopyKeyframe(target.clipId, target.keyframeId);
              onClose();
            }}
            className={itemCls}
          >
            <span className="flex items-center gap-2"><Copy className="w-3.5 h-3.5" />Copy Keyframe</span>
          </button>
          {hasCopiedKeyframe && (
            <button
              type="button"
              onClick={() => {
                onPasteKeyframe(target.clipId);
                onClose();
              }}
              className={itemCls}
            >
              <span className="flex items-center gap-2"><ClipboardPaste className="w-3.5 h-3.5" />Paste Keyframe</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              onDeleteKeyframe(target.clipId, target.keyframeId);
              onClose();
            }}
            className={dangerCls}
          >
            <span className="flex items-center gap-2"><Trash2 className="w-3.5 h-3.5" />Delete Keyframe</span>
          </button>
        </>
      )}

      {/* 5. EMPTY TIMELINE AREA CONTEXT MENU */}
      {target.kind === 'empty' && (
        <>
          <div className="px-3 py-1 border-b border-[#3E3E44] text-[10px] font-semibold text-[#A1A1AA]">
            Timeline @ {target.time.toFixed(2)}s
          </div>

          {hasClipboard && (
            <>
              <button type="button" onClick={() => { onPasteClip(target.time); onClose(); }} className={itemCls}>
                <span className="flex items-center gap-2"><ClipboardPaste className="w-3.5 h-3.5" />Paste</span>
                <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">Ctrl+V</span>
              </button>
              <div className={sepCls} />
            </>
          )}

          <button type="button" onClick={() => { onAddNullClip(); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Crosshair className="w-3.5 h-3.5 text-[#D4D4D8]" />Add Null Object</span>
          </button>
          <button type="button" onClick={() => { onAddTextClip(); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Type className="w-3.5 h-3.5 text-amber-400" />Add Text Layer</span>
          </button>
          <button type="button" onClick={() => { onAddShapeClip(); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Square className="w-3.5 h-3.5 text-sky-400" />Add Shape Layer</span>
          </button>
          <button type="button" onClick={() => { onAddEffectLayer(); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Sparkles className="w-3.5 h-3.5 text-[#D4D4D8]" />Add Adjustment / Effect Layer</span>
          </button>

          <div className={sepCls} />

          <button type="button" onClick={() => { onAddTrack('video'); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Film className="w-3.5 h-3.5" />Add Video Track</span>
          </button>
          <button type="button" onClick={() => { onAddTrack('audio'); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Music className="w-3.5 h-3.5" />Add Audio Track</span>
          </button>
          <button type="button" onClick={() => { onAddMarkerAtTime(target.time); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Bookmark className="w-3.5 h-3.5 text-[#D4D4D8]" />Add Timeline Marker</span>
            <span className="text-[10px] text-[#A1A1AA] font-mono-tabular">M</span>
          </button>

          <div className={sepCls} />

          <button type="button" onClick={() => { onZoomToFit(); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2"><Maximize2 className="w-3.5 h-3.5" />Zoom to Fit</span>
          </button>
          <button type="button" onClick={() => { onToggleSnap(); onClose(); }} className={itemCls}>
            <span className="flex items-center gap-2">
              <Magnet className={`w-3.5 h-3.5 ${snapEnabled ? 'text-[#D4D4D8]' : ''}`} />
              {snapEnabled ? 'Disable Snap' : 'Enable Snap'}
            </span>
          </button>
        </>
      )}
    </div>
  );
};
