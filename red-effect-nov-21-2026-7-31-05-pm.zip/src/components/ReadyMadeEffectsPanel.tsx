import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Search,
  Sparkles,
  Trash2,
  X,
  Plus,
  Layers,
} from 'lucide-react';
import { ReadyMadeCategoryId, ReadyMadeEffectPreset } from '../types/effects';
import { ColorGrade } from '../types/studio';
import { READY_MADE_CATEGORIES, READY_MADE_PRESETS } from '../services/readyMadeEffects';
import { applyEffectsStackToCanvas, applyFullColorGradeToCanvas } from '../services/effectsProcessor';

interface ReadyMadeEffectsPanelProps {
  customPresets: ReadyMadeEffectPreset[];
  selectedClipName?: string;
  selectedClipType?: string;
  variant?: 'drawer' | 'docked';
  hoverPreviewEnabled?: boolean;
  onApplyPreset: (preset: ReadyMadeEffectPreset) => void;
  onHoverPreset: (preset: ReadyMadeEffectPreset | null) => void;
  onClearHoverImmediate?: () => void;
  onDeleteCustomPreset?: (id: string) => void;
  onClose?: () => void;
}

function drawThumbnailScene(ctx: CanvasRenderingContext2D, w: number, h: number, isText: boolean, accent: string) {
  const grad = ctx.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, '#0F172A');
  grad.addColorStop(0.55, '#1E1B2E');
  grad.addColorStop(1, '#2D0A14');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Subtle horizon grid + glowing orb
  ctx.strokeStyle = 'rgba(255,255,255,0.09)';
  ctx.lineWidth = 1;
  for (let gx = 12; gx < w; gx += 16) {
    ctx.beginPath();
    ctx.moveTo(gx, h * 0.58);
    ctx.lineTo(w * 0.5 + (gx - w * 0.5) * 1.8, h);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(0, h * 0.58);
  ctx.lineTo(w, h * 0.58);
  ctx.stroke();

  const orb = ctx.createRadialGradient(w * 0.72, h * 0.34, 2, w * 0.72, h * 0.34, w * 0.35);
  orb.addColorStop(0, '#FFFFFF');
  orb.addColorStop(0.28, accent);
  orb.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = orb;
  ctx.fillRect(0, 0, w, h);

  // Foreground geometric silhouette
  ctx.fillStyle = 'rgba(255,255,255,0.88)';
  ctx.beginPath();
  ctx.moveTo(0, h);
  ctx.lineTo(0, h * 0.68);
  ctx.lineTo(w * 0.34, h * 0.44);
  ctx.lineTo(w * 0.58, h * 0.65);
  ctx.lineTo(w, h * 0.48);
  ctx.lineTo(w, h);
  ctx.closePath();
  ctx.fillStyle = 'rgba(12, 12, 16, 0.86)';
  ctx.fill();

  if (isText) {
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '800 13px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('RED FX', w * 0.5, h * 0.5);
  }
}

const PresetLiveThumbnail: React.FC<{
  preset: ReadyMadeEffectPreset;
  isHovered: boolean;
}> = ({ preset, isHovered }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const w = 112;
    const h = 62;
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }

    let rafId = 0;
    const renderSample = (tSec: number) => {
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) return;

      drawThumbnailScene(ctx, w, h, preset.category === 'text', preset.accentColor || '#A1A1AA');

      if (preset.effectsStack && preset.effectsStack.length > 0) {
        applyEffectsStackToCanvas(
          canvas,
          preset.effectsStack,
          tSec,
          [],
          Math.max(0.8, preset.defaultDuration || 2.5)
        );
      } else if (preset.colorGrade) {
        const grade: ColorGrade = {
          preset: 'none',
          exposure: 0,
          contrast: 0,
          saturation: 0,
          temperature: 0,
          tint: 0,
          vignette: 0,
          highlights: 0,
          shadows: 0,
          whites: 0,
          blacks: 0,
          vibrance: 0,
          lutIntensity: 95,
          ...(preset.colorGrade as Partial<ColorGrade>),
        };
        applyFullColorGradeToCanvas(canvas, grade);
      } else if (preset.textPreset) {
        const tp = preset.textPreset;
        ctx.clearRect(0, 0, w, h);
        const bg = ctx.createLinearGradient(0, 0, w, h);
        bg.addColorStop(0, '#0C0C10');
        bg.addColorStop(1, '#1A1116');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, w, h);

        const speed = tp.effectSpeed || 1;
        const t = (tSec * speed) % 1.8;
        let ox = 0;
        let oy = 0;
        let sc = 1;
        let alpha = 1;
        let text = 'TITLE FX';
        if (tp.animation === 'text-shake') {
          ox = Math.sin(t * 48) * 3.5;
          oy = Math.cos(t * 62) * 2.5;
        } else if (tp.animation === 'text-bounce') {
          oy = -Math.abs(Math.sin(t * 5.2)) * 8;
        } else if (tp.animation === 'pop-up' || tp.animation === 'text-zoom') {
          const u = Math.min(1, t / 0.7);
          sc = 0.65 + u * 0.45;
          alpha = Math.min(1, u * 2.5);
        } else if (tp.animation === 'typewriter' || tp.animation === 'character-reveal') {
          const chars = Math.max(1, Math.ceil((Math.min(1, t / 1.1)) * text.length));
          text = text.slice(0, chars);
        } else if (tp.animation === 'velocity-text') {
          const u = Math.min(1, t / 0.65);
          ox = (1 - u) * -32;
        }

        ctx.save();
        ctx.translate(w * 0.5 + ox, h * 0.5 + oy);
        ctx.scale(sc, sc);
        ctx.globalAlpha = alpha;
        ctx.font = `800 15px Inter, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        if (tp.animation === 'rgb-text' || tp.animation === 'text-glitch') {
          ctx.fillStyle = '#FF0044';
          ctx.fillText(text, -2.5, 0);
          ctx.fillStyle = '#00F0FF';
          ctx.fillText(text, 2.5, 0);
        }
          if (tp.shadowBlur) {
            ctx.shadowColor = tp.shadowColor || '#A1A1AA';
            ctx.shadowBlur = Math.min(12, tp.shadowBlur * 0.4);
          }
        ctx.fillStyle = tp.color || '#FFFFFF';
        ctx.fillText(text, 0, 0);
        ctx.restore();
      } else if (preset.transitionConfig) {
        const u = (tSec % 1.2) / 1.2;
        ctx.fillStyle = `rgba(229, 9, 20, ${(1 - u) * 0.45})`;
        ctx.fillRect(0, 0, w * (1 - u), h);
      }
    };

    if (isHovered) {
      const start = performance.now();
      const tick = () => {
        renderSample((performance.now() - start) / 1000);
        rafId = requestAnimationFrame(tick);
      };
      rafId = requestAnimationFrame(tick);
      return () => cancelAnimationFrame(rafId);
    } else {
      renderSample(0.45);
    }
  }, [preset, isHovered]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-[54px] rounded-sm bg-[#18181A] border border-[#3E3E44] block object-cover"
    />
  );
};

export const ReadyMadeEffectsPanel: React.FC<ReadyMadeEffectsPanelProps> = ({
  customPresets,
  selectedClipName,
  selectedClipType,
  variant = 'drawer',
  hoverPreviewEnabled = true,
  onApplyPreset,
  onHoverPreset,
  onClearHoverImmediate,
  onDeleteCustomPreset,
  onClose,
}) => {
  const [activeCategory, setActiveCategory] = useState<ReadyMadeCategoryId | 'custom'>('shake');
  const [search, setSearch] = useState('');
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const clearHover = () => {
    setHoveredId(null);
    if (onClearHoverImmediate) {
      onClearHoverImmediate();
    } else {
      onHoverPreset(null);
    }
  };

  useEffect(() => {
    return () => {
      if (onClearHoverImmediate) {
        onClearHoverImmediate();
      } else {
        onHoverPreset(null);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const visiblePresets = useMemo(() => {
    const q = search.trim().toLowerCase();
    const pool =
      activeCategory === 'custom'
        ? customPresets
        : [...customPresets.filter((p) => p.category === activeCategory), ...READY_MADE_PRESETS.filter((p) => p.category === activeCategory)];
    if (!q) return pool;
    const allPool = [...customPresets, ...READY_MADE_PRESETS];
    return allPool.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
    );
  }, [activeCategory, customPresets, search]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { custom: customPresets.length };
    for (const c of READY_MADE_CATEGORIES) {
      if (c.id !== 'custom') {
        counts[c.id] =
          READY_MADE_PRESETS.filter((p) => p.category === c.id).length +
          customPresets.filter((p) => p.category === c.id).length;
      }
    }
    return counts;
  }, [customPresets]);

  return (
    <div
      onMouseLeave={clearHover}
      className={`flex flex-col bg-[#222225] text-[#F4F4F5] select-none ${
        variant === 'drawer'
          ? 'border-b border-[#3E3E44] shadow-2xl'
          : 'h-full'
      }`}
    >
      {/* Header Bar */}
      <div className="px-3 py-2 bg-[#2C2C30] border-b border-[#3E3E44] flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 min-w-0">
          <Sparkles className="w-4 h-4 text-[#D4D4D8] shrink-0" />
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-xs font-semibold text-[#F4F4F5] tracking-wide uppercase">
                Ready-Made Effects Library
              </h2>
              <span className="text-[10px] font-mono-tabular text-[#A1A1AA]">
                {READY_MADE_PRESETS.length + customPresets.length} Presets
              </span>
            </div>
            <p className="text-[10px] text-[#A1A1AA] truncate">
              {selectedClipName
                ? `Target: ${selectedClipName} (${selectedClipType?.toUpperCase() || 'CLIP'}) — Drag to timeline or click to apply non-destructive FX layer`
                : 'Drag any preset onto a timeline clip/track or click to apply as an editable FX layer'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-[#A1A1AA] absolute left-2 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search shake, glitch, cc, text..."
              className="pl-7 pr-2.5 py-1 w-56 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] placeholder-[#A1A1AA] focus:outline-none focus:border-[#A1A1AA]"
            />
          </div>
          {onClose && (
            <button
              type="button"
              onClick={() => {
                onHoverPreset(null);
                onClose();
              }}
              title="Close Effects Library"
              className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#3E3E44]/40 rounded"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Category Tabs (Zero-Pill architectural segmented tabs) */}
      <div className="px-2 bg-[#18181A] border-b border-[#3E3E44] flex items-center gap-0.5 overflow-x-auto shrink-0">
        {READY_MADE_CATEGORIES.map((cat) => {
          const isActive = activeCategory === cat.id && !search.trim();
          const count = categoryCounts[cat.id] ?? 0;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => {
                setSearch('');
                setActiveCategory(cat.id);
              }}
              className={`px-2.5 py-1.5 text-[11px] font-medium whitespace-nowrap shrink-0 border-b-2 transition-colors flex items-center gap-1.5 ${
                isActive
                  ? 'border-[#A1A1AA] text-[#F4F4F5] bg-[#2C2C30]'
                  : 'border-transparent text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]/50'
              }`}
            >
              <span
                className="w-1.5 h-1.5 rounded-xs shrink-0"
                style={{ backgroundColor: cat.accent }}
              />
              <span>{variant === 'drawer' ? cat.label : cat.shortLabel}</span>
              <span className="text-[10px] font-mono-tabular text-[#A1A1AA]">{count}</span>
            </button>
          );
        })}
      </div>

      {/* Presets Grid */}
      <div
        className={`p-2.5 overflow-y-auto ${
          variant === 'drawer' ? 'max-h-[268px]' : 'flex-1 min-h-0'
        }`}
      >
        {visiblePresets.length === 0 ? (
          <div className="py-8 text-center text-xs text-zinc-500">
            {activeCategory === 'custom'
              ? 'No custom presets saved yet. Adjust any Shake, Text, Glitch, or CC effect in the Inspector and click "Save Custom Preset".'
              : 'No matching presets found.'}
          </div>
        ) : (
          <div
            className={`grid gap-2 ${
              variant === 'drawer'
                ? 'grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8'
                : 'grid-cols-2'
            }`}
          >
            {visiblePresets.map((preset) => {
              const isHov = hoveredId === preset.id;
              return (
                <div
                  key={preset.id}
                  draggable
                  onDragStart={(e) => {
                    clearHover();
                    e.dataTransfer.setData(
                      'application/x-redeffect-fx',
                      JSON.stringify({ kind: 'readyPreset', presetId: preset.id })
                    );
                    e.dataTransfer.effectAllowed = 'copy';
                  }}
                  onMouseEnter={() => {
                    setHoveredId(preset.id);
                    if (hoverPreviewEnabled) {
                      onHoverPreset(preset);
                    }
                  }}
                  onMouseLeave={() => {
                    setHoveredId((prev) => (prev === preset.id ? null : prev));
                    if (hoverPreviewEnabled) {
                      onHoverPreset(null);
                    }
                  }}
                  onClick={() => {
                    clearHover();
                    onApplyPreset(preset);
                  }}
                  title={`${preset.name}: ${preset.description} (Drag to timeline or click to apply)`}
                  className={`group relative flex flex-col gap-1.5 p-1.5 rounded bg-[#2C2C30] border transition-colors cursor-grab active:cursor-grabbing ${
                    isHov
                      ? 'border-[#A1A1AA] bg-[#71717A]/15'
                      : 'border-[#3E3E44] hover:border-[#A1A1AA]/60'
                  }`}
                >
                  <PresetLiveThumbnail preset={preset} isHovered={isHov} />

                  <div className="flex items-start justify-between gap-1 px-0.5">
                    <div className="min-w-0">
                      <div className="text-[11px] font-medium text-[#F4F4F5] truncate leading-tight">
                        {preset.name}
                      </div>
                      <div className="text-[9px] text-[#A1A1AA] truncate mt-0.5">
                        {preset.category === 'text'
                          ? 'Text Layer FX'
                          : preset.category === 'transition'
                          ? `${preset.transitionConfig?.duration ?? 0.6}s Cut`
                          : preset.category === 'cc'
                          ? 'CC Grade Layer'
                          : 'FX Stack Layer'}
                      </div>
                    </div>

                    <div className="flex items-center gap-0.5 shrink-0">
                      {preset.isCustom && onDeleteCustomPreset && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteCustomPreset(preset.id);
                          }}
                          title="Delete Custom Preset"
                          className="p-0.5 text-[#A1A1AA] hover:text-rose-400 rounded"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                      <span
                        className="p-0.5 text-[#A1A1AA] group-hover:text-[#F4F4F5]"
                        title="Click to apply"
                      >
                        <Plus className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer Hint */}
      <div className="px-3 py-1 bg-[#18181A] border-t border-[#3E3E44] flex items-center justify-between text-[10px] text-[#A1A1AA]">
        <span className="flex items-center gap-1.5">
          <Layers className="w-3 h-3 text-[#D4D4D8]" />
          {hoverPreviewEnabled
            ? 'Clip effects create non-destructive FX layers above your clip. Hover any preset for live Preview Monitor preview.'
            : 'Live hover preview is paused in Settings. Click or drag any preset to apply.'}
        </span>
        <span className="font-mono-tabular hidden sm:inline">
          Drag &amp; Drop Supported
        </span>
      </div>
    </div>
  );
};
