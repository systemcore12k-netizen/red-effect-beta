import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bell,
  Bookmark,
  Check,
  ChevronRight,
  Clapperboard,
  Copy,
  Crown,
  Download,
  Edit3,
  Film,
  FolderOpen,
  GraduationCap,
  Home,
  Image as ImageIcon,
  Layers,
  Loader2,
  MoreVertical,
  Play,
  Plus,
  RefreshCw,
  Search,
  Settings,
  Sliders,
  Trash2,
  Video,
  Volume2,
  X,
  Zap,
  Box,
  Boxes,
  AlertCircle,
  Palette,
} from 'lucide-react';
import { PreviewQuality, StudioProject, StudioSettings } from '../types/studio';
import { ReadyMadeCategoryId, ReadyMadeEffectPreset } from '../types/effects';
import { ProjectThumbnail } from './ProjectThumbnail';
import { SettingsModalTab } from './SettingsModal';
import { UiThemeCustomizer } from './UiThemeCustomizer';
import { getProjectEndTime } from '../services/exportEngine';
import {
  getAllReadyMadePresets,
  READY_MADE_CATEGORIES,
} from '../services/readyMadeEffects';
import {
  deleteCustomTemplate,
  loadSavedCustomTemplates,
  RED_REBELLION_META,
  SavedCustomTemplate,
} from '../services/trailerTemplate';
import { AudioOutputDeviceInfo, listAudioOutputDevices } from '../services/audioEngine';
import { detectHardwareProfile, textBitmapCache } from '../services/performanceEngine';
import { enhancedImageCache } from '../services/qualityEnhancerEngine';
import { smoothVideoCache } from '../services/smoothVideoEngine';
import { clearHoverPreviewCache } from '../services/hoverPreviewCache';

export type HomeTabId = 'home' | 'projects' | 'templates' | 'effects' | 'settings';

interface NotificationEntry {
  id: string;
  title: string;
  detail: string;
  timeLabel: string;
  read: boolean;
}

interface HomeScreenProps {
  recentProjects: StudioProject[];
  activeProjectId: string;
  settings: StudioSettings;
  customReadyPresets: ReadyMadeEffectPreset[];
  isLoadingProjects?: boolean;
  projectsError?: string | null;
  onDismissProjectsError?: () => void;
  onNewProject: (initialMediaPick?: 'video' | 'image' | 'all' | null) => void;
  onOpenProjectFromPC: () => void;
  onLoadRecentProject: (project: StudioProject) => void;
  onRenameRecentProject: (id: string, nextName: string) => Promise<void> | void;
  onDuplicateRecentProject: (project: StudioProject) => Promise<void> | void;
  onExportRecentProject: (project: StudioProject) => void;
  onDeleteRecentProject: (id: string) => Promise<void> | void;
  onImportMediaAndEdit: (files: FileList) => void;
  onCreateTemplateProject: (tpl: {
    name: string;
    width: number;
    height: number;
    fps: number;
    aspectRatio: '16:9' | '9:16' | '1:1';
  }) => Promise<void> | void;
  onOpen3DGenerator: () => void;
  onOpen4DStudio: () => void;
  onUpdateSettings: (next: StudioSettings) => void;
  onSelectAudioDevice: (deviceId: string) => Promise<void>;
  onOpenSettings: (tab?: SettingsModalTab) => void;
  onResumeActiveProject: () => void;
  onOpenInteractiveTutorial: () => void;
  onOpenTrailerTemplate?: () => void;
  onApplyReadyMadePreset?: (preset: ReadyMadeEffectPreset) => void;
  onDeleteCustomReadyPreset?: (id: string) => void;
}

function formatDurationClock(sec: number): string {
  const safe = Math.max(0, Math.round(sec));
  const mins = Math.floor(safe / 60);
  const rem = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
}

function formatEditedDate(ts: number): string {
  if (!ts) return 'Just now';
  const diffMs = Date.now() - ts;
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return new Date(ts).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  recentProjects,
  activeProjectId,
  settings,
  customReadyPresets,
  isLoadingProjects = false,
  projectsError = null,
  onDismissProjectsError,
  onNewProject,
  onOpenProjectFromPC,
  onLoadRecentProject,
  onRenameRecentProject,
  onDuplicateRecentProject,
  onExportRecentProject,
  onDeleteRecentProject,
  onImportMediaAndEdit,
  onCreateTemplateProject,
  onOpen3DGenerator,
  onOpen4DStudio,
  onUpdateSettings,
  onSelectAudioDevice,
  onOpenSettings,
  onResumeActiveProject,
  onOpenInteractiveTutorial,
  onOpenTrailerTemplate,
  onApplyReadyMadePreset,
  onDeleteCustomReadyPreset,
}) => {
  const [activeTab, setActiveTab] = useState<HomeTabId>('home');
  const [projectSearch, setProjectSearch] = useState('');
  const [projectAspectFilter, setProjectAspectFilter] = useState<
    'all' | '16:9' | '9:16' | '1:1' | 'other'
  >('all');
  const [projectSort, setProjectSort] = useState<'recent' | 'name' | 'duration'>('recent');

  const [effectCategory, setEffectCategory] = useState<ReadyMadeCategoryId | 'all' | 'custom'>('all');
  const [effectSearch, setEffectSearch] = useState('');

  const [menuProjectId, setMenuProjectId] = useState<string | null>(null);
  const [renameTarget, setRenameTarget] = useState<{ id: string; name: string } | null>(null);
  const [renameDraft, setRenameDraft] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<StudioProject | null>(null);
  const [busyProjectAction, setBusyProjectAction] = useState(false);

  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [vipSheetOpen, setVipSheetOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationEntry[]>(() => [
    {
      id: 'notif-studio-ready',
      title: 'RED EFFECT APPS Workspace Ready',
      detail: '60/120fps timeline, Null Object rigging, and local 4K export are active.',
      timeLabel: 'Today',
      read: false,
    },
    {
      id: 'notif-autosave',
      title: 'Local Auto-Save Active',
      detail: 'Projects are automatically backed up to your local device storage.',
      timeLabel: 'System',
      read: true,
    },
  ]);

  const [customTemplates, setCustomTemplates] = useState<SavedCustomTemplate[]>(() =>
    loadSavedCustomTemplates()
  );
  const [audioDevices, setAudioDevices] = useState<AudioOutputDeviceInfo[]>([
    { deviceId: 'default', label: 'System Default Output' },
  ]);
  const [cacheNotice, setCacheNotice] = useState<string | null>(null);

  const photoInputRef = useRef<HTMLInputElement>(null);
  const activeProject = useMemo(
    () => recentProjects.find((p) => p.id === activeProjectId) || recentProjects[0] || null,
    [recentProjects, activeProjectId]
  );

  const unreadCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  // Close three-dot menu when clicking outside or pressing Escape
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMenuProjectId(null);
        setNotificationsOpen(false);
        setVipSheetOpen(false);
        setRenameTarget(null);
        setDeleteTarget(null);
      }
    };
    const onClick = () => setMenuProjectId(null);
    window.addEventListener('keydown', onKey);
    window.addEventListener('click', onClick);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('click', onClick);
    };
  }, []);

  useEffect(() => {
    if (activeTab === 'settings') {
      listAudioOutputDevices()
        .then(setAudioDevices)
        .catch(() => {});
    }
  }, [activeTab]);

  const filteredProjects = useMemo(() => {
    const q = projectSearch.trim().toLowerCase();
    const list = recentProjects.filter((rp) => {
      if (q && !rp.name.toLowerCase().includes(q)) return false;
      if (projectAspectFilter === '16:9') return rp.aspectRatio === '16:9';
      if (projectAspectFilter === '9:16') return rp.aspectRatio === '9:16';
      if (projectAspectFilter === '1:1') return rp.aspectRatio === '1:1';
      if (projectAspectFilter === 'other') {
        return !['16:9', '9:16', '1:1'].includes(rp.aspectRatio || '16:9');
      }
      return true;
    });
    return [...list].sort((a, b) => {
      if (projectSort === 'name') return a.name.localeCompare(b.name);
      if (projectSort === 'duration') return getProjectEndTime(b) - getProjectEndTime(a);
      return b.updatedAt - a.updatedAt;
    });
  }, [recentProjects, projectSearch, projectAspectFilter, projectSort]);

  const allEffects = useMemo(
    () => getAllReadyMadePresets(customReadyPresets),
    [customReadyPresets]
  );

  const filteredEffects = useMemo(() => {
    const q = effectSearch.trim().toLowerCase();
    return allEffects.filter((fx) => {
      if (effectCategory === 'custom') {
        if (!fx.isCustom) return false;
      } else if (effectCategory !== 'all' && fx.category !== effectCategory) {
        return false;
      }
      if (q) {
        return (
          fx.name.toLowerCase().includes(q) ||
          fx.description.toLowerCase().includes(q) ||
          fx.category.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [allEffects, effectCategory, effectSearch]);

  const hwProfile = useMemo(() => detectHardwareProfile(), []);

  const handleConfirmRename = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameTarget) return;
    const trimmed = renameDraft.trim();
    if (!trimmed) return;
    setBusyProjectAction(true);
    try {
      await onRenameRecentProject(renameTarget.id, trimmed);
      setRenameTarget(null);
    } finally {
      setBusyProjectAction(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setBusyProjectAction(true);
    try {
      await onDeleteRecentProject(deleteTarget.id);
      setDeleteTarget(null);
    } finally {
      setBusyProjectAction(false);
    }
  };

  const renderProjectCard = (rp: StudioProject) => {
    const durationSec = getProjectEndTime(rp);
    const durationLabel = formatDurationClock(durationSec);
    const isMenuOpen = menuProjectId === rp.id;
    const isActive = rp.id === activeProjectId;

    return (
      <div
        key={rp.id}
        className={`group relative bg-[#2C2C30] border rounded-2xl transition-colors ${
          isActive
            ? 'border-[#A1A1AA]/65'
            : 'border-[#3E3E44] hover:border-[#A1A1AA]/50'
        }`}
      >
        {/* One-tap Thumbnail + Card Open */}
        <button
          type="button"
          onClick={() => onLoadRecentProject(rp)}
          className="w-full text-left block rounded-t-2xl overflow-hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A1A1AA]"
        >
          <ProjectThumbnail project={rp} durationLabel={durationLabel} />
        </button>

        {/* Card Metadata & Three-Dot Menu */}
        <div className="p-3.5 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => onLoadRecentProject(rp)}
            className="flex-1 min-w-0 text-left focus-visible:outline-none"
          >
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-white truncate">
                {rp.name}
              </span>
              {isActive && (
                <span className="text-[11px] font-medium text-[#D4D4D8] shrink-0">
                  Active
                </span>
              )}
            </div>
            <div className="mt-1 flex items-center gap-1.5 text-xs text-[#A1A1AA] font-mono-tabular truncate">
              <span>{formatEditedDate(rp.updatedAt)}</span>
              <span aria-hidden="true">·</span>
              <span>{durationLabel}</span>
              <span aria-hidden="true">·</span>
              <span>
                {rp.width}×{rp.height}
              </span>
            </div>
          </button>

          <div className="relative shrink-0">
            <button
              type="button"
              aria-label={`Project options for ${rp.name}`}
              onClick={(e) => {
                e.stopPropagation();
                setMenuProjectId((prev) => (prev === rp.id ? null : rp.id));
              }}
              className="min-w-[44px] min-h-[44px] -mr-1.5 flex items-center justify-center text-[#A1A1AA] hover:text-white rounded-xl hover:bg-[#303030]/60 transition-colors"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {isMenuOpen && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 bottom-full mb-1.5 w-48 bg-[#222225] border border-[#3E3E44] rounded-xl shadow-2xl py-1.5 z-50 text-xs"
              >
                <button
                  type="button"
                  onClick={() => {
                    setMenuProjectId(null);
                    onLoadRecentProject(rp);
                  }}
                  className="w-full min-h-[40px] px-3.5 py-2 text-left text-white hover:bg-[#2C2C30] flex items-center gap-2.5 transition-colors"
                >
                  <Play className="w-3.5 h-3.5 text-[#D4D4D8]" />
                  <span>Open Project</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMenuProjectId(null);
                    setRenameDraft(rp.name);
                    setRenameTarget({ id: rp.id, name: rp.name });
                  }}
                  className="w-full min-h-[40px] px-3.5 py-2 text-left text-white hover:bg-[#2C2C30] flex items-center gap-2.5 transition-colors"
                >
                  <Edit3 className="w-3.5 h-3.5 text-[#A1A1AA]" />
                  <span>Rename</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMenuProjectId(null);
                    void onDuplicateRecentProject(rp);
                  }}
                  className="w-full min-h-[40px] px-3.5 py-2 text-left text-white hover:bg-[#2C2C30] flex items-center gap-2.5 transition-colors"
                >
                  <Copy className="w-3.5 h-3.5 text-[#A1A1AA]" />
                  <span>Duplicate</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMenuProjectId(null);
                    onExportRecentProject(rp);
                  }}
                  className="w-full min-h-[40px] px-3.5 py-2 text-left text-white hover:bg-[#2C2C30] flex items-center gap-2.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-[#A1A1AA]" />
                  <span>Export</span>
                </button>
                <div className="my-1 border-t border-[#3E3E44]" />
                <button
                  type="button"
                  onClick={() => {
                    setMenuProjectId(null);
                    setDeleteTarget(rp);
                  }}
                  className="w-full min-h-[40px] px-3.5 py-2 text-left text-[#D4D4D8] hover:bg-[#71717A]/15 flex items-center gap-2.5 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="h-screen w-screen bg-[#18181A] text-white flex flex-col overflow-hidden">
      {/* Hidden Photo Editing Picker */}
      <input
        ref={photoInputRef}
        type="file"
        multiple
        accept="image/*,.png,.jpg,.jpeg,.webp"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            onImportMediaAndEdit(e.target.files);
            e.target.value = '';
          }
        }}
        className="hidden"
      />

      {/* A. Top Navigation Bar (Compact 52px sticky bar) */}
      <header className="h-[52px] sticky top-0 z-30 bg-[#18181A]/95 backdrop-blur-md border-b border-[#3E3E44] px-4 sm:px-6 shrink-0">
        <div className="max-w-6xl mx-auto h-full flex items-center justify-between gap-4">
          {/* Left: RED EFFECT APPS Brand & Logo */}
          <button
            type="button"
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A1A1AA] rounded-lg py-1"
          >
            <img
              src="/assets/aistudio/Project_Name_107_473da90f.png"
              alt="RED EFFECT APPS logo"
              className="w-8 h-8 rounded-lg object-cover shrink-0 shadow-sm"
            />
            <span className="font-display text-sm sm:text-base font-bold tracking-tight text-white">
              RED EFFECT APPS
            </span>
          </button>

          {/* Right: Notification, Premium/VIP, Settings */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              aria-label="Notifications"
              onClick={() => {
                setNotificationsOpen((v) => !v);
                setVipSheetOpen(false);
              }}
              className="relative min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-[#A1A1AA] hover:text-white hover:bg-[#222225] transition-colors"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-[#52525B]" />
              )}
            </button>

            <button
              type="button"
              aria-label="Studio Pro Capabilities"
              onClick={() => {
                setVipSheetOpen((v) => !v);
                setNotificationsOpen(false);
              }}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-[#D4D4D8] hover:text-white hover:bg-[#222225] transition-colors"
            >
              <Crown className="w-5 h-5" />
            </button>

            <button
              type="button"
              aria-label="UI Theme & Colors"
              title="Customize UI Theme & Colors"
              onClick={() => {
                setNotificationsOpen(false);
                setVipSheetOpen(false);
                onOpenSettings('appearance');
              }}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-[#A1A1AA] hover:text-white hover:bg-[#222225] transition-colors"
            >
              <Palette className="w-5 h-5" />
            </button>

            <button
              type="button"
              aria-label="Settings"
              onClick={() => {
                setNotificationsOpen(false);
                setVipSheetOpen(false);
                setActiveTab('settings');
              }}
              className={`min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl transition-colors ${
                activeTab === 'settings'
                  ? 'text-[#D4D4D8] bg-[#222225]'
                  : 'text-[#A1A1AA] hover:text-white hover:bg-[#222225]'
              }`}
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Scrollable Viewport (leaves bottom space for 58px nav bar) */}
      <main className="flex-1 overflow-y-auto pb-[78px]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-5 sm:py-7 space-y-7">
          {projectsError && (
            <div className="p-3.5 bg-[#2C2C30] border border-[#A1A1AA]/60 rounded-2xl flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 text-xs text-white">
                <AlertCircle className="w-4 h-4 text-[#D4D4D8] shrink-0" />
                <span>{projectsError}</span>
              </div>
              {onDismissProjectsError && (
                <button
                  type="button"
                  onClick={onDismissProjectsError}
                  className="min-w-[36px] min-h-[36px] flex items-center justify-center text-[#A1A1AA] hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          )}

          {/* TAB 1: HOME */}
          {activeTab === 'home' && (
            <div className="space-y-7">
              {/* B. Create New Project Hero + Active Resume */}
              <section className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 items-stretch">
                <button
                  type="button"
                  onClick={() => onNewProject(null)}
                  className={`${
                    activeProject ? 'lg:col-span-8' : 'lg:col-span-12'
                  } w-full p-5 sm:p-6 bg-[#222225] hover:bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA]/75 rounded-2xl flex items-center justify-between gap-4 text-left transition-all active:scale-[0.99] group`}
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="w-14 h-14 rounded-2xl bg-[#52525B] group-hover:bg-[#6B7280] flex items-center justify-center shrink-0 shadow-lg shadow-[#71717A]/25 transition-colors">
                      <Plus className="w-7 h-7 text-white stroke-[2.5]" />
                    </div>
                    <div className="min-w-0">
                      <h1 className="font-display text-lg sm:text-xl font-bold text-white tracking-tight">
                        New Project
                      </h1>
                      <p className="text-xs sm:text-sm text-[#A1A1AA] mt-0.5">
                        Start creating your next video
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="hidden sm:inline text-xs font-mono-tabular text-[#A1A1AA]">
                      16:9 · 9:16 · 4K
                    </span>
                    <ChevronRight className="w-5 h-5 text-[#A1A1AA] group-hover:text-white transition-colors" />
                  </div>
                </button>

                {activeProject && (
                  <button
                    type="button"
                    onClick={onResumeActiveProject}
                    className="lg:col-span-4 w-full p-4 sm:p-5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA]/50 rounded-2xl flex items-center justify-between gap-3 text-left transition-all active:scale-[0.99]"
                  >
                    <div className="min-w-0">
                      <div className="text-[11px] font-medium text-[#D4D4D8]">
                        Continue Editing
                      </div>
                      <div className="text-sm font-semibold text-white truncate mt-0.5">
                        {activeProject.name}
                      </div>
                      <div className="text-xs text-[#A1A1AA] font-mono-tabular mt-1">
                        {activeProject.width}×{activeProject.height} · {activeProject.fps} fps
                      </div>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-[#222225] border border-[#3E3E44] flex items-center justify-center shrink-0">
                      <Play className="w-4 h-4 text-[#D4D4D8] fill-current" />
                    </div>
                  </button>
                )}
              </section>

              {/* D. Quick Start Section */}
              <section className="space-y-3">
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    Quick Start
                  </h2>
                  <button
                    type="button"
                    onClick={onOpenInteractiveTutorial}
                    className="min-h-[36px] px-2.5 text-xs font-medium text-[#A1A1AA] hover:text-white flex items-center gap-1.5 transition-colors"
                  >
                    <GraduationCap className="w-4 h-4 text-[#D4D4D8]" />
                    <span>RED EFFECT Tutorial</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                  <button
                    type="button"
                    onClick={() => onNewProject('video')}
                    className="min-h-[84px] p-4 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl flex flex-col justify-between items-start gap-2.5 text-left transition-all active:scale-[0.98]"
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#71717A]/15 flex items-center justify-center">
                      <Video className="w-4 h-4 text-[#D4D4D8]" />
                    </div>
                    <span className="text-xs sm:text-sm font-semibold text-white">
                      Video Editing
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => photoInputRef.current?.click()}
                    className="min-h-[84px] p-4 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl flex flex-col justify-between items-start gap-2.5 text-left transition-all active:scale-[0.98]"
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#222225] border border-[#3E3E44] flex items-center justify-center">
                      <ImageIcon className="w-4 h-4 text-[#D4D4D8]" />
                    </div>
                    <span className="text-xs sm:text-sm font-semibold text-white">
                      Photo Editing
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setEffectCategory('all');
                      setActiveTab('effects');
                    }}
                    className="min-h-[84px] p-4 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl flex flex-col justify-between items-start gap-2.5 text-left transition-all active:scale-[0.98]"
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#222225] border border-[#3E3E44] flex items-center justify-center">
                      <Zap className="w-4 h-4 text-[#D4D4D8]" />
                    </div>
                    <span className="text-xs sm:text-sm font-semibold text-white">
                      Effects
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('templates')}
                    className="min-h-[84px] p-4 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl flex flex-col justify-between items-start gap-2.5 text-left transition-all active:scale-[0.98]"
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#222225] border border-[#3E3E44] flex items-center justify-center">
                      <Clapperboard className="w-4 h-4 text-[#D4D4D8]" />
                    </div>
                    <span className="text-xs sm:text-sm font-semibold text-white">
                      Templates
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setEffectCategory('custom');
                      setActiveTab('effects');
                    }}
                    className="col-span-2 sm:col-span-1 min-h-[84px] p-4 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl flex flex-col justify-between items-start gap-2.5 text-left transition-all active:scale-[0.98]"
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#222225] border border-[#3E3E44] flex items-center justify-center">
                      <Bookmark className="w-4 h-4 text-[#D4D4D8]" />
                    </div>
                    <span className="text-xs sm:text-sm font-semibold text-white">
                      My Presets
                    </span>
                  </button>
                </div>
              </section>

              {/* C. Recent Projects Section */}
              <section className="space-y-3.5">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-baseline gap-2.5">
                    <h2 className="font-display text-sm sm:text-base font-bold text-white">
                      Recent Projects
                    </h2>
                    <span className="text-xs text-[#A1A1AA] font-mono-tabular">
                      {recentProjects.length} saved
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={onOpenProjectFromPC}
                      className="min-h-[36px] px-3 py-1.5 text-xs font-medium text-[#A1A1AA] hover:text-white bg-[#222225] border border-[#3E3E44] rounded-xl flex items-center gap-1.5 transition-colors"
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Open File</span>
                    </button>
                    {recentProjects.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setActiveTab('projects')}
                        className="min-h-[36px] px-2.5 text-xs font-semibold text-[#D4D4D8] hover:text-white transition-colors"
                      >
                        See All
                      </button>
                    )}
                  </div>
                </div>

                {isLoadingProjects ? (
                  <div className="p-10 bg-[#222225] border border-[#3E3E44] rounded-2xl flex flex-col items-center justify-center gap-3 text-[#A1A1AA]">
                    <Loader2 className="w-6 h-6 text-[#D4D4D8] animate-spin" />
                    <span className="text-xs">Loading your saved projects...</span>
                  </div>
                ) : recentProjects.length === 0 ? (
                  <div className="p-10 bg-[#222225] border border-dashed border-[#3E3E44] rounded-2xl flex flex-col items-center justify-center text-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-[#2C2C30] border border-[#3E3E44] flex items-center justify-center">
                      <Film className="w-5 h-5 text-[#D4D4D8]" />
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm font-semibold text-white">
                        No projects yet
                      </div>
                      <p className="text-xs text-[#A1A1AA] max-w-xs">
                        Create your first video sequence or import an existing `.redeffect.json` project file.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onNewProject(null)}
                      className="min-h-[44px] px-5 py-2.5 bg-[#52525B] hover:bg-[#6B7280] text-white text-xs font-semibold rounded-xl transition-colors"
                    >
                      Create First Project
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {recentProjects.slice(0, 6).map(renderProjectCard)}
                  </div>
                )}
              </section>
            </div>
          )}

          {/* TAB 2: PROJECTS */}
          {activeTab === 'projects' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="font-display text-xl font-bold text-white">
                    Projects
                  </h1>
                  <p className="text-xs text-[#A1A1AA]">
                    Manage, rename, duplicate, export, or open your video sequences
                  </p>
                </div>
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={onOpenProjectFromPC}
                    className="min-h-[44px] px-4 py-2 bg-[#222225] hover:bg-[#2C2C30] border border-[#3E3E44] rounded-xl text-xs font-medium text-white flex items-center gap-2 transition-colors"
                  >
                    <FolderOpen className="w-4 h-4 text-[#A1A1AA]" />
                    Open File
                  </button>
                  <button
                    type="button"
                    onClick={() => onNewProject(null)}
                    className="min-h-[44px] px-4 py-2 bg-[#52525B] hover:bg-[#6B7280] rounded-xl text-xs font-semibold text-white flex items-center gap-2 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    New Project
                  </button>
                </div>
              </div>

              {/* Search & Aspect Filters */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-[#A1A1AA] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={projectSearch}
                    onChange={(e) => setProjectSearch(e.target.value)}
                    placeholder="Search projects..."
                    className="w-full min-h-[44px] pl-10 pr-4 py-2 bg-[#222225] border border-[#3E3E44] rounded-xl text-xs text-white placeholder-[#777777] focus:outline-none focus:border-[#A1A1AA]"
                  />
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-1 p-1 bg-[#222225] border border-[#3E3E44] rounded-xl">
                    {(['all', '16:9', '9:16', '1:1', 'other'] as const).map((ar) => (
                      <button
                        key={ar}
                        type="button"
                        onClick={() => setProjectAspectFilter(ar)}
                        className={`min-h-[34px] px-2.5 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                          projectAspectFilter === ar
                            ? 'bg-[#52525B] text-white'
                            : 'text-[#A1A1AA] hover:text-white'
                        }`}
                      >
                        {ar === 'all' ? 'All' : ar === 'other' ? 'Other' : ar}
                      </button>
                    ))}
                  </div>

                  <select
                    value={projectSort}
                    onChange={(e) =>
                      setProjectSort(e.target.value as 'recent' | 'name' | 'duration')
                    }
                    className="min-h-[42px] px-3 py-2 bg-[#222225] border border-[#3E3E44] rounded-xl text-xs text-white focus:outline-none focus:border-[#A1A1AA]"
                  >
                    <option value="recent">Sort: Last Edited</option>
                    <option value="name">Sort: Name</option>
                    <option value="duration">Sort: Duration</option>
                  </select>
                </div>
              </div>

              {filteredProjects.length === 0 ? (
                <div className="p-10 bg-[#222225] border border-dashed border-[#3E3E44] rounded-2xl flex flex-col items-center justify-center text-center gap-3">
                  <Film className="w-7 h-7 text-[#A1A1AA]" />
                  <div className="text-sm font-semibold text-white">
                    {recentProjects.length === 0
                      ? 'No saved projects yet'
                      : 'No matching projects'}
                  </div>
                  <p className="text-xs text-[#A1A1AA]">
                    {recentProjects.length === 0
                      ? 'Tap New Project to start your first video edit.'
                      : 'Try clearing your search query or aspect ratio filter.'}
                  </p>
                  {recentProjects.length === 0 ? (
                    <button
                      type="button"
                      onClick={() => onNewProject(null)}
                      className="min-h-[44px] px-5 py-2 bg-[#52525B] hover:bg-[#6B7280] text-white text-xs font-semibold rounded-xl"
                    >
                      New Project
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setProjectSearch('');
                        setProjectAspectFilter('all');
                      }}
                      className="min-h-[40px] px-4 py-2 bg-[#2C2C30] border border-[#3E3E44] text-white text-xs font-medium rounded-xl"
                    >
                      Reset Filters
                    </button>
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredProjects.map(renderProjectCard)}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: TEMPLATES */}
          {activeTab === 'templates' && (
            <div className="space-y-6">
              <div>
                <h1 className="font-display text-xl font-bold text-white">
                  Templates
                </h1>
                <p className="text-xs text-[#A1A1AA]">
                  Launch ready-made timelines, motion sequences, and your saved custom templates
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* RED REBELLION Featured Template */}
                {onOpenTrailerTemplate && (
                  <div className="bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl overflow-hidden flex flex-col transition-colors">
                    <div className="relative aspect-video bg-[#1E1E21] overflow-hidden">
                      <img
                        src="/src/assets/images/template_red_rebellion_1795119263004.jpg"
                        alt="RED REBELLION Trailer Template"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                      <div className="absolute bottom-2.5 left-3 text-[11px] font-mono-tabular text-[#D4D4D4]">
                        {RED_REBELLION_META.width}×{RED_REBELLION_META.height} · {RED_REBELLION_META.fps} fps
                      </div>
                      <div className="absolute bottom-2.5 right-3 px-1.5 py-0.5 rounded bg-black/75 text-[11px] font-mono-tabular text-white">
                        00:20
                      </div>
                    </div>
                    <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                      <div>
                        <div className="text-sm font-bold text-white">
                          {RED_REBELLION_META.name}
                        </div>
                        <p className="text-xs text-[#A1A1AA] mt-1 line-clamp-2">
                          {RED_REBELLION_META.description}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={onOpenTrailerTemplate}
                        className="w-full min-h-[44px] bg-[#52525B] hover:bg-[#6B7280] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        Use Template
                      </button>
                    </div>
                  </div>
                )}

                {/* 9:16 Vertical Reels Starter */}
                <div className="bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl overflow-hidden flex flex-col transition-colors">
                  <div className="relative aspect-video bg-[#1E1E21] overflow-hidden">
                    <img
                      src="/src/assets/images/template_vertical_motion_1795119262941.jpg"
                      alt="Vertical Reels Motion Template"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    <div className="absolute bottom-2.5 left-3 text-[11px] font-mono-tabular text-[#D4D4D4]">
                      1080×1920 · 60 fps
                    </div>
                    <div className="absolute bottom-2.5 right-3 px-1.5 py-0.5 rounded bg-black/75 text-[11px] font-mono-tabular text-white">
                      9:16
                    </div>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                    <div>
                      <div className="text-sm font-bold text-white">
                        Vertical Motion Reels
                      </div>
                      <p className="text-xs text-[#A1A1AA] mt-1">
                        Portrait 9:16 sequence tuned for short-form high-FPS edits and kinetic typography.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        void onCreateTemplateProject({
                          name: 'Vertical_Reels_60fps',
                          width: 1080,
                          height: 1920,
                          fps: 60,
                          aspectRatio: '9:16',
                        })
                      }
                      className="w-full min-h-[44px] bg-[#222225] hover:bg-[#52525B] border border-[#3E3E44] hover:border-[#A1A1AA] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      Start Vertical Edit
                    </button>
                  </div>
                </div>

                {/* 16:9 Cinema Grade Sequence */}
                <div className="bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl overflow-hidden flex flex-col transition-colors">
                  <div className="relative aspect-video bg-[#1E1E21] overflow-hidden">
                    <img
                      src="/src/assets/images/template_cinema_grade_1795119263573.jpg"
                      alt="Cinema Grade Widescreen Template"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    <div className="absolute bottom-2.5 left-3 text-[11px] font-mono-tabular text-[#D4D4D4]">
                      1920×1080 · 24 fps
                    </div>
                    <div className="absolute bottom-2.5 right-3 px-1.5 py-0.5 rounded bg-black/75 text-[11px] font-mono-tabular text-white">
                      16:9
                    </div>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                    <div>
                      <div className="text-sm font-bold text-white">
                        Cinema Color Sequence
                      </div>
                      <p className="text-xs text-[#A1A1AA] mt-1">
                        Film-cadence 24fps widescreen timeline ready for color grading and atmospheric LUTs.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        void onCreateTemplateProject({
                          name: 'Cinema_Sequence_24fps',
                          width: 1920,
                          height: 1080,
                          fps: 24,
                          aspectRatio: '16:9',
                        })
                      }
                      className="w-full min-h-[44px] bg-[#222225] hover:bg-[#52525B] border border-[#3E3E44] hover:border-[#A1A1AA] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      Start Cinema Edit
                    </button>
                  </div>
                </div>
              </div>

              {/* Guided Tutorial & Saved Custom Templates */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-5 bg-[#222225] border border-[#3E3E44] rounded-2xl flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="text-sm font-bold text-white flex items-center gap-2">
                      <GraduationCap className="w-4 h-4 text-[#D4D4D8]" />
                      RED EFFECT Tutorial Project
                    </div>
                    <p className="text-xs text-[#A1A1AA]">
                      Hands-on 10-chapter walkthrough for Null Object parenting, keyframes, and shakes.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={onOpenInteractiveTutorial}
                    className="min-h-[44px] px-4 py-2 bg-[#2C2C30] hover:bg-[#52525B] border border-[#3E3E44] hover:border-[#A1A1AA] text-white text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition-colors"
                  >
                    Open Tutorial
                  </button>
                </div>

                {customTemplates.length > 0 && (
                  <div className="p-5 bg-[#222225] border border-[#3E3E44] rounded-2xl space-y-3">
                    <div className="text-sm font-bold text-white">
                      Saved Custom Templates ({customTemplates.length})
                    </div>
                    <div className="space-y-2">
                      {customTemplates.map((tpl) => (
                        <div
                          key={tpl.id}
                          className="p-3 bg-[#2C2C30] border border-[#3E3E44] rounded-xl flex items-center justify-between gap-3"
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-semibold text-white truncate">
                              {tpl.name}
                            </div>
                            <div className="text-[11px] text-[#A1A1AA] font-mono-tabular">
                              {tpl.width}×{tpl.height} · {tpl.fps} fps
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => onOpenTrailerTemplate?.()}
                              className="min-h-[36px] px-3 py-1.5 bg-[#52525B] hover:bg-[#6B7280] text-white text-xs font-semibold rounded-lg"
                            >
                              Open
                            </button>
                            <button
                              type="button"
                              aria-label={`Delete ${tpl.name}`}
                              onClick={() => setCustomTemplates(deleteCustomTemplate(tpl.id))}
                              className="min-w-[36px] min-h-[36px] flex items-center justify-center text-[#A1A1AA] hover:text-[#D4D4D8] rounded-lg"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: EFFECTS & MY PRESETS */}
          {activeTab === 'effects' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="font-display text-xl font-bold text-white">
                    Effects &amp; My Presets
                  </h1>
                  <p className="text-xs text-[#A1A1AA]">
                    Tap any effect or saved preset to apply it directly in the editor
                  </p>
                </div>

                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 text-[#A1A1AA] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={effectSearch}
                    onChange={(e) => setEffectSearch(e.target.value)}
                    placeholder="Search shakes, LUTs, presets..."
                    className="w-full min-h-[44px] pl-10 pr-4 py-2 bg-[#222225] border border-[#3E3E44] rounded-xl text-xs text-white placeholder-[#777777] focus:outline-none focus:border-[#A1A1AA]"
                  />
                </div>
              </div>

              {/* Category Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                <button
                  type="button"
                  onClick={() => setEffectCategory('all')}
                  className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 border transition-colors ${
                    effectCategory === 'all'
                      ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                      : 'bg-[#222225] border-[#3E3E44] text-[#A1A1AA] hover:text-white'
                  }`}
                >
                  All Effects
                </button>
                <button
                  type="button"
                  onClick={() => setEffectCategory('custom')}
                  className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 border transition-colors ${
                    effectCategory === 'custom'
                      ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                      : 'bg-[#222225] border-[#3E3E44] text-[#A1A1AA] hover:text-white'
                  }`}
                >
                  My Presets ({customReadyPresets.length})
                </button>
                {READY_MADE_CATEGORIES.filter((c) => c.id !== 'custom').map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setEffectCategory(cat.id as ReadyMadeCategoryId)}
                    className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 border transition-colors ${
                      effectCategory === cat.id
                        ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                        : 'bg-[#222225] border-[#3E3E44] text-[#A1A1AA] hover:text-white'
                    }`}
                  >
                    {cat.shortLabel}
                  </button>
                ))}
              </div>

              {/* Effects Grid */}
              {filteredEffects.length === 0 ? (
                <div className="p-10 bg-[#222225] border border-dashed border-[#3E3E44] rounded-2xl flex flex-col items-center justify-center text-center gap-2.5">
                  <Layers className="w-6 h-6 text-[#A1A1AA]" />
                  <div className="text-sm font-semibold text-white">
                    {effectCategory === 'custom'
                      ? 'No saved presets yet'
                      : 'No matching effects found'}
                  </div>
                  <p className="text-xs text-[#A1A1AA] max-w-sm">
                    {effectCategory === 'custom'
                      ? 'Save your custom color grades or shake stacks inside the Inspector to access them here.'
                      : 'Try another category or clear your search query.'}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {filteredEffects.map((fx) => (
                    <div
                      key={fx.id}
                      className="p-4 bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl flex flex-col justify-between gap-3 transition-colors"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold text-white truncate">
                            {fx.name}
                          </span>
                          <span className="text-[11px] font-mono-tabular text-[#A1A1AA] shrink-0">
                            {(fx.defaultDuration ?? 1.5).toFixed(1)}s
                          </span>
                        </div>
                        <p className="text-xs text-[#A1A1AA] line-clamp-2">
                          {fx.description}
                        </p>
                      </div>

                      <div className="flex items-center justify-between gap-2 pt-1">
                        <span className="text-[11px] text-[#A1A1AA] capitalize">
                          {fx.isCustom ? 'Saved Preset' : `${fx.category} effect`}
                        </span>
                        <div className="flex items-center gap-1.5">
                          {fx.isCustom && onDeleteCustomReadyPreset && (
                            <button
                              type="button"
                              aria-label={`Delete ${fx.name}`}
                              onClick={() => onDeleteCustomReadyPreset(fx.id)}
                              className="min-w-[36px] min-h-[36px] flex items-center justify-center text-[#A1A1AA] hover:text-[#D4D4D8] rounded-xl"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              if (onApplyReadyMadePreset) {
                                onApplyReadyMadePreset(fx);
                              } else {
                                onResumeActiveProject();
                              }
                            }}
                            className="min-h-[38px] px-3.5 py-1.5 bg-[#222225] hover:bg-[#52525B] border border-[#3E3E44] hover:border-[#A1A1AA] text-white text-xs font-semibold rounded-xl transition-colors"
                          >
                            Apply in Editor
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Additional Studio Modules */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
                <button
                  type="button"
                  onClick={onOpen3DGenerator}
                  className="p-4 bg-[#222225] hover:bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl flex items-center justify-between gap-3 text-left transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#2C2C30] border border-[#3E3E44] flex items-center justify-center">
                      <Box className="w-5 h-5 text-[#D4D4D8]" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-white">3D Studio</div>
                      <div className="text-xs text-[#A1A1AA]">
                        Build and inspect GLB/OBJ models
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A1A1AA]" />
                </button>

                <button
                  type="button"
                  onClick={onOpen4DStudio}
                  className="p-4 bg-[#222225] hover:bg-[#2C2C30] border border-[#3E3E44] hover:border-[#A1A1AA]/60 rounded-2xl flex items-center justify-between gap-3 text-left transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#2C2C30] border border-[#3E3E44] flex items-center justify-center">
                      <Boxes className="w-5 h-5 text-[#D4D4D8]" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-white">4D Studio</div>
                      <div className="text-xs text-[#A1A1AA]">
                        Animate 3D rigs, particles, and cameras
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A1A1AA]" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 5: SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-5 max-w-3xl">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div>
                  <h1 className="font-display text-xl font-bold text-white">
                    Settings &amp; UI Customization
                  </h1>
                  <p className="text-xs text-[#A1A1AA]">
                    Customize UI colors (Gray, White, Red, Purple, All Colors), export defaults, preview &amp; audio
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onOpenSettings('appearance')}
                    className="min-h-[44px] px-3.5 py-2 bg-[#71717A]/20 hover:bg-[#52525B] border border-[#A1A1AA]/60 rounded-xl text-xs font-semibold text-white flex items-center gap-2 transition-colors"
                  >
                    <Palette className="w-4 h-4 text-[#D4D4D8]" />
                    <span>UI &amp; Colors</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenSettings('shortcuts')}
                    className="min-h-[44px] px-4 py-2 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded-xl text-xs font-semibold text-white flex items-center gap-2 transition-colors"
                  >
                    <Sliders className="w-4 h-4 text-[#D4D4D8]" />
                    <span>Shortcuts &amp; Advanced</span>
                  </button>
                </div>
              </div>

              {/* UI Theme & Colors Customizer */}
              <UiThemeCustomizer
                settings={settings}
                onUpdateSettings={onUpdateSettings}
              />

              {/* Project & Render Defaults */}
              <div className="p-5 bg-[#222225] border border-[#3E3E44] rounded-2xl space-y-4">
                <div className="text-sm font-bold text-white">
                  Default Project &amp; Export Settings
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="text-xs text-[#A1A1AA] block mb-1.5">
                      Default Resolution
                    </label>
                    <select
                      value={settings.defaultResolution}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          defaultResolution: e.target.value as StudioSettings['defaultResolution'],
                        })
                      }
                      className="w-full min-h-[44px] px-3 py-2 bg-[#18181A] border border-[#3E3E44] rounded-xl text-xs text-white focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value="720p">720p HD</option>
                      <option value="1080p">1080p Full HD</option>
                      <option value="2k">1440p 2K QHD</option>
                      <option value="4k">2160p 4K UHD</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-[#A1A1AA] block mb-1.5">
                      Default Frame Rate
                    </label>
                    <select
                      value={settings.defaultFps}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          defaultFps: Number(e.target.value) as 24 | 30 | 60,
                        })
                      }
                      className="w-full min-h-[44px] px-3 py-2 bg-[#18181A] border border-[#3E3E44] rounded-xl text-xs text-white font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value={24}>24 fps</option>
                      <option value={30}>30 fps</option>
                      <option value={60}>60 fps</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-[#A1A1AA] block mb-1.5">
                      Auto-Save Interval
                    </label>
                    <select
                      value={settings.autoSaveIntervalSec}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          autoSaveIntervalSec: Number(e.target.value),
                        })
                      }
                      className="w-full min-h-[44px] px-3 py-2 bg-[#18181A] border border-[#3E3E44] rounded-xl text-xs text-white font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value={0}>Off</option>
                      <option value={15}>Every 15 sec</option>
                      <option value={30}>Every 30 sec</option>
                      <option value={60}>Every 60 sec</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Performance & Preview */}
              <div className="p-5 bg-[#222225] border border-[#3E3E44] rounded-2xl space-y-4">
                <div className="text-sm font-bold text-white">
                  Preview &amp; Performance
                </div>

                <div>
                  <label className="text-xs text-[#A1A1AA] block mb-2">
                    Timeline Preview Quality
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(['full', 'high', 'balanced', 'fast'] as PreviewQuality[]).map((q) => {
                      const active = settings.previewQuality === q;
                      return (
                        <button
                          key={q}
                          type="button"
                          onClick={() =>
                            onUpdateSettings({ ...settings, previewQuality: q })
                          }
                          className={`min-h-[44px] px-3 py-2 rounded-xl border text-xs font-semibold capitalize transition-colors ${
                            active
                              ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                              : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-white'
                          }`}
                        >
                          {q}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2.5 pt-1">
                  <label className="flex items-center justify-between gap-3 p-3 bg-[#2C2C30] border border-[#3E3E44] rounded-xl cursor-pointer">
                    <div>
                      <div className="text-xs font-semibold text-white">
                        Live Effect Hover Preview
                      </div>
                      <div className="text-[11px] text-[#A1A1AA]">
                        Preview effects in real time when hovering over presets
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.hoverPreviewEnabled !== false}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          hoverPreviewEnabled: e.target.checked,
                        })
                      }
                      className="accent-[#A1A1AA] w-4 h-4 shrink-0"
                    />
                  </label>

                  <label className="flex items-center justify-between gap-3 p-3 bg-[#2C2C30] border border-[#3E3E44] rounded-xl cursor-pointer">
                    <div>
                      <div className="text-xs font-semibold text-white">
                        Hardware Acceleration
                      </div>
                      <div className="text-[11px] text-[#A1A1AA]">
                        Use GPU canvas compositing ({hwProfile.cpuCores} logical cores detected)
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.hardwareAcceleration}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          hardwareAcceleration: e.target.checked,
                        })
                      }
                      className="accent-[#A1A1AA] w-4 h-4 shrink-0"
                    />
                  </label>
                </div>
              </div>

              {/* Audio Output & Storage */}
              <div className="p-5 bg-[#222225] border border-[#3E3E44] rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-[#D4D4D8]" />
                    Audio Output &amp; Cache
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      listAudioOutputDevices()
                        .then(setAudioDevices)
                        .catch(() => {});
                    }}
                    className="min-h-[36px] px-3 py-1.5 bg-[#2C2C30] border border-[#3E3E44] rounded-xl text-xs text-white flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Refresh
                  </button>
                </div>

                <select
                  value={settings.audioOutputDeviceId || 'default'}
                  onChange={(e) => {
                    const id = e.target.value;
                    onUpdateSettings({ ...settings, audioOutputDeviceId: id });
                    void onSelectAudioDevice(id);
                  }}
                  className="w-full min-h-[44px] px-3 py-2 bg-[#18181A] border border-[#3E3E44] rounded-xl text-xs text-white focus:outline-none focus:border-[#A1A1AA]"
                >
                  {audioDevices.map((d) => (
                    <option key={d.deviceId} value={d.deviceId}>
                      {d.label}
                    </option>
                  ))}
                </select>

                <div className="flex items-center justify-between gap-3 pt-1">
                  <span className="text-xs text-[#A1A1AA]">
                    {cacheNotice || 'Free temporary preview & texture buffers'}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      textBitmapCache.clear();
                      enhancedImageCache.clearAll();
                      smoothVideoCache.clearAll();
                      clearHoverPreviewCache();
                      setCacheNotice('Preview & texture caches cleared');
                    }}
                    className="min-h-[40px] px-4 py-2 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded-xl text-xs font-medium text-white shrink-0"
                  >
                    Clear Cache
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* E. Fixed Bottom Navigation Bar (5 Tabs, 58px height) */}
      <nav
        aria-label="Primary Navigation"
        className="fixed bottom-0 left-0 right-0 z-40 h-[58px] bg-[#222225]/95 backdrop-blur-md border-t border-[#3E3E44]"
      >
        <div className="max-w-4xl mx-auto h-full grid grid-cols-5">
          {(
            [
              { id: 'home', label: 'Home', Icon: Home },
              { id: 'projects', label: 'Projects', Icon: Film },
              { id: 'templates', label: 'Templates', Icon: Clapperboard },
              { id: 'effects', label: 'Effects', Icon: Zap },
              { id: 'settings', label: 'Settings', Icon: Settings },
            ] as const
          ).map(({ id, label, Icon }) => {
            const active = activeTab === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setActiveTab(id)}
                className={`relative min-h-[44px] flex flex-col items-center justify-center gap-1 transition-colors ${
                  active ? 'text-[#D4D4D8]' : 'text-[#A1A1AA] hover:text-white'
                }`}
              >
                {active && (
                  <span className="absolute top-0 w-7 h-[2px] bg-[#52525B] rounded-b-full" />
                )}
                <Icon className="w-5 h-5" />
                <span className="text-[11px] font-medium leading-none whitespace-nowrap">
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Notifications Drawer */}
      {notificationsOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/60 flex justify-end"
          onClick={() => setNotificationsOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-[#222225] border-l border-[#3E3E44] h-full p-5 flex flex-col gap-4"
          >
            <div className="flex items-center justify-between border-b border-[#3E3E44] pb-3">
              <div className="font-display text-base font-bold text-white">
                Notifications
              </div>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button
                    type="button"
                    onClick={() =>
                      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
                    }
                    className="text-xs text-[#D4D4D8] hover:text-white font-medium"
                  >
                    Mark all read
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setNotificationsOpen(false)}
                  aria-label="Close notifications"
                  className="min-w-[40px] min-h-[40px] flex items-center justify-center text-[#A1A1AA] hover:text-white rounded-xl"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2.5">
              {notifications.length === 0 ? (
                <div className="py-12 text-center text-xs text-[#A1A1AA]">
                  You&apos;re all caught up.
                </div>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    className={`p-3.5 rounded-2xl border ${
                      n.read
                        ? 'bg-[#2C2C30]/60 border-[#3E3E44]'
                        : 'bg-[#2C2C30] border-[#A1A1AA]/50'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-white">
                        {n.title}
                      </span>
                      <span className="text-[11px] text-[#A1A1AA]">{n.timeLabel}</span>
                    </div>
                    <p className="text-xs text-[#A1A1AA] mt-1">{n.detail}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Pro Capabilities / VIP Sheet */}
      {vipSheetOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4"
          onClick={() => setVipSheetOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-[#222225] border border-[#3E3E44] rounded-2xl p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#71717A]/15 border border-[#A1A1AA]/40 flex items-center justify-center">
                  <Crown className="w-5 h-5 text-[#D4D4D8]" />
                </div>
                <div>
                  <h3 className="font-display text-base font-bold text-white">
                    RED EFFECT APPS Pro Studio
                  </h3>
                  <p className="text-xs text-[#A1A1AA]">
                    All local cinema tools unlocked on this device
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setVipSheetOpen(false)}
                aria-label="Close Pro sheet"
                className="min-w-[40px] min-h-[40px] flex items-center justify-center text-[#A1A1AA] hover:text-white rounded-xl"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {[
                'Up to 4K & 8K UHD Export with 60/120fps support',
                'Multi-layer Null Object parenting & graph keyframes',
                'Shake, Glitch, RGB, Distortion & LUT Effects Suite',
                '3D Model Builder & 4D Particle Animation Workspace',
              ].map((feat) => (
                <div
                  key={feat}
                  className="p-3 bg-[#2C2C30] border border-[#3E3E44] rounded-xl flex items-center gap-2.5 text-xs text-white"
                >
                  <Check className="w-4 h-4 text-[#D4D4D8] shrink-0" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2.5 pt-1">
              {onOpenTrailerTemplate && (
                <button
                  type="button"
                  onClick={() => {
                    setVipSheetOpen(false);
                    onOpenTrailerTemplate();
                  }}
                  className="flex-1 min-h-[44px] bg-[#52525B] hover:bg-[#6B7280] text-white text-xs font-semibold rounded-xl transition-colors"
                >
                  Try Trailer Template
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  setVipSheetOpen(false);
                  onNewProject(null);
                }}
                className="flex-1 min-h-[44px] bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-white text-xs font-semibold rounded-xl transition-colors"
              >
                New Project
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rename Project Modal */}
      {renameTarget && (
        <div
          className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4"
          onClick={() => setRenameTarget(null)}
        >
          <form
            onSubmit={handleConfirmRename}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-[#222225] border border-[#3E3E44] rounded-2xl p-5 space-y-4 shadow-2xl"
          >
            <div className="font-display text-base font-bold text-white">
              Rename Project
            </div>
            <input
              type="text"
              autoFocus
              required
              value={renameDraft}
              onChange={(e) => setRenameDraft(e.target.value)}
              className="w-full min-h-[44px] px-3.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded-xl text-sm text-white focus:outline-none focus:border-[#A1A1AA]"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setRenameTarget(null)}
                className="min-h-[42px] px-4 py-2 text-xs font-medium text-[#A1A1AA] hover:text-white rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busyProjectAction || !renameDraft.trim()}
                className="min-h-[42px] px-5 py-2 bg-[#52525B] hover:bg-[#6B7280] disabled:opacity-50 text-white text-xs font-semibold rounded-xl"
              >
                Save Name
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div
          className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4"
          onClick={() => setDeleteTarget(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-[#222225] border border-[#3E3E44] rounded-2xl p-5 space-y-4 shadow-2xl"
          >
            <div className="space-y-1">
              <h3 className="font-display text-base font-bold text-white">
                Delete Project?
              </h3>
              <p className="text-xs text-[#A1A1AA] leading-relaxed">
                This will permanently remove <span className="text-white font-semibold">{deleteTarget.name}</span> from your saved projects.
              </p>
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="min-h-[42px] px-4 py-2 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-xs font-medium text-white rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={busyProjectAction}
                onClick={() => void handleConfirmDelete()}
                className="min-h-[42px] px-5 py-2 bg-[#52525B] hover:bg-[#6B7280] disabled:opacity-50 text-white text-xs font-semibold rounded-xl"
              >
                {busyProjectAction ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
