import React, { useEffect, useRef, useState } from 'react';
import {
  X,
  Download,
  Loader2,
  CheckCircle2,
  ExternalLink,
  AlertCircle,
  HardDrive,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { ExportSettings, StudioProject } from '../types/studio';
import {
  detectSupportedVideoCodecs,
  exportProjectMedia,
  getProjectEndTime,
} from '../services/exportEngine';
import { saveBlobWithWindowsDialog, SavedFileResult } from '../services/projectStorage';

interface ExportModalProps {
  project: StudioProject;
  playheadTime: number;
  defaultSettings: Partial<ExportSettings>;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  project,
  playheadTime,
  defaultSettings,
  onClose,
}) => {
  const [settings, setSettings] = useState<ExportSettings>({
    format: defaultSettings.format || project.videoFormat || 'mp4',
    codec: defaultSettings.codec || 'h264',
    resolution: defaultSettings.resolution || 'project',
    fps:
      defaultSettings.fps ||
      ([24, 25, 30, 50, 60, 120, 240].includes(project.fps)
        ? (project.fps as ExportSettings['fps'])
        : 30),
    bitrateMbps: defaultSettings.bitrateMbps || 18,
    fileName: project.name || 'RED_EFFECT_Export',
    audioEnabled: true,
    audioQuality: '192',
  });

  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [savedResult, setSavedResult] = useState<SavedFileResult | null>(null);
  const [codecSupport, setCodecSupport] = useState<{ h264: boolean; h265: boolean }>({
    h264: true,
    h265: false,
  });
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    detectSupportedVideoCodecs(project.width, project.height, settings.fps)
      .then(setCodecSupport)
      .catch(() => {});
  }, [project.width, project.height, settings.fps]);

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  const handleCancelExport = () => {
    abortControllerRef.current?.abort();
    setStage('Cancelling export...');
  };

  const duration = getProjectEndTime(project);
  const isImageFormat = settings.format === 'png' || settings.format === 'jpg';
  const isAudioOnly = settings.format === 'wav' || settings.format === 'mp3';

  const handleExport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isExporting) return;
    const ac = new AbortController();
    abortControllerRef.current = ac;
    setIsExporting(true);
    setErrorMsg(null);
    setSavedResult(null);
    setProgress(2);
    setStage('Preparing render & audio pipeline...');

    try {
      const rendered = await exportProjectMedia(
        project,
        settings,
        playheadTime,
        (pct, stg) => {
          setProgress(pct);
          setStage(stg);
        },
        ac.signal
      );

      setStage('Opening Windows Save File dialog...');
      const acceptMap: Record<string, string[]> = {
        [rendered.mimeType.split(';')[0] || 'application/octet-stream']: [rendered.extension],
      };

      const saved = await saveBlobWithWindowsDialog(
        rendered.blob,
        rendered.suggestedFileName,
        acceptMap,
        `RED EFFECT ${settings.format.toUpperCase()} Export`
      );

      if (saved.cancelled) {
        setStage('Save dialog cancelled.');
      } else {
        setSavedResult(saved);
        setStage(
          saved.usedNativeDialog
            ? `Saved directly to Windows folder as ${saved.fileName}`
            : `Saved ${saved.fileName}`
        );
      }
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        setStage('Export cancelled.');
        setProgress(0);
      } else {
        setErrorMsg(err instanceof Error ? err.message : 'Export failed.');
      }
    } finally {
      abortControllerRef.current = null;
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4 text-xs">
      <div className="w-full max-w-xl bg-[#222225] border border-[#3E3E44] rounded-md shadow-2xl overflow-hidden">
        <div className="px-4 py-3 bg-[#2C2C30] border-b border-[#3E3E44] flex items-center justify-between">
          <div className="font-display text-sm font-semibold text-[#F4F4F5]">
            Export Media · {project.name}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleExport} className="p-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="text-[11px] text-[#A1A1AA] block mb-1">Output File Name</label>
              <input
                type="text"
                value={settings.fileName}
                onChange={(e) => setSettings((s) => ({ ...s, fileName: e.target.value }))}
                className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
              />
            </div>

            <div>
              <label className="text-[11px] text-[#A1A1AA] block mb-1">Format</label>
              <select
                value={settings.format}
                onChange={(e) =>
                  setSettings((s) => ({ ...s, format: e.target.value as ExportSettings['format'] }))
                }
                className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
              >
                <option value="mp4">MP4 (Standard Cinema + Audio)</option>
                <option value="mov">MOV (QuickTime + Audio)</option>
                <option value="webm">WebM (VP9 + Opus)</option>
                <option value="png">PNG (Lossless Frame)</option>
                <option value="jpg">JPG (High Quality Frame)</option>
                <option value="wav">WAV (Lossless Audio Mix)</option>
                <option value="mp3">Audio Mixdown</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] text-[#A1A1AA] block mb-1">Resolution (Separate from Preview)</label>
              <select
                disabled={isAudioOnly}
                value={settings.resolution}
                onChange={(e) =>
                  setSettings((s) => ({
                    ...s,
                    resolution: e.target.value as ExportSettings['resolution'],
                  }))
                }
                className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA] disabled:opacity-40"
              >
                <option value="project">
                  Match Project ({project.width}×{project.height})
                </option>
                <option value="720p">720p HD (1280×720)</option>
                <option value="1080p">1080p Full HD (1920×1080)</option>
                <option value="2k">2K QHD (2560×1440)</option>
                <option value="4k">4K UHD (3840×2160)</option>
                <option value="8k">8K UHD (7680×4320)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] text-[#A1A1AA] block mb-1">Video Encoder Codec</label>
              <select
                disabled={isImageFormat || isAudioOnly || settings.format === 'webm'}
                value={settings.format === 'webm' ? 'vp9' : settings.codec || 'h264'}
                onChange={(e) =>
                  setSettings((s) => ({
                    ...s,
                    codec: e.target.value as ExportSettings['codec'],
                  }))
                }
                className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA] disabled:opacity-40"
              >
                <option value="h264">
                  H.264 / AVC {codecSupport.h264 ? '(Hardware Ready)' : '(Fallback)'}
                </option>
                <option value="h265" disabled={!codecSupport.h265}>
                  H.265 / HEVC {codecSupport.h265 ? '(Supported)' : '(Not Supported on Device)'}
                </option>
                {settings.format === 'webm' && <option value="vp9">VP9 (WebM)</option>}
              </select>
            </div>

            <div>
              <label className="text-[11px] text-[#A1A1AA] block mb-1">Frame Rate</label>
              <select
                disabled={isImageFormat || isAudioOnly}
                value={settings.fps}
                onChange={(e) =>
                  setSettings((s) => ({
                    ...s,
                    fps: Number(e.target.value) as ExportSettings['fps'],
                  }))
                }
                className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA] disabled:opacity-40 font-mono-tabular"
              >
                <option value={24}>24 FPS (Cinema)</option>
                <option value={25}>25 FPS (PAL)</option>
                <option value={30}>30 FPS (Standard)</option>
                <option value={50}>50 FPS</option>
                <option value={60}>60 FPS (High Motion)</option>
                <option value={120}>120 FPS (Ultra)</option>
                <option value={240}>240 FPS (Smooth Motion)</option>
              </select>
            </div>

            <div className="col-span-2">
              <div className="flex justify-between text-[11px] text-[#A1A1AA] mb-1">
                <span>Video Bitrate (Full-Quality Export)</span>
                <span className="font-mono-tabular text-[#F4F4F5]">{settings.bitrateMbps} Mbps</span>
              </div>
              <input
                type="range"
                min={2}
                max={100}
                step={2}
                disabled={isImageFormat || isAudioOnly}
                value={settings.bitrateMbps}
                onChange={(e) =>
                  setSettings((s) => ({ ...s, bitrateMbps: Number(e.target.value) }))
                }
                className="w-full mt-1 cursor-pointer disabled:opacity-40"
              />
            </div>
          </div>

          {/* Audio Export Settings */}
          {!isImageFormat && (
            <div className="p-3 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-medium text-[#F4F4F5] flex items-center gap-1.5">
                  {settings.audioEnabled ? (
                    <Volume2 className="w-3.5 h-3.5 text-[#D4D4D8]" />
                  ) : (
                    <VolumeX className="w-3.5 h-3.5 text-[#A1A1AA]" />
                  )}
                  Audio Track Export
                </span>
                <button
                  type="button"
                  disabled={isAudioOnly}
                  onClick={() =>
                    setSettings((s) => ({ ...s, audioEnabled: !s.audioEnabled }))
                  }
                  className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                    settings.audioEnabled
                      ? 'bg-[#52525B] hover:bg-[#6B7280] text-white'
                      : 'bg-[#18181A] text-[#A1A1AA] hover:text-[#F4F4F5] border border-[#3E3E44]'
                  }`}
                >
                  {settings.audioEnabled ? 'Audio Enabled' : 'Audio Disabled'}
                </button>
              </div>

              {settings.audioEnabled && (
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="text-[11px] text-[#A1A1AA] block mb-1">
                      Audio Quality (Bitrate)
                    </label>
                    <select
                      value={settings.audioQuality}
                      onChange={(e) =>
                        setSettings((s) => ({
                          ...s,
                          audioQuality: e.target.value as ExportSettings['audioQuality'],
                        }))
                      }
                      className="w-full px-2 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value="128">128 kbps (Standard)</option>
                      <option value="192">192 kbps (High Stereo)</option>
                      <option value="256">256 kbps (Studio AAC)</option>
                      <option value="320">320 kbps (Master Quality)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-[#A1A1AA] block mb-1">
                      Sample Rate
                    </label>
                    <div className="px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] font-mono-tabular">
                      {(project.audioSampleRate || 48000).toLocaleString()} Hz · Stereo
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="p-2.5 bg-[#2C2C30] border border-[#3E3E44] rounded flex items-center justify-between text-[11px] text-[#A1A1AA] font-mono-tabular">
            <span>Duration: {duration.toFixed(2)}s</span>
            <span>
              Est. Size:{' '}
              {isImageFormat
                ? '~2.4 MB'
                : `${((duration * (isAudioOnly ? 1.5 : settings.bitrateMbps)) / 8).toFixed(1)} MB`}
            </span>
          </div>

          {(isExporting || stage) && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-[#F4F4F5]">
                <span>{stage}</span>
                <span className="font-mono-tabular">{progress}%</span>
              </div>
              <div className="w-full h-1.5 bg-[#18181A] rounded overflow-hidden">
                <div
                  style={{ width: `${progress}%` }}
                  className="h-full bg-[#52525B] transition-[width] duration-150"
                />
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="p-2.5 bg-rose-950/50 border border-rose-500/40 rounded text-rose-200 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {savedResult && !savedResult.cancelled && (
            <div className="p-3 bg-emerald-950/30 border border-emerald-500/40 rounded space-y-2">
              <div className="flex items-center gap-2 text-emerald-300 font-medium">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>
                  Saved {savedResult.fileName} ({(savedResult.sizeBytes / 1024 / 1024).toFixed(2)} MB)
                </span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={savedResult.previewUrl}
                  download={savedResult.fileName}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-100 rounded border border-white/[0.1] inline-flex items-center gap-1"
                >
                  <ExternalLink className="w-3 h-3" />
                  Open Exported File
                </a>
                <span className="text-[11px] text-zinc-400 flex items-center gap-1">
                  <HardDrive className="w-3 h-3" />
                  {savedResult.usedNativeDialog
                    ? 'Written to selected Windows folder'
                    : 'Saved to Windows Downloads folder'}
                </span>
              </div>
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#3E3E44]">
            {isExporting ? (
              <button
                type="button"
                onClick={handleCancelExport}
                className="px-4 py-2 bg-[#2C2C30] hover:bg-[#2E323E] text-rose-300 border border-rose-500/40 rounded font-medium"
              >
                Cancel Export
              </button>
            ) : (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-[#A1A1AA] hover:text-[#F4F4F5] rounded"
              >
                Close
              </button>
            )}
            <button
              type="submit"
              disabled={isExporting}
              className="px-5 py-2 bg-[#52525B] hover:bg-[#6B7280] disabled:opacity-50 text-white font-medium rounded flex items-center gap-2"
            >
              {isExporting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Rendering...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Export &amp; Save to PC
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
