import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Film, ArrowRightLeft, Search } from 'lucide-react';
import {
  AnimationEasing,
  ReadyMadeEffectPreset,
  TransitionCategoryId,
  TransitionDefinition,
  TransitionDirection,
  TransitionSettings,
} from '../types/effects';
import { TimelineClip } from '../types/studio';
import { TRANSITION_CATEGORIES, TRANSITIONS_CATALOG } from '../services/effectsCatalog';
import { computeTransitionState } from '../services/effectsProcessor';
import { transitionDefToHoverPreset } from '../services/hoverPreviewCache';

interface TransitionsPanelProps {
  selectedClip: TimelineClip | null;
  hoverPreviewEnabled?: boolean;
  onApplyTransition: (
    side: 'in' | 'out' | 'both',
    settings: TransitionSettings,
    targetClipId?: string
  ) => void;
  onHoverTransition?: (preset: ReadyMadeEffectPreset | null) => void;
  onClearHoverImmediate?: () => void;
}

export const TransitionsPanel: React.FC<TransitionsPanelProps> = ({
  selectedClip,
  hoverPreviewEnabled = true,
  onApplyTransition,
  onHoverTransition,
  onClearHoverImmediate,
}) => {
  const [search, setSearch] = useState('');
  const [activeCat, setActiveCat] = useState<TransitionCategoryId | 'all'>('all');
  const [previewDef, setPreviewDef] = useState<TransitionDefinition>(TRANSITIONS_CATALOG[0]);
  const [duration, setDuration] = useState(0.6);
  const [speed, setSpeed] = useState(1);
  const [direction, setDirection] = useState<TransitionDirection>('left');
  const [intensity, setIntensity] = useState(80);
  const [easing, setEasing] = useState<AnimationEasing>('easeInOut');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const items = useMemo(() => {
    const q = search.trim().toLowerCase();
    return TRANSITIONS_CATALOG.filter((tr) => {
      if (activeCat !== 'all' && tr.category !== activeCat) return false;
      if (q && !tr.name.toLowerCase().includes(q) && !tr.description.toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [activeCat, search]);

  const buildSettings = (def: TransitionDefinition): TransitionSettings => ({
    ...def.defaultSettings,
    duration,
    speed,
    direction,
    intensity,
    easing,
  });

  // Live animated mini-preview canvas for the active transition
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let raf = 0;
    const start = performance.now();

    const loop = (now: number) => {
      const w = canvas.width;
      const h = canvas.height;
      const tSec = ((now - start) / 1000) % 1.8;
      const p = Math.min(1, tSec / 1.1);

      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = '#18181A';
      ctx.fillRect(0, 0, w, h);

      // Outgoing scene A
      ctx.fillStyle = '#2C2C30';
      ctx.fillRect(8, 8, w - 16, h - 16);
      ctx.fillStyle = '#A1A1AA';
      ctx.font = '600 10px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText('CLIP A', w * 0.5, h * 0.52);

      // Incoming scene B transformed by real computeTransitionState
      const settings: TransitionSettings = {
        ...previewDef.defaultSettings,
        duration,
        speed,
        direction,
        intensity,
        easing,
      };
      const st = computeTransitionState(settings, p, false, w, h, tSec);

      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, st.opacityMult));
      ctx.translate(w * 0.5 + st.offsetX + st.shakeX, h * 0.5 + st.offsetY + st.shakeY);
      ctx.rotate((st.rotationDeg * Math.PI) / 180);
      ctx.scale(st.scaleMultX, st.scaleMultY);

      if (st.clipMode === 'circle') {
        ctx.beginPath();
        ctx.arc(0, 0, Math.max(w, h) * st.clipProgress * 0.7, 0, Math.PI * 2);
        ctx.clip();
      } else if (st.clipMode === 'rect-wipe') {
        ctx.beginPath();
        ctx.rect(-w * 0.5, -h * 0.5, w * st.clipProgress, h);
        ctx.clip();
      } else if (st.clipMode === 'radial-wipe') {
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, w, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * st.clipProgress);
        ctx.closePath();
        ctx.clip();
      } else if (st.clipMode === 'diamond') {
        const d = Math.max(w, h) * st.clipProgress * 0.75;
        ctx.beginPath();
        ctx.moveTo(0, -d);
        ctx.lineTo(d, 0);
        ctx.lineTo(0, d);
        ctx.lineTo(-d, 0);
        ctx.closePath();
        ctx.clip();
      }

      if (st.blurAdd > 0.3) ctx.filter = `blur(${(st.blurAdd * 0.35).toFixed(1)}px)`;

      const grad = ctx.createLinearGradient(-w * 0.5, -h * 0.5, w * 0.5, h * 0.5);
      grad.addColorStop(0, '#4C389C');
      grad.addColorStop(1, '#A1A1AA');
      ctx.fillStyle = grad;
      ctx.fillRect(-w * 0.44, -h * 0.4, w * 0.88, h * 0.8);

      ctx.filter = 'none';
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '700 11px "Outfit", sans-serif';
      ctx.fillText(previewDef.name.toUpperCase(), 0, 4);
      ctx.restore();

      if (st.flashAlpha > 0.01) {
        ctx.fillStyle = st.flashColor;
        ctx.globalAlpha = Math.min(1, st.flashAlpha);
        ctx.fillRect(0, 0, w, h);
        ctx.globalAlpha = 1;
      }

      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [previewDef, duration, speed, direction, intensity, easing]);

  const clearHover = () => {
    if (onClearHoverImmediate) {
      onClearHoverImmediate();
    } else {
      onHoverTransition?.(null);
    }
  };

  useEffect(() => {
    return () => {
      clearHover();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      data-tutorial-target="transitions-panel"
      onMouseLeave={clearHover}
      className="p-2.5 flex flex-col gap-2.5 h-full text-xs bg-[#222225] text-[#F4F4F5]"
    >
      {/* Live Animated Transition Preview */}
      <div className="rounded border border-[#3E3E44] bg-[#18181A] p-2 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-[#F4F4F5] truncate flex items-center gap-1.5">
            <ArrowRightLeft className="w-3.5 h-3.5 text-[#D4D4D8]" />
            {previewDef.name}
          </span>
          <span className="text-[10px] text-[#A1A1AA] uppercase">{previewDef.category}</span>
        </div>

        <canvas
          ref={canvasRef}
          width={260}
          height={86}
          className="w-full h-[86px] rounded border border-[#3E3E44] block"
        />

        {/* Quick Customization */}
        <div className="grid grid-cols-2 gap-1.5 text-[10px]">
          <label className="space-y-0.5 text-[#A1A1AA]">
            <span>Duration ({duration.toFixed(2)}s)</span>
            <input
              type="range"
              min={0.15}
              max={2.5}
              step={0.05}
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="w-full h-1"
            />
          </label>
          <label className="space-y-0.5 text-[#A1A1AA]">
            <span>Speed ({speed.toFixed(1)}×)</span>
            <input
              type="range"
              min={0.4}
              max={2.5}
              step={0.1}
              value={speed}
              onChange={(e) => setSpeed(Number(e.target.value))}
              className="w-full h-1"
            />
          </label>
          <label className="space-y-0.5 text-[#A1A1AA]">
            <span>Direction</span>
            <select
              value={direction}
              onChange={(e) => setDirection(e.target.value as TransitionDirection)}
              className="w-full px-1.5 py-1 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#F4F4F5]"
            >
              <option value="left">Left</option>
              <option value="right">Right</option>
              <option value="up">Up</option>
              <option value="down">Down</option>
              <option value="center">Center</option>
            </select>
          </label>
          <label className="space-y-0.5 text-[#A1A1AA]">
            <span>Easing</span>
            <select
              value={easing}
              onChange={(e) => setEasing(e.target.value as AnimationEasing)}
              className="w-full px-1.5 py-1 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#F4F4F5]"
            >
              <option value="linear">Linear</option>
              <option value="easeIn">Ease In</option>
              <option value="easeOut">Ease Out</option>
              <option value="easeInOut">Ease In-Out</option>
            </select>
          </label>
        </div>

        <label className="space-y-0.5 text-[10px] text-[#A1A1AA] block">
          <span>Intensity ({intensity}%)</span>
          <input
            type="range"
            min={10}
            max={100}
            step={5}
            value={intensity}
            onChange={(e) => setIntensity(Number(e.target.value))}
            className="w-full h-1"
          />
        </label>

        <div className="grid grid-cols-3 gap-1">
          <button
            type="button"
            disabled={!selectedClip}
            onClick={() => onApplyTransition('in', buildSettings(previewDef), selectedClip?.id)}
            className="py-1 bg-[#52525B] hover:bg-[#6B7280] disabled:opacity-40 text-white rounded text-[10px] font-medium"
          >
            Apply In
          </button>
          <button
            type="button"
            disabled={!selectedClip}
            onClick={() => onApplyTransition('out', buildSettings(previewDef), selectedClip?.id)}
            className="py-1 bg-[#2C2C30] hover:bg-[#343439] disabled:opacity-40 border border-[#3E3E44] text-[#F4F4F5] rounded text-[10px] font-medium"
          >
            Apply Out
          </button>
          <button
            type="button"
            disabled={!selectedClip}
            onClick={() => onApplyTransition('both', buildSettings(previewDef), selectedClip?.id)}
            className="py-1 bg-[#2C2C30] hover:bg-[#343439] disabled:opacity-40 border border-[#3E3E44] text-[#F4F4F5] rounded text-[10px] font-medium"
          >
            Both
          </button>
        </div>
      </div>

      {/* Search & Category Tabs */}
      <div className="relative">
        <Search className="w-3.5 h-3.5 text-[#A1A1AA] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search 37 transitions..."
          className="w-full pl-8 pr-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] placeholder:text-[#A1A1AA] focus:outline-none focus:border-[#A1A1AA]"
        />
      </div>

      <div className="flex flex-wrap gap-1">
        <button
          type="button"
          onClick={() => setActiveCat('all')}
          className={`px-2 py-1 rounded text-[10px] font-medium ${
            activeCat === 'all'
              ? 'bg-[#52525B] text-white'
              : 'bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5] border border-[#3E3E44]'
          }`}
        >
          All ({TRANSITIONS_CATALOG.length})
        </button>
        {TRANSITION_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setActiveCat(cat.id)}
            className={`px-2 py-1 rounded text-[10px] font-medium ${
              activeCat === cat.id
                ? 'bg-[#52525B] text-white'
                : 'bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5] border border-[#3E3E44]'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Transition List */}
      <div
        onMouseLeave={clearHover}
        className="flex-1 overflow-y-auto space-y-1.5 pr-0.5"
      >
        {items.map((tr) => {
          const settings = buildSettings(tr);
          const payload = JSON.stringify({
            kind: 'transitionConfig',
            side: 'in',
            config: settings,
          });
          const active = previewDef.type === tr.type;
          return (
            <div
              key={tr.type}
              draggable
              onMouseEnter={() => {
                setPreviewDef(tr);
                if (hoverPreviewEnabled && onHoverTransition) {
                  onHoverTransition(transitionDefToHoverPreset(tr, settings));
                }
              }}
              onMouseLeave={() => {
                if (hoverPreviewEnabled && onHoverTransition) {
                  onHoverTransition(null);
                }
              }}
              onDragStart={(e) => {
                clearHover();
                e.dataTransfer.setData('application/x-redeffect-fx', payload);
                e.dataTransfer.effectAllowed = 'copy';
              }}
              onClick={() => {
                clearHover();
                setPreviewDef(tr);
                if (selectedClip) onApplyTransition('in', settings, selectedClip.id);
              }}
              className={`p-2 rounded border cursor-pointer flex items-center justify-between gap-2 transition-colors ${
                active
                  ? 'bg-[#2C2C30] border-[#A1A1AA]'
                  : 'bg-[#2C2C30] border-[#3E3E44] hover:border-[#A1A1AA]/60'
              }`}
            >
              <div className="flex items-center gap-2 min-w-0">
                <Film className="w-3.5 h-3.5 text-[#D4D4D8] shrink-0" />
                <div className="min-w-0">
                  <div className="text-[#F4F4F5] font-medium truncate">{tr.name}</div>
                  <div className="text-[10px] text-[#A1A1AA] truncate">{tr.description}</div>
                </div>
              </div>
              <span className="text-[10px] text-[#D4D4D8] shrink-0">
                {selectedClip ? 'Apply' : 'Drag'}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
