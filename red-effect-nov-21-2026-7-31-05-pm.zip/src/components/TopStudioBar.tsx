import React, { useEffect, useState } from 'react';
import {
  Undo2,
  Redo2,
  Download,
  Settings,
  ChevronRight,
  ChevronDown,
  Check,
  Sparkles,
  SlidersHorizontal,
  Gauge,
  Save,
  FolderCog,
  Zap,
  Volume2,
  VolumeX,
  Palette,
} from 'lucide-react';
import {
  PanelId,
  PreviewQuality,
  StudioProject,
  WorkspaceMode,
} from '../types/studio';

export type StudioMenuAction =
  | 'file:new'
  | 'file:open'
  | 'file:save'
  | 'file:saveAs'
  | 'file:importMedia'
  | 'file:export'
  | 'file:exitHome'
  | 'edit:undo'
  | 'edit:redo'
  | 'edit:cut'
  | 'edit:copy'
  | 'edit:paste'
  | 'edit:delete'
  | 'edit:selectAll'
  | 'edit:preferences'
  | 'view:workspace:editing'
  | 'view:workspace:motion'
  | 'view:workspace:3d'
  | 'view:workspace:4d'
  | 'view:workspace:audio'
  | 'view:saveCustomLayout'
  | 'view:restoreDefaultLayout'
  | 'view:resetLayout'
  | 'view:home'
  | 'view:uiTheme'
  | 'project:settings'
  | 'project:saveSnapshot'
  | 'clip:split'
  | 'clip:merge'
  | 'clip:duplicate'
  | 'clip:toggleMute'
  | 'clip:toggleLock'
  | 'clip:speedSlow'
  | 'clip:speedFast'
  | 'clip:resetTransform'
  | 'sequence:addVideoTrack'
  | 'sequence:addAudioTrack'
  | 'sequence:addImageTrack'
  | 'sequence:addTextTrack'
  | 'sequence:addMarker'
  | 'sequence:toggleSnap'
  | 'layer:addTitle'
  | 'layer:addSubtitle'
  | 'layer:toggle3D'
  | 'layer:openLayers'
  | 'effects:tealOrange'
  | 'effects:crimsonNoir'
  | 'effects:crossDissolve'
  | 'effects:chromaKey'
  | 'effects:redSmoke'
  | 'effects:openPanel'
  | 'animation:keyScale'
  | 'animation:keyOpacity'
  | 'animation:zoomIn'
  | 'animation:logoSpin'
  | 'audio:addTrack'
  | 'audio:toggleMasterMute'
  | 'audio:fadeIn'
  | 'audio:fadeOut'
  | 'audio:openMixer'
  | 'audio:deviceSettings'
  | 'export:video'
  | 'export:framePNG'
  | 'export:audioWAV'
  | 'help:tutorial'
  | 'help:shortcuts'
  | 'help:guide';

interface TopStudioBarProps {
  projectName: string;
  recentProjects: StudioProject[];
  workspaceMode: WorkspaceMode;
  canUndo: boolean;
  canRedo: boolean;
  hasSelectedClip: boolean;
  hasClipboard: boolean;
  masterVolume: number;
  masterMuted: boolean;
  closedPanels?: PanelId[];
  floatingPanels?: PanelId[];
  activeLayoutPresetId?: string;
  customLayouts?: Array<{ id: string; name: string }>;
  previewQuality?: PreviewQuality;
  performanceMode?: boolean;
  lastSavedAt?: number | null;
  onChangeWorkspace: (mode: WorkspaceMode) => void;
  onMenuAction: (action: StudioMenuAction) => void;
  onLoadRecentProject: (proj: StudioProject) => void;
  onToggleMasterMute: () => void;
  onSetMasterVolume: (vol: number) => void;
  onTogglePanelWindow?: (panelId: PanelId) => void;
  onSelectLayoutPreset?: (presetId: string) => void;
  onRenameCustomLayout?: () => void;
  onDuplicateLayout?: () => void;
  onDeleteCustomLayout?: () => void;
  effectsLibraryOpen?: boolean;
  onToggleEffectsLibrary?: () => void;
  onOpenQualityEnhancer?: (tab: 'enhancer' | 'smooth') => void;
  onChangePreviewQuality?: (q: PreviewQuality) => void;
  onTogglePerformanceMode?: () => void;
}

type MenuId = 'File' | 'Edit' | 'View' | 'Workspace';

interface MenuItemDef {
  label: string;
  action?: StudioMenuAction;
  onCustomClick?: () => void;
  shortcut?: string;
  disabled?: boolean;
  checked?: boolean;
  dividerBefore?: boolean;
  submenuRecent?: boolean;
  sectionHeader?: string;
}

const WINDOW_PANEL_LIST: Array<{ id: PanelId; label: string }> = [
  { id: 'templates', label: 'Asset Browser' },
  { id: 'monitor', label: 'Video Preview' },
  { id: 'properties', label: 'Properties Inspector' },
  { id: 'timeline', label: 'Multi-Track Timeline' },
  { id: 'keyframes', label: 'Keyframe Graph Editor' },
  { id: 'nullHierarchy', label: 'Null Objects & Parenting' },
  { id: 'colorControls', label: 'Color Correction Panel' },
  { id: 'mixer', label: 'Audio Mixer' },
  { id: 'layers', label: 'Layers & Tracking' },
];

const WORKSPACE_MODES: Array<{ id: string; label: string; mode?: WorkspaceMode }> = [
  { id: 'editing-workspace', label: 'Editing', mode: 'editing' },
  { id: 'effects-workspace', label: 'Effects', mode: 'editing' },
  { id: 'motion-workspace', label: 'Motion Graphics', mode: 'motion' },
  { id: 'color-workspace', label: 'Color', mode: 'editing' },
  { id: 'audio-workspace', label: 'Audio', mode: 'audio' },
];

export const TopStudioBar: React.FC<TopStudioBarProps> = ({
  projectName,
  recentProjects,
  workspaceMode,
  canUndo,
  canRedo,
  hasSelectedClip,
  hasClipboard,
  masterVolume,
  masterMuted,
  closedPanels = [],
  floatingPanels = [],
  activeLayoutPresetId = 'editing-workspace',
  customLayouts = [],
  previewQuality = 'high',
  performanceMode = false,
  lastSavedAt = null,
  onChangeWorkspace,
  onMenuAction,
  onLoadRecentProject,
  onToggleMasterMute,
  onSetMasterVolume,
  onTogglePanelWindow,
  onSelectLayoutPreset,
  onRenameCustomLayout,
  onDuplicateLayout,
  onDeleteCustomLayout,
  effectsLibraryOpen = false,
  onToggleEffectsLibrary,
  onOpenQualityEnhancer,
  onChangePreviewQuality,
  onTogglePerformanceMode,
}) => {
  const [openMenu, setOpenMenu] = useState<MenuId | null>(null);
  const [recentOpen, setRecentOpen] = useState(false);
  const [justSaved, setJustSaved] = useState(false);

  useEffect(() => {
    if (!lastSavedAt) return;
    setJustSaved(true);
    const id = window.setTimeout(() => setJustSaved(false), 1800);
    return () => window.clearTimeout(id);
  }, [lastSavedAt]);

  useEffect(() => {
    const onEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpenMenu(null);
        setRecentOpen(false);
      }
    };
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, []);

  const isCustomActive = customLayouts.some((l) => l.id === activeLayoutPresetId);

  const activeWorkspaceLabel = (() => {
    if (workspaceMode === '3d') return '3D Studio';
    if (workspaceMode === '4d') return '4D Studio';
    const custom = customLayouts.find((c) => c.id === activeLayoutPresetId);
    if (custom) return custom.name;
    const found = WORKSPACE_MODES.find((w) => w.id === activeLayoutPresetId);
    return found?.label || 'Editing';
  })();

  const menus: Record<MenuId, MenuItemDef[]> = {
    File: [
      { label: 'New Project...', action: 'file:new', shortcut: 'Ctrl+N' },
      { label: 'Open Project...', action: 'file:open', shortcut: 'Ctrl+O' },
      { label: 'Open Recent', submenuRecent: true },
      { label: 'Import Media...', action: 'file:importMedia', shortcut: 'Ctrl+I', dividerBefore: true },
      { label: 'Save Project', action: 'file:save', shortcut: 'Ctrl+S', dividerBefore: true },
      { label: 'Save As (.redeffect)...', action: 'file:saveAs', shortcut: 'Ctrl+Shift+S' },
      { label: 'Project Settings...', action: 'project:settings', dividerBefore: true },
      { label: 'Export Video (MP4 / MOV)...', action: 'export:video', shortcut: 'Ctrl+M', dividerBefore: true },
      { label: 'Snapshot Frame (PNG)', action: 'export:framePNG' },
      { label: 'Export Audio (WAV)', action: 'export:audioWAV' },
      { label: 'Home Launchpad', action: 'view:home', dividerBefore: true },
    ],
    Edit: [
      { label: 'Undo', action: 'edit:undo', shortcut: 'Ctrl+Z', disabled: !canUndo },
      { label: 'Redo', action: 'edit:redo', shortcut: 'Ctrl+Shift+Z', disabled: !canRedo },
      { label: 'Cut Clip', action: 'edit:cut', shortcut: 'Ctrl+X', disabled: !hasSelectedClip, dividerBefore: true },
      { label: 'Copy Clip', action: 'edit:copy', shortcut: 'Ctrl+C', disabled: !hasSelectedClip },
      { label: 'Paste Clip', action: 'edit:paste', shortcut: 'Ctrl+V', disabled: !hasClipboard },
      { label: 'Duplicate Clip', action: 'clip:duplicate', shortcut: 'Ctrl+D', disabled: !hasSelectedClip },
      { label: 'Split at Playhead', action: 'clip:split', disabled: !hasSelectedClip, dividerBefore: true },
      { label: 'Reset Clip Transform', action: 'clip:resetTransform', disabled: !hasSelectedClip },
      { label: 'Delete Selection', action: 'edit:delete', shortcut: 'Del', disabled: !hasSelectedClip },
      { label: 'Select All Clips', action: 'edit:selectAll', shortcut: 'Ctrl+A', dividerBefore: true },
      { label: 'Preferences & Shortcuts...', action: 'edit:preferences', dividerBefore: true },
    ],
    View: [
      ...WINDOW_PANEL_LIST.map((p) => {
        const isClosed = closedPanels.includes(p.id);
        const isFloating = floatingPanels.includes(p.id);
        return {
          label: isFloating ? `${p.label} (Floating)` : p.label,
          checked: !isClosed,
          onCustomClick: () => onTogglePanelWindow?.(p.id),
        };
      }),
      { label: 'Effects Library Drawer', action: 'effects:openPanel', dividerBefore: true },
      { label: 'Quality Enhancer...', onCustomClick: () => onOpenQualityEnhancer?.('enhancer') },
      { label: 'Smooth Video Interpolation...', onCustomClick: () => onOpenQualityEnhancer?.('smooth') },
      { label: 'Toggle Timeline Snap', action: 'sequence:toggleSnap', dividerBefore: true },
      { label: 'Add Timeline Marker', action: 'sequence:addMarker', shortcut: 'M' },
      { label: 'UI Theme & Colors...', action: 'view:uiTheme', dividerBefore: true },
      { label: 'RED EFFECT Tutorial', action: 'help:tutorial' },
      { label: 'Keyboard Shortcuts...', action: 'help:shortcuts' },
    ],
    Workspace: [
      ...WORKSPACE_MODES.map((w) => ({
        label: `${w.label} Workspace`,
        checked: activeLayoutPresetId === w.id && workspaceMode !== '3d' && workspaceMode !== '4d',
        onCustomClick: () => onSelectLayoutPreset?.(w.id),
      })),
      {
        label: '3D Studio',
        checked: workspaceMode === '3d',
        dividerBefore: true,
        action: 'view:workspace:3d',
      },
      {
        label: '4D Studio',
        checked: workspaceMode === '4d',
        action: 'view:workspace:4d',
      },
      ...customLayouts.map((c, idx) => ({
        label: `Custom: ${c.name}`,
        checked: activeLayoutPresetId === c.id,
        dividerBefore: idx === 0,
        onCustomClick: () => onSelectLayoutPreset?.(c.id),
      })),
      { label: 'Save Custom Workspace...', action: 'view:saveCustomLayout', dividerBefore: true },
      {
        label: 'Rename Custom Workspace...',
        disabled: !isCustomActive,
        onCustomClick: () => onRenameCustomLayout?.(),
      },
      { label: 'Duplicate Active Layout', onCustomClick: () => onDuplicateLayout?.() },
      {
        label: 'Delete Custom Workspace',
        disabled: !isCustomActive,
        onCustomClick: () => onDeleteCustomLayout?.(),
      },
      { label: 'Restore Default Workspace', action: 'view:restoreDefaultLayout', dividerBefore: true },
    ],
  };

  return (
    <header
      data-tutorial-target="main-toolbar"
      className="h-[50px] px-3 bg-[#222225] border-b border-[#3E3E44] flex items-center justify-between gap-2 shrink-0 relative z-40 select-none"
    >
      {openMenu && (
        <div
          onClick={() => {
            setOpenMenu(null);
            setRecentOpen(false);
          }}
          className="fixed inset-0 z-40"
        />
      )}

      {/* LEFT: Application Logo · Project Name · File · Edit · View · Workspace */}
      <div className="flex items-center gap-1.5 min-w-0 relative z-50">
        <button
          type="button"
          data-tutorial-target="home-button"
          onClick={() => onMenuAction('view:home')}
          title="RED EFFECT Studio Home"
          className="flex items-center gap-2 pr-2.5 border-r border-[#3E3E44] shrink-0 group"
        >
          <img
            src="/assets/aistudio/Project_Name_107_473da90f.png"
            alt="RED EFFECT logo"
            className="w-6 h-6 rounded object-cover shrink-0 shadow-sm"
          />
          <span className="font-display text-xs font-bold tracking-wider text-[#F4F4F5] group-hover:text-white whitespace-nowrap hidden sm:inline">
            RED EFFECT
          </span>
        </button>

        <button
          type="button"
          onClick={() => onMenuAction('project:settings')}
          title={`Active Project: ${projectName} (Click for Project Settings)`}
          className="hidden md:flex items-center gap-1.5 px-2 py-1 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] max-w-[155px] transition-colors shrink-0"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#52525B] shrink-0" />
          <span className="truncate font-medium">{projectName}</span>
        </button>

        <nav className="flex items-center gap-0.5 ml-0.5">
          {(['File', 'Edit', 'View', 'Workspace'] as MenuId[]).map((menuId) => {
            const isOpen = openMenu === menuId;
            return (
              <div key={menuId} className="relative">
                <button
                  type="button"
                  data-tutorial-target={menuId === 'Workspace' ? 'workspace-tabs' : undefined}
                  onClick={() => {
                    setOpenMenu(isOpen ? null : menuId);
                    setRecentOpen(false);
                  }}
                  onMouseEnter={() => {
                    if (openMenu) {
                      setOpenMenu(menuId);
                      setRecentOpen(false);
                    }
                  }}
                  className={`px-2 py-1 text-[11px] font-medium rounded flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 ${
                    isOpen
                      ? 'bg-[#52525B] text-white'
                      : menuId === 'Workspace'
                      ? 'bg-[#2C2C30] border border-[#3E3E44] text-[#F4F4F5] hover:border-[#A1A1AA]/70'
                      : 'text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
                  }`}
                >
                  <span>{menuId === 'Workspace' ? activeWorkspaceLabel : menuId}</span>
                  {menuId === 'Workspace' && <ChevronDown className="w-3 h-3 opacity-80" />}
                </button>

                {isOpen && (
                  <div className="absolute left-0 top-full mt-1 w-64 max-h-[80vh] overflow-y-auto bg-[#222225] border border-[#3E3E44] rounded shadow-2xl py-1 z-50 text-xs">
                    {menus[menuId].map((item, idx) => (
                      <React.Fragment key={idx}>
                        {item.dividerBefore && (
                          <div className="my-1 border-t border-[#3E3E44]" />
                        )}
                        {item.submenuRecent ? (
                          <div
                            className="relative"
                            onMouseEnter={() => setRecentOpen(true)}
                            onMouseLeave={() => setRecentOpen(false)}
                          >
                            <button
                              type="button"
                              onClick={() => setRecentOpen((v) => !v)}
                              className="w-full px-3 py-1.5 text-left text-[#F4F4F5] hover:bg-[#71717A]/20 flex items-center justify-between"
                            >
                              <span>{item.label}</span>
                              <ChevronRight className="w-3.5 h-3.5 text-[#A1A1AA]" />
                            </button>
                            {recentOpen && (
                              <div className="absolute left-full top-0 ml-0.5 w-56 bg-[#222225] border border-[#3E3E44] rounded shadow-2xl py-1 z-50">
                                {recentProjects.length === 0 ? (
                                  <div className="px-3 py-1.5 text-[#A1A1AA]">No recent projects</div>
                                ) : (
                                  recentProjects.slice(0, 8).map((rp) => (
                                    <button
                                      key={rp.id}
                                      type="button"
                                      onClick={() => {
                                        setOpenMenu(null);
                                        setRecentOpen(false);
                                        onLoadRecentProject(rp);
                                      }}
                                      className="w-full px-3 py-1.5 text-left text-[#F4F4F5] hover:bg-[#71717A]/20 flex items-center justify-between gap-2"
                                    >
                                      <span className="truncate">{rp.name}</span>
                                      <span className="text-[10px] font-mono-tabular text-[#A1A1AA] shrink-0">
                                        {rp.width}×{rp.height}
                                      </span>
                                    </button>
                                  ))
                                )}
                              </div>
                            )}
                          </div>
                        ) : (
                          <button
                            type="button"
                            disabled={item.disabled}
                            onClick={() => {
                              setOpenMenu(null);
                              if (item.onCustomClick) item.onCustomClick();
                              else if (item.action) onMenuAction(item.action);
                            }}
                            className="w-full px-3 py-1.5 text-left text-[#F4F4F5] hover:bg-[#71717A]/20 disabled:opacity-35 disabled:hover:bg-transparent flex items-center justify-between gap-2"
                          >
                            <span className="flex items-center gap-2 min-w-0">
                              <span className="w-3.5 shrink-0 flex items-center justify-center">
                                {item.checked && (
                                  <Check className="w-3 h-3 text-[#D4D4D8]" />
                                )}
                              </span>
                              <span className="truncate">{item.label}</span>
                            </span>
                            {item.shortcut && (
                              <span className="text-[10px] font-mono-tabular text-[#A1A1AA] shrink-0">
                                {item.shortcut}
                              </span>
                            )}
                          </button>
                        )}
                      </React.Fragment>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Compact Quick Workspace Switcher on wide desktop screens */}
        <div className="hidden 2xl:flex items-center gap-0.5 bg-[#18181A] p-0.5 rounded border border-[#3E3E44] ml-1">
          {WORKSPACE_MODES.map((w) => {
            const active =
              activeLayoutPresetId === w.id && workspaceMode !== '3d' && workspaceMode !== '4d';
            return (
              <button
                key={w.id}
                type="button"
                onClick={() => onSelectLayoutPreset?.(w.id)}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-[#71717A]/20 text-[#F4F4F5] border border-[#A1A1AA]/60'
                    : 'text-[#A1A1AA] hover:text-[#F4F4F5] border border-transparent'
                }`}
              >
                {w.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* CENTER: Undo · Redo · Save · Project Settings */}
      <div className="flex items-center gap-1 px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded shrink-0">
        <button
          type="button"
          disabled={!canUndo}
          onClick={() => onMenuAction('edit:undo')}
          title="Undo (Ctrl+Z)"
          className="px-2 py-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-30 rounded flex items-center gap-1 text-[11px] transition-colors"
        >
          <Undo2 className="w-3.5 h-3.5" />
          <span className="hidden lg:inline">Undo</span>
        </button>
        <button
          type="button"
          disabled={!canRedo}
          onClick={() => onMenuAction('edit:redo')}
          title="Redo (Ctrl+Shift+Z)"
          className="px-2 py-1 text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] disabled:opacity-30 rounded flex items-center gap-1 text-[11px] transition-colors"
        >
          <Redo2 className="w-3.5 h-3.5" />
          <span className="hidden lg:inline">Redo</span>
        </button>
        <div className="w-px h-4 bg-[#3E3E44]" />
        <button
          type="button"
          onClick={() => onMenuAction('file:save')}
          title="Save Project (Ctrl+S)"
          className={`px-2.5 py-1 rounded flex items-center gap-1 text-[11px] font-medium whitespace-nowrap transition-colors ${
            justSaved
              ? 'text-emerald-300 bg-emerald-500/15'
              : 'text-[#F4F4F5] hover:bg-[#2C2C30]'
          }`}
        >
          {justSaved ? (
            <Check className="w-3.5 h-3.5" />
          ) : (
            <Save className="w-3.5 h-3.5 text-[#D4D4D8]" />
          )}
          <span>{justSaved ? 'Saved' : 'Save'}</span>
        </button>
        <button
          type="button"
          onClick={() => onMenuAction('project:settings')}
          title="Project Settings (Resolution, FPS, Tracks)"
          className="px-2 py-1 rounded text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30] flex items-center gap-1 text-[11px] whitespace-nowrap transition-colors"
        >
          <FolderCog className="w-3.5 h-3.5 text-[#A1A1AA]" />
          <span className="hidden xl:inline">Project Settings</span>
        </button>
      </div>

      {/* RIGHT: Effects / Quality / Smooth · Preview Quality · Performance Mode · Settings · Export */}
      <div className="flex items-center gap-1.5 shrink-0">
        {onToggleEffectsLibrary && (
          <button
            type="button"
            data-tutorial-target="top-effects-button"
            onClick={onToggleEffectsLibrary}
            title="Toggle Ready-Made Effects Drawer"
            className={`px-2 py-1 rounded border text-[11px] font-medium flex items-center gap-1 whitespace-nowrap shrink-0 transition-colors ${
              effectsLibraryOpen
                ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#D4D4D8]" />
            <span className="hidden xl:inline">Effects</span>
          </button>
        )}

        {onOpenQualityEnhancer && (
          <div className="hidden xl:flex items-center gap-1">
            <button
              type="button"
              onClick={() => onOpenQualityEnhancer('enhancer')}
              title="Quality Enhancer (Sharpening, Detail, Denoise, Deblur)"
              className="p-1.5 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5] transition-colors"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#D4D4D8]" />
            </button>
            <button
              type="button"
              onClick={() => onOpenQualityEnhancer('smooth')}
              title="Smooth Video Frame Interpolation"
              className="p-1.5 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5] transition-colors"
            >
              <Gauge className="w-3.5 h-3.5 text-[#D4D4D8]" />
            </button>
          </div>
        )}

        {onChangePreviewQuality && (
          <select
            value={previewQuality}
            disabled={performanceMode}
            onChange={(e) => onChangePreviewQuality(e.target.value as PreviewQuality)}
            title={
              performanceMode
                ? 'Locked by Performance Mode (Export remains Full Quality)'
                : 'Preview Quality'
            }
            className="px-2 py-1 bg-[#2C2C30] border border-[#3E3E44] rounded text-[11px] font-mono-tabular text-[#F4F4F5] disabled:opacity-55 focus:outline-none focus:border-[#A1A1AA]"
          >
            <option value="ultra">Ultra</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
            <option value="performance">Perf</option>
          </select>
        )}

        {onTogglePerformanceMode && (
          <button
            type="button"
            onClick={onTogglePerformanceMode}
            title="Toggle Performance Mode (Fast playback & hover, full-quality export)"
            className={`px-2 py-1 rounded border text-[11px] font-medium flex items-center gap-1 whitespace-nowrap shrink-0 transition-colors ${
              performanceMode
                ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${performanceMode ? 'text-[#D4D4D8]' : 'text-[#A1A1AA]'}`} />
            <span className="hidden lg:inline">Perf</span>
          </button>
        )}

        <div className="hidden 2xl:flex items-center gap-1 px-1.5 py-0.5 bg-[#2C2C30] border border-[#3E3E44] rounded">
          <button
            type="button"
            onClick={onToggleMasterMute}
            title={masterMuted ? 'Unmute Master Audio' : 'Mute Master Audio'}
            className={`p-0.5 rounded ${
              masterMuted ? 'text-rose-400' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            {masterMuted || masterVolume === 0 ? (
              <VolumeX className="w-3.5 h-3.5" />
            ) : (
              <Volume2 className="w-3.5 h-3.5" />
            )}
          </button>
          <input
            type="range"
            min={0}
            max={1.5}
            step={0.05}
            value={masterMuted ? 0 : masterVolume}
            onChange={(e) => onSetMasterVolume(Number(e.target.value))}
            title={`Master Volume: ${Math.round((masterMuted ? 0 : masterVolume) * 100)}%`}
            className="w-12 h-1 accent-[#A1A1AA] cursor-pointer"
          />
        </div>

        <button
          type="button"
          onClick={() => onMenuAction('view:uiTheme')}
          title="Customize UI Theme & Colors (Gray, White, Red, Purple, All Colors)"
          className="p-1.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded text-[11px] text-[#A1A1AA] hover:text-[#F4F4F5] flex items-center gap-1 transition-colors"
        >
          <Palette className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={() => onMenuAction('edit:preferences')}
          title="Settings & Shortcuts"
          className="px-2 py-1 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded text-[11px] text-[#A1A1AA] hover:text-[#F4F4F5] flex items-center gap-1 transition-colors"
        >
          <Settings className="w-3.5 h-3.5" />
          <span className="hidden xl:inline">Settings</span>
        </button>

        <button
          type="button"
          data-tutorial-target="export-button"
          onClick={() => onMenuAction('file:export')}
          className="px-3 py-1 bg-[#52525B] hover:bg-[#6B7280] text-white text-[11px] font-semibold rounded flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors"
        >
          <Download className="w-3.5 h-3.5" />
          Export
        </button>
      </div>
    </header>
  );
};
