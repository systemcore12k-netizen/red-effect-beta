import React, { useMemo, useRef, useState } from 'react';
import {
  Diamond,
  Plus,
  Trash2,
  Copy,
  ClipboardPaste,
  ArrowLeftRight,
  Repeat,
  ZoomIn,
  ZoomOut,
  Maximize2,
  RotateCcw,
  BookmarkPlus,
  ChevronLeft,
  ChevronRight,
  Activity,
  TrendingUp,
} from 'lucide-react';
import { AnimationEasing, AnimationPlaybackMode, CustomCurvePreset } from '../types/effects';
import { Keyframe, KeyframeProperty, TimelineClip } from '../types/studio';
import {
  ANIMATION_CURVE_PRESETS,
  applyEasingCurve,
  getPresetBezier,
  sampleCurvePreviewPoints,
} from '../services/effectsProcessor';

interface KeyframeGraphPanelProps {
  selectedClip: TimelineClip | null;
  playheadTime: number;
  onUpdateClip: (clipId: string, updater: (c: TimelineClip) => TimelineClip) => void;
  onSeek: (time: number) => void;
}

const CUSTOM_CURVES_STORAGE_KEY = 'redeffect_custom_curve_presets_v1';

interface PropDescriptor {
  prop: KeyframeProperty;
  label: string;
  group: 'Transform' | 'Effects' | 'Text' | 'Mask' | 'Stack FX';
  getVal: (c: TimelineClip) => number;
}

const STANDARD_PROPS: PropDescriptor[] = [
  { prop: 'x', label: 'Position X', group: 'Transform', getVal: (c) => c.transform.x },
  { prop: 'y', label: 'Position Y', group: 'Transform', getVal: (c) => c.transform.y },
  { prop: 'z', label: 'Position Z', group: 'Transform', getVal: (c) => c.transform.zDepth },
  { prop: 'scale', label: 'Uniform Scale', group: 'Transform', getVal: (c) => c.transform.scale },
  { prop: 'scaleX', label: 'Scale X', group: 'Transform', getVal: (c) => c.transform.scaleX ?? 1 },
  { prop: 'scaleY', label: 'Scale Y', group: 'Transform', getVal: (c) => c.transform.scaleY ?? 1 },
  { prop: 'rotation', label: 'Rotation Z', group: 'Transform', getVal: (c) => c.transform.rotation },
  { prop: 'rotZ', label: 'Roll (Rot Z)', group: 'Transform', getVal: (c) => c.transform.rotation },
  { prop: 'rotX', label: 'Rotation X', group: 'Transform', getVal: (c) => c.transform.rotX },
  { prop: 'rotY', label: 'Rotation Y', group: 'Transform', getVal: (c) => c.transform.rotY },
  { prop: 'anchorX', label: 'Anchor X', group: 'Transform', getVal: (c) => c.transform.anchorX },
  { prop: 'anchorY', label: 'Anchor Y', group: 'Transform', getVal: (c) => c.transform.anchorY },
  { prop: 'opacity', label: 'Opacity', group: 'Transform', getVal: (c) => c.transform.opacity },
  { prop: 'blur', label: 'Gaussian Blur', group: 'Effects', getVal: (c) => c.effects.blur },
  { prop: 'glow', label: 'Glow Radius', group: 'Effects', getVal: (c) => c.effects.glow },
  { prop: 'glowRadius', label: 'Glow Intensity', group: 'Effects', getVal: (c) => c.effects.glow },
  { prop: 'fontSize', label: 'Font Size', group: 'Text', getVal: (c) => c.textProps?.fontSize ?? 64 },
  { prop: 'textTracking', label: 'Text Tracking', group: 'Text', getVal: (c) => c.textProps?.letterSpacing ?? 0 },
  { prop: 'maskRadius', label: 'Mask Radius', group: 'Mask', getVal: (c) => c.mask.radiusX },
  { prop: 'maskFeather', label: 'Mask Feather', group: 'Mask', getVal: (c) => c.mask.feather },
  { prop: 'maskExpansion', label: 'Mask Expansion', group: 'Mask', getVal: (c) => c.mask.expansion ?? 0 },
  { prop: 'maskOpacity', label: 'Mask Opacity', group: 'Mask', getVal: () => 1 },
];

type GraphMode = 'easing' | 'value';

export const KeyframeGraphPanel: React.FC<KeyframeGraphPanelProps> = ({
  selectedClip,
  playheadTime,
  onUpdateClip,
  onSeek,
}) => {
  const [graphMode, setGraphMode] = useState<GraphMode>('easing');
  const [activeProp, setActiveProp] = useState<KeyframeProperty>('x');
  const [selectedKfIds, setSelectedKfIds] = useState<string[]>([]);
  const [copiedKfs, setCopiedKfs] = useState<Keyframe[]>([]);
  const [copiedCurve, setCopiedCurve] = useState<{
    easing: AnimationEasing;
    bezier: [number, number, number, number];
  } | null>(null);
  const [graphZoom, setGraphZoom] = useState<number>(1);
  const [customPresets, setCustomPresets] = useState<CustomCurvePreset[]>(() => {
    try {
      const raw = localStorage.getItem(CUSTOM_CURVES_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as CustomCurvePreset[]) : [];
    } catch {
      return [];
    }
  });
  const [presetNameInput, setPresetNameInput] = useState('');
  const [showSaveInput, setShowSaveInput] = useState(false);

  const [draggingHandle, setDraggingHandle] = useState<1 | 2 | null>(null);
  const [draggingKfId, setDraggingKfId] = useState<string | null>(null);
  const [draggingDopeKfId, setDraggingDopeKfId] = useState<string | null>(null);

  const svgRef = useRef<SVGSVGElement | null>(null);
  const dopeRef = useRef<HTMLDivElement | null>(null);

  const allDescriptors = useMemo<PropDescriptor[]>(() => {
    const list: PropDescriptor[] = [...STANDARD_PROPS];
    if (selectedClip?.effectsStack) {
      selectedClip.effectsStack.forEach((fx) => {
        Object.entries(fx.params).forEach(([k, v]) => {
          if (typeof v === 'number') {
            list.push({
              prop: `effect:${fx.id}:${k}`,
              label: `${fx.name} · ${k}`,
              group: 'Stack FX',
              getVal: (c) => {
                const match = c.effectsStack?.find((item) => item.id === fx.id);
                const val = match?.params[k];
                return typeof val === 'number' ? val : v;
              },
            });
          }
        });
      });
    }
    return list;
  }, [selectedClip]);

  if (!selectedClip) {
    return (
      <div
        data-tutorial-target="graph-editor-panel"
        className="p-4 text-xs text-[#A1A1AA] bg-[#222225] h-full flex items-center justify-center"
      >
        Select any timeline clip or Null Object to animate keyframes &amp; Bezier curves in the Graph Editor.
      </div>
    );
  }

  const clipDuration = Math.max(0.2, selectedClip.duration);
  const localTime = Math.max(0, Math.min(clipDuration, playheadTime - selectedClip.startTime));

  const propKfs = selectedClip.keyframes
    .filter((k) => k.property === activeProp)
    .sort((a, b) => a.time - b.time);

  // Determine active segment / selected keyframe for easing curve mode
  const primarySelectedKf =
    selectedClip.keyframes.find((k) => selectedKfIds.includes(k.id)) ||
    propKfs.find((k) => k.time >= localTime) ||
    propKfs[propKfs.length - 1] ||
    null;

  const activeEasing: AnimationEasing = primarySelectedKf?.easing || 'easeInOut';
  const activeBezier: [number, number, number, number] =
    primarySelectedKf?.bezier || getPresetBezier(activeEasing);

  const animatedPropSet = new Set(selectedClip.keyframes.map((k) => k.property));

  const getCurrentPropValue = (prop: KeyframeProperty): number => {
    const desc = allDescriptors.find((d) => d.prop === prop);
    return desc ? desc.getVal(selectedClip) : 0;
  };

  const addOrToggleKfAtPlayhead = (prop: KeyframeProperty = activeProp) => {
    const roundedT = Math.round(localTime * 100) / 100;
    const currentVal = getCurrentPropValue(prop);
    onUpdateClip(selectedClip.id, (c) => {
      const idx = c.keyframes.findIndex(
        (k) => k.property === prop && Math.abs(k.time - roundedT) < 0.08
      );
      if (idx >= 0) {
        const removedId = c.keyframes[idx].id;
        setSelectedKfIds((ids) => ids.filter((id) => id !== removedId));
        return { ...c, keyframes: c.keyframes.filter((_, i) => i !== idx) };
      }
      const nextKf: Keyframe = {
        id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        time: roundedT,
        property: prop,
        value: Math.round(currentVal * 1000) / 1000,
        easing: 'easeInOut',
        bezier: [0.42, 0, 0.58, 1],
      };
      setSelectedKfIds([nextKf.id]);
      return { ...c, keyframes: [...c.keyframes, nextKf] };
    });
  };

  const duplicateSelectedKeyframes = () => {
    const targets = selectedClip.keyframes.filter((k) => selectedKfIds.includes(k.id));
    if (targets.length === 0) return;
    const clones: Keyframe[] = targets.map((k) => ({
      ...structuredClone(k),
      id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      time: Math.min(clipDuration, Math.round((k.time + 0.5) * 100) / 100),
    }));
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes: [...c.keyframes, ...clones],
    }));
    setSelectedKfIds(clones.map((k) => k.id));
  };

  const deleteSelectedKeyframes = () => {
    if (selectedKfIds.length === 0) return;
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes: c.keyframes.filter((k) => !selectedKfIds.includes(k.id)),
    }));
    setSelectedKfIds([]);
  };

  const jumpAdjacentKf = (dir: 'prev' | 'next') => {
    const pool = propKfs.length > 0 ? propKfs : [...selectedClip.keyframes].sort((a, b) => a.time - b.time);
    if (pool.length === 0) return;
    if (dir === 'prev') {
      const prev = [...pool].reverse().find((k) => k.time < localTime - 0.04) || pool[pool.length - 1];
      setSelectedKfIds([prev.id]);
      onSeek(selectedClip.startTime + prev.time);
    } else {
      const next = pool.find((k) => k.time > localTime + 0.04) || pool[0];
      setSelectedKfIds([next.id]);
      onSeek(selectedClip.startTime + next.time);
    }
  };

  const applyCurveToTargets = (
    easing: AnimationEasing,
    bezier?: [number, number, number, number]
  ) => {
    const nextBezier = bezier || getPresetBezier(easing);
    const targetIds =
      selectedKfIds.length > 0
        ? new Set(selectedKfIds)
        : primarySelectedKf
        ? new Set([primarySelectedKf.id])
        : new Set(propKfs.map((k) => k.id));

    if (targetIds.size === 0) return;
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes: c.keyframes.map((k) =>
        targetIds.has(k.id) ? { ...k, easing, bezier: [...nextBezier] as [number, number, number, number] } : k
      ),
    }));
  };

  const reverseCurve = () => {
    const revBezier: [number, number, number, number] = [
      Number((1 - activeBezier[2]).toFixed(2)),
      Number((1 - activeBezier[3]).toFixed(2)),
      Number((1 - activeBezier[0]).toFixed(2)),
      Number((1 - activeBezier[1]).toFixed(2)),
    ];
    applyCurveToTargets('bezier', revBezier);
  };

  const saveCustomCurvePreset = () => {
    const label = presetNameInput.trim() || `Custom Curve ${customPresets.length + 1}`;
    const newPreset: CustomCurvePreset = {
      id: `curve-${Date.now()}`,
      name: label,
      easing: activeEasing,
      bezier: [...activeBezier] as [number, number, number, number],
      createdAt: Date.now(),
    };
    const next = [newPreset, ...customPresets];
    setCustomPresets(next);
    try {
      localStorage.setItem(CUSTOM_CURVES_STORAGE_KEY, JSON.stringify(next));
    } catch {
      // Ignore storage errors
    }
    setPresetNameInput('');
    setShowSaveInput(false);
  };

  const reverseKeyframes = () => {
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes: c.keyframes.map((k) =>
        k.property === activeProp || propKfs.length === 0
          ? { ...k, time: Math.max(0, Math.round((c.duration - k.time) * 100) / 100) }
          : k
      ),
    }));
  };

  // Graph SVG Geometry
  const SVG_W = 540;
  const SVG_H = 190;
  const PAD_X = 36;
  const PAD_Y = 24;
  const PLOT_W = SVG_W - PAD_X * 2;
  const PLOT_H = SVG_H - PAD_Y * 2;

  // Value Graph bounds
  const values = propKfs.map((k) => k.value);
  const rawMinVal = values.length > 0 ? Math.min(...values) : 0;
  const rawMaxVal = values.length > 0 ? Math.max(...values) : 1;
  const valSpan = Math.max(1, rawMaxVal - rawMinVal);
  const minVal = rawMinVal - valSpan * 0.2;
  const maxVal = rawMaxVal + valSpan * 0.2;
  const zoomSpan = Math.max(0.2, clipDuration / graphZoom);
  const visibleTimeEnd = Math.min(clipDuration, Math.max(zoomSpan, localTime + zoomSpan * 0.5));
  const visibleTimeStart = Math.max(0, visibleTimeEnd - zoomSpan);

  const timeToSvgX = (t: number) =>
    PAD_X + ((t - visibleTimeStart) / Math.max(0.05, visibleTimeEnd - visibleTimeStart)) * PLOT_W;
  const valToSvgY = (v: number) =>
    PAD_Y + (1 - (v - minVal) / Math.max(0.001, maxVal - minVal)) * PLOT_H;

  // Sampled Easing Curve SVG Path (handles bounce/elastic/overshoot accurately!)
  const easingCurvePath = useMemo(() => {
    const pts = sampleCurvePreviewPoints(activeEasing, activeBezier, 48);
    return pts
      .map((pt, i) => {
        const x = PAD_X + pt.t * PLOT_W;
        const y = PAD_Y + (1 - pt.v) * PLOT_H;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  }, [activeEasing, activeBezier, PLOT_W, PLOT_H]);

  // Sampled Value Graph Trajectory Path
  const valueCurvePath = useMemo(() => {
    if (propKfs.length === 0) return '';
    if (propKfs.length === 1) {
      const y = valToSvgY(propKfs[0].value);
      return `M ${PAD_X} ${y} L ${PAD_X + PLOT_W} ${y}`;
    }
    const pts: string[] = [];
    const steps = 64;
    for (let i = 0; i <= steps; i++) {
      const t = visibleTimeStart + (i / steps) * (visibleTimeEnd - visibleTimeStart);
      let val = propKfs[0].value;
      if (t >= propKfs[propKfs.length - 1].time) {
        val = propKfs[propKfs.length - 1].value;
      } else if (t > propKfs[0].time) {
        for (let s = 0; s < propKfs.length - 1; s++) {
          const k1 = propKfs[s];
          const k2 = propKfs[s + 1];
          if (t >= k1.time && t <= k2.time) {
            const p = (t - k1.time) / Math.max(0.0001, k2.time - k1.time);
            const eased = applyEasingCurve(p, k2.easing, k2.bezier);
            val = k1.value + (k2.value - k1.value) * eased;
            break;
          }
        }
      }
      pts.push(`${i === 0 ? 'M' : 'L'} ${timeToSvgX(t).toFixed(1)} ${valToSvgY(val).toFixed(1)}`);
    }
    return pts.join(' ');
  }, [propKfs, visibleTimeStart, visibleTimeEnd, minVal, maxVal]);

  const handleSvgPointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const viewX = ((e.clientX - rect.left) / Math.max(1, rect.width)) * SVG_W;
    const viewY = ((e.clientY - rect.top) / Math.max(1, rect.height)) * SVG_H;

    if (draggingHandle && primarySelectedKf) {
      const nx = Math.max(0, Math.min(1, (viewX - PAD_X) / PLOT_W));
      const ny = Math.max(-0.6, Math.min(1.6, 1 - (viewY - PAD_Y) / PLOT_H));
      const nextBezier: [number, number, number, number] =
        draggingHandle === 1
          ? [Number(nx.toFixed(2)), Number(ny.toFixed(2)), activeBezier[2], activeBezier[3]]
          : [activeBezier[0], activeBezier[1], Number(nx.toFixed(2)), Number(ny.toFixed(2))];

      onUpdateClip(selectedClip.id, (c) => ({
        ...c,
        keyframes: c.keyframes.map((k) =>
          k.id === primarySelectedKf.id ? { ...k, easing: 'bezier', bezier: nextBezier } : k
        ),
      }));
      return;
    }

    if (draggingKfId && graphMode === 'value') {
      const nextTime = Math.max(
        0,
        Math.min(
          clipDuration,
          visibleTimeStart + ((viewX - PAD_X) / PLOT_W) * (visibleTimeEnd - visibleTimeStart)
        )
      );
      const nextVal = minVal + (1 - (viewY - PAD_Y) / PLOT_H) * (maxVal - minVal);
      onUpdateClip(selectedClip.id, (c) => ({
        ...c,
        keyframes: c.keyframes.map((k) =>
          k.id === draggingKfId
            ? {
                ...k,
                time: Math.round(nextTime * 100) / 100,
                value: Math.round(nextVal * 100) / 100,
              }
            : k
        ),
      }));
    }
  };

  const handleDopePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!draggingDopeKfId || !dopeRef.current) return;
    const rect = dopeRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / Math.max(1, rect.width)));
    const nextTime = Math.round(ratio * clipDuration * 100) / 100;
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      keyframes: c.keyframes.map((k) => (k.id === draggingDopeKfId ? { ...k, time: nextTime } : k)),
    }));
  };

  const p1X = PAD_X + activeBezier[0] * PLOT_W;
  const p1Y = PAD_Y + (1 - activeBezier[1]) * PLOT_H;
  const p2X = PAD_X + activeBezier[2] * PLOT_W;
  const p2Y = PAD_Y + (1 - activeBezier[3]) * PLOT_H;

  return (
    <div
      data-tutorial-target="graph-editor-panel"
      className="h-full bg-[#222225] text-[#F4F4F5] text-xs flex overflow-hidden select-none"
    >
      {/* Left: Animated Properties Tree */}
      <div className="w-52 shrink-0 border-r border-[#3E3E44] bg-[#18181A] flex flex-col">
        <div className="px-2.5 py-1.5 border-b border-[#3E3E44] flex items-center justify-between">
          <span className="text-[11px] font-semibold text-[#F4F4F5]">Animated Properties</span>
          <span className="text-[10px] font-mono-tabular text-[#D4D4D8]">
            {selectedClip.keyframes.length} KF
          </span>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-[#3E3E44]/60">
          {(['Transform', 'Effects', 'Text', 'Mask', 'Stack FX'] as const).map((group) => {
            const groupItems = allDescriptors.filter((d) => {
              if (d.group !== group) return false;
              if (group === 'Text' && selectedClip.type !== 'text' && !animatedPropSet.has(d.prop)) {
                return false;
              }
              return true;
            });
            if (groupItems.length === 0) return null;
            return (
              <div key={group} className="py-1">
                <div className="px-2.5 py-0.5 text-[9px] uppercase tracking-wider text-[#A1A1AA] font-semibold">
                  {group}
                </div>
                {groupItems.map((item) => {
                  const count = selectedClip.keyframes.filter((k) => k.property === item.prop).length;
                  const isActive = activeProp === item.prop;
                  const atPlayhead = selectedClip.keyframes.some(
                    (k) => k.property === item.prop && Math.abs(k.time - localTime) < 0.08
                  );
                  return (
                    <div
                      key={item.prop}
                      onClick={() => setActiveProp(item.prop)}
                      className={`px-2.5 py-1 flex items-center justify-between gap-1 cursor-pointer transition-colors ${
                        isActive
                          ? 'bg-[#71717A]/18 text-[#F4F4F5] border-l-2 border-l-[#A1A1AA]'
                          : 'text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#2C2C30]'
                      }`}
                    >
                      <span className="truncate text-[11px]">{item.label}</span>
                      <div className="flex items-center gap-1 shrink-0">
                        {count > 0 && (
                          <span className="px-1 rounded bg-[#2C2C30] text-[9px] font-mono-tabular text-[#F4F4F5]">
                            {count}
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveProp(item.prop);
                            addOrToggleKfAtPlayhead(item.prop);
                          }}
                          title="Add / Remove Keyframe at Playhead"
                          className={`p-0.5 rounded ${
                            atPlayhead
                              ? 'text-[#D4D4D8]'
                              : count > 0
                              ? 'text-amber-400 hover:text-[#F4F4F5]'
                              : 'text-[#6E7280] hover:text-white'
                          }`}
                        >
                          <Diamond className="w-2.5 h-2.5 fill-current" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>

      {/* Center: Top Controls + Interactive Graph Canvas + Bottom Dope Sheet */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Graph Toolbar */}
        <div className="px-2.5 py-1.5 bg-[#222225] border-b border-[#3E3E44] flex flex-wrap items-center justify-between gap-1.5 shrink-0">
          <div className="flex items-center gap-1">
            {/* Mode Switcher */}
            <div className="flex rounded border border-[#3E3E44] bg-[#18181A] p-0.5">
              <button
                type="button"
                onClick={() => setGraphMode('easing')}
                className={`px-2 py-0.5 rounded text-[10px] font-medium flex items-center gap-1 ${
                  graphMode === 'easing' ? 'bg-[#52525B] text-white' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                <Activity className="w-3 h-3" />
                Easing Curve
              </button>
              <button
                type="button"
                onClick={() => setGraphMode('value')}
                className={`px-2 py-0.5 rounded text-[10px] font-medium flex items-center gap-1 ${
                  graphMode === 'value' ? 'bg-[#52525B] text-white' : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                <TrendingUp className="w-3 h-3" />
                Value Graph
              </button>
            </div>

            <div className="w-px h-4 bg-[#3E3E44] mx-0.5" />

            <button
              type="button"
              onClick={() => setGraphZoom((z) => Math.max(0.6, Number((z - 0.25).toFixed(2))))}
              title="Zoom Out Graph"
              className="p-1 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[#F4F4F5]"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => setGraphZoom((z) => Math.min(3, Number((z + 0.25).toFixed(2))))}
              title="Zoom In Graph"
              className="p-1 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[#F4F4F5]"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => setGraphZoom(1)}
              title="Fit Graph"
              className="px-1.5 py-0.5 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[10px] text-[#F4F4F5] flex items-center gap-1"
            >
              <Maximize2 className="w-2.5 h-2.5" />
              Fit
            </button>

            <div className="w-px h-4 bg-[#3E3E44] mx-0.5" />

            <button
              type="button"
              onClick={() => applyCurveToTargets('linear', [0, 0, 1, 1])}
              title="Reset Curve to Linear"
              className="px-1.5 py-0.5 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[10px] text-[#F4F4F5] flex items-center gap-1"
            >
              <RotateCcw className="w-2.5 h-2.5" />
              Reset
            </button>
            <button
              type="button"
              onClick={() => setCopiedCurve({ easing: activeEasing, bezier: [...activeBezier] as [number, number, number, number] })}
              title="Copy Curve"
              className="px-1.5 py-0.5 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[10px] text-[#F4F4F5] flex items-center gap-1"
            >
              <Copy className="w-2.5 h-2.5" />
              Copy Curve
            </button>
            <button
              type="button"
              disabled={!copiedCurve}
              onClick={() => copiedCurve && applyCurveToTargets(copiedCurve.easing, copiedCurve.bezier)}
              title="Paste Curve"
              className="px-1.5 py-0.5 rounded bg-[#2C2C30] hover:bg-[#343439] disabled:opacity-40 border border-[#3E3E44] text-[10px] text-[#F4F4F5] flex items-center gap-1"
            >
              <ClipboardPaste className="w-2.5 h-2.5" />
              Paste Curve
            </button>
            <button
              type="button"
              onClick={reverseCurve}
              title="Reverse Curve Shape"
              className="px-1.5 py-0.5 rounded bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[10px] text-[#F4F4F5] flex items-center gap-1"
            >
              <ArrowLeftRight className="w-2.5 h-2.5" />
              Reverse
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-[10px]">
            <Repeat className="w-3 h-3 text-[#D4D4D8]" />
            <select
              value={selectedClip.animationLoopMode || 'none'}
              onChange={(e) =>
                onUpdateClip(selectedClip.id, (c) => ({
                  ...c,
                  animationLoopMode: e.target.value as AnimationPlaybackMode,
                }))
              }
              className="px-1.5 py-0.5 bg-[#2C2C30] border border-[#3E3E44] rounded text-[#F4F4F5]"
            >
              <option value="none">Once</option>
              <option value="loop">Loop</option>
              <option value="pingpong">Ping-Pong</option>
              <option value="reverse">Reverse</option>
            </select>
            <input
              type="number"
              min={0.25}
              max={4}
              step={0.25}
              value={selectedClip.animationSpeed ?? 1}
              onChange={(e) =>
                onUpdateClip(selectedClip.id, (c) => ({
                  ...c,
                  animationSpeed: Number(e.target.value),
                }))
              }
              title="Animation Speed Multiplier"
              className="w-11 px-1 py-0.5 bg-[#2C2C30] border border-[#3E3E44] rounded text-right font-mono-tabular text-[#F4F4F5]"
            />
            <span className="text-[#A1A1AA]">×</span>
          </div>
        </div>

        {/* Interactive Graph SVG Viewport */}
        <div className="flex-1 min-h-0 flex flex-col bg-[#18181A] p-2 gap-1.5">
          <div className="flex items-center justify-between text-[10px] text-[#A1A1AA] px-1">
            <span>
              Property: <strong className="text-[#F4F4F5]">{activeProp}</strong> · Curve:{' '}
              <strong className="text-[#D4D4D8]">{activeEasing}</strong>{' '}
              <span className="font-mono-tabular">
                [{activeBezier.map((n) => n.toFixed(2)).join(', ')}]
              </span>
            </span>
            {primarySelectedKf && (
              <span className="font-mono-tabular">
                Selected KF: {primarySelectedKf.value.toFixed(2)} @ {primarySelectedKf.time.toFixed(2)}s
              </span>
            )}
          </div>

          <svg
            ref={svgRef}
            viewBox={`0 0 ${SVG_W} ${SVG_H}`}
            onPointerMove={handleSvgPointerMove}
            onPointerUp={() => {
              setDraggingHandle(null);
              setDraggingKfId(null);
            }}
            onPointerLeave={() => {
              setDraggingHandle(null);
              setDraggingKfId(null);
            }}
            className="w-full flex-1 min-h-[115px] bg-[#14161B] border border-[#3E3E44] rounded touch-none"
          >
            {/* Grid Lines */}
            {[0, 0.25, 0.5, 0.75, 1].map((g) => (
              <React.Fragment key={g}>
                <line
                  x1={PAD_X}
                  y1={PAD_Y + g * PLOT_H}
                  x2={PAD_X + PLOT_W}
                  y2={PAD_Y + g * PLOT_H}
                  stroke={g === 0 || g === 1 ? '#3E3E44' : '#2C2C30'}
                  strokeDasharray={g === 0 || g === 1 ? undefined : '3 3'}
                />
                <line
                  x1={PAD_X + g * PLOT_W}
                  y1={PAD_Y}
                  x2={PAD_X + g * PLOT_W}
                  y2={PAD_Y + PLOT_H}
                  stroke={g === 0 || g === 1 ? '#3E3E44' : '#2C2C30'}
                  strokeDasharray={g === 0 || g === 1 ? undefined : '3 3'}
                />
              </React.Fragment>
            ))}

            {graphMode === 'easing' ? (
              <>
                {/* Linear reference diagonal */}
                <line
                  x1={PAD_X}
                  y1={PAD_Y + PLOT_H}
                  x2={PAD_X + PLOT_W}
                  y2={PAD_Y}
                  stroke="#3E3E44"
                  strokeDasharray="4 4"
                />

                {/* Handle tangent lines */}
                <line
                  x1={PAD_X}
                  y1={PAD_Y + PLOT_H}
                  x2={p1X}
                  y2={p1Y}
                  stroke="#A1A1AA"
                  strokeWidth="1.2"
                  strokeDasharray="3 2"
                />
                <line
                  x1={PAD_X + PLOT_W}
                  y1={PAD_Y}
                  x2={p2X}
                  y2={p2Y}
                  stroke="#A1A1AA"
                  strokeWidth="1.2"
                  strokeDasharray="3 2"
                />

                {/* Easing Curve Path */}
                <path d={easingCurvePath} fill="none" stroke="#A1A1AA" strokeWidth="2.6" />

                {/* Endpoints */}
                <circle cx={PAD_X} cy={PAD_Y + PLOT_H} r="4" fill="#F4F4F5" />
                <circle cx={PAD_X + PLOT_W} cy={PAD_Y} r="4" fill="#F4F4F5" />

                {/* Draggable P1 & P2 Handles */}
                <circle
                  cx={p1X}
                  cy={p1Y}
                  r="6"
                  fill="#A1A1AA"
                  stroke="#F4F4F5"
                  strokeWidth="1.6"
                  className="cursor-grab active:cursor-grabbing"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setDraggingHandle(1);
                  }}
                />
                <circle
                  cx={p2X}
                  cy={p2Y}
                  r="6"
                  fill="#A1A1AA"
                  stroke="#F4F4F5"
                  strokeWidth="1.6"
                  className="cursor-grab active:cursor-grabbing"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setDraggingHandle(2);
                  }}
                />
              </>
            ) : (
              <>
                {/* Playhead line in Value Graph */}
                <line
                  x1={timeToSvgX(localTime)}
                  y1={PAD_Y - 8}
                  x2={timeToSvgX(localTime)}
                  y2={PAD_Y + PLOT_H + 8}
                  stroke="#A1A1AA"
                  strokeWidth="1.4"
                />

                {/* Min / Max Axis Labels */}
                <text x={PAD_X - 4} y={PAD_Y + 6} textAnchor="end" fill="#A1A1AA" fontSize="9">
                  {maxVal.toFixed(1)}
                </text>
                <text x={PAD_X - 4} y={PAD_Y + PLOT_H} textAnchor="end" fill="#A1A1AA" fontSize="9">
                  {minVal.toFixed(1)}
                </text>

                {valueCurvePath && (
                  <path d={valueCurvePath} fill="none" stroke="#A1A1AA" strokeWidth="2.4" />
                )}

                {propKfs.map((kf) => {
                  const cx = timeToSvgX(kf.time);
                  const cy = valToSvgY(kf.value);
                  const isSel = selectedKfIds.includes(kf.id);
                  return (
                    <circle
                      key={kf.id}
                      cx={cx}
                      cy={cy}
                      r={isSel ? 6 : 4.8}
                      fill={isSel ? '#F4F4F5' : '#A1A1AA'}
                      stroke="#F4F4F5"
                      strokeWidth="1.5"
                      className="cursor-grab active:cursor-grabbing"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        setSelectedKfIds((prev) =>
                          e.shiftKey || e.ctrlKey
                            ? Array.from(new Set([...prev, kf.id]))
                            : [kf.id]
                        );
                        setDraggingKfId(kf.id);
                        onSeek(selectedClip.startTime + kf.time);
                      }}
                    />
                  );
                })}
              </>
            )}
          </svg>
        </div>

        {/* Bottom Time Ruler + Multi-Select Keyframe Dope Sheet */}
        <div className="border-t border-[#3E3E44] bg-[#222225] shrink-0">
          <div className="px-2.5 py-1 border-b border-[#3E3E44] flex flex-wrap items-center gap-1">
            <button
              type="button"
              onClick={() => addOrToggleKfAtPlayhead()}
              className="px-2 py-0.5 bg-[#52525B] hover:bg-[#6B7280] text-white rounded text-[10px] font-medium flex items-center gap-1"
            >
              <Plus className="w-3 h-3" />
              Add KF
            </button>
            <button
              type="button"
              disabled={selectedKfIds.length === 0}
              onClick={duplicateSelectedKeyframes}
              className="px-2 py-0.5 bg-[#2C2C30] hover:bg-[#343439] disabled:opacity-40 border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]"
            >
              Duplicate
            </button>
            <button
              type="button"
              disabled={selectedKfIds.length === 0}
              onClick={deleteSelectedKeyframes}
              className="px-2 py-0.5 bg-[#2C2C30] hover:bg-[#343439] disabled:opacity-40 border border-[#3E3E44] rounded text-[10px] text-rose-300 flex items-center gap-0.5"
            >
              <Trash2 className="w-3 h-3" />
              Delete
            </button>
            <button
              type="button"
              onClick={() => jumpAdjacentKf('prev')}
              title="Previous Keyframe"
              className="p-0.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded text-[#F4F4F5]"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => jumpAdjacentKf('next')}
              title="Next Keyframe"
              className="p-0.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded text-[#F4F4F5]"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setCopiedKfs(structuredClone(selectedClip.keyframes))}
              className="px-2 py-0.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]"
            >
              Copy All
            </button>
            <button
              type="button"
              disabled={copiedKfs.length === 0}
              onClick={() =>
                onUpdateClip(selectedClip.id, (c) => ({
                  ...c,
                  keyframes: [
                    ...c.keyframes,
                    ...copiedKfs.map((k) => ({
                      ...k,
                      id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                    })),
                  ],
                }))
              }
              className="px-2 py-0.5 bg-[#2C2C30] hover:bg-[#343439] disabled:opacity-40 border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]"
            >
              Paste All
            </button>
            <button
              type="button"
              onClick={reverseKeyframes}
              className="px-2 py-0.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]"
            >
              Reverse Keys
            </button>
          </div>

          <div
            ref={dopeRef}
            onPointerMove={handleDopePointerMove}
            onPointerUp={() => setDraggingDopeKfId(null)}
            onPointerLeave={() => setDraggingDopeKfId(null)}
            onClick={(e) => {
              if (!dopeRef.current) return;
              const rect = dopeRef.current.getBoundingClientRect();
              const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / Math.max(1, rect.width)));
              onSeek(selectedClip.startTime + ratio * clipDuration);
            }}
            className="relative h-8 mx-2.5 my-1.5 bg-[#18181A] border border-[#3E3E44] rounded cursor-pointer"
          >
            {/* Playhead Marker */}
            <div
              className="absolute top-0 bottom-0 w-px bg-[#52525B] pointer-events-none z-10"
              style={{ left: `${(localTime / clipDuration) * 100}%` }}
            />
            {propKfs.map((kf) => {
              const pct = Math.max(1, Math.min(99, (kf.time / clipDuration) * 100));
              const isSel = selectedKfIds.includes(kf.id);
              return (
                <button
                  key={kf.id}
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setDraggingDopeKfId(kf.id);
                    setSelectedKfIds((prev) =>
                      e.shiftKey || e.ctrlKey
                        ? prev.includes(kf.id)
                          ? prev.filter((x) => x !== kf.id)
                          : [...prev, kf.id]
                        : [kf.id]
                    );
                    onSeek(selectedClip.startTime + kf.time);
                  }}
                  title={`${kf.property} = ${kf.value.toFixed(2)} @ ${kf.time.toFixed(2)}s (${kf.easing})`}
                  style={{ left: `${pct}%` }}
                  className={`absolute top-1/2 -translate-x-1/2 -translate-y-1/2 p-0.5 z-20 cursor-ew-resize ${
                    isSel ? 'text-white scale-125' : 'text-[#D4D4D8] hover:scale-110'
                  }`}
                >
                  <Diamond className="w-3 h-3 fill-current" />
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right: 13 Curve Presets with Live SVG Curve Previews */}
      <div className="w-64 shrink-0 border-l border-[#3E3E44] bg-[#18181A] flex flex-col">
        <div className="px-2.5 py-1.5 border-b border-[#3E3E44] flex items-center justify-between">
          <span className="text-[11px] font-semibold text-[#F4F4F5]">Curve Presets (13)</span>
          <button
            type="button"
            onClick={() => setShowSaveInput((v) => !v)}
            title="Save Current Curve as Custom Preset"
            className="px-1.5 py-0.5 rounded bg-[#71717A]/20 hover:bg-[#52525B] border border-[#A1A1AA]/50 text-[10px] text-[#F4F4F5] flex items-center gap-1"
          >
            <BookmarkPlus className="w-3 h-3" />
            Save
          </button>
        </div>

        {showSaveInput && (
          <div className="p-2 border-b border-[#3E3E44] bg-[#222225] flex gap-1">
            <input
              type="text"
              value={presetNameInput}
              onChange={(e) => setPresetNameInput(e.target.value)}
              placeholder="Preset name..."
              className="flex-1 min-w-0 px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
            />
            <button
              type="button"
              onClick={saveCustomCurvePreset}
              className="px-2 py-1 bg-[#52525B] hover:bg-[#6B7280] text-white rounded text-[10px] font-medium"
            >
              Add
            </button>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-2 space-y-2">
          <div className="grid grid-cols-3 gap-1.5">
            {ANIMATION_CURVE_PRESETS.map((preset) => {
              const pts = sampleCurvePreviewPoints(preset.easing, preset.bezier, 20);
              const d = pts
                .map((p, i) => {
                  const x = 4 + p.t * 36;
                  const y = 26 - p.v * 20;
                  return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
                })
                .join(' ');
              const isSelected = activeEasing === preset.easing;
              return (
                <button
                  key={preset.easing}
                  type="button"
                  onClick={() => applyCurveToTargets(preset.easing, preset.bezier)}
                  title={`${preset.label} (${preset.category})`}
                  className={`p-1 rounded border flex flex-col items-center gap-0.5 transition-colors ${
                    isSelected
                      ? 'bg-[#71717A]/20 border-[#A1A1AA] text-white'
                      : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5] hover:border-[#A1A1AA]/50'
                  }`}
                >
                  <svg viewBox="0 0 44 30" className="w-full h-7 bg-[#18181A] rounded-xs">
                    <path d={d} fill="none" stroke={isSelected ? '#FFFFFF' : '#A1A1AA'} strokeWidth="2" />
                  </svg>
                  <span className="text-[9px] truncate w-full text-center">{preset.label}</span>
                </button>
              );
            })}
          </div>

          {customPresets.length > 0 && (
            <div className="pt-1 border-t border-[#3E3E44] space-y-1">
              <div className="text-[9px] uppercase tracking-wider text-[#A1A1AA] font-semibold">
                Saved Custom Curves
              </div>
              <div className="grid grid-cols-2 gap-1">
                {customPresets.map((cp) => (
                  <div
                    key={cp.id}
                    className="flex items-center justify-between gap-1 px-1.5 py-1 bg-[#2C2C30] border border-[#3E3E44] rounded text-[10px]"
                  >
                    <button
                      type="button"
                      onClick={() => applyCurveToTargets(cp.easing, cp.bezier)}
                      className="truncate text-left flex-1 hover:text-[#F4F4F5]"
                    >
                      {cp.name}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const next = customPresets.filter((x) => x.id !== cp.id);
                        setCustomPresets(next);
                        try {
                          localStorage.setItem(CUSTOM_CURVES_STORAGE_KEY, JSON.stringify(next));
                        } catch {
                          // Ignore
                        }
                      }}
                      className="text-[#A1A1AA] hover:text-rose-400"
                    >
                      <Trash2 className="w-2.5 h-2.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
