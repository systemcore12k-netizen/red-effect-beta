import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  X,
  SlidersHorizontal,
  Film,
  Play,
  Pause,
  RotateCcw,
  Check,
  Loader2,
  MoveHorizontal,
  Sparkles,
  Gauge,
} from 'lucide-react';
import {
  EnhancementProcessingQuality,
  MediaAsset,
  QualityEnhancerSettings,
  SmoothVideoFpsTarget,
  SmoothVideoSettings,
  StudioProject,
  TimelineClip,
  UpscaleResolutionTarget,
} from '../types/studio';
import {
  computeEnhancementTargetSize,
  createDefaultQualityEnhancerSettings,
  enhancedImageCache,
  processImageEnhancementTiled,
} from '../services/qualityEnhancerEngine';
import {
  createDefaultSmoothVideoSettings,
  preRenderSmoothClipSequence,
  renderOpticalFlowFrameCanvas,
  resolveEffectiveTargetFps,
  smoothVideoCache,
} from '../services/smoothVideoEngine';
import { detectHardwareProfile } from '../services/performanceEngine';

interface QualityEnhancerModalProps {
  initialTab: 'enhancer' | 'smooth';
  project: StudioProject;
  selectedClipId: string | null;
  playheadTime: number;
  onUpdateClip: (
    clipId: string,
    updater: (c: TimelineClip) => TimelineClip,
    commitHistory?: boolean
  ) => void;
  onClose: () => void;
}

export const QualityEnhancerModal: React.FC<QualityEnhancerModalProps> = ({
  initialTab,
  project,
  selectedClipId,
  playheadTime,
  onUpdateClip,
  onClose,
}) => {
  const mediaClips = useMemo(
    () =>
      project.clips.filter((c) => {
        const asset = project.assets.find((a) => a.id === c.assetId);
        return asset && (asset.type === 'image' || asset.type === 'video');
      }),
    [project.clips, project.assets]
  );

  const initialClip =
    mediaClips.find((c) => c.id === selectedClipId) || mediaClips[0] || null;

  const [activeClipId, setActiveClipId] = useState<string | null>(initialClip?.id || null);
  const [activeTab, setActiveTab] = useState<'enhancer' | 'smooth'>(initialTab);
  const [splitPct, setSplitPct] = useState<number>(50);
  const [isDraggingSplit, setIsDraggingSplit] = useState(false);

  const activeClip = useMemo(
    () => mediaClips.find((c) => c.id === activeClipId) || null,
    [mediaClips, activeClipId]
  );
  const activeAsset: MediaAsset | null = useMemo(
    () =>
      activeClip ? project.assets.find((a) => a.id === activeClip.assetId) || null : null,
    [activeClip, project.assets]
  );

  const isVideo = activeAsset?.type === 'video';
  const [enhancer, setEnhancer] = useState<QualityEnhancerSettings>(() => ({
    ...createDefaultQualityEnhancerSettings(),
    ...(initialClip?.qualityEnhancer || {}),
  }));
  const [smooth, setSmooth] = useState<SmoothVideoSettings>(() => ({
    ...createDefaultSmoothVideoSettings(),
    ...(initialClip?.smoothVideo || {}),
  }));

  useEffect(() => {
    if (!activeClip) return;
    setEnhancer({
      ...createDefaultQualityEnhancerSettings(),
      ...(activeClip.qualityEnhancer || {}),
    });
    setSmooth({
      ...createDefaultSmoothVideoSettings(),
      ...(activeClip.smoothVideo || {}),
    });
  }, [activeClip?.id]);

  // Comparison preview playback state
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const [localTime, setLocalTime] = useState<number>(() => {
    if (!initialClip) return 0;
    return Math.max(0, Math.min(initialClip.duration, playheadTime - initialClip.startTime));
  });

  // Processing progress + cancellation state
  const [isProcessing, setIsProcessing] = useState(false);
  const [processProgress, setProcessProgress] = useState(0);
  const [processStage, setProcessStage] = useState('');
  const [processError, setProcessError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const beforeCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const afterCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const splitContainerRef = useRef<HTMLDivElement | null>(null);
  const loadedImageRef = useRef<HTMLImageElement | null>(null);
  const videoARef = useRef<HTMLVideoElement | null>(null);
  const videoBRef = useRef<HTMLVideoElement | null>(null);
  const [sourceDims, setSourceDims] = useState<{ w: number; h: number }>({
    w: activeAsset?.width || 1920,
    h: activeAsset?.height || 1080,
  });

  const hwProfile = useMemo(() => detectHardwareProfile(), []);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
    };
  }, []);

  // Load clean original Image / dual Video decoders for comparison preview
  useEffect(() => {
    loadedImageRef.current = null;
    videoARef.current = null;
    videoBRef.current = null;
    if (!activeAsset) return;
    const srcUrl = activeAsset.originalUrl || activeAsset.url;

    if (activeAsset.type === 'image') {
      const img = new Image();
      if (!srcUrl.startsWith('blob:') && !srcUrl.startsWith('data:')) {
        img.crossOrigin = 'anonymous';
      }
      img.onload = () => {
        loadedImageRef.current = img;
        setSourceDims({ w: img.naturalWidth, h: img.naturalHeight });
      };
      img.src = srcUrl;
    } else if (activeAsset.type === 'video') {
      const makeV = () => {
        const v = document.createElement('video');
        if (!srcUrl.startsWith('blob:') && !srcUrl.startsWith('data:')) {
          v.crossOrigin = 'anonymous';
        }
        v.muted = true;
        v.playsInline = true;
        v.preload = 'auto';
        v.src = srcUrl;
        return v;
      };
      const vA = makeV();
      const vB = makeV();
      vA.onloadeddata = () => {
        setSourceDims({
          w: vA.videoWidth || activeAsset.width || 1920,
          h: vA.videoHeight || activeAsset.height || 1080,
        });
      };
      videoARef.current = vA;
      videoBRef.current = vB;
      return () => {
        try {
          vA.pause();
          vA.removeAttribute('src');
          vA.load();
          vB.pause();
          vB.removeAttribute('src');
          vB.load();
        } catch {
          // ignore cleanup
        }
      };
    }
  }, [activeAsset?.id]);

  // Playback ticker when previewing inside Comparison Viewer
  useEffect(() => {
    if (!previewPlaying || !activeClip) return;
    const stepFps =
      smooth.enabled && smooth.targetFps !== 'original'
        ? Math.min(60, resolveEffectiveTargetFps(smooth.targetFps, activeAsset?.sourceFps || 30))
        : 30;
    const intervalMs = Math.max(16, Math.round(1000 / stepFps));
    let last = performance.now();
    const id = window.setInterval(() => {
      const now = performance.now();
      const dt = (now - last) / 1000;
      last = now;
      setLocalTime((prev) => {
        const next = prev + dt;
        return next >= activeClip.duration ? 0 : next;
      });
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [previewPlaying, activeClip?.duration, smooth.enabled, smooth.targetFps, activeAsset?.sourceFps]);

  const targetSizeInfo = useMemo(
    () =>
      computeEnhancementTargetSize(
        sourceDims.w,
        sourceDims.h,
        enhancer.targetResolution,
        enhancer.processingQuality,
        enhancer.upscaling
      ),
    [
      sourceDims.w,
      sourceDims.h,
      enhancer.targetResolution,
      enhancer.processingQuality,
      enhancer.upscaling,
    ]
  );

  // Render Before & After canvases whenever inputs or scrub position change
  const renderComparisonFrames = useCallback(async () => {
    const beforeC = beforeCanvasRef.current;
    const afterC = afterCanvasRef.current;
    if (!beforeC || !afterC || !activeClip || !activeAsset) return;

    const maxPreviewW = hwProfile.tier === 'low-end' ? 840 : 1280;
    const aspect = sourceDims.w / Math.max(1, sourceDims.h);
    const viewW = Math.min(maxPreviewW, sourceDims.w);
    const viewH = Math.max(120, Math.round(viewW / Math.max(0.1, aspect)));

    if (beforeC.width !== viewW || beforeC.height !== viewH) {
      beforeC.width = viewW;
      beforeC.height = viewH;
    }
    if (afterC.width !== viewW || afterC.height !== viewH) {
      afterC.width = viewW;
      afterC.height = viewH;
    }

    const bCtx = beforeC.getContext('2d', { colorSpace: 'srgb' }) || beforeC.getContext('2d')!;
    const aCtx = afterC.getContext('2d', { colorSpace: 'srgb' }) || afterC.getContext('2d')!;
    bCtx.imageSmoothingEnabled = true;
    bCtx.imageSmoothingQuality = 'high';
    aCtx.imageSmoothingEnabled = true;
    aCtx.imageSmoothingQuality = 'high';

    if (activeAsset.type === 'image') {
      const img = loadedImageRef.current;
      if (!img || !img.complete || img.naturalWidth === 0) return;
      bCtx.clearRect(0, 0, viewW, viewH);
      bCtx.drawImage(img, 0, 0, viewW, viewH);

      if (enhancer.enabled && enhancer.intensity > 0) {
        const fastPreviewSettings: QualityEnhancerSettings = {
          ...enhancer,
          targetResolution: 'original',
          upscaling: false,
        };
        const result = await processImageEnhancementTiled(
          img,
          viewW,
          viewH,
          fastPreviewSettings,
          false
        );
        aCtx.clearRect(0, 0, viewW, viewH);
        aCtx.drawImage(result.canvas, 0, 0, viewW, viewH);
      } else {
        aCtx.clearRect(0, 0, viewW, viewH);
        aCtx.drawImage(img, 0, 0, viewW, viewH);
      }
      return;
    }

    // Video frame pair comparison
    const vA = videoARef.current;
    const vB = videoBRef.current;
    if (!vA || !vB) return;

    const slowMult = smooth.enabled ? smooth.slowMotionSpeed : 1;
    const srcTime = Math.max(
      0,
      Math.min(activeAsset.duration, activeClip.sourceOffset + localTime * activeClip.speed * slowMult)
    );
    const srcFps = activeAsset.sourceFps || 30;
    const srcStep = 1 / Math.max(12, srcFps);
    const pairIdx = Math.floor(srcTime / srcStep);
    const tA = Math.min(activeAsset.duration, pairIdx * srcStep);
    const tB = Math.min(activeAsset.duration, (pairIdx + 1) * srcStep);
    const alpha = Math.max(0, Math.min(1, (srcTime - tA) / Math.max(0.0001, tB - tA)));

    const seekV = (v: HTMLVideoElement, tSec: number) =>
      new Promise<void>((res) => {
        const s = Math.max(0, Math.min(v.duration || tSec, tSec));
        if (Math.abs(v.currentTime - s) <= 0.01 && v.readyState >= 2) {
          res();
          return;
        }
        let done = false;
        const fin = () => {
          if (done) return;
          done = true;
          v.removeEventListener('seeked', fin);
          res();
        };
        v.addEventListener('seeked', fin);
        try {
          v.currentTime = s;
        } catch {
          fin();
        }
        setTimeout(fin, 160);
      });

    await seekV(vA, tA);
    bCtx.clearRect(0, 0, viewW, viewH);
    bCtx.drawImage(vA, 0, 0, viewW, viewH);

    // For After: use Smooth Video optical flow if enabled, otherwise raw vA
    let afterSource: CanvasImageSource = vA;
    if (smooth.enabled && smooth.targetFps !== 'original' && alpha > 0.04 && alpha < 0.96) {
      const cached = smoothVideoCache.getNearestFrame(activeAsset.id, smooth, srcTime, 0.03);
      if (cached) {
        afterSource = cached;
      } else {
        await seekV(vB, tB);
        const interpW = Math.min(viewW, 720);
        const interpH = Math.max(90, Math.round(interpW / Math.max(0.1, aspect)));
        afterSource = renderOpticalFlowFrameCanvas(
          vA,
          vB,
          interpW,
          interpH,
          alpha,
          smooth.processingQuality,
          smooth.artifactSuppression
        );
      }
    }

    if (enhancer.enabled && enhancer.intensity > 0) {
      const enhancedVidFrame = await processImageEnhancementTiled(
        afterSource,
        viewW,
        viewH,
        { ...enhancer, targetResolution: 'original', upscaling: false },
        true
      );
      aCtx.clearRect(0, 0, viewW, viewH);
      aCtx.drawImage(enhancedVidFrame.canvas, 0, 0, viewW, viewH);
    } else {
      aCtx.clearRect(0, 0, viewW, viewH);
      aCtx.drawImage(afterSource, 0, 0, viewW, viewH);
    }
  }, [
    activeClip,
    activeAsset,
    sourceDims,
    enhancer,
    smooth,
    localTime,
    hwProfile.tier,
  ]);

  useEffect(() => {
    const id = window.setTimeout(() => {
      void renderComparisonFrames();
    }, previewPlaying ? 0 : 40);
    return () => window.clearTimeout(id);
  }, [renderComparisonFrames, previewPlaying]);

  // Drag split handle smoothly
  useEffect(() => {
    if (!isDraggingSplit) return;
    const onMove = (e: PointerEvent) => {
      const el = splitContainerRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const pct = ((e.clientX - r.left) / Math.max(1, r.width)) * 100;
      setSplitPct(Math.max(4, Math.min(96, pct)));
    };
    const onUp = () => setIsDraggingSplit(false);
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
  }, [isDraggingSplit]);

  const handleApplyToClip = () => {
    if (!activeClip || !activeAsset) return;
    onUpdateClip(
      activeClip.id,
      (c) => {
        let nextDur = c.duration;
        if (activeAsset.type === 'video') {
          const prevSlow = c.smoothVideo?.enabled ? c.smoothVideo.slowMotionSpeed : 1;
          const nextSlow = smooth.enabled ? smooth.slowMotionSpeed : 1;
          if (prevSlow !== nextSlow) {
            const baseNaturalDur = c.duration * prevSlow;
            nextDur = Math.max(
              0.5,
              Math.min(activeAsset.duration * 10, Math.round((baseNaturalDur / nextSlow) * 100) / 100)
            );
          }
        }
        return {
          ...c,
          duration: nextDur,
          qualityEnhancer: { ...enhancer },
          smoothVideo: activeAsset.type === 'video' ? { ...smooth } : c.smoothVideo,
        };
      },
      true
    );
    setProcessStage('Applied non-destructively to clip.');
  };

  const handleProcessAndCacheFull = async () => {
    if (!activeClip || !activeAsset || isProcessing) return;
    const ac = new AbortController();
    abortRef.current = ac;
    setIsProcessing(true);
    setProcessError(null);
    setProcessProgress(2);

    try {
      if (activeTab === 'enhancer') {
        const nextSettings: QualityEnhancerSettings = { ...enhancer, enabled: true };
        setEnhancer(nextSettings);

        if (activeAsset.type === 'image') {
          const img = loadedImageRef.current;
          if (!img) throw new Error('Source image not loaded yet.');
          const res = await processImageEnhancementTiled(
            img,
            img.naturalWidth,
            img.naturalHeight,
            nextSettings,
            false,
            (pct, stg) => {
              setProcessProgress(pct);
              setProcessStage(stg);
            },
            ac.signal
          );
          enhancedImageCache.set(activeAsset.id, nextSettings, res.canvas, res.width, res.height);
        } else {
          setProcessProgress(100);
          setProcessStage('Video enhancement pipeline armed for real-time preview & export.');
        }

        onUpdateClip(
          activeClip.id,
          (c) => ({ ...c, qualityEnhancer: nextSettings }),
          true
        );
      } else if (activeAsset.type === 'video') {
        const nextSmooth: SmoothVideoSettings = { ...smooth, enabled: true };
        setSmooth(nextSmooth);
        const generated = await preRenderSmoothClipSequence({
          asset: activeAsset,
          clip: activeClip,
          settings: nextSmooth,
          onProgress: (pct, stg) => {
            setProcessProgress(pct);
            setProcessStage(stg);
          },
          signal: ac.signal,
        });
        const updatedSmooth = { ...nextSmooth, preRenderedCount: generated };
        setSmooth(updatedSmooth);

        onUpdateClip(
          activeClip.id,
          (c) => {
            const prevSlow = c.smoothVideo?.enabled ? c.smoothVideo.slowMotionSpeed : 1;
            const baseNaturalDur = c.duration * prevSlow;
            const nextDur = Math.max(
              0.5,
              Math.round((baseNaturalDur / updatedSmooth.slowMotionSpeed) * 100) / 100
            );
            return {
              ...c,
              duration: nextDur,
              smoothVideo: updatedSmooth,
            };
          },
          true
        );
        setProcessStage(`Cached ${generated} optical-flow frames cleanly.`);
      }
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        setProcessStage('Processing cancelled.');
        setProcessProgress(0);
      } else {
        setProcessError(err instanceof Error ? err.message : 'Processing failed.');
      }
    } finally {
      abortRef.current = null;
      setIsProcessing(false);
    }
  };

  const handleResetCurrent = () => {
    if (!activeClip || !activeAsset) return;
    if (activeTab === 'enhancer') {
      const def = createDefaultQualityEnhancerSettings();
      setEnhancer(def);
      enhancedImageCache.clearAsset(activeAsset.id);
      onUpdateClip(activeClip.id, (c) => ({ ...c, qualityEnhancer: def }), true);
      setProcessStage('Enhancement reset to original source.');
    } else {
      const def = createDefaultSmoothVideoSettings();
      setSmooth(def);
      smoothVideoCache.clearAsset(activeAsset.id);
      onUpdateClip(
        activeClip.id,
        (c) => {
          const prevSlow = c.smoothVideo?.enabled ? c.smoothVideo.slowMotionSpeed : 1;
          const restoredDur = Math.max(0.5, Math.round(c.duration * prevSlow * 100) / 100);
          return { ...c, duration: restoredDur, smoothVideo: def };
        },
        true
      );
      setProcessStage('Smooth Video reset to original FPS.');
    }
  };

  const origFps = activeAsset?.sourceFps || project.fps || 30;
  const targetFpsDisplay = smooth.enabled
    ? resolveEffectiveTargetFps(smooth.targetFps, origFps)
    : origFps;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 text-xs">
      <div className="w-full max-w-6xl max-h-[92vh] bg-[#222225] border border-[#3E3E44] rounded-md shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 bg-[#2C2C30] border-b border-[#3E3E44] flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-4 min-w-0">
            <div className="flex items-center gap-2 font-display text-sm font-semibold text-[#F4F4F5] whitespace-nowrap shrink-0">
              <Sparkles className="w-4 h-4 text-[#D4D4D8]" />
              Quality Enhancer &amp; Smooth Video Studio
            </div>

            <div className="flex items-center gap-1 p-0.5 bg-[#18181A] border border-[#3E3E44] rounded">
              <button
                type="button"
                onClick={() => setActiveTab('enhancer')}
                className={`px-3 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
                  activeTab === 'enhancer'
                    ? 'bg-[#52525B] text-white'
                    : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                Quality Enhancer
              </button>
              <button
                type="button"
                disabled={!isVideo && mediaClips.every((m) => project.assets.find((a) => a.id === m.assetId)?.type !== 'video')}
                onClick={() => {
                  setActiveTab('smooth');
                  if (!isVideo) {
                    const firstVid = mediaClips.find(
                      (m) => project.assets.find((a) => a.id === m.assetId)?.type === 'video'
                    );
                    if (firstVid) setActiveClipId(firstVid.id);
                  }
                }}
                className={`px-3 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors disabled:opacity-40 ${
                  activeTab === 'smooth'
                    ? 'bg-[#52525B] text-white'
                    : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
                }`}
              >
                Smooth Video (Optical Flow)
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            {mediaClips.length > 0 && (
              <select
                value={activeClipId || ''}
                onChange={(e) => setActiveClipId(e.target.value)}
                className="px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] max-w-[240px] focus:outline-none focus:border-[#A1A1AA]"
              >
                {mediaClips.map((c) => {
                  const asset = project.assets.find((a) => a.id === c.assetId);
                  return (
                    <option key={c.id} value={c.id}>
                      {c.name} ({asset?.type === 'video' ? 'Video' : 'Photo'})
                    </option>
                  );
                })}
              </select>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-[#A1A1AA] hover:text-[#F4F4F5] rounded hover:bg-[#2E323E]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Main Workspace Split */}
        {!activeClip || !activeAsset ? (
          <div className="p-12 text-center text-[#A1A1AA] space-y-2">
            <Film className="w-8 h-8 text-[#A1A1AA] mx-auto" />
            <div className="text-sm font-medium text-[#F4F4F5]">
              No photo or video clip selected
            </div>
            <p className="text-xs text-[#A1A1AA]">
              Import a photo or video into your timeline first to run Quality Enhancer or Smooth Video optical-flow interpolation.
            </p>
          </div>
        ) : (
          <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
            {/* Left / Main: Split-Screen Before / After Viewer */}
            <div className="lg:col-span-7 flex flex-col border-b lg:border-b-0 lg:border-r border-[#3E3E44] bg-[#18181A] min-h-[340px]">
              {/* Metadata Bar (Zero Pills, Clean Tabular Numerals) */}
              <div className="px-4 py-2 bg-[#2C2C30] border-b border-[#3E3E44] flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono-tabular">
                <div className="flex items-center gap-2 text-[#A1A1AA]">
                  <span>Before:</span>
                  <span className="text-[#F4F4F5]">
                    {sourceDims.w}×{sourceDims.h}
                  </span>
                  {isVideo && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-[#F4F4F5]">{origFps} FPS</span>
                    </>
                  )}
                </div>
                <div className="flex items-center gap-2 text-[#F4F4F5]">
                  <span className="text-[#E4E4E7] font-medium">After:</span>
                  <span>
                    {enhancer.enabled && enhancer.upscaling
                      ? `${targetSizeInfo.width}×${targetSizeInfo.height}`
                      : `${sourceDims.w}×${sourceDims.h}`}
                  </span>
                  {isVideo && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>
                        {targetFpsDisplay} FPS
                        {smooth.enabled && smooth.slowMotionSpeed < 1
                          ? ` (${smooth.slowMotionSpeed}x Slow-Mo)`
                          : ''}
                      </span>
                    </>
                  )}
                </div>
              </div>

              {/* Split Canvas Area */}
              <div
                ref={splitContainerRef}
                className="relative flex-1 min-h-[260px] flex items-center justify-center overflow-hidden select-none p-4 bg-[#18181A]"
              >
                <div className="relative max-w-full max-h-full aspect-video w-full flex items-center justify-center bg-[#000000]">
                  {/* Base Before Layer */}
                  <canvas
                    ref={beforeCanvasRef}
                    className="w-full h-full object-contain block"
                  />

                  {/* Clipped After Layer */}
                  <div
                    style={{ clipPath: `inset(0 0 0 ${splitPct}%)` }}
                    className="absolute inset-0 flex items-center justify-center pointer-events-none"
                  >
                    <canvas
                      ref={afterCanvasRef}
                      className="w-full h-full object-contain block"
                    />
                  </div>

                  {/* Labels */}
                  <div className="absolute top-2.5 left-3 px-2 py-0.5 bg-black/75 text-[10px] font-mono-tabular text-[#F4F4F5] rounded pointer-events-none">
                    Before ({sourceDims.w}×{sourceDims.h})
                  </div>
                  <div className="absolute top-2.5 right-3 px-2 py-0.5 bg-black/75 text-[10px] font-mono-tabular text-[#E4E4E7] rounded pointer-events-none">
                    After ({enhancer.enabled && enhancer.upscaling ? `${targetSizeInfo.width}×${targetSizeInfo.height}` : `${sourceDims.w}×${sourceDims.h}`})
                  </div>

                  {/* Draggable Split Line + Handle */}
                  <div
                    onPointerDown={() => setIsDraggingSplit(true)}
                    style={{ left: `${splitPct}%` }}
                    className="absolute top-0 bottom-0 -ml-0.5 w-1 bg-[#52525B] cursor-ew-resize flex items-center justify-center"
                  >
                    <div className="w-7 h-7 -ml-3 rounded bg-[#52525B] border border-white/60 shadow-lg flex items-center justify-center text-white">
                      <MoveHorizontal className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Comparison Playback Controls */}
              <div className="px-4 py-2.5 bg-[#2C2C30] border-t border-[#3E3E44] flex items-center gap-3">
                <button
                  type="button"
                  disabled={!isVideo}
                  onClick={() => setPreviewPlaying((p) => !p)}
                  className="px-3 py-1.5 bg-[#52525B] hover:bg-[#6B7280] disabled:opacity-40 text-white rounded flex items-center gap-1.5 font-medium shrink-0"
                >
                  {previewPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  {previewPlaying ? 'Pause' : 'Play'}
                </button>
                <input
                  type="range"
                  disabled={!isVideo}
                  min={0}
                  max={Math.max(0.1, activeClip.duration)}
                  step={0.01}
                  value={localTime}
                  onChange={(e) => {
                    setPreviewPlaying(false);
                    setLocalTime(Number(e.target.value));
                  }}
                  className="flex-1 cursor-pointer disabled:opacity-40"
                />
                <span className="font-mono-tabular text-[11px] text-[#F4F4F5] w-24 text-right shrink-0">
                  {localTime.toFixed(2)}s / {activeClip.duration.toFixed(2)}s
                </span>
              </div>
            </div>

            {/* Right Controls Drawer */}
            <div className="lg:col-span-5 flex flex-col overflow-y-auto p-4 space-y-4 bg-[#222225]">
              {activeTab === 'enhancer' ? (
                <>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-[#F4F4F5] flex items-center gap-2">
                      <SlidersHorizontal className="w-4 h-4 text-[#D4D4D8]" />
                      {isVideo ? 'Video Enhancement' : 'Image Enhancement'}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setEnhancer((s) => ({ ...s, enabled: !s.enabled }))
                      }
                      className={`px-3 py-1 rounded text-xs font-medium border transition-colors ${
                        enhancer.enabled
                          ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                          : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                      }`}
                    >
                      {enhancer.enabled ? 'Enhancer On' : 'Enhancer Off'}
                    </button>
                  </div>

                  {/* Honest DSP Engine Disclosure */}
                  <div className="p-2.5 bg-[#2C2C30] border border-[#3E3E44] rounded text-[11px] text-[#A1A1AA]">
                    Deterministic local {hwProfile.webgl2Supported ? 'WebGL2 GPU + Tiled' : 'Tiled CPU'} Engine · Edge-Directed Lanczos-3 Super-Resolution, Bilateral Denoising &amp; Deconvolution. Original source remains untouched.
                  </div>

                  {/* Processing Quality + Upscale Target */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-[#A1A1AA] block mb-1">
                        Processing Quality
                      </label>
                      <select
                        value={enhancer.processingQuality}
                        onChange={(e) =>
                          setEnhancer((s) => ({
                            ...s,
                            processingQuality: e.target.value as EnhancementProcessingQuality,
                          }))
                        }
                        className="w-full px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                      >
                        <option value="fast">Fast (Low-End PC)</option>
                        <option value="balanced">Balanced (Recommended)</option>
                        <option value="high">High Quality (Lanczos-3)</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[11px] text-[#A1A1AA] block mb-1">
                        Resolution Upscaling
                      </label>
                      <select
                        value={enhancer.upscaling ? enhancer.targetResolution : 'original'}
                        onChange={(e) => {
                          const v = e.target.value as UpscaleResolutionTarget;
                          setEnhancer((s) => ({
                            ...s,
                            enabled: true,
                            upscaling: v !== 'original',
                            targetResolution: v,
                          }));
                        }}
                        className="w-full px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                      >
                        <option value="original">Original Resolution ({sourceDims.w}×{sourceDims.h})</option>
                        <option value="720p">720p HD (Aspect Preserved)</option>
                        <option value="1080p">1080p Full HD (Aspect Preserved)</option>
                        <option value="2k">2K QHD (Aspect Preserved)</option>
                        <option value="4k">4K UHD (Aspect Preserved)</option>
                      </select>
                    </div>
                  </div>

                  {targetSizeInfo.clampedByHardware && targetSizeInfo.reason && (
                    <div className="text-[11px] text-amber-300 bg-amber-950/30 border border-amber-500/30 rounded px-2.5 py-1.5">
                      {targetSizeInfo.reason}
                    </div>
                  )}

                  {/* Master Intensity */}
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="text-[#F4F4F5] font-medium">Master Enhancement Intensity</span>
                      <span className="font-mono-tabular text-[#E4E4E7]">{enhancer.intensity}%</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={enhancer.intensity}
                      onChange={(e) =>
                        setEnhancer((s) => ({
                          ...s,
                          enabled: true,
                          intensity: Number(e.target.value),
                        }))
                      }
                      className="w-full cursor-pointer"
                    />
                  </div>

                  {/* Option Sliders (dynamically show Image vs Video controls) */}
                  <div className="space-y-2.5 border-t border-[#3E3E44] pt-3">
                    {(isVideo
                      ? ([
                          ['sharpening', 'Video Sharpening'],
                          ['detailRecovery', 'Detail Recovery'],
                          ['noiseReduction', 'Noise Reduction'],
                          ['deblurring', 'Deblurring'],
                          ['colorCorrection', 'Color Correction'],
                          ['lowLightEnhancement', 'Low-Light Enhancement'],
                          ['compressionArtifactReduction', 'Compression Artifact Reduction'],
                        ] as const)
                      : ([
                          ['sharpening', 'Image Sharpening'],
                          ['detailRecovery', 'Detail Recovery'],
                          ['noiseReduction', 'Noise Reduction'],
                          ['deblurring', 'Deblurring'],
                          ['textureEnhancement', 'Texture Enhancement'],
                          ['faceDetailEnhancement', 'Face Detail Enhancement'],
                          ['colorEnhancement', 'Color Enhancement'],
                        ] as const)
                    ).map(([key, label]) => (
                      <div key={key}>
                        <div className="flex justify-between text-[11px] text-[#F4F4F5] mb-0.5">
                          <span>{label}</span>
                          <span className="font-mono-tabular text-[#A1A1AA]">{enhancer[key]}%</span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={enhancer[key]}
                          onChange={(e) =>
                            setEnhancer((s) => ({
                              ...s,
                              enabled: true,
                              [key]: Number(e.target.value),
                            }))
                          }
                          className="w-full h-1 cursor-pointer"
                        />
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-[#F4F4F5] flex items-center gap-2">
                      <Gauge className="w-4 h-4 text-[#D4D4D8]" />
                      Smooth Video (Optical Flow)
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setSmooth((s) => ({ ...s, enabled: !s.enabled }))
                      }
                      className={`px-3 py-1 rounded text-xs font-medium border transition-colors ${
                        smooth.enabled
                          ? 'bg-[#52525B] border-[#A1A1AA] text-white'
                          : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                      }`}
                    >
                      {smooth.enabled ? 'Interpolation On' : 'Interpolation Off'}
                    </button>
                  </div>

                  <div className="p-2.5 bg-[#2C2C30] border border-[#3E3E44] rounded text-[11px] text-[#A1A1AA]">
                    Generates genuine bidirectional motion-compensated intermediate frames via coarse-to-fine block optical flow to remove judder and minimize ghosting.
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-[#A1A1AA] block mb-1">Target Frame Rate</label>
                      <select
                        value={smooth.targetFps}
                        onChange={(e) => {
                          const raw = e.target.value;
                          const val: SmoothVideoFpsTarget =
                            raw === 'original' ? 'original' : (Number(raw) as SmoothVideoFpsTarget);
                          setSmooth((s) => ({ ...s, enabled: val !== 'original', targetFps: val }));
                        }}
                        className="w-full px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                      >
                        <option value="original">Original FPS ({origFps})</option>
                        <option value={30}>30 FPS</option>
                        <option value={50}>50 FPS</option>
                        <option value={60}>60 FPS (Smooth)</option>
                        <option value={120}>120 FPS (High Motion)</option>
                        <option value={240}>
                          240 FPS {hwProfile.tier === 'low-end' ? '(Heavy CPU)' : '(Ultra Smooth)'}
                        </option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] text-[#A1A1AA] block mb-1">
                        Processing Quality
                      </label>
                      <select
                        value={smooth.processingQuality}
                        onChange={(e) =>
                          setSmooth((s) => ({
                            ...s,
                            processingQuality: e.target.value as EnhancementProcessingQuality,
                          }))
                        }
                        className="w-full px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                      >
                        <option value="fast">Fast (Low-End PC)</option>
                        <option value="balanced">Balanced (Recommended)</option>
                        <option value="high">High Quality</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] text-[#A1A1AA] block mb-1">
                      Smooth Slow-Motion Conversion
                    </label>
                    <select
                      value={smooth.slowMotionSpeed}
                      onChange={(e) =>
                        setSmooth((s) => ({
                          ...s,
                          enabled: true,
                          slowMotionSpeed: Number(e.target.value) as SmoothVideoSettings['slowMotionSpeed'],
                        }))
                      }
                      className="w-full px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] font-mono-tabular focus:outline-none focus:border-[#A1A1AA]"
                    >
                      <option value={1}>1.0× Normal Speed (Preserve Original Duration)</option>
                      <option value={0.75}>0.75× Gentle Slow-Mo</option>
                      <option value={0.5}>0.50× 2× Smooth Slow Motion</option>
                      <option value={0.25}>0.25× 4× Cinematic Slow Motion</option>
                      <option value={0.1}>0.10× 10× Super Slow Motion</option>
                    </select>
                    <p className="text-[11px] text-[#A1A1AA] mt-1">
                      Audio track automatically stretches &amp; stays synchronized during playback and export.
                    </p>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-[#F4F4F5] mb-1">
                      <span>Ghosting &amp; Occlusion Suppression</span>
                      <span className="font-mono-tabular text-[#A1A1AA]">{smooth.artifactSuppression}%</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={smooth.artifactSuppression}
                      onChange={(e) =>
                        setSmooth((s) => ({
                          ...s,
                          enabled: true,
                          artifactSuppression: Number(e.target.value),
                        }))
                      }
                      className="w-full h-1 cursor-pointer"
                    />
                  </div>
                </>
              )}

              {/* Progress / Errors */}
              {(isProcessing || processStage) && (
                <div className="p-2.5 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-1.5">
                  <div className="flex justify-between text-[11px] text-[#F4F4F5]">
                    <span className="truncate">{processStage}</span>
                    <span className="font-mono-tabular shrink-0 ml-2">{processProgress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-[#18181A] rounded overflow-hidden">
                    <div
                      style={{ width: `${processProgress}%` }}
                      className="h-full bg-[#52525B] transition-[width] duration-150"
                    />
                  </div>
                </div>
              )}

              {processError && (
                <div className="p-2.5 bg-rose-950/40 border border-rose-500/40 rounded text-rose-200 text-[11px]">
                  {processError}
                </div>
              )}

              {/* Footer Actions */}
              <div className="mt-auto pt-3 border-t border-[#3E3E44] flex flex-wrap items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={handleResetCurrent}
                  disabled={isProcessing}
                  className="px-3 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-[#3E3E44] rounded text-[#F4F4F5] flex items-center gap-1.5 disabled:opacity-40"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Reset
                </button>

                <div className="flex items-center gap-2">
                  {isProcessing ? (
                    <button
                      type="button"
                      onClick={() => abortRef.current?.abort()}
                      className="px-3 py-1.5 bg-[#2C2C30] hover:bg-[#2E323E] border border-rose-500/40 text-rose-300 rounded font-medium"
                    >
                      Cancel
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleProcessAndCacheFull}
                      className="px-3 py-1.5 bg-[#71717A]/15 hover:bg-[#71717A]/25 border border-[#A1A1AA]/45 text-[#F4F4F5] rounded font-medium flex items-center gap-1.5"
                    >
                      {activeTab === 'enhancer' ? (
                        <>
                          <Sparkles className="w-3.5 h-3.5 text-[#D4D4D8]" />
                          Process &amp; Cache
                        </>
                      ) : (
                        <>
                          <Film className="w-3.5 h-3.5 text-[#D4D4D8]" />
                          Pre-Render Flow Frames
                        </>
                      )}
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={handleApplyToClip}
                    className="px-4 py-1.5 bg-[#52525B] hover:bg-[#6B7280] text-white rounded font-semibold flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Apply to Clip
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
