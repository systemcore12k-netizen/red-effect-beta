import React, { useRef, useState } from 'react';
import {
  Upload,
  Video,
  Image as ImageIcon,
  Music,
  Box,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { MediaAsset, MediaType } from '../types/studio';

interface MediaExplorerPanelProps {
  assets: MediaAsset[];
  activeFolder: string;
  selectedAssetId: string | null;
  onSelectAsset: (assetId: string) => void;
  onImportFiles: (files: FileList) => void;
  onAddAssetToTimeline: (asset: MediaAsset) => void;
  onOpen3DForAsset: (asset: MediaAsset) => void;
  onDeleteAsset: (assetId: string) => void;
}

export const MediaExplorerPanel: React.FC<MediaExplorerPanelProps> = ({
  assets,
  activeFolder,
  selectedAssetId,
  onSelectAsset,
  onImportFiles,
  onAddAssetToTimeline,
  onOpen3DForAsset,
  onDeleteAsset,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [filterType, setFilterType] = useState<'all' | MediaType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isDragOver, setIsDragOver] = useState(false);

  const filtered = assets.filter((a) => {
    if (activeFolder !== 'ALL') {
      if (a.folder !== activeFolder && !a.folder.startsWith(`${activeFolder}/`)) return false;
    }
    if (filterType !== 'all' && a.type !== filterType) return false;
    if (searchQuery.trim() && !a.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onImportFiles(e.dataTransfer.files);
    }
  };

  const renderIcon = (type: MediaType) => {
    switch (type) {
      case 'video':
        return <Video className="w-4 h-4 text-[#D4D4D8]" />;
      case 'image':
        return <ImageIcon className="w-4 h-4 text-sky-400" />;
      case 'audio':
        return <Music className="w-4 h-4 text-emerald-400" />;
      case 'model3d':
        return <Box className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <div
      data-tutorial-target="media-explorer"
      onDragOver={(e) => {
        if (e.dataTransfer.types.includes('Files')) {
          e.preventDefault();
          setIsDragOver(true);
        }
      }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={handleDrop}
      className={`p-2.5 flex flex-col gap-2.5 h-full text-xs bg-[#222225] text-[#F4F4F5] ${
        isDragOver ? 'bg-[#71717A]/15' : ''
      }`}
    >
      {/* Import Controls */}
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          data-tutorial-target="import-media-btn"
          onClick={() => fileInputRef.current?.click()}
          className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2.5 bg-[#52525B] hover:bg-[#6B7280] text-white font-medium rounded transition-colors whitespace-nowrap"
        >
          <Upload className="w-3.5 h-3.5" />
          Import Media
        </button>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".mp4,.mov,.avi,.mkv,.webm,.mp3,.wav,.aac,.m4a,.ogg,.png,.jpg,.jpeg,.webp,.psd,.obj,.glb,.gltf,.fbx,video/*,image/*,audio/*"
          onChange={(e) => {
            if (e.target.files && e.target.files.length > 0) {
              onImportFiles(e.target.files);
              e.target.value = '';
            }
          }}
          className="hidden"
        />
      </div>

      {/* Search & Filter */}
      <div className="flex items-center gap-1.5">
        <div className="relative flex-1 min-w-0">
          <Search className="w-3.5 h-3.5 text-[#A1A1AA] absolute left-2 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search clips, audio, 3D..."
            className="w-full pl-7 pr-2 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] placeholder:text-[#A1A1AA] focus:outline-none focus:border-[#A1A1AA]"
          />
        </div>
      </div>

      <div className="flex items-center gap-1 bg-[#18181A] p-0.5 rounded border border-[#3E3E44]">
        {(['all', 'video', 'image', 'audio', 'model3d'] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setFilterType(t)}
            className={`flex-1 py-1 px-1 rounded text-[10px] font-medium capitalize transition-colors whitespace-nowrap ${
              filterType === t
                ? 'bg-[#2C2C30] text-[#F4F4F5] border border-[#3E3E44]'
                : 'text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            {t === 'model3d' ? '3D' : t}
          </button>
        ))}
      </div>

      {/* Asset Grid */}
      {filtered.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-4 border border-dashed border-[#3E3E44] rounded text-[#A1A1AA] bg-[#18181A]/50">
          <Upload className="w-6 h-6 mb-2 text-[#A1A1AA]" />
          <p className="text-[#F4F4F5] font-medium mb-1">Drop PC Media Here</p>
          <p className="text-[11px]">
            Supports MP4, MOV, AVI, MKV, MP3, WAV, PNG, JPG, OBJ, GLB, FBX
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2 overflow-y-auto pr-0.5">
          {filtered.map((asset) => {
            const isSelected = asset.id === selectedAssetId;
            return (
              <div
                key={asset.id}
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData('application/x-redeffect-asset', asset.id);
                  e.dataTransfer.effectAllowed = 'copy';
                }}
                onClick={() => onSelectAsset(asset.id)}
                onDoubleClick={() => onAddAssetToTimeline(asset)}
                className={`group relative flex flex-col bg-[#2C2C30] rounded border overflow-hidden cursor-pointer transition-colors ${
                  isSelected
                    ? 'border-[#A1A1AA] ring-1 ring-[#A1A1AA]'
                    : 'border-[#3E3E44] hover:border-[#A1A1AA]/60'
                }`}
              >
                <div className="aspect-video bg-[#18181A] relative flex items-center justify-center overflow-hidden">
                  {asset.type === 'image' ? (
                    <img
                      src={asset.url}
                      alt={asset.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : asset.type === 'video' ? (
                    <video
                      src={asset.url}
                      muted
                      preload="metadata"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="flex flex-col items-center gap-1 text-[#A1A1AA]">
                      {renderIcon(asset.type)}
                      <span className="text-[10px] font-mono-tabular uppercase">
                        {asset.type}
                      </span>
                    </div>
                  )}

                  {/* Quick Hover Overlay Controls */}
                  <div className="absolute inset-0 bg-black/65 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onAddAssetToTimeline(asset);
                      }}
                      title="Insert onto Timeline"
                      className="p-1.5 bg-[#52525B] hover:bg-[#6B7280] text-white rounded"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    {asset.type === 'model3d' && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpen3DForAsset(asset);
                        }}
                        title="Open in 3D Studio"
                        className="p-1.5 bg-[#2C2C30] hover:bg-[#343439] text-[#F4F4F5] border border-[#3E3E44] rounded"
                      >
                        <Box className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {!asset.isStarter && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteAsset(asset.id);
                        }}
                        title="Remove Asset"
                        className="p-1.5 bg-[#222225] hover:bg-rose-600 text-[#F4F4F5] rounded"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="p-1.5">
                  <div className="text-[11px] font-medium text-[#F4F4F5] truncate">
                    {asset.name}
                  </div>
                  <div className="text-[10px] text-[#A1A1AA] font-mono-tabular">
                    {asset.type.toUpperCase()} · {asset.duration.toFixed(1)}s
                    {asset.type === 'video' && asset.hasAudio ? ' · Audio' : ''}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
