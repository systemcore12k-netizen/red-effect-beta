import React from 'react';
import {
  Check,
  Palette,
  Pipette,
  RotateCcw,
  Sparkles,
  Sun,
  Moon,
} from 'lucide-react';
import {
  StudioSettings,
  UiThemeSettings,
} from '../types/studio';
import { DEFAULT_UI_THEME } from '../services/projectStorage';
import {
  CURATED_UI_COMBOS,
  normalizeHex,
  resolveUiThemeTokens,
  UI_ACCENT_PRESETS,
  UI_SURFACE_PRESETS,
} from '../services/uiThemeEngine';

interface UiThemeCustomizerProps {
  settings: StudioSettings;
  onUpdateSettings: (next: StudioSettings) => void;
  compact?: boolean;
}

export const UiThemeCustomizer: React.FC<UiThemeCustomizerProps> = ({
  settings,
  onUpdateSettings,
  compact = false,
}) => {
  const theme: UiThemeSettings = {
    ...DEFAULT_UI_THEME,
    ...(settings.uiTheme || {}),
  };

  const resolved = resolveUiThemeTokens(theme);

  const updateTheme = (patch: Partial<UiThemeSettings>) => {
    onUpdateSettings({
      ...settings,
      uiTheme: {
        ...theme,
        ...patch,
      },
    });
  };

  const resetDefault = () => {
    onUpdateSettings({
      ...settings,
      uiTheme: { ...DEFAULT_UI_THEME },
    });
  };

  return (
    <div
      className={
        compact
          ? 'space-y-4'
          : 'p-5 bg-[#222225] border border-[#3E3E44] rounded-2xl space-y-5'
      }
    >
      {/* Header + Reset */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <div
            className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
            style={{
              backgroundColor: resolved.accentSoft,
              color: resolved.accentTextHex,
              border: `1px solid ${resolved.accentBorder}`,
            }}
          >
            <Palette className="w-4 h-4" />
          </div>
          <div>
            <div className="text-sm font-bold text-[#F4F4F5]">
              UI Theme &amp; Color Customization
            </div>
            <div className="text-[11px] text-[#A1A1AA]">
              Personalize app background (Gray, White, Black) &amp; accent colors (Red, Purple, Blue, Any Color)
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={resetDefault}
          className="px-2.5 py-1.5 rounded-lg bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[11px] font-medium text-[#F4F4F5] flex items-center gap-1.5 transition-colors shrink-0"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset Gray Default</span>
        </button>
      </div>

      {/* Quick 1-Click Theme Combos */}
      <div className="space-y-2">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-[#A1A1AA] flex items-center gap-1.5">
          <Sparkles className="w-3 h-3" />
          <span>Quick Theme Presets</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {CURATED_UI_COMBOS.map((combo) => {
            const comboSurf =
              UI_SURFACE_PRESETS.find((s) => s.id === combo.surface) || UI_SURFACE_PRESETS[0];
            const comboAcc =
              UI_ACCENT_PRESETS.find((a) => a.id === combo.accentPreset) || UI_ACCENT_PRESETS[0];
            const isActive =
              theme.surface === combo.surface && theme.accentPreset === combo.accentPreset;
            return (
              <button
                key={combo.id}
                type="button"
                onClick={() =>
                  updateTheme({
                    surface: combo.surface,
                    accentPreset: combo.accentPreset,
                  })
                }
                className={`px-2.5 py-2 rounded-xl border text-left flex items-center gap-2 transition-all ${
                  isActive
                    ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                    : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5] hover:border-[#A1A1AA]/60'
                }`}
              >
                <span
                  className="w-5 h-5 rounded-md border shrink-0 flex items-center justify-center"
                  style={{
                    backgroundColor: comboSurf.bgPanel,
                    borderColor: comboSurf.border,
                  }}
                >
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: comboAcc.hex }}
                  />
                </span>
                <span className="text-[11px] font-semibold truncate">{combo.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Base UI Background / Surface Mode */}
      <div className="space-y-2">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
          UI Base Theme (Gray / White / Dark)
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {UI_SURFACE_PRESETS.map((surf) => {
            const active = theme.surface === surf.id;
            return (
              <button
                key={surf.id}
                type="button"
                onClick={() => updateTheme({ surface: surf.id })}
                className={`p-2.5 rounded-xl border text-left transition-all flex items-center gap-2.5 ${
                  active
                    ? 'bg-[#71717A]/20 border-[#A1A1AA] shadow-sm'
                    : 'bg-[#2C2C30] border-[#3E3E44] hover:border-[#A1A1AA]/60'
                }`}
              >
                {/* Miniature workspace surface preview */}
                <div
                  className="w-9 h-7 rounded border shrink-0 p-1 flex flex-col justify-between"
                  style={{
                    backgroundColor: surf.bgMain,
                    borderColor: surf.border,
                  }}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span
                      className="h-1 w-4 rounded-full"
                      style={{ backgroundColor: surf.textPrimary }}
                    />
                    <span
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ backgroundColor: resolved.accentHex }}
                    />
                  </div>
                  <div
                    className="h-2.5 w-full rounded-sm"
                    style={{ backgroundColor: surf.bgPanel }}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1 text-xs font-semibold text-[#F4F4F5]">
                    {surf.isLight ? (
                      <Sun className="w-3 h-3 shrink-0" />
                    ) : (
                      <Moon className="w-3 h-3 shrink-0 text-[#A1A1AA]" />
                    )}
                    <span className="truncate">{surf.label}</span>
                  </div>
                  <div className="text-[10px] text-[#A1A1AA] truncate">
                    {surf.isLight ? 'Light UI' : surf.shortLabel}
                  </div>
                </div>
                {active && (
                  <Check
                    className="w-3.5 h-3.5 shrink-0"
                    style={{ color: resolved.accentTextHex }}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Accent & Button Color Grid ("All Colors" + Custom Picker) */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-[#A1A1AA]">
            Accent Color (Buttons, Active Tabs &amp; Highlights)
          </div>
          <span className="text-[10px] font-mono-tabular text-[#A1A1AA]">
            {resolved.accentHex}
          </span>
        </div>

        <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
          {UI_ACCENT_PRESETS.map((preset) => {
            const active = theme.accentPreset === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                title={preset.label}
                onClick={() => updateTheme({ accentPreset: preset.id })}
                className={`group flex flex-col items-center gap-1 p-1.5 rounded-lg border transition-all ${
                  active
                    ? 'bg-[#71717A]/20 border-[#A1A1AA]'
                    : 'bg-[#2C2C30] border-[#3E3E44] hover:border-[#A1A1AA]/60'
                }`}
              >
                <span
                  className="w-6 h-6 rounded-full border flex items-center justify-center shadow-inner transition-transform group-hover:scale-105"
                  style={{
                    backgroundColor: preset.hex,
                    borderColor:
                      preset.id === 'white'
                        ? 'rgba(148,163,184,0.8)'
                        : 'rgba(255,255,255,0.2)',
                  }}
                >
                  {active && (
                    <Check
                      className="w-3.5 h-3.5"
                      style={{
                        color:
                          preset.id === 'white' || preset.id === 'yellow' || preset.id === 'lime'
                            ? '#111827'
                            : '#FFFFFF',
                      }}
                    />
                  )}
                </span>
                <span className="text-[9px] font-medium text-[#A1A1AA] truncate max-w-full">
                  {preset.label}
                </span>
              </button>
            );
          })}

          {/* Custom Color Wheel Button */}
          <label
            title="Pick Any Custom Color"
            className={`cursor-pointer group flex flex-col items-center gap-1 p-1.5 rounded-lg border transition-all ${
              theme.accentPreset === 'custom'
                ? 'bg-[#71717A]/20 border-[#A1A1AA]'
                : 'bg-[#2C2C30] border-[#3E3E44] hover:border-[#A1A1AA]/60'
            }`}
          >
            <span
              className="w-6 h-6 rounded-full border border-white/30 flex items-center justify-center relative overflow-hidden"
              style={{
                background:
                  theme.accentPreset === 'custom'
                    ? theme.customAccentHex
                    : 'conic-gradient(#FF3030, #F59E0B, #22C55E, #06B6D4, #3B82F6, #8B5CF6, #EC4899, #FF3030)',
              }}
            >
              <Pipette
                className="w-3 h-3 drop-shadow"
                style={{
                  color:
                    theme.accentPreset === 'custom' ? resolved.accentOnHex : '#FFFFFF',
                }}
              />
            </span>
            <span className="text-[9px] font-medium text-[#A1A1AA]">Custom</span>
            <input
              type="color"
              value={normalizeHex(theme.customAccentHex, '#8B5CF6')}
              onChange={(e) =>
                updateTheme({
                  accentPreset: 'custom',
                  customAccentHex: e.target.value.toUpperCase(),
                })
              }
              className="sr-only"
            />
          </label>
        </div>

        {/* Custom Hex Input Strip */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <label className="flex items-center gap-2 px-2.5 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded-lg cursor-pointer">
            <input
              type="color"
              value={
                theme.accentPreset === 'custom'
                  ? normalizeHex(theme.customAccentHex, '#8B5CF6')
                  : resolved.accentHex
              }
              onChange={(e) =>
                updateTheme({
                  accentPreset: 'custom',
                  customAccentHex: e.target.value.toUpperCase(),
                })
              }
              className="w-5 h-5 rounded cursor-pointer bg-transparent border-0 p-0"
            />
            <span className="text-[11px] text-[#A1A1AA]">Custom Color Wheel</span>
          </label>

          <div className="flex items-center gap-1.5 bg-[#18181A] border border-[#3E3E44] rounded-lg px-2.5 py-1">
            <span className="text-[10px] text-[#A1A1AA] uppercase">HEX</span>
            <input
              type="text"
              value={
                theme.accentPreset === 'custom'
                  ? theme.customAccentHex
                  : resolved.accentHex
              }
              onChange={(e) => {
                const raw = e.target.value;
                updateTheme({
                  accentPreset: 'custom',
                  customAccentHex: raw.startsWith('#') ? raw : `#${raw}`,
                });
              }}
              maxLength={7}
              placeholder="#8B5CF6"
              className="w-20 bg-transparent text-xs font-mono-tabular text-[#F4F4F5] focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Corner Style & UI Scale */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        <div>
          <label className="text-[11px] text-[#A1A1AA] block mb-1.5">
            Panel Corner Style
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {(['sharp', 'rounded', 'pill'] as const).map((r) => {
              const active = (theme.borderRadius || 'rounded') === r;
              return (
                <button
                  key={r}
                  type="button"
                  onClick={() => updateTheme({ borderRadius: r })}
                  className={`py-1.5 px-2 rounded-lg border text-[11px] font-medium capitalize transition-colors ${
                    active
                      ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                      : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                  }`}
                >
                  {r}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label className="text-[11px] text-[#A1A1AA] block mb-1.5">
            UI Density / Scale
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {(['compact', 'normal', 'comfortable'] as const).map((s) => {
              const active = (theme.uiScale || 'normal') === s;
              return (
                <button
                  key={s}
                  type="button"
                  onClick={() => updateTheme({ uiScale: s })}
                  className={`py-1.5 px-2 rounded-lg border text-[11px] font-medium capitalize transition-colors ${
                    active
                      ? 'bg-[#71717A]/20 border-[#A1A1AA] text-[#F4F4F5]'
                      : 'bg-[#2C2C30] border-[#3E3E44] text-[#A1A1AA] hover:text-[#F4F4F5]'
                  }`}
                >
                  {s === 'comfortable' ? 'Large' : s}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Live Preview Strip */}
      <div
        className="p-3 rounded-xl border flex items-center justify-between gap-3 flex-wrap"
        style={{
          backgroundColor: resolved.surface.bgMain,
          borderColor: resolved.surface.border,
          color: resolved.surface.textPrimary,
        }}
      >
        <div className="flex items-center gap-2.5">
          <div
            className="px-2.5 py-1 rounded text-[11px] font-semibold"
            style={{
              backgroundColor: resolved.accentSoft,
              color: resolved.accentTextHex,
              border: `1px solid ${resolved.accentBorder}`,
            }}
          >
            Active Tab
          </div>
          <span
            className="text-[11px]"
            style={{ color: resolved.surface.textSecondary }}
          >
            Live UI Preview ({resolved.surface.label})
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span
            className="px-2.5 py-1 rounded text-[11px] font-medium border"
            style={{
              backgroundColor: resolved.surface.bgPanel,
              borderColor: resolved.surface.border,
              color: resolved.surface.textPrimary,
            }}
          >
            Panel Card
          </span>
          <span
            className="px-3 py-1 rounded text-[11px] font-semibold"
            style={{
              backgroundColor: resolved.accentHex,
              color: resolved.accentOnHex,
            }}
          >
            Primary Action
          </span>
        </div>
      </div>
    </div>
  );
};
