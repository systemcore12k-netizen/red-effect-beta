import React, { useEffect, useState } from 'react';
import {
  X,
  Keyboard,
  Cpu,
  RotateCcw,
  Volume2,
  RefreshCw,
  Palette,
} from 'lucide-react';
import { PreviewQuality, ShortcutMap, StudioSettings } from '../types/studio';
import { DEFAULT_SHORTCUTS } from '../services/projectStorage';
import { AudioOutputDeviceInfo, listAudioOutputDevices } from '../services/audioEngine';
import {
  detectHardwareProfile,
  releasePooledBuffers,
  textBitmapCache,
} from '../services/performanceEngine';
import { enhancedImageCache } from '../services/qualityEnhancerEngine';
import { smoothVideoCache } from '../services/smoothVideoEngine';
import { clearHoverPreviewCache } from '../services/hoverPreviewCache';
import { UiThemeCustomizer } from './UiThemeCustomizer';

export type SettingsModalTab = 'appearance' | 'performance' | 'audio' | 'shortcuts';

interface SettingsModalProps {
  settings: StudioSettings;
  initialTab?: SettingsModalTab;
  onUpdateSettings: (next: StudioSettings) => void;
  onSelectAudioDevice: (deviceId: string) => Promise<void>;
  onClose: () => void;
}

const SHORTCUT_LABELS: Array<{ key: keyof ShortcutMap; label: string }> = [
  { key: 'newProject', label: 'New Project' },
  { key: 'openProject', label: 'Open Project' },
  { key: 'saveProject', label: 'Save Project' },
  { key: 'saveAs', label: 'Save Project As' },
  { key: 'importMedia', label: 'Import Media' },
  { key: 'undo', label: 'Undo' },
  { key: 'redo', label: 'Redo' },
  { key: 'playPause', label: 'Play / Pause' },
  { key: 'selectTool', label: 'Selection Tool (V)' },
  { key: 'cutTool', label: 'Razor / Cut Tool' },
  { key: 'textTool', label: 'Text Tool (T)' },
  { key: 'keyPosition', label: 'Keyframe Position (P)' },
  { key: 'keyScale', label: 'Keyframe Scale (S)' },
  { key: 'keyRotation', label: 'Keyframe Rotation (R)' },
  { key: 'keyAnchor', label: 'Keyframe Anchor Point (A)' },
  { key: 'keyOpacity', label: 'Keyframe Opacity (O)' },
  { key: 'showAnimated', label: 'Show Animated Properties (U)' },
  { key: 'easyEase', label: 'Easy Ease Keyframes (F9)' },
  { key: 'duplicateClip', label: 'Duplicate Clip (Ctrl+D)' },
  { key: 'copyClip', label: 'Copy Selected Clip' },
  { key: 'pasteClip', label: 'Paste Clip' },
  { key: 'selectAll', label: 'Select All Clips' },
  { key: 'renameClip', label: 'Rename Layer / Clip (F2)' },
  { key: 'deleteClip', label: 'Remove Selected Clip / Marker' },
  { key: 'addMarker', label: 'Add Timeline Marker' },
  { key: 'exportVideo', label: 'Export Video' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  initialTab = 'appearance',
  onUpdateSettings,
  onSelectAudioDevice,
  onClose,
}) => {
  const [tab, setTab] = useState<SettingsModalTab>(initialTab);
  const [listeningKey, setListeningKey] = useState<keyof ShortcutMap | null>(null);
  const [audioDevices, setAudioDevices] = useState<AudioOutputDeviceInfo[]>([
    { deviceId: 'default', label: 'System Default Speakers / Headphones' },
  ]);
  const [deviceStatus, setDeviceStatus] = useState<string | null>(null);
  const [cacheNotice, setCacheNotice] = useState<string | null>(null);
  const hwProfile = detectHardwareProfile();
  const cacheStats = textBitmapCache.getStats();

  const refreshDevices = async () => {
    const list = await listAudioOutputDevices();
    setAudioDevices(list);
  };

  useEffect(() => {
    void refreshDevices();
  }, []);

  const handleKeyCapture = (e: React.KeyboardEvent, shortcutKey: keyof ShortcutMap) => {
    e.preventDefault();
    e.stopPropagation();
    const parts: string[] = [];
    if (e.ctrlKey || e.metaKey) parts.push('Ctrl');
    if (e.shiftKey) parts.push('Shift');
    if (e.altKey) parts.push('Alt');
    const rawKey = e.key === ' ' ? 'Space' : e.key.length === 1 ? e.key.toUpperCase() : e.key;
    if (!['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) {
      parts.push(rawKey);
      const combo = parts.join('+');
      onUpdateSettings({
        ...settings,
        shortcuts: { ...settings.shortcuts, [shortcutKey]: combo },
      });
      setListeningKey(null);
    }
  };

  const handleDeviceChange = async (deviceId: string) => {
    onUpdateSettings({ ...settings, audioOutputDeviceId: deviceId });
    await onSelectAudioDevice(deviceId);
    const chosen = audioDevices.find((d) => d.deviceId === deviceId);
    setDeviceStatus(`Audio output routed to: ${chosen?.label || deviceId}`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4 text-xs">
      <div className="w-full max-w-xl bg-[#222225] border border-[#3E3E44] rounded-md shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        <div className="px-4 py-3 bg-[#2C2C30] border-b border-[#3E3E44] flex items-center justify-between">
          <div className="font-display text-sm font-semibold text-[#F4F4F5]">
            Studio Preferences, Audio Hardware &amp; Shortcuts
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-4 pt-3 flex gap-4 border-b border-[#3E3E44] overflow-x-auto">
          <button
            type="button"
            onClick={() => setTab('appearance')}
            className={`pb-2 px-1 font-medium flex items-center gap-1.5 border-b-2 transition-colors whitespace-nowrap ${
              tab === 'appearance'
                ? 'border-[#A1A1AA] text-[#F4F4F5]'
                : 'border-transparent text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            UI &amp; Colors
          </button>
          <button
            type="button"
            onClick={() => setTab('performance')}
            className={`pb-2 px-1 font-medium flex items-center gap-1.5 border-b-2 transition-colors whitespace-nowrap ${
              tab === 'performance'
                ? 'border-[#A1A1AA] text-[#F4F4F5]'
                : 'border-transparent text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            Performance &amp; Export
          </button>
          <button
            type="button"
            onClick={() => setTab('audio')}
            className={`pb-2 px-1 font-medium flex items-center gap-1.5 border-b-2 transition-colors whitespace-nowrap ${
              tab === 'audio'
                ? 'border-[#A1A1AA] text-[#F4F4F5]'
                : 'border-transparent text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            Audio Hardware
          </button>
          <button
            type="button"
            onClick={() => setTab('shortcuts')}
            className={`pb-2 px-1 font-medium flex items-center gap-1.5 border-b-2 transition-colors whitespace-nowrap ${
              tab === 'shortcuts'
                ? 'border-[#A1A1AA] text-[#F4F4F5]'
                : 'border-transparent text-[#A1A1AA] hover:text-[#F4F4F5]'
            }`}
          >
            <Keyboard className="w-3.5 h-3.5" />
            Keyboard Shortcuts
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4">
          {tab === 'appearance' && (
            <UiThemeCustomizer
              compact
              settings={settings}
              onUpdateSettings={onUpdateSettings}
            />
          )}

          {tab === 'performance' && (
            <div className="space-y-4">
              {/* Detected Hardware Profile Card */}
              <div className="p-3 bg-[#2C2C30] border border-[#3E3E44] rounded space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="text-[#F4F4F5] font-medium flex items-center gap-2">
                      <span>Detected PC Hardware</span>
                      <span
                        className={`px-1.5 py-0.5 text-[10px] font-mono-tabular uppercase rounded border ${
                          hwProfile.tier === 'low-end'
                            ? 'border-amber-500/40 bg-amber-500/15 text-amber-300'
                            : hwProfile.tier === 'mid-range'
                            ? 'border-sky-500/40 bg-sky-500/15 text-sky-300'
                            : 'border-emerald-500/40 bg-emerald-500/15 text-emerald-300'
                        }`}
                      >
                        {hwProfile.tier.replace('-', ' ')}
                      </span>
                    </div>
                    <div className="text-[11px] text-[#A1A1AA] mt-0.5 font-mono-tabular">
                      {hwProfile.cpuCores} CPU Threads ·{' '}
                      {hwProfile.deviceMemoryGB !== null ? `${hwProfile.deviceMemoryGB} GB RAM · ` : ''}
                      {hwProfile.webgl2Supported ? 'WebGL2 GPU Ready' : 'CPU Fallback'}
                    </div>
                    <div className="text-[10px] text-[#A1A1AA] truncate max-w-[440px]">
                      GPU: {hwProfile.gpuRenderer}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        performanceMode: hwProfile.recommendedPerformanceMode,
                        previewQuality: hwProfile.recommendedPreviewQuality,
                        proxyQuality: hwProfile.recommendedProxyQuality,
                        autoDownscalePreview: true,
                      })
                    }
                    className="px-2.5 py-1.5 bg-[#71717A]/20 hover:bg-[#52525B] text-[#E4E4E7] hover:text-white border border-[#A1A1AA]/40 rounded text-[11px] font-medium shrink-0 transition-colors"
                  >
                    Apply Recommended
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#F4F4F5] font-medium">Low-End Performance Mode</div>
                  <div className="text-[11px] text-[#A1A1AA]">
                    Prioritize smooth scrubbing &amp; playback on integrated GPUs (Final export stays 100% full quality)
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.performanceMode}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      performanceMode: e.target.checked,
                      previewQuality: e.target.checked ? 'performance' : settings.previewQuality,
                    })
                  }
                  className="accent-[#A1A1AA] w-4 h-4 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#F4F4F5] font-medium">Auto-Downscale on FPS Drop</div>
                  <div className="text-[11px] text-[#A1A1AA]">
                    Temporarily lower internal preview resolution when scrubbing or playback drops below target FPS
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoDownscalePreview}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, autoDownscalePreview: e.target.checked })
                  }
                  className="accent-[#A1A1AA] w-4 h-4 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#F4F4F5] font-medium">GPU Hardware Acceleration</div>
                  <div className="text-[11px] text-[#A1A1AA]">
                    Use WebCodecs H.264 &amp; WebGL2 shaders when supported on Windows 10/11
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.hardwareAcceleration}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, hardwareAcceleration: e.target.checked })
                  }
                  className="accent-[#A1A1AA] w-4 h-4 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#F4F4F5] font-medium">Live Effect Hover Preview</div>
                  <div className="text-[11px] text-[#A1A1AA]">
                    Temporarily preview Effects, Color Grades, Text Styles &amp; Transitions on your clip while hovering
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.hoverPreviewEnabled !== false}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, hoverPreviewEnabled: e.target.checked })
                  }
                  className="accent-[#A1A1AA] w-4 h-4 cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-[#A1A1AA] block mb-1">
                    Preview Quality Tier
                  </label>
                  <select
                    value={settings.previewQuality}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        previewQuality: e.target.value as PreviewQuality,
                      })
                    }
                    className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  >
                    <option value="ultra">Ultra (Full Effects &amp; Blur)</option>
                    <option value="high">High (Balanced)</option>
                    <option value="medium">Medium (Reduced Samples)</option>
                    <option value="low">Low (Fast Laptop Mode)</option>
                    <option value="performance">Performance (Ultra-Light)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-[#A1A1AA] block mb-1">
                    Default Proxy Playback Resolution
                  </label>
                  <select
                    value={settings.proxyQuality}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        proxyQuality: e.target.value as StudioSettings['proxyQuality'],
                      })
                    }
                    className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  >
                    <option value="full">Full Resolution (1:1)</option>
                    <option value="half">1/2 Proxy (Fast Editing)</option>
                    <option value="quarter">1/4 Proxy (4K Smooth Scrub)</option>
                    <option value="eighth">1/8 Proxy (Ultra-Fast Low-End)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-[#A1A1AA] block mb-1">
                    Auto-Save Interval
                  </label>
                  <select
                    value={settings.autoSaveIntervalSec}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        autoSaveIntervalSec: Number(e.target.value),
                      })
                    }
                    className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  >
                    <option value={15}>Every 15 seconds</option>
                    <option value={30}>Every 30 seconds</option>
                    <option value={60}>Every 1 minute</option>
                    <option value={0}>Manual Save Only</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-[#A1A1AA] block mb-1">
                    Default Export Resolution
                  </label>
                  <select
                    value={settings.defaultResolution}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        defaultResolution: e.target.value as StudioSettings['defaultResolution'],
                      })
                    }
                    className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  >
                    <option value="720p">720p HD</option>
                    <option value="1080p">1080p Full HD</option>
                    <option value="2k">2K QHD</option>
                    <option value="4k">4K UHD</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-[#A1A1AA] block mb-1">
                    Default Sequence FPS
                  </label>
                  <select
                    value={settings.defaultFps}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        defaultFps: Number(e.target.value) as StudioSettings['defaultFps'],
                      })
                    }
                    className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                  >
                    <option value={24}>24 FPS</option>
                    <option value={25}>25 FPS</option>
                    <option value={30}>30 FPS</option>
                    <option value={50}>50 FPS</option>
                    <option value={60}>60 FPS</option>
                    <option value={120}>120 FPS</option>
                  </select>
                </div>

                <div className="flex flex-col justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      textBitmapCache.clear();
                      enhancedImageCache.clearAll();
                      smoothVideoCache.clearAll();
                      clearHoverPreviewCache();
                      releasePooledBuffers();
                      setCacheNotice('Render, hover-preview, enhancement & optical-flow caches cleared.');
                    }}
                    className="w-full px-2.5 py-2 bg-[#2C2C30] hover:bg-[#2E323E] text-[#F4F4F5] border border-[#3E3E44] rounded text-[11px] font-medium"
                  >
                    Clear Cache ({cacheStats.usedMB} / {cacheStats.budgetMB} MB)
                  </button>
                </div>
              </div>
              {cacheNotice && (
                <div className="text-[11px] text-emerald-400">{cacheNotice}</div>
              )}
            </div>
          )}

          {tab === 'audio' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[#F4F4F5] font-medium">Audio Output Device</div>
                  <div className="text-[11px] text-[#A1A1AA]">
                    Route timeline and video monitor sound to your PC speakers or headphones
                  </div>
                </div>
                <button
                  type="button"
                  onClick={refreshDevices}
                  className="px-2.5 py-1 bg-[#2C2C30] hover:bg-[#2E323E] text-[#F4F4F5] rounded border border-[#3E3E44] flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  Refresh
                </button>
              </div>

              <div>
                <label className="text-[11px] text-[#A1A1AA] block mb-1">
                  Output Speakers / Headphones
                </label>
                <select
                  value={settings.audioOutputDeviceId || 'default'}
                  onChange={(e) => void handleDeviceChange(e.target.value)}
                  className="w-full px-2.5 py-2 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
                >
                  {audioDevices.map((dev) => (
                    <option key={dev.deviceId} value={dev.deviceId}>
                      {dev.label}
                    </option>
                  ))}
                </select>
              </div>

              {deviceStatus && (
                <div className="p-2.5 bg-emerald-950/30 border border-emerald-500/35 rounded text-emerald-300 text-[11px]">
                  {deviceStatus}
                </div>
              )}

              <div className="p-3 bg-[#2C2C30] border border-[#3E3E44] rounded text-[11px] text-[#A1A1AA] leading-relaxed">
                Tip: If connected USB headphones or HDMI monitors appear unnamed, connect them before clicking Refresh or allow browser audio device listing. You can also switch output devices directly from the Audio Mixer panel.
              </div>
            </div>
          )}

          {tab === 'shortcuts' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px] text-[#A1A1AA] pb-1">
                <span>Click any shortcut button and press your desired key combination.</span>
                <button
                  type="button"
                  onClick={() =>
                    onUpdateSettings({ ...settings, shortcuts: DEFAULT_SHORTCUTS })
                  }
                  className="text-[#E4E4E7] hover:text-white flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  Reset Defaults
                </button>
              </div>
              <div className="divide-y divide-[#3E3E44] border border-[#3E3E44] rounded bg-[#18181A]">
                {SHORTCUT_LABELS.map(({ key, label }) => {
                  const isListening = listeningKey === key;
                  return (
                    <div
                      key={key}
                      className="px-3 py-2 flex items-center justify-between"
                    >
                      <span className="text-[#F4F4F5]">{label}</span>
                      <button
                        type="button"
                        onClick={() => setListeningKey(key)}
                        onKeyDown={(e) => isListening && handleKeyCapture(e, key)}
                        className={`px-2.5 py-1 rounded font-mono-tabular text-[11px] border transition-colors ${
                          isListening
                            ? 'border-[#A1A1AA] bg-[#71717A]/25 text-[#F4F4F5]'
                            : 'border-[#3E3E44] bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5] hover:border-[#A1A1AA]/50'
                        }`}
                      >
                        {isListening ? 'Press keys...' : settings.shortcuts[key]}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="px-4 py-3 bg-[#2C2C30] border-t border-[#3E3E44] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-[#52525B] hover:bg-[#6B7280] text-white font-medium rounded"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
