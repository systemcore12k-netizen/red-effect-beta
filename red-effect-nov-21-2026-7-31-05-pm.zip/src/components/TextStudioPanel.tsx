import React, { useEffect } from 'react';
import { Type, Plus, Sparkles, AlignLeft, AlignCenter, AlignRight, Diamond, RotateCcw, Save } from 'lucide-react';
import {
  ReadyMadeEffectPreset,
  TextAnimationEffect,
  TextGranularity,
  TextPathMode,
  TransitionDirection,
} from '../types/effects';
import { KeyframeProperty, TextProperties, TimelineClip } from '../types/studio';
import { textStyleToHoverPreset } from '../services/hoverPreviewCache';

interface TextStudioPanelProps {
  selectedClip: TimelineClip | null;
  playheadTime?: number;
  hoverPreviewEnabled?: boolean;
  onAddTextClip: (isSubtitle?: boolean, presetOverrides?: Partial<TextProperties>) => void;
  onUpdateClip: (clipId: string, updater: (c: TimelineClip) => TimelineClip) => void;
  onSaveReadyMadePreset?: (preset: ReadyMadeEffectPreset) => void;
  onHoverTextPreset?: (preset: ReadyMadeEffectPreset | null) => void;
  onClearHoverImmediate?: () => void;
}

const TEXT_EFFECT_OPTIONS: Array<{ value: TextAnimationEffect; label: string }> = [
  { value: 'none', label: 'None (Static)' },
  { value: 'typewriter', label: 'Typewriter' },
  { value: 'fade-in', label: 'Fade In' },
  { value: 'fade-out', label: 'Fade Out' },
  { value: 'fade-up', label: 'Fade Up' },
  { value: 'letter-reveal', label: 'Letter Reveal' },
  { value: 'word-reveal', label: 'Word Reveal' },
  { value: 'character-reveal', label: 'Character Reveal' },
  { value: 'tracking-animation', label: 'Tracking Animation' },
  { value: 'text-shake', label: 'Text Shake' },
  { value: 'text-bounce', label: 'Bounce Text' },
  { value: 'pop-up', label: 'Pop-up Text' },
  { value: 'text-wave', label: 'Text Wave' },
  { value: 'text-rotation', label: 'Text Rotation' },
  { value: 'text-zoom', label: 'Zoom Text' },
  { value: 'text-flip', label: 'Text Flip' },
  { value: 'text-glitch', label: 'Text Glitch' },
  { value: 'rgb-text', label: 'RGB Split Text' },
  { value: 'velocity-text', label: 'Velocity Text' },
  { value: 'distortion-text', label: 'Distortion Text' },
  { value: 'neon-text', label: 'Neon Text' },
  { value: 'fire-text', label: 'Fire Text' },
  { value: 'smoke-text', label: 'Smoke Text' },
  { value: 'liquid-text', label: 'Liquid Text' },
  { value: '3d-extrude', label: '3D Text' },
  { value: 'metallic-text', label: 'Metallic Text' },
  { value: 'cinematic-title', label: 'Cinematic Text' },
  { value: 'kinetic-typography', label: 'Kinetic Typography' },
];

const FONT_FAMILIES = [
  'Outfit',
  'Plus Jakarta Sans',
  'JetBrains Mono',
  'Impact',
  'Georgia',
  'Arial Black',
  'Courier New',
];

export const TextStudioPanel: React.FC<TextStudioPanelProps> = ({
  selectedClip,
  playheadTime = 0,
  hoverPreviewEnabled = true,
  onAddTextClip,
  onUpdateClip,
  onSaveReadyMadePreset,
  onHoverTextPreset,
  onClearHoverImmediate,
}) => {
  const clearHover = () => {
    if (onClearHoverImmediate) {
      onClearHoverImmediate();
    } else {
      onHoverTextPreset?.(null);
    }
  };

  useEffect(() => {
    return () => {
      clearHover();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const tp = selectedClip?.type === 'text' ? selectedClip.textProps : null;
  const localTime = selectedClip
    ? Math.max(0, Math.min(selectedClip.duration, playheadTime - selectedClip.startTime))
    : 0;

  const hasKfAtPlayhead = (prop: KeyframeProperty) =>
    Boolean(
      selectedClip?.keyframes.some(
        (k) => k.property === prop && Math.abs(k.time - localTime) < 0.12
      )
    );

  const toggleKf = (prop: KeyframeProperty, val: number) => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, (c) => {
      const idx = c.keyframes.findIndex(
        (k) => k.property === prop && Math.abs(k.time - localTime) < 0.12
      );
      if (idx >= 0) {
        return { ...c, keyframes: c.keyframes.filter((_, i) => i !== idx) };
      }
      return {
        ...c,
        keyframes: [
          ...c.keyframes,
          {
            id: `kf-${Date.now()}-${prop}-${Math.random().toString(36).slice(2, 5)}`,
            time: Math.round(localTime * 100) / 100,
            property: prop,
            value: val,
            easing: 'easeInOut',
          },
        ],
      };
    });
  };

  const updateTp = (patch: Partial<TextProperties>) => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, (c) => ({
      ...c,
      textProps: { ...(c.textProps as TextProperties), ...patch },
    }));
  };

  return (
    <div
      data-tutorial-target="text-studio-panel"
      className="p-2.5 flex flex-col gap-3 h-full text-xs bg-[#222225] text-[#F4F4F5] overflow-y-auto"
    >
      {/* Quick Layer Creation */}
      <div className="grid grid-cols-2 gap-1.5">
        <button
          type="button"
          onClick={() => onAddTextClip(false)}
          className="py-1.5 px-2 bg-[#52525B] hover:bg-[#6B7280] text-white rounded font-medium flex items-center justify-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" />
          New Title Layer
        </button>
        <button
          type="button"
          onClick={() => onAddTextClip(true)}
          className="py-1.5 px-2 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] text-[#F4F4F5] rounded font-medium flex items-center justify-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" />
          New Subtitle
        </button>
      </div>

      {/* Quick Text FX Presets */}
      <div className="space-y-1.5">
        <div className="text-[10px] font-semibold text-[#A1A1AA] uppercase tracking-wider">
          Instant Text Styles
        </div>
        <div
          onMouseLeave={clearHover}
          className="grid grid-cols-3 gap-1"
        >
          {[
            { label: 'Neon', anim: 'neon-text' as const, strokeColor: '#A1A1AA', strokeWidth: 2 },
            { label: '3D Extrude', anim: '3d-extrude' as const, extrude3D: true, extrudeDepth: 10 },
            { label: 'RGB Glitch', anim: 'text-glitch' as const, color: '#FFFFFF' },
            { label: 'Fire Burn', anim: 'fire-text' as const, color: '#F97316' },
            { label: 'Metallic', anim: 'metallic-text' as const, color: '#E2E8F0' },
            { label: 'Kinetic', anim: 'kinetic-typography' as const, fontWeight: 900 },
          ].map((preset) => (
            <button
              key={preset.label}
              type="button"
              onMouseEnter={() => {
                if (hoverPreviewEnabled && onHoverTextPreset) {
                  onHoverTextPreset(
                    textStyleToHoverPreset(preset.label.toLowerCase(), preset.label, preset.anim, preset)
                  );
                }
              }}
              onMouseLeave={() => {
                if (hoverPreviewEnabled && onHoverTextPreset) {
                  onHoverTextPreset(null);
                }
              }}
              onClick={() => {
                clearHover();
                if (tp && selectedClip) {
                  updateTp({
                    animation: preset.anim,
                    strokeColor: preset.strokeColor ?? tp.strokeColor,
                    strokeWidth: preset.strokeWidth ?? tp.strokeWidth,
                    extrude3D: preset.extrude3D ?? tp.extrude3D,
                    extrudeDepth: preset.extrudeDepth ?? tp.extrudeDepth,
                    color: preset.color ?? tp.color,
                    fontWeight: preset.fontWeight ?? tp.fontWeight,
                  });
                } else {
                  onAddTextClip(false, {
                    animation: preset.anim,
                    strokeColor: preset.strokeColor || '#A1A1AA',
                    strokeWidth: preset.strokeWidth ?? 0,
                    extrude3D: preset.extrude3D ?? false,
                    extrudeDepth: preset.extrudeDepth ?? 8,
                  });
                }
              }}
              className="py-1 px-1.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] hover:border-[#A1A1AA] rounded text-[10px] text-[#F4F4F5] truncate"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {!tp || !selectedClip ? (
        <div className="p-3 bg-[#18181A] border border-[#3E3E44] rounded text-[11px] text-[#A1A1AA] space-y-1">
          <div className="flex items-center gap-1.5 text-[#F4F4F5] font-medium">
            <Type className="w-3.5 h-3.5 text-[#D4D4D8]" />
            Text &amp; Kinetic Typography Studio
          </div>
          <p>
            Select any text layer on the timeline or click <strong className="text-[#F4F4F5]">New Title Layer</strong> above to customize typography, gradients, extrusion, text paths, and 24 animations.
          </p>
        </div>
      ) : (
        <div className="space-y-3 border-t border-[#3E3E44] pt-2.5">
          <div className="space-y-1">
            <label className="text-[10px] text-[#A1A1AA]">Text Content</label>
            <textarea
              rows={2}
              value={tp.text}
              onChange={(e) => updateTp({ text: e.target.value })}
              className="w-full px-2 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5] focus:outline-none focus:border-[#A1A1AA]"
            />
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            <div>
              <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Font Family</label>
              <select
                value={tp.fontFamily}
                onChange={(e) => updateTp({ fontFamily: e.target.value })}
                className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5]"
              >
                {FONT_FAMILIES.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Weight</label>
              <select
                value={tp.fontWeight ?? 700}
                onChange={(e) => updateTp({ fontWeight: Number(e.target.value) })}
                className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5]"
              >
                <option value={400}>Regular (400)</option>
                <option value={500}>Medium (500)</option>
                <option value={700}>Bold (700)</option>
                <option value={800}>ExtraBold (800)</option>
                <option value={900}>Black (900)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <SliderField
              label="Size"
              value={tp.fontSize}
              min={16}
              max={180}
              step={2}
              unit="px"
              keyframeActive={hasKfAtPlayhead('fontSize')}
              onToggleKeyframe={() => toggleKf('fontSize', tp.fontSize)}
              onChange={(v) => updateTp({ fontSize: v })}
            />
            <SliderField
              label="Tracking"
              value={tp.letterSpacing ?? 0}
              min={-8}
              max={40}
              step={1}
              unit="px"
              keyframeActive={hasKfAtPlayhead('textTracking')}
              onToggleKeyframe={() => toggleKf('textTracking', tp.letterSpacing ?? 0)}
              onChange={(v) => updateTp({ letterSpacing: v })}
            />
            <SliderField
              label="Line Space"
              value={tp.lineHeight ?? 1.2}
              min={0.8}
              max={2.4}
              step={0.05}
              unit="×"
              onChange={(v) => updateTp({ lineHeight: v })}
            />
            <SliderField
              label="Reveal %"
              value={tp.revealProgress ?? 100}
              min={0}
              max={100}
              step={1}
              unit="%"
              onChange={(v) => updateTp({ revealProgress: v })}
            />
          </div>

          {/* Alignment & Subtitle */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex rounded border border-[#3E3E44] overflow-hidden">
              {(['left', 'center', 'right'] as const).map((al) => (
                <button
                  key={al}
                  type="button"
                  onClick={() => updateTp({ align: al })}
                  className={`px-2 py-1 ${
                    tp.align === al
                      ? 'bg-[#52525B] text-white'
                      : 'bg-[#2C2C30] text-[#A1A1AA] hover:text-[#F4F4F5]'
                  }`}
                >
                  {al === 'left' ? (
                    <AlignLeft className="w-3.5 h-3.5" />
                  ) : al === 'center' ? (
                    <AlignCenter className="w-3.5 h-3.5" />
                  ) : (
                    <AlignRight className="w-3.5 h-3.5" />
                  )}
                </button>
              ))}
            </div>
            <label className="flex items-center gap-1.5 text-[11px] text-[#A1A1AA] cursor-pointer">
              <input
                type="checkbox"
                checked={tp.isSubtitle}
                onChange={(e) => updateTp({ isSubtitle: e.target.checked })}
                className="accent-[#A1A1AA]"
              />
              Subtitle Box
            </label>
          </div>

          {/* Text Animation Effect (All 24+) */}
          <div className="space-y-1.5 border-t border-[#3E3E44] pt-2">
            <div className="flex items-center gap-1 text-[10px] font-semibold text-[#A1A1AA] uppercase">
              <Sparkles className="w-3 h-3 text-[#D4D4D8]" />
              Text Animation Effect
            </div>
            <select
              value={tp.animation}
              onChange={(e) => updateTp({ animation: e.target.value as TextAnimationEffect })}
              className="w-full px-2 py-1.5 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5]"
            >
              {TEXT_EFFECT_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>

            <div className="grid grid-cols-2 gap-1.5">
              <div>
                <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Granularity</label>
                <select
                  value={tp.granularity ?? 'all'}
                  onChange={(e) => updateTp({ granularity: e.target.value as TextGranularity })}
                  className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5]"
                >
                  <option value="all">Whole Block</option>
                  <option value="character">Per Character</option>
                  <option value="word">Per Word</option>
                  <option value="line">Per Line</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-[#A1A1AA] block mb-0.5">Text Path</label>
                <select
                  value={tp.pathMode ?? 'none'}
                  onChange={(e) => updateTp({ pathMode: e.target.value as TextPathMode })}
                  className="w-full px-1.5 py-1 bg-[#18181A] border border-[#3E3E44] rounded text-[#F4F4F5]"
                >
                  <option value="none">Straight</option>
                  <option value="arc">Arc Curve</option>
                  <option value="wave">Wave Path</option>
                  <option value="circle">Circular</option>
                </select>
              </div>
            </div>
            {tp.pathMode && tp.pathMode !== 'none' && (
              <SliderField
                label="Path Curvature"
                value={tp.pathCurvature ?? 35}
                min={-100}
                max={100}
                step={2}
                onChange={(v) => updateTp({ pathCurvature: v })}
              />
            )}

            {/* Text FX Parameters */}
            <div className="p-2 bg-[#18181A] border border-[#3E3E44] rounded space-y-1.5 mt-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-semibold text-[#F4F4F5] uppercase">
                  Text FX Controls
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() =>
                      updateTp({
                        effectSpeed: 1,
                        effectIntensity: 100,
                        effectDuration: 1.0,
                        effectDirection: 'center',
                        animationStrength: 100,
                      })
                    }
                    title="Reset Text Effect Parameters"
                    className="px-1.5 py-0.5 bg-[#2C2C30] hover:bg-[#343439] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5] flex items-center gap-0.5"
                  >
                    <RotateCcw className="w-2.5 h-2.5" />
                    Reset
                  </button>
                  {onSaveReadyMadePreset && (
                    <button
                      type="button"
                      onClick={() =>
                        onSaveReadyMadePreset({
                          id: `custom-text-${Date.now()}`,
                          name: `${selectedClip.name} Text FX`,
                          category: 'text',
                          description: `Custom ${tp.animation} text preset`,
                          accentColor: '#F59E0B',
                          defaultDuration: selectedClip.duration,
                          textPreset: {
                            animation: tp.animation,
                            effectSpeed: tp.effectSpeed ?? 1,
                            effectIntensity: tp.effectIntensity ?? 100,
                            effectDuration: tp.effectDuration ?? 1.0,
                            effectDirection: tp.effectDirection ?? 'center',
                            animationStrength: tp.animationStrength ?? 100,
                            fontWeight: tp.fontWeight,
                            color: tp.color,
                            strokeColor: tp.strokeColor,
                            strokeWidth: tp.strokeWidth,
                            shadowBlur: tp.shadowBlur,
                            shadowColor: tp.shadowColor,
                            extrude3D: tp.extrude3D,
                            extrudeDepth: tp.extrudeDepth,
                            letterSpacing: tp.letterSpacing,
                            gradientEnabled: tp.gradientEnabled,
                            gradientStart: tp.gradientStart,
                            gradientEnd: tp.gradientEnd,
                          },
                        })
                      }
                      title="Save Text Effect as Custom Preset"
                      className="px-1.5 py-0.5 bg-[#52525B] hover:bg-[#6B7280] rounded text-[10px] text-white flex items-center gap-0.5"
                    >
                      <Save className="w-2.5 h-2.5" />
                      Save Preset
                    </button>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <SliderField
                  label="Speed"
                  value={tp.effectSpeed ?? 1}
                  min={0.2}
                  max={3}
                  step={0.05}
                  unit="×"
                  onChange={(v) => updateTp({ effectSpeed: v })}
                />
                <SliderField
                  label="Intensity"
                  value={tp.effectIntensity ?? 100}
                  min={0}
                  max={200}
                  step={5}
                  unit="%"
                  onChange={(v) => updateTp({ effectIntensity: v })}
                />
                <SliderField
                  label="Duration"
                  value={tp.effectDuration ?? 1.0}
                  min={0.2}
                  max={5}
                  step={0.1}
                  unit="s"
                  onChange={(v) => updateTp({ effectDuration: v })}
                />
                <SliderField
                  label="Anim Strength"
                  value={tp.animationStrength ?? 100}
                  min={0}
                  max={200}
                  step={5}
                  unit="%"
                  onChange={(v) => updateTp({ animationStrength: v })}
                />
              </div>
              <div className="flex items-center justify-between gap-2 pt-0.5">
                <span className="text-[10px] text-[#A1A1AA]">Direction</span>
                <select
                  value={tp.effectDirection ?? 'center'}
                  onChange={(e) =>
                    updateTp({ effectDirection: e.target.value as TransitionDirection })
                  }
                  className="px-2 py-0.5 bg-[#222225] border border-[#3E3E44] rounded text-[10px] text-[#F4F4F5]"
                >
                  <option value="center">Center</option>
                  <option value="left">Left</option>
                  <option value="right">Right</option>
                  <option value="up">Up</option>
                  <option value="down">Down</option>
                </select>
              </div>
            </div>
          </div>

          {/* Colors, Gradient, Stroke, Outline, 3D Extrude */}
          <div className="space-y-2 border-t border-[#3E3E44] pt-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-[#A1A1AA]">Fill / Stroke / Shadow Colors</span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  title="Fill Color"
                  value={tp.color}
                  onChange={(e) => updateTp({ color: e.target.value })}
                  className="w-6 h-6 bg-transparent border border-[#3E3E44] rounded cursor-pointer"
                />
                <input
                  type="color"
                  title="Stroke Color"
                  value={tp.strokeColor}
                  onChange={(e) => updateTp({ strokeColor: e.target.value })}
                  className="w-6 h-6 bg-transparent border border-[#3E3E44] rounded cursor-pointer"
                />
                <input
                  type="color"
                  title="Shadow Color"
                  value={tp.shadowColor || '#000000'}
                  onChange={(e) => updateTp({ shadowColor: e.target.value })}
                  className="w-6 h-6 bg-transparent border border-[#3E3E44] rounded cursor-pointer"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <SliderField
                label="Stroke"
                value={tp.strokeWidth}
                min={0}
                max={12}
                step={0.5}
                unit="px"
                onChange={(v) => updateTp({ strokeWidth: v })}
              />
              <SliderField
                label="Shadow Blur"
                value={tp.shadowBlur ?? 0}
                min={0}
                max={40}
                step={1}
                unit="px"
                onChange={(v) => updateTp({ shadowBlur: v })}
              />
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-1.5 text-[11px] text-[#A1A1AA] cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(tp.gradientEnabled)}
                  onChange={(e) => updateTp({ gradientEnabled: e.target.checked })}
                  className="accent-[#A1A1AA]"
                />
                Gradient Fill
              </label>
              {tp.gradientEnabled && (
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={tp.gradientStart || '#FFFFFF'}
                    onChange={(e) => updateTp({ gradientStart: e.target.value })}
                    className="w-5 h-5 bg-transparent border border-[#3E3E44] rounded"
                  />
                  <input
                    type="color"
                    value={tp.gradientEnd || '#A1A1AA'}
                    onChange={(e) => updateTp({ gradientEnd: e.target.value })}
                    className="w-5 h-5 bg-transparent border border-[#3E3E44] rounded"
                  />
                  <label className="flex items-center gap-1 text-[10px] text-[#A1A1AA]">
                    <input
                      type="checkbox"
                      checked={Boolean(tp.animatedGradient)}
                      onChange={(e) => updateTp({ animatedGradient: e.target.checked })}
                      className="accent-[#A1A1AA]"
                    />
                    Anim
                  </label>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-1.5 text-[11px] text-[#A1A1AA] cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(tp.extrude3D || tp.animation === '3d-extrude')}
                  onChange={(e) => updateTp({ extrude3D: e.target.checked })}
                  className="accent-[#A1A1AA]"
                />
                3D Extrusion Depth
              </label>
              {(tp.extrude3D || tp.animation === '3d-extrude') && (
                <input
                  type="number"
                  min={2}
                  max={24}
                  value={tp.extrudeDepth ?? 8}
                  onChange={(e) => updateTp({ extrudeDepth: Number(e.target.value) })}
                  className="w-14 px-1.5 py-0.5 bg-[#18181A] border border-[#3E3E44] rounded text-right text-[#F4F4F5]"
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const SliderField: React.FC<{
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit?: string;
  keyframeActive?: boolean;
  onToggleKeyframe?: () => void;
  onChange: (v: number) => void;
}> = ({ label, value, min, max, step, unit = '', keyframeActive, onToggleKeyframe, onChange }) => (
  <div className="space-y-0.5">
    <div className="flex justify-between items-center text-[10px] gap-1">
      <div className="flex items-center gap-1 text-[#A1A1AA] min-w-0">
        {onToggleKeyframe && (
          <button
            type="button"
            onClick={onToggleKeyframe}
            title="Toggle Keyframe at Playhead"
            className={`p-0.5 rounded ${
              keyframeActive ? 'text-[#D4D4D8]' : 'text-[#6E7280] hover:text-white'
            }`}
          >
            <Diamond className="w-2.5 h-2.5 fill-current" />
          </button>
        )}
        <span className="truncate">{label}</span>
      </div>
      <span className="font-mono-tabular text-[#F4F4F5] shrink-0">
        {Number.isInteger(step) ? Math.round(value) : value.toFixed(2)}
        {unit}
      </span>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="w-full h-1 cursor-pointer"
    />
  </div>
);
