import React from 'react';
import { X, Film, Volume2, Sparkles, GraduationCap } from 'lucide-react';

interface HelpModalProps {
  onClose: () => void;
  onOpenShortcuts: () => void;
  onOpenInteractiveTutorial: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({
  onClose,
  onOpenShortcuts,
  onOpenInteractiveTutorial,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4 text-xs">
      <div className="w-full max-w-lg bg-[#222225] border border-[#3E3E44] rounded-md shadow-2xl overflow-hidden">
        <div className="px-4 py-3 bg-[#2C2C30] border-b border-[#3E3E44] flex items-center justify-between">
          <div className="font-display text-sm font-semibold text-[#F4F4F5]">
            RED EFFECT Studio Guide
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-[#A1A1AA] hover:text-[#F4F4F5] rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-4 text-[#F4F4F5] leading-relaxed">
          <div className="flex items-start gap-3">
            <Film className="w-4 h-4 text-[#D4D4D8] mt-0.5 shrink-0" />
            <div>
              <div className="font-semibold text-[#F4F4F5]">Supported Media &amp; Export</div>
              <p className="text-[#A1A1AA] text-[11px] mt-0.5">
                Import MP4, MOV, AVI, MKV, WebM, MP3, WAV, AAC, PNG, JPG, OBJ, and GLB directly from your Windows PC. Export MP4 / MOV up to 4K 120 FPS with synchronized stereo audio via Windows Save File Dialog.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Volume2 className="w-4 h-4 text-[#D4D4D8] mt-0.5 shrink-0" />
            <div>
              <div className="font-semibold text-[#F4F4F5]">Video Audio &amp; Output Hardware</div>
              <p className="text-[#A1A1AA] text-[11px] mt-0.5">
                Embedded audio from imported videos plays automatically with real-time waveform visualization on the timeline. Switch PC speakers or headphones anytime in Audio Mixer or Preferences → Audio Hardware.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Sparkles className="w-4 h-4 text-[#D4D4D8] mt-0.5 shrink-0" />
            <div>
              <div className="font-semibold text-[#F4F4F5]">Keyframes, Graph Editor &amp; 3D/4D Studio</div>
              <p className="text-[#A1A1AA] text-[11px] mt-0.5">
                Animate Transform, Effects, Text, and Null Object hierarchies using diamond keyframe toggles and 13 smooth Bezier/Physics animation curves. Build or transfer 3D models into 4D Studio for skeletal motion and particle simulation.
              </p>
            </div>
          </div>
        </div>

        <div className="px-4 py-3 bg-[#2C2C30] border-t border-[#3E3E44] flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenInteractiveTutorial();
              }}
              className="px-3 py-1.5 bg-[#71717A]/20 hover:bg-[#71717A]/35 text-[#E4E4E7] rounded border border-[#A1A1AA]/40 flex items-center gap-1.5"
            >
              <GraduationCap className="w-3.5 h-3.5" />
              RED EFFECT Tutorial
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenShortcuts();
              }}
              className="px-3 py-1.5 bg-[#18181A] hover:bg-[#2E323E] text-[#F4F4F5] rounded border border-[#3E3E44]"
            >
              Shortcuts
            </button>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-[#52525B] hover:bg-[#6B7280] text-white font-medium rounded"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
