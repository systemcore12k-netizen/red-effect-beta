import React, { useState } from 'react';
import { Film } from 'lucide-react';
import { StudioProject } from '../types/studio';

interface ProjectThumbnailProps {
  project: StudioProject;
  durationLabel: string;
  className?: string;
}

const FALLBACK_COVERS = [
  '/src/assets/images/template_red_rebellion_1795119263004.jpg',
  '/src/assets/images/template_cinema_grade_1795119263573.jpg',
  '/src/assets/images/template_vertical_motion_1795119262941.jpg',
];

export const ProjectThumbnail: React.FC<ProjectThumbnailProps> = ({
  project,
  durationLabel,
  className = '',
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  const imageAsset = project.assets.find(
    (a) => a.type === 'image' && a.url && !a.url.startsWith('blob:')
  ) || project.assets.find((a) => a.type === 'image' && a.url);

  const videoAsset = project.assets.find((a) => a.type === 'video' && a.url);

  const firstTextClip = project.clips.find(
    (c) => c.type === 'text' && c.textProps?.text?.trim()
  );

  const isTrailer =
    project.id.includes('red-rebellion') ||
    project.name.toUpperCase().includes('RED REBELLION');
  const isTutorial =
    project.id.includes('tutorial') ||
    project.name.toUpperCase().includes('TUTORIAL');

  const coverIdx =
    Math.abs(
      project.id.split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 0)
    ) % FALLBACK_COVERS.length;

  const fallbackCoverUrl = isTrailer
    ? FALLBACK_COVERS[0]
    : isTutorial
    ? FALLBACK_COVERS[2]
    : null;

  const aspectBoxRatio = Math.max(
    0.45,
    Math.min(2.4, (project.width || 1920) / Math.max(1, project.height || 1080))
  );

  return (
    <div
      style={{ backgroundColor: '#1E1E21' }}
      className={`re-stage-keep-dark relative w-full aspect-video bg-[#1E1E21] overflow-hidden select-none ${className}`}
    >
      {imageAsset?.url && !imgFailed ? (
        <img
          src={imageAsset.url}
          alt={`${project.name} thumbnail`}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
      ) : videoAsset?.url ? (
        <video
          src={videoAsset.url}
          muted
          playsInline
          preload="metadata"
          className="w-full h-full object-cover"
        />
      ) : fallbackCoverUrl && !imgFailed ? (
        <img
          src={fallbackCoverUrl}
          alt={`${project.name} preview`}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
      ) : (
        <div
          className="w-full h-full flex flex-col items-center justify-center p-4 relative"
          style={{
            background: `radial-gradient(circle at 75% 20%, rgba(161,161,170,0.16), transparent 55%), ${
              project.backgroundColor && project.backgroundColor !== '#050507'
                ? project.backgroundColor
                : '#1E1E21'
            }`,
          }}
        >
          {/* Proportional canvas aspect frame */}
          <div
            className="border border-[#3E3E44] bg-[#222225]/80 rounded-lg flex flex-col items-center justify-center px-3 py-2 max-w-[82%] max-h-[72%] overflow-hidden"
            style={{
              aspectRatio: `${aspectBoxRatio}`,
              minWidth: aspectBoxRatio < 1 ? '44px' : '96px',
              minHeight: '44px',
            }}
          >
            {firstTextClip?.textProps?.text ? (
              <span className="font-display text-xs font-bold tracking-wide text-white text-center line-clamp-2">
                {firstTextClip.textProps.text}
              </span>
            ) : (
              <Film className="w-4 h-4 text-[#D4D4D8]" />
            )}
          </div>

          {/* Mini timeline clip track bars at bottom */}
          {project.clips.length > 0 && (
            <div className="mt-2.5 w-3/4 flex items-center gap-1 opacity-75">
              {project.clips.slice(0, 5).map((clip) => (
                <div
                  key={clip.id}
                  className="h-1 flex-1 rounded-full"
                  style={{
                    backgroundColor:
                      clip.type === 'fx' || clip.type === 'null'
                        ? '#71717A'
                        : clip.type === 'audio'
                        ? '#525252'
                        : '#8A8A8A',
                  }}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Contrast Scrim */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent" />

      {/* Duration & Aspect Info */}
      <div className="pointer-events-none absolute bottom-2 right-2.5 px-1.5 py-0.5 rounded bg-black/75 text-[11px] font-mono-tabular font-medium text-white">
        {durationLabel}
      </div>
      <div className="pointer-events-none absolute bottom-2 left-2.5 text-[11px] font-mono-tabular text-[#D4D4D4]">
        {project.aspectRatio || `${project.width}:${project.height}`}
      </div>
    </div>
  );
};
